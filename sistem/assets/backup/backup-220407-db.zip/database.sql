#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`id`, `nama`, `email`, `username`, `password`) VALUES (1, 'Administrator', 'admin@admin.com', 'admin', '$2y$10$8SoPqIecyMythHypIhN90OUrIFpvazbImXIgBcKZQenn9SVcD47fS');


#
# TABLE STRUCTURE FOR: das_kategori
#

DROP TABLE IF EXISTS `das_kategori`;

CREATE TABLE `das_kategori` (
  `id_das_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_dana` varchar(50) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `dana` double DEFAULT NULL,
  `sisa_dana` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  PRIMARY KEY (`id_das_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `das_kategori` (`id_das_kategori`, `jenis_dana`, `tahun_ajaran`, `dana`, `sisa_dana`, `tanggal`) VALUES (1, 'baksos', '2011', '200000', '200000', '2022-04-05');


#
# TABLE STRUCTURE FOR: das_sumber_dana
#

DROP TABLE IF EXISTS `das_sumber_dana`;

CREATE TABLE `das_sumber_dana` (
  `id_das_sumber_dana` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_dana_masuk` varchar(100) DEFAULT NULL,
  `jumlah_dana` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`id_das_sumber_dana`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: das_user
#

DROP TABLE IF EXISTS `das_user`;

CREATE TABLE `das_user` (
  `id_das_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_das` int(11) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `total_terima` double DEFAULT NULL,
  `sisa_saldo` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `no_das` varchar(25) NOT NULL,
  `status_das_user` char(1) NOT NULL DEFAULT '0',
  `open` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_das_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: das_user_bendahara
#

DROP TABLE IF EXISTS `das_user_bendahara`;

CREATE TABLE `das_user_bendahara` (
  `id_das_user_bendahara` int(11) NOT NULL AUTO_INCREMENT,
  `id_das_bendahara` int(11) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `total_terima` double DEFAULT NULL,
  `sisa_saldo` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `no_das` varchar(25) DEFAULT NULL,
  `status_das_user` char(1) DEFAULT '0',
  PRIMARY KEY (`id_das_user_bendahara`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: das_user_bendahara_output
#

DROP TABLE IF EXISTS `das_user_bendahara_output`;

CREATE TABLE `das_user_bendahara_output` (
  `id_das_user_bendahara_output` int(11) NOT NULL AUTO_INCREMENT,
  `id_das_user_bendahara` int(11) DEFAULT NULL,
  `jenis_das` varchar(15) DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `ada_nota` char(1) DEFAULT '0',
  `ada_bku` char(1) DEFAULT '0',
  PRIMARY KEY (`id_das_user_bendahara_output`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: das_user_output
#

DROP TABLE IF EXISTS `das_user_output`;

CREATE TABLE `das_user_output` (
  `id_das_user_output` int(11) NOT NULL AUTO_INCREMENT,
  `id_das_user` int(11) DEFAULT NULL,
  `jenis_das` varchar(50) NOT NULL,
  `jumlah` double DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `ada_nota` char(1) NOT NULL DEFAULT '0',
  `ada_bku` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_das_user_output`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_inventarisasi
#

DROP TABLE IF EXISTS `det_inventarisasi`;

CREATE TABLE `det_inventarisasi` (
  `id_det_inventarisasi` varchar(50) NOT NULL,
  `id_inventarisasi` varchar(50) DEFAULT NULL,
  `id_pengajuan` varchar(50) DEFAULT NULL,
  `id_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_det_inventarisasi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_pengadaan
#

DROP TABLE IF EXISTS `det_pengadaan`;

CREATE TABLE `det_pengadaan` (
  `id_det_pengadaan` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengadaan` varchar(50) DEFAULT NULL,
  `nama_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `harga_pengadaan` double DEFAULT NULL,
  `harga_realisasi` double DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  PRIMARY KEY (`id_det_pengadaan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_pengelolaan
#

DROP TABLE IF EXISTS `det_pengelolaan`;

CREATE TABLE `det_pengelolaan` (
  `id_det_pengelolaan` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengelolaan` varchar(50) DEFAULT NULL,
  `id_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_det_pengelolaan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_penghapusan
#

DROP TABLE IF EXISTS `det_penghapusan`;

CREATE TABLE `det_penghapusan` (
  `id_det_penghapusan` int(50) NOT NULL AUTO_INCREMENT,
  `id_penghapusan` varchar(50) DEFAULT NULL,
  `id_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `jenis_hapus` varchar(50) DEFAULT NULL,
  `nilai_asset` double DEFAULT NULL,
  PRIMARY KEY (`id_det_penghapusan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_perencanaan
#

DROP TABLE IF EXISTS `det_perencanaan`;

CREATE TABLE `det_perencanaan` (
  `id_det_perencanaan` int(11) NOT NULL AUTO_INCREMENT,
  `id_perencanaan` varchar(50) DEFAULT NULL,
  `id_kategori_asset` varchar(50) DEFAULT NULL,
  `id_jenis_asset` varchar(50) DEFAULT NULL,
  `nama_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  PRIMARY KEY (`id_det_perencanaan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: pembayaran_bebas_dt
#

DROP TABLE IF EXISTS `pembayaran_bebas_dt`;

CREATE TABLE `pembayaran_bebas_dt` (
  `id_pembayaran_bebas_dt` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembayaran_bebas` int(11) DEFAULT NULL,
  `bayar` float DEFAULT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id_pembayaran_bebas_dt`),
  KEY `id_pembayaran_bebas` (`id_pembayaran_bebas`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sr_account
#

DROP TABLE IF EXISTS `sr_account`;

CREATE TABLE `sr_account` (
  `id_akun` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `kode_akun` varchar(20) DEFAULT NULL,
  `jenis_akun` int(20) DEFAULT NULL,
  `kategori` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `modul_keuangan` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_akun`)
) ENGINE=InnoDB AUTO_INCREMENT=622662 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (1, '5', '1-1000', 1, 'utama', 'AKTIVA', NULL);
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622655, '5', '1-1100', 2, 'keuangan', 'Kas Tunai SMA', 'aset');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622656, '5', '1-1900', 2, 'keuangan', 'Piutang', 'aset');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622657, '5', '2-2000', 1, 'utama', 'PASIVA', 'aset');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622658, '5', '4-4000', 1, 'utama', 'Pendapatan', 'pendapatan');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622659, '5', '4-4010', 2, 'keuangan', 'Pendapatan SPP', 'pendapatan');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622660, '5', '5-5000', 1, 'utama', 'Beban', 'biaya');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622661, '5', '5-5010', 2, 'keuangan', 'Biaya Listrik', 'biaya');


#
# TABLE STRUCTURE FOR: sr_akun_gaji
#

DROP TABLE IF EXISTS `sr_akun_gaji`;

CREATE TABLE `sr_akun_gaji` (
  `id_akun_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `akun_gaji` varchar(20) DEFAULT NULL,
  `id_user` varchar(20) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_akun_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_akun_gaji` (`id_akun_gaji`, `akun_gaji`, `id_user`, `unit`) VALUES (1, '622661', '40', '5');
INSERT INTO `sr_akun_gaji` (`id_akun_gaji`, `akun_gaji`, `id_user`, `unit`) VALUES (2, '622660', '38', '5');


#
# TABLE STRUCTURE FOR: sr_bukukerja
#

DROP TABLE IF EXISTS `sr_bukukerja`;

CREATE TABLE `sr_bukukerja` (
  `bukukerja_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` int(11) NOT NULL,
  `nomer` varchar(100) NOT NULL,
  `matapelajaran` varchar(10) NOT NULL,
  `files` varchar(255) NOT NULL,
  `created` varchar(100) NOT NULL,
  PRIMARY KEY (`bukukerja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_bukukerja` (`bukukerja_id`, `unit`, `nomer`, `matapelajaran`, `files`, `created`) VALUES (2, 5, 'Buku kerja nomer 1', 'Pendidikan', 'Buku_Kerja_Guru_1.docx', '2022-03-25 15:34:30');


#
# TABLE STRUCTURE FOR: sr_bulan
#

DROP TABLE IF EXISTS `sr_bulan`;

CREATE TABLE `sr_bulan` (
  `id_bulan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bulan` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id_bulan`),
  UNIQUE KEY `nama_bulan` (`nama_bulan`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (2, 'Agustus');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (10, 'April');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (6, 'Desember');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (8, 'Febuari');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (7, 'Januari');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (1, 'Juli');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (12, 'Juni');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (9, 'Maret');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (11, 'Mei');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (5, 'November');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (4, 'Oktober');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (3, 'September');


#
# TABLE STRUCTURE FOR: sr_butir_sikap
#

DROP TABLE IF EXISTS `sr_butir_sikap`;

CREATE TABLE `sr_butir_sikap` (
  `idbutir_sikap` int(11) NOT NULL AUTO_INCREMENT,
  `bs_kategori` varchar(10) NOT NULL,
  `bs_kode` varchar(255) NOT NULL,
  `bs_keterangan` text NOT NULL,
  `bs_unit` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idbutir_sikap`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_butir_sikap` (`idbutir_sikap`, `bs_kategori`, `bs_kode`, `bs_keterangan`, `bs_unit`) VALUES (1, '2', 'Jujur (1.1)', 'Tidak mau berbohong atau tidak mencontek', '5');


#
# TABLE STRUCTURE FOR: sr_ekstra
#

DROP TABLE IF EXISTS `sr_ekstra`;

CREATE TABLE `sr_ekstra` (
  `idekstra` int(11) NOT NULL AUTO_INCREMENT,
  `e_nama` varchar(255) NOT NULL,
  `unit` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idekstra`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_ekstra` (`idekstra`, `e_nama`, `unit`) VALUES (2, 'futsal', '5');


#
# TABLE STRUCTURE FOR: sr_gaji_karyawan
#

DROP TABLE IF EXISTS `sr_gaji_karyawan`;

CREATE TABLE `sr_gaji_karyawan` (
  `id_gaji_karyawan` int(11) NOT NULL AUTO_INCREMENT,
  `gaji_pokok` varchar(100) DEFAULT NULL,
  `gaji_potongan` varchar(100) DEFAULT NULL,
  `gaji_pendapatan_lain_lain` varchar(100) DEFAULT NULL,
  `akun` varchar(20) DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_gaji_karyawan`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_gaji_karyawan` (`id_gaji_karyawan`, `gaji_pokok`, `gaji_potongan`, `gaji_pendapatan_lain_lain`, `akun`, `unit`, `id_user`) VALUES (9, '400000', '2000', '100000', '622661', '5', 40);


#
# TABLE STRUCTURE FOR: sr_gaji_karyawan_perbulan
#

DROP TABLE IF EXISTS `sr_gaji_karyawan_perbulan`;

CREATE TABLE `sr_gaji_karyawan_perbulan` (
  `id_gaji_karyawan` int(11) NOT NULL AUTO_INCREMENT,
  `gaji_pokok` varchar(100) DEFAULT NULL,
  `gaji_potongan` varchar(100) DEFAULT NULL,
  `gaji_pendapatan_lain_lain` varchar(100) DEFAULT NULL,
  `akun` varchar(20) DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  PRIMARY KEY (`id_gaji_karyawan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_gaji_karyawan_perbulan` (`id_gaji_karyawan`, `gaji_pokok`, `gaji_potongan`, `gaji_pendapatan_lain_lain`, `akun`, `unit`, `id_user`, `tanggal`) VALUES (1, '400000', '2000', '100000', '622661', '5', 40, NULL);
INSERT INTO `sr_gaji_karyawan_perbulan` (`id_gaji_karyawan`, `gaji_pokok`, `gaji_potongan`, `gaji_pendapatan_lain_lain`, `akun`, `unit`, `id_user`, `tanggal`) VALUES (2, '400000', '2000', '100000', '622661', '5', 40, NULL);


#
# TABLE STRUCTURE FOR: sr_guestbook
#

DROP TABLE IF EXISTS `sr_guestbook`;

CREATE TABLE `sr_guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_visit` varchar(100) NOT NULL,
  `user_phone` varchar(100) NOT NULL,
  `user_created` varchar(100) NOT NULL,
  `user_ip` varchar(20) DEFAULT NULL,
  `user_os` varchar(100) DEFAULT NULL,
  `user_browser` varchar(100) DEFAULT NULL,
  `approve` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `sr_guestbook` (`id`, `unit`, `user_name`, `user_email`, `user_visit`, `user_phone`, `user_created`, `user_ip`, `user_os`, `user_browser`, `approve`) VALUES (7, '2', 'Reza Lesmana Putra', 'rzalvaero@gmail.com', '2022-05-20', '088906033372', '2022-03-17 15:00:01', '::1', 'Windows 10', '99.0.4844.51', 0);


#
# TABLE STRUCTURE FOR: sr_guru_tes
#

DROP TABLE IF EXISTS `sr_guru_tes`;

CREATE TABLE `sr_guru_tes` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_guru` int(6) NOT NULL,
  `jenis` enum('acak','paket') NOT NULL,
  `id_mapel` int(6) DEFAULT NULL,
  `id_paket` int(6) DEFAULT NULL,
  `nama_ujian` varchar(200) NOT NULL,
  `jumlah_soal` int(6) DEFAULT NULL,
  `waktu` int(6) NOT NULL,
  `detil_jenis` varchar(200) NOT NULL,
  `tgl_mulai` datetime NOT NULL,
  `terlambat` datetime NOT NULL,
  `token` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (5, 1, 'paket', NULL, 7, 'Ujian Paket ips', 10, 1110, '', '2022-04-02 06:07:00', '2022-04-05 06:07:00', '234');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (7, 1, 'paket', NULL, 9, 'ujian uas', 10, 10, '', '2022-04-04 15:41:00', '2022-04-05 17:41:00', '123');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (8, 1, 'paket', NULL, 8, 'paket baru', 10, 10, '', '2022-04-04 15:49:00', '2022-04-06 16:49:00', '123');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (9, 1, 'paket', NULL, 8, 'paket ujian sd ipa', 10, 15, '', '2022-04-04 16:18:00', '2022-04-06 19:18:00', '123');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (10, 1, 'paket', NULL, 8, 'Ujian Paketyyy', 10, 10, '', '2022-04-05 10:14:00', '2022-04-06 09:14:00', '123');


#
# TABLE STRUCTURE FOR: sr_ikut_ujian
#

DROP TABLE IF EXISTS `sr_ikut_ujian`;

CREATE TABLE `sr_ikut_ujian` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_tes` int(6) NOT NULL,
  `id_user` int(6) NOT NULL,
  `jml_benar` int(6) NOT NULL,
  `nilai` decimal(10,2) NOT NULL,
  `nilai_bobot` decimal(10,2) NOT NULL,
  `tgl_mulai` datetime NOT NULL,
  `tgl_selesai` datetime NOT NULL,
  `status` enum('Y','N') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `sr_ikut_ujian` (`id`, `id_tes`, `id_user`, `jml_benar`, `nilai`, `nilai_bobot`, `tgl_mulai`, `tgl_selesai`, `status`) VALUES (28, 7, 11, 2, '100.00', '0.00', '2022-04-04 16:22:46', '2022-04-04 16:32:46', 'N');
INSERT INTO `sr_ikut_ujian` (`id`, `id_tes`, `id_user`, `jml_benar`, `nilai`, `nilai_bobot`, `tgl_mulai`, `tgl_selesai`, `status`) VALUES (29, 9, 12, 0, '0.00', '0.00', '2022-04-05 11:27:11', '2022-04-05 11:42:11', 'N');
INSERT INTO `sr_ikut_ujian` (`id`, `id_tes`, `id_user`, `jml_benar`, `nilai`, `nilai_bobot`, `tgl_mulai`, `tgl_selesai`, `status`) VALUES (30, 7, 12, 0, '0.00', '0.00', '2022-04-05 14:36:39', '2022-04-05 14:46:39', 'N');
INSERT INTO `sr_ikut_ujian` (`id`, `id_tes`, `id_user`, `jml_benar`, `nilai`, `nilai_bobot`, `tgl_mulai`, `tgl_selesai`, `status`) VALUES (31, 7, 145, 0, '0.00', '0.00', '2022-04-05 17:00:31', '2022-04-05 17:10:31', 'Y');


#
# TABLE STRUCTURE FOR: sr_ikut_ujian_detil_jawaban
#

DROP TABLE IF EXISTS `sr_ikut_ujian_detil_jawaban`;

CREATE TABLE `sr_ikut_ujian_detil_jawaban` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `id_ikut_ujian` int(10) NOT NULL,
  `id_soal` int(10) NOT NULL,
  `jawaban_user` varchar(1) NOT NULL,
  `status_jawaban` int(1) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (39, 28, 28, 'C', 1, '2022-04-04 16:23:31');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (40, 28, 30, 'D', 1, '2022-04-04 16:23:35');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (41, 29, 30, 'B', 0, '2022-04-05 11:27:16');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (42, 30, 28, 'B', 0, '2022-04-05 14:36:43');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (43, 30, 30, 'B', 0, '2022-04-05 14:36:45');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (44, 31, 28, '', 0, '2022-04-05 17:00:31');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (45, 31, 30, '', 0, '2022-04-05 17:00:31');


#
# TABLE STRUCTURE FOR: sr_interval_predikat
#

DROP TABLE IF EXISTS `sr_interval_predikat`;

CREATE TABLE `sr_interval_predikat` (
  `idinterval_predikat` int(11) NOT NULL AUTO_INCREMENT,
  `idkkm` int(11) NOT NULL,
  `amin` int(11) NOT NULL,
  `amax` int(11) NOT NULL,
  `bmin` int(11) NOT NULL,
  `bmax` int(11) NOT NULL,
  `cmin` int(11) NOT NULL,
  `cmax` int(11) NOT NULL,
  `dmin` int(11) NOT NULL,
  `dmax` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  PRIMARY KEY (`idinterval_predikat`),
  KEY `idkkm` (`idkkm`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_interval_predikat` (`idinterval_predikat`, `idkkm`, `amin`, `amax`, `bmin`, `bmax`, `cmin`, `cmax`, `dmin`, `dmax`, `unit`) VALUES (6, 2, 90, 100, 89, 79, 69, 60, 59, 0, 5);


#
# TABLE STRUCTURE FOR: sr_jabatan
#

DROP TABLE IF EXISTS `sr_jabatan`;

CREATE TABLE `sr_jabatan` (
  `id_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jabatan` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (4, 'Operator');
INSERT INTO `sr_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (5, 'Guru Mata Pelajaran');
INSERT INTO `sr_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (6, 'Wali Kelas');


#
# TABLE STRUCTURE FOR: sr_jenis_bayar
#

DROP TABLE IF EXISTS `sr_jenis_bayar`;

CREATE TABLE `sr_jenis_bayar` (
  `id_jenis_bayar` int(11) NOT NULL AUTO_INCREMENT,
  `id_pos` varchar(20) DEFAULT NULL,
  `tingkat` varchar(20) DEFAULT NULL,
  `tipe` varchar(20) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_jenis_bayar`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_jenis_bayar` (`id_jenis_bayar`, `id_pos`, `tingkat`, `tipe`, `unit`) VALUES (2, '1', '2022', 'bulanan', '5');
INSERT INTO `sr_jenis_bayar` (`id_jenis_bayar`, `id_pos`, `tingkat`, `tipe`, `unit`) VALUES (3, '2', '2022', 'bebas', '5');


#
# TABLE STRUCTURE FOR: sr_jenis_pengaduan
#

DROP TABLE IF EXISTS `sr_jenis_pengaduan`;

CREATE TABLE `sr_jenis_pengaduan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_kamar
#

DROP TABLE IF EXISTS `sr_kamar`;

CREATE TABLE `sr_kamar` (
  `id_kamar` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `nama_kamar` varchar(100) NOT NULL,
  `kategori_kamar` varchar(10) NOT NULL,
  `kapasitas_kamar` varchar(10) NOT NULL,
  PRIMARY KEY (`id_kamar`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kamar` (`id_kamar`, `unit`, `nama_kamar`, `kategori_kamar`, `kapasitas_kamar`) VALUES (1, '5', 'MELATI - I', '1', '10');
INSERT INTO `sr_kamar` (`id_kamar`, `unit`, `nama_kamar`, `kategori_kamar`, `kapasitas_kamar`) VALUES (2, '5', 'ANGREK - I', '2', '5');


#
# TABLE STRUCTURE FOR: sr_kamar_kategori
#

DROP TABLE IF EXISTS `sr_kamar_kategori`;

CREATE TABLE `sr_kamar_kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kamar_kategori` (`id_kategori`, `nama_kategori`) VALUES (1, 'Regular');
INSERT INTO `sr_kamar_kategori` (`id_kategori`, `nama_kategori`) VALUES (2, 'VIP');
INSERT INTO `sr_kamar_kategori` (`id_kategori`, `nama_kategori`) VALUES (3, 'VVIP\r\n');


#
# TABLE STRUCTURE FOR: sr_kamar_penghuni
#

DROP TABLE IF EXISTS `sr_kamar_penghuni`;

CREATE TABLE `sr_kamar_penghuni` (
  `id_penghuni` int(11) NOT NULL AUTO_INCREMENT,
  `id_kamar` varchar(10) NOT NULL,
  `id_siswa` varchar(10) NOT NULL,
  `unit` varchar(11) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id_penghuni`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (1, '1', '11', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (2, '1', '12', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (3, '1', '13', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (4, '2', '14', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (5, '2', '15', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (6, '2', '16', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (7, '1', '19', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (8, '1', '21', '5', 0);


#
# TABLE STRUCTURE FOR: sr_kelas
#

DROP TABLE IF EXISTS `sr_kelas`;

CREATE TABLE `sr_kelas` (
  `idkelas` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `walikelas` varchar(50) NOT NULL,
  `k_tingkat` int(11) NOT NULL,
  `k_romawi` varchar(20) NOT NULL,
  `k_keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (1, '5', '42', 10, 'X - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (2, '5', '', 10, 'X - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (3, '5', '', 10, 'X - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (4, '5', '', 10, 'X - MM', 'Multimedia');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (5, '5', '', 11, 'XI - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (6, '5', '', 11, 'XI - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (11, '5', '', 11, 'XI - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (16, '5', '', 11, 'XI - MM', 'Multimedia');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (17, '5', '', 12, 'XII - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (19, '5', '', 12, 'XII - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (20, '5', '', 12, 'XII - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (21, '5', '', 12, 'XII - MM', 'Multimedia');


#
# TABLE STRUCTURE FOR: sr_kelas_guru
#

DROP TABLE IF EXISTS `sr_kelas_guru`;

CREATE TABLE `sr_kelas_guru` (
  `idkelas_guru` int(11) NOT NULL AUTO_INCREMENT,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  PRIMARY KEY (`idkelas_guru`),
  KEY `idusers` (`idusers`),
  KEY `idkelas` (`idkelas`),
  CONSTRAINT `sr_kelas_guru_ibfk_1` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`),
  CONSTRAINT `sr_kelas_guru_ibfk_2` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (17, 37, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (18, 38, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (22, 39, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (23, 39, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (24, 39, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (25, 39, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (26, 39, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (27, 39, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (28, 40, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (29, 41, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (30, 41, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (31, 41, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (32, 41, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (33, 41, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (34, 41, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (35, 40, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (36, 40, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (37, 40, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (38, 40, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (39, 40, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (40, 42, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (41, 43, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (42, 44, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (43, 45, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (50, 57, 17);


#
# TABLE STRUCTURE FOR: sr_kesehatan
#

DROP TABLE IF EXISTS `sr_kesehatan`;

CREATE TABLE `sr_kesehatan` (
  `idkesehatan` int(11) NOT NULL AUTO_INCREMENT,
  `ks_aspek` varchar(255) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idkesehatan`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kesehatan` (`idkesehatan`, `ks_aspek`, `unit`) VALUES (2, 'Penglihatan', '5');
INSERT INTO `sr_kesehatan` (`idkesehatan`, `ks_aspek`, `unit`) VALUES (3, 'pendengaran', '5');


#
# TABLE STRUCTURE FOR: sr_kkm
#

DROP TABLE IF EXISTS `sr_kkm`;

CREATE TABLE `sr_kkm` (
  `idkkm` int(11) NOT NULL AUTO_INCREMENT,
  `idkelas` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `k_kkm` int(11) NOT NULL,
  `unit` int(11) DEFAULT NULL,
  PRIMARY KEY (`idkkm`),
  KEY `idkelas` (`idkelas`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_kkm_ibfk_1` FOREIGN KEY (`idmata_pelajaran`) REFERENCES `sr_mata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_kkm_ibfk_2` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kkm` (`idkkm`, `idkelas`, `idmata_pelajaran`, `k_kkm`, `unit`) VALUES (2, 3, 50, 80, 5);
INSERT INTO `sr_kkm` (`idkkm`, `idkelas`, `idmata_pelajaran`, `k_kkm`, `unit`) VALUES (3, 4, 49, 80, 5);


#
# TABLE STRUCTURE FOR: sr_kode_kelompok
#

DROP TABLE IF EXISTS `sr_kode_kelompok`;

CREATE TABLE `sr_kode_kelompok` (
  `id_kode_kelompok` int(11) NOT NULL,
  `unit` varchar(11) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `kode` varchar(2) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_kompetensi_inti
#

DROP TABLE IF EXISTS `sr_kompetensi_inti`;

CREATE TABLE `sr_kompetensi_inti` (
  `idkompetensiinti` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kd` varchar(100) NOT NULL,
  `nama_kd` text NOT NULL,
  `kategori_kd` enum('Pengetahuan','Keterampilan') NOT NULL,
  PRIMARY KEY (`idkompetensiinti`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kompetensi_inti` (`idkompetensiinti`, `kode_kd`, `nama_kd`, `kategori_kd`) VALUES (1, 'K 1', 'Kompetensi inti sikap spiritual', 'Pengetahuan');
INSERT INTO `sr_kompetensi_inti` (`idkompetensiinti`, `kode_kd`, `nama_kd`, `kategori_kd`) VALUES (2, 'K 2', 'Kompetensi inti sikap sosial ', 'Pengetahuan');
INSERT INTO `sr_kompetensi_inti` (`idkompetensiinti`, `kode_kd`, `nama_kd`, `kategori_kd`) VALUES (3, 'K 3', 'Kompetensi inti pengetahuan', 'Pengetahuan');
INSERT INTO `sr_kompetensi_inti` (`idkompetensiinti`, `kode_kd`, `nama_kd`, `kategori_kd`) VALUES (4, 'K 4', 'Kompetensi inti keterampilan ', 'Keterampilan');


#
# TABLE STRUCTURE FOR: sr_kota
#

DROP TABLE IF EXISTS `sr_kota`;

CREATE TABLE `sr_kota` (
  `city_id` int(11) NOT NULL,
  `province_id` varchar(11) NOT NULL,
  `province` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `postal_code` int(11) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (1, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Barat', 23681);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (2, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Barat Daya', 23764);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (3, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Besar', 23951);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (4, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Jaya', 23654);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (5, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Selatan', 23719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (6, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Singkil', 24785);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (7, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tamiang', 24476);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (8, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tengah', 24511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (9, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tenggara', 24611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (10, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Timur', 24454);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (11, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Utara', 24382);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (12, '32', 'Sumatera Barat', 'Kabupaten', 'Agam', 26411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (13, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Alor', 85811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (14, '19', 'Maluku', 'Kota', 'Ambon', 97222);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (15, '34', 'Sumatera Utara', 'Kabupaten', 'Asahan', 21214);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (16, '24', 'Papua', 'Kabupaten', 'Asmat', 99777);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (17, '1', 'Bali', 'Kabupaten', 'Badung', 80351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (18, '13', 'Kalimantan Selatan', 'Kabupaten', 'Balangan', 71611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (19, '15', 'Kalimantan Timur', 'Kota', 'Balikpapan', 76111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (20, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Banda Aceh', 23238);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (21, '18', 'Lampung', 'Kota', 'Bandar Lampung', 35139);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (22, '9', 'Jawa Barat', 'Kabupaten', 'Bandung', 40311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (23, '9', 'Jawa Barat', 'Kota', 'Bandung', 40111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (24, '9', 'Jawa Barat', 'Kabupaten', 'Bandung Barat', 40721);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (25, '29', 'Sulawesi Tengah', 'Kabupaten', 'Banggai', 94711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (26, '29', 'Sulawesi Tengah', 'Kabupaten', 'Banggai Kepulauan', 94881);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (27, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka', 33212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (28, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Barat', 33315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (29, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Selatan', 33719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (30, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Tengah', 33613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (31, '11', 'Jawa Timur', 'Kabupaten', 'Bangkalan', 69118);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (32, '1', 'Bali', 'Kabupaten', 'Bangli', 80619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (33, '13', 'Kalimantan Selatan', 'Kabupaten', 'Banjar', 70619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (34, '9', 'Jawa Barat', 'Kota', 'Banjar', 46311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (35, '13', 'Kalimantan Selatan', 'Kota', 'Banjarbaru', 70712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (36, '13', 'Kalimantan Selatan', 'Kota', 'Banjarmasin', 70117);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (37, '10', 'Jawa Tengah', 'Kabupaten', 'Banjarnegara', 53419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (38, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bantaeng', 92411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (39, '5', 'DI Yogyakarta', 'Kabupaten', 'Bantul', 55715);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (40, '33', 'Sumatera Selatan', 'Kabupaten', 'Banyuasin', 30911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (41, '10', 'Jawa Tengah', 'Kabupaten', 'Banyumas', 53114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (42, '11', 'Jawa Timur', 'Kabupaten', 'Banyuwangi', 68416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (43, '13', 'Kalimantan Selatan', 'Kabupaten', 'Barito Kuala', 70511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (44, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Selatan', 73711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (45, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Timur', 73671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (46, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Utara', 73881);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (47, '28', 'Sulawesi Selatan', 'Kabupaten', 'Barru', 90719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (48, '17', 'Kepulauan Riau', 'Kota', 'Batam', 29413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (49, '10', 'Jawa Tengah', 'Kabupaten', 'Batang', 51211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (50, '8', 'Jambi', 'Kabupaten', 'Batang Hari', 36613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (51, '11', 'Jawa Timur', 'Kota', 'Batu', 65311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (52, '34', 'Sumatera Utara', 'Kabupaten', 'Batu Bara', 21655);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (53, '30', 'Sulawesi Tenggara', 'Kota', 'Bau-Bau', 93719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (54, '9', 'Jawa Barat', 'Kabupaten', 'Bekasi', 17837);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (55, '9', 'Jawa Barat', 'Kota', 'Bekasi', 17121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (56, '2', 'Bangka Belitung', 'Kabupaten', 'Belitung', 33419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (57, '2', 'Bangka Belitung', 'Kabupaten', 'Belitung Timur', 33519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (58, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Belu', 85711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (59, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Bener Meriah', 24581);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (60, '26', 'Riau', 'Kabupaten', 'Bengkalis', 28719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (61, '12', 'Kalimantan Barat', 'Kabupaten', 'Bengkayang', 79213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (62, '4', 'Bengkulu', 'Kota', 'Bengkulu', 38229);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (63, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Selatan', 38519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (64, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Tengah', 38319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (65, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Utara', 38619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (66, '15', 'Kalimantan Timur', 'Kabupaten', 'Berau', 77311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (67, '24', 'Papua', 'Kabupaten', 'Biak Numfor', 98119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (68, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Bima', 84171);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (69, '22', 'Nusa Tenggara Barat (NTB)', 'Kota', 'Bima', 84139);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (70, '34', 'Sumatera Utara', 'Kota', 'Binjai', 20712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (71, '17', 'Kepulauan Riau', 'Kabupaten', 'Bintan', 29135);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (72, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Bireuen', 24219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (73, '31', 'Sulawesi Utara', 'Kota', 'Bitung', 95512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (74, '11', 'Jawa Timur', 'Kabupaten', 'Blitar', 66171);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (75, '11', 'Jawa Timur', 'Kota', 'Blitar', 66124);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (76, '10', 'Jawa Tengah', 'Kabupaten', 'Blora', 58219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (77, '7', 'Gorontalo', 'Kabupaten', 'Boalemo', 96319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (78, '9', 'Jawa Barat', 'Kabupaten', 'Bogor', 16911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (79, '9', 'Jawa Barat', 'Kota', 'Bogor', 16119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (80, '11', 'Jawa Timur', 'Kabupaten', 'Bojonegoro', 62119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (81, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow (Bolmong)', 95755);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (82, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Selatan', 95774);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (83, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Timur', 95783);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (84, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Utara', 95765);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (85, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Bombana', 93771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (86, '11', 'Jawa Timur', 'Kabupaten', 'Bondowoso', 68219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (87, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bone', 92713);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (88, '7', 'Gorontalo', 'Kabupaten', 'Bone Bolango', 96511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (89, '15', 'Kalimantan Timur', 'Kota', 'Bontang', 75313);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (90, '24', 'Papua', 'Kabupaten', 'Boven Digoel', 99662);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (91, '10', 'Jawa Tengah', 'Kabupaten', 'Boyolali', 57312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (92, '10', 'Jawa Tengah', 'Kabupaten', 'Brebes', 52212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (93, '32', 'Sumatera Barat', 'Kota', 'Bukittinggi', 26115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (94, '1', 'Bali', 'Kabupaten', 'Buleleng', 81111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (95, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bulukumba', 92511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (96, '16', 'Kalimantan Utara', 'Kabupaten', 'Bulungan (Bulongan)', 77211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (97, '8', 'Jambi', 'Kabupaten', 'Bungo', 37216);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (98, '29', 'Sulawesi Tengah', 'Kabupaten', 'Buol', 94564);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (99, '19', 'Maluku', 'Kabupaten', 'Buru', 97371);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (100, '19', 'Maluku', 'Kabupaten', 'Buru Selatan', 97351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (101, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Buton', 93754);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (102, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Buton Utara', 93745);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (103, '9', 'Jawa Barat', 'Kabupaten', 'Ciamis', 46211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (104, '9', 'Jawa Barat', 'Kabupaten', 'Cianjur', 43217);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (105, '10', 'Jawa Tengah', 'Kabupaten', 'Cilacap', 53211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (106, '3', 'Banten', 'Kota', 'Cilegon', 42417);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (107, '9', 'Jawa Barat', 'Kota', 'Cimahi', 40512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (108, '9', 'Jawa Barat', 'Kabupaten', 'Cirebon', 45611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (109, '9', 'Jawa Barat', 'Kota', 'Cirebon', 45116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (110, '34', 'Sumatera Utara', 'Kabupaten', 'Dairi', 22211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (111, '24', 'Papua', 'Kabupaten', 'Deiyai (Deliyai)', 98784);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (112, '34', 'Sumatera Utara', 'Kabupaten', 'Deli Serdang', 20511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (113, '10', 'Jawa Tengah', 'Kabupaten', 'Demak', 59519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (114, '1', 'Bali', 'Kota', 'Denpasar', 80227);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (115, '9', 'Jawa Barat', 'Kota', 'Depok', 16416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (116, '32', 'Sumatera Barat', 'Kabupaten', 'Dharmasraya', 27612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (117, '24', 'Papua', 'Kabupaten', 'Dogiyai', 98866);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (118, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Dompu', 84217);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (119, '29', 'Sulawesi Tengah', 'Kabupaten', 'Donggala', 94341);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (120, '26', 'Riau', 'Kota', 'Dumai', 28811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (121, '33', 'Sumatera Selatan', 'Kabupaten', 'Empat Lawang', 31811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (122, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Ende', 86351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (123, '28', 'Sulawesi Selatan', 'Kabupaten', 'Enrekang', 91719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (124, '25', 'Papua Barat', 'Kabupaten', 'Fakfak', 98651);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (125, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Flores Timur', 86213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (126, '9', 'Jawa Barat', 'Kabupaten', 'Garut', 44126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (127, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Gayo Lues', 24653);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (128, '1', 'Bali', 'Kabupaten', 'Gianyar', 80519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (129, '7', 'Gorontalo', 'Kabupaten', 'Gorontalo', 96218);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (130, '7', 'Gorontalo', 'Kota', 'Gorontalo', 96115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (131, '7', 'Gorontalo', 'Kabupaten', 'Gorontalo Utara', 96611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (132, '28', 'Sulawesi Selatan', 'Kabupaten', 'Gowa', 92111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (133, '11', 'Jawa Timur', 'Kabupaten', 'Gresik', 61115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (134, '10', 'Jawa Tengah', 'Kabupaten', 'Grobogan', 58111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (135, '5', 'DI Yogyakarta', 'Kabupaten', 'Gunung Kidul', 55812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (136, '14', 'Kalimantan Tengah', 'Kabupaten', 'Gunung Mas', 74511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (137, '34', 'Sumatera Utara', 'Kota', 'Gunungsitoli', 22813);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (138, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Barat', 97757);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (139, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Selatan', 97911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (140, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Tengah', 97853);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (141, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Timur', 97862);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (142, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Utara', 97762);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (143, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Selatan', 71212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (144, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Tengah', 71313);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (145, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Utara', 71419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (146, '34', 'Sumatera Utara', 'Kabupaten', 'Humbang Hasundutan', 22457);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (147, '26', 'Riau', 'Kabupaten', 'Indragiri Hilir', 29212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (148, '26', 'Riau', 'Kabupaten', 'Indragiri Hulu', 29319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (149, '9', 'Jawa Barat', 'Kabupaten', 'Indramayu', 45214);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (150, '24', 'Papua', 'Kabupaten', 'Intan Jaya', 98771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (151, '6', 'DKI Jakarta', 'Kota', 'Jakarta Barat', 11220);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (152, '6', 'DKI Jakarta', 'Kota', 'Jakarta Pusat', 10540);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (153, '6', 'DKI Jakarta', 'Kota', 'Jakarta Selatan', 12230);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (154, '6', 'DKI Jakarta', 'Kota', 'Jakarta Timur', 13330);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (155, '6', 'DKI Jakarta', 'Kota', 'Jakarta Utara', 14140);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (156, '8', 'Jambi', 'Kota', 'Jambi', 36111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (157, '24', 'Papua', 'Kabupaten', 'Jayapura', 99352);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (158, '24', 'Papua', 'Kota', 'Jayapura', 99114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (159, '24', 'Papua', 'Kabupaten', 'Jayawijaya', 99511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (160, '11', 'Jawa Timur', 'Kabupaten', 'Jember', 68113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (161, '1', 'Bali', 'Kabupaten', 'Jembrana', 82251);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (162, '28', 'Sulawesi Selatan', 'Kabupaten', 'Jeneponto', 92319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (163, '10', 'Jawa Tengah', 'Kabupaten', 'Jepara', 59419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (164, '11', 'Jawa Timur', 'Kabupaten', 'Jombang', 61415);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (165, '25', 'Papua Barat', 'Kabupaten', 'Kaimana', 98671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (166, '26', 'Riau', 'Kabupaten', 'Kampar', 28411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (167, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kapuas', 73583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (168, '12', 'Kalimantan Barat', 'Kabupaten', 'Kapuas Hulu', 78719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (169, '10', 'Jawa Tengah', 'Kabupaten', 'Karanganyar', 57718);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (170, '1', 'Bali', 'Kabupaten', 'Karangasem', 80819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (171, '9', 'Jawa Barat', 'Kabupaten', 'Karawang', 41311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (172, '17', 'Kepulauan Riau', 'Kabupaten', 'Karimun', 29611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (173, '34', 'Sumatera Utara', 'Kabupaten', 'Karo', 22119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (174, '14', 'Kalimantan Tengah', 'Kabupaten', 'Katingan', 74411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (175, '4', 'Bengkulu', 'Kabupaten', 'Kaur', 38911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (176, '12', 'Kalimantan Barat', 'Kabupaten', 'Kayong Utara', 78852);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (177, '10', 'Jawa Tengah', 'Kabupaten', 'Kebumen', 54319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (178, '11', 'Jawa Timur', 'Kabupaten', 'Kediri', 64184);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (179, '11', 'Jawa Timur', 'Kota', 'Kediri', 64125);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (180, '24', 'Papua', 'Kabupaten', 'Keerom', 99461);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (181, '10', 'Jawa Tengah', 'Kabupaten', 'Kendal', 51314);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (182, '30', 'Sulawesi Tenggara', 'Kota', 'Kendari', 93126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (183, '4', 'Bengkulu', 'Kabupaten', 'Kepahiang', 39319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (184, '17', 'Kepulauan Riau', 'Kabupaten', 'Kepulauan Anambas', 29991);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (185, '19', 'Maluku', 'Kabupaten', 'Kepulauan Aru', 97681);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (186, '32', 'Sumatera Barat', 'Kabupaten', 'Kepulauan Mentawai', 25771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (187, '26', 'Riau', 'Kabupaten', 'Kepulauan Meranti', 28791);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (188, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Sangihe', 95819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (189, '6', 'DKI Jakarta', 'Kabupaten', 'Kepulauan Seribu', 14550);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (190, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Siau Tagulandang Biaro (Sitaro)', 95862);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (191, '20', 'Maluku Utara', 'Kabupaten', 'Kepulauan Sula', 97995);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (192, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Talaud', 95885);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (193, '24', 'Papua', 'Kabupaten', 'Kepulauan Yapen (Yapen Waropen)', 98211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (194, '8', 'Jambi', 'Kabupaten', 'Kerinci', 37167);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (195, '12', 'Kalimantan Barat', 'Kabupaten', 'Ketapang', 78874);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (196, '10', 'Jawa Tengah', 'Kabupaten', 'Klaten', 57411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (197, '1', 'Bali', 'Kabupaten', 'Klungkung', 80719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (198, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Kolaka', 93511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (199, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Kolaka Utara', 93911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (200, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe', 93411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (201, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe Selatan', 93811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (202, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe Utara', 93311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (203, '13', 'Kalimantan Selatan', 'Kabupaten', 'Kotabaru', 72119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (204, '31', 'Sulawesi Utara', 'Kota', 'Kotamobagu', 95711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (205, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kotawaringin Barat', 74119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (206, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kotawaringin Timur', 74364);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (207, '26', 'Riau', 'Kabupaten', 'Kuantan Singingi', 29519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (208, '12', 'Kalimantan Barat', 'Kabupaten', 'Kubu Raya', 78311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (209, '10', 'Jawa Tengah', 'Kabupaten', 'Kudus', 59311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (210, '5', 'DI Yogyakarta', 'Kabupaten', 'Kulon Progo', 55611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (211, '9', 'Jawa Barat', 'Kabupaten', 'Kuningan', 45511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (212, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Kupang', 85362);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (213, '23', 'Nusa Tenggara Timur (NTT)', 'Kota', 'Kupang', 85119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (214, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Barat', 75711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (215, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Kartanegara', 75511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (216, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Timur', 75611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (217, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu', 21412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (218, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu Selatan', 21511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (219, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu Utara', 21711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (220, '33', 'Sumatera Selatan', 'Kabupaten', 'Lahat', 31419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (221, '14', 'Kalimantan Tengah', 'Kabupaten', 'Lamandau', 74611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (222, '11', 'Jawa Timur', 'Kabupaten', 'Lamongan', 64125);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (223, '18', 'Lampung', 'Kabupaten', 'Lampung Barat', 34814);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (224, '18', 'Lampung', 'Kabupaten', 'Lampung Selatan', 35511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (225, '18', 'Lampung', 'Kabupaten', 'Lampung Tengah', 34212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (226, '18', 'Lampung', 'Kabupaten', 'Lampung Timur', 34319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (227, '18', 'Lampung', 'Kabupaten', 'Lampung Utara', 34516);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (228, '12', 'Kalimantan Barat', 'Kabupaten', 'Landak', 78319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (229, '34', 'Sumatera Utara', 'Kabupaten', 'Langkat', 20811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (230, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Langsa', 24412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (231, '24', 'Papua', 'Kabupaten', 'Lanny Jaya', 99531);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (232, '3', 'Banten', 'Kabupaten', 'Lebak', 42319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (233, '4', 'Bengkulu', 'Kabupaten', 'Lebong', 39264);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (234, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Lembata', 86611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (235, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Lhokseumawe', 24352);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (236, '32', 'Sumatera Barat', 'Kabupaten', 'Lima Puluh Koto/Kota', 26671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (237, '17', 'Kepulauan Riau', 'Kabupaten', 'Lingga', 29811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (238, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Barat', 83311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (239, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Tengah', 83511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (240, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Timur', 83612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (241, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Utara', 83711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (242, '33', 'Sumatera Selatan', 'Kota', 'Lubuk Linggau', 31614);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (243, '11', 'Jawa Timur', 'Kabupaten', 'Lumajang', 67319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (244, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu', 91994);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (245, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu Timur', 92981);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (246, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu Utara', 92911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (247, '11', 'Jawa Timur', 'Kabupaten', 'Madiun', 63153);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (248, '11', 'Jawa Timur', 'Kota', 'Madiun', 63122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (249, '10', 'Jawa Tengah', 'Kabupaten', 'Magelang', 56519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (250, '10', 'Jawa Tengah', 'Kota', 'Magelang', 56133);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (251, '11', 'Jawa Timur', 'Kabupaten', 'Magetan', 63314);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (252, '9', 'Jawa Barat', 'Kabupaten', 'Majalengka', 45412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (253, '27', 'Sulawesi Barat', 'Kabupaten', 'Majene', 91411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (254, '28', 'Sulawesi Selatan', 'Kota', 'Makassar', 90111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (255, '11', 'Jawa Timur', 'Kabupaten', 'Malang', 65163);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (256, '11', 'Jawa Timur', 'Kota', 'Malang', 65112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (257, '16', 'Kalimantan Utara', 'Kabupaten', 'Malinau', 77511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (258, '19', 'Maluku', 'Kabupaten', 'Maluku Barat Daya', 97451);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (259, '19', 'Maluku', 'Kabupaten', 'Maluku Tengah', 97513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (260, '19', 'Maluku', 'Kabupaten', 'Maluku Tenggara', 97651);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (261, '19', 'Maluku', 'Kabupaten', 'Maluku Tenggara Barat', 97465);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (262, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamasa', 91362);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (263, '24', 'Papua', 'Kabupaten', 'Mamberamo Raya', 99381);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (264, '24', 'Papua', 'Kabupaten', 'Mamberamo Tengah', 99553);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (265, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamuju', 91519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (266, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamuju Utara', 91571);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (267, '31', 'Sulawesi Utara', 'Kota', 'Manado', 95247);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (268, '34', 'Sumatera Utara', 'Kabupaten', 'Mandailing Natal', 22916);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (269, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai', 86551);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (270, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai Barat', 86711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (271, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai Timur', 86811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (272, '25', 'Papua Barat', 'Kabupaten', 'Manokwari', 98311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (273, '25', 'Papua Barat', 'Kabupaten', 'Manokwari Selatan', 98355);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (274, '24', 'Papua', 'Kabupaten', 'Mappi', 99853);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (275, '28', 'Sulawesi Selatan', 'Kabupaten', 'Maros', 90511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (276, '22', 'Nusa Tenggara Barat (NTB)', 'Kota', 'Mataram', 83131);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (277, '25', 'Papua Barat', 'Kabupaten', 'Maybrat', 98051);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (278, '34', 'Sumatera Utara', 'Kota', 'Medan', 20228);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (279, '12', 'Kalimantan Barat', 'Kabupaten', 'Melawi', 78619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (280, '8', 'Jambi', 'Kabupaten', 'Merangin', 37319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (281, '24', 'Papua', 'Kabupaten', 'Merauke', 99613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (282, '18', 'Lampung', 'Kabupaten', 'Mesuji', 34911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (283, '18', 'Lampung', 'Kota', 'Metro', 34111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (284, '24', 'Papua', 'Kabupaten', 'Mimika', 99962);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (285, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa', 95614);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (286, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Selatan', 95914);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (287, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Tenggara', 95995);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (288, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Utara', 95316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (289, '11', 'Jawa Timur', 'Kabupaten', 'Mojokerto', 61382);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (290, '11', 'Jawa Timur', 'Kota', 'Mojokerto', 61316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (291, '29', 'Sulawesi Tengah', 'Kabupaten', 'Morowali', 94911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (292, '33', 'Sumatera Selatan', 'Kabupaten', 'Muara Enim', 31315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (293, '8', 'Jambi', 'Kabupaten', 'Muaro Jambi', 36311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (294, '4', 'Bengkulu', 'Kabupaten', 'Muko Muko', 38715);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (295, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Muna', 93611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (296, '14', 'Kalimantan Tengah', 'Kabupaten', 'Murung Raya', 73911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (297, '33', 'Sumatera Selatan', 'Kabupaten', 'Musi Banyuasin', 30719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (298, '33', 'Sumatera Selatan', 'Kabupaten', 'Musi Rawas', 31661);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (299, '24', 'Papua', 'Kabupaten', 'Nabire', 98816);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (300, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Nagan Raya', 23674);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (301, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Nagekeo', 86911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (302, '17', 'Kepulauan Riau', 'Kabupaten', 'Natuna', 29711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (303, '24', 'Papua', 'Kabupaten', 'Nduga', 99541);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (304, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Ngada', 86413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (305, '11', 'Jawa Timur', 'Kabupaten', 'Nganjuk', 64414);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (306, '11', 'Jawa Timur', 'Kabupaten', 'Ngawi', 63219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (307, '34', 'Sumatera Utara', 'Kabupaten', 'Nias', 22876);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (308, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Barat', 22895);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (309, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Selatan', 22865);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (310, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Utara', 22856);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (311, '16', 'Kalimantan Utara', 'Kabupaten', 'Nunukan', 77421);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (312, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Ilir', 30811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (313, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ilir', 30618);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (314, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu', 32112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (315, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu Selatan', 32211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (316, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu Timur', 32312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (317, '11', 'Jawa Timur', 'Kabupaten', 'Pacitan', 63512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (318, '32', 'Sumatera Barat', 'Kota', 'Padang', 25112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (319, '34', 'Sumatera Utara', 'Kabupaten', 'Padang Lawas', 22763);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (320, '34', 'Sumatera Utara', 'Kabupaten', 'Padang Lawas Utara', 22753);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (321, '32', 'Sumatera Barat', 'Kota', 'Padang Panjang', 27122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (322, '32', 'Sumatera Barat', 'Kabupaten', 'Padang Pariaman', 25583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (323, '34', 'Sumatera Utara', 'Kota', 'Padang Sidempuan', 22727);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (324, '33', 'Sumatera Selatan', 'Kota', 'Pagar Alam', 31512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (325, '34', 'Sumatera Utara', 'Kabupaten', 'Pakpak Bharat', 22272);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (326, '14', 'Kalimantan Tengah', 'Kota', 'Palangka Raya', 73112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (327, '33', 'Sumatera Selatan', 'Kota', 'Palembang', 31512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (328, '28', 'Sulawesi Selatan', 'Kota', 'Palopo', 91911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (329, '29', 'Sulawesi Tengah', 'Kota', 'Palu', 94111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (330, '11', 'Jawa Timur', 'Kabupaten', 'Pamekasan', 69319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (331, '3', 'Banten', 'Kabupaten', 'Pandeglang', 42212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (332, '9', 'Jawa Barat', 'Kabupaten', 'Pangandaran', 46511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (333, '28', 'Sulawesi Selatan', 'Kabupaten', 'Pangkajene Kepulauan', 90611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (334, '2', 'Bangka Belitung', 'Kota', 'Pangkal Pinang', 33115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (335, '24', 'Papua', 'Kabupaten', 'Paniai', 98765);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (336, '28', 'Sulawesi Selatan', 'Kota', 'Parepare', 91123);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (337, '32', 'Sumatera Barat', 'Kota', 'Pariaman', 25511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (338, '29', 'Sulawesi Tengah', 'Kabupaten', 'Parigi Moutong', 94411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (339, '32', 'Sumatera Barat', 'Kabupaten', 'Pasaman', 26318);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (340, '32', 'Sumatera Barat', 'Kabupaten', 'Pasaman Barat', 26511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (341, '15', 'Kalimantan Timur', 'Kabupaten', 'Paser', 76211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (342, '11', 'Jawa Timur', 'Kabupaten', 'Pasuruan', 67153);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (343, '11', 'Jawa Timur', 'Kota', 'Pasuruan', 67118);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (344, '10', 'Jawa Tengah', 'Kabupaten', 'Pati', 59114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (345, '32', 'Sumatera Barat', 'Kota', 'Payakumbuh', 26213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (346, '25', 'Papua Barat', 'Kabupaten', 'Pegunungan Arfak', 98354);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (347, '24', 'Papua', 'Kabupaten', 'Pegunungan Bintang', 99573);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (348, '10', 'Jawa Tengah', 'Kabupaten', 'Pekalongan', 51161);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (349, '10', 'Jawa Tengah', 'Kota', 'Pekalongan', 51122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (350, '26', 'Riau', 'Kota', 'Pekanbaru', 28112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (351, '26', 'Riau', 'Kabupaten', 'Pelalawan', 28311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (352, '10', 'Jawa Tengah', 'Kabupaten', 'Pemalang', 52319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (353, '34', 'Sumatera Utara', 'Kota', 'Pematang Siantar', 21126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (354, '15', 'Kalimantan Timur', 'Kabupaten', 'Penajam Paser Utara', 76311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (355, '18', 'Lampung', 'Kabupaten', 'Pesawaran', 35312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (356, '18', 'Lampung', 'Kabupaten', 'Pesisir Barat', 35974);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (357, '32', 'Sumatera Barat', 'Kabupaten', 'Pesisir Selatan', 25611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (358, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Pidie', 24116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (359, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Pidie Jaya', 24186);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (360, '28', 'Sulawesi Selatan', 'Kabupaten', 'Pinrang', 91251);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (361, '7', 'Gorontalo', 'Kabupaten', 'Pohuwato', 96419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (362, '27', 'Sulawesi Barat', 'Kabupaten', 'Polewali Mandar', 91311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (363, '11', 'Jawa Timur', 'Kabupaten', 'Ponorogo', 63411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (364, '12', 'Kalimantan Barat', 'Kabupaten', 'Pontianak', 78971);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (365, '12', 'Kalimantan Barat', 'Kota', 'Pontianak', 78112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (366, '29', 'Sulawesi Tengah', 'Kabupaten', 'Poso', 94615);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (367, '33', 'Sumatera Selatan', 'Kota', 'Prabumulih', 31121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (368, '18', 'Lampung', 'Kabupaten', 'Pringsewu', 35719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (369, '11', 'Jawa Timur', 'Kabupaten', 'Probolinggo', 67282);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (370, '11', 'Jawa Timur', 'Kota', 'Probolinggo', 67215);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (371, '14', 'Kalimantan Tengah', 'Kabupaten', 'Pulang Pisau', 74811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (372, '20', 'Maluku Utara', 'Kabupaten', 'Pulau Morotai', 97771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (373, '24', 'Papua', 'Kabupaten', 'Puncak', 98981);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (374, '24', 'Papua', 'Kabupaten', 'Puncak Jaya', 98979);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (375, '10', 'Jawa Tengah', 'Kabupaten', 'Purbalingga', 53312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (376, '9', 'Jawa Barat', 'Kabupaten', 'Purwakarta', 41119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (377, '10', 'Jawa Tengah', 'Kabupaten', 'Purworejo', 54111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (378, '25', 'Papua Barat', 'Kabupaten', 'Raja Ampat', 98489);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (379, '4', 'Bengkulu', 'Kabupaten', 'Rejang Lebong', 39112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (380, '10', 'Jawa Tengah', 'Kabupaten', 'Rembang', 59219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (381, '26', 'Riau', 'Kabupaten', 'Rokan Hilir', 28992);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (382, '26', 'Riau', 'Kabupaten', 'Rokan Hulu', 28511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (383, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Rote Ndao', 85982);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (384, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Sabang', 23512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (385, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sabu Raijua', 85391);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (386, '10', 'Jawa Tengah', 'Kota', 'Salatiga', 50711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (387, '15', 'Kalimantan Timur', 'Kota', 'Samarinda', 75133);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (388, '12', 'Kalimantan Barat', 'Kabupaten', 'Sambas', 79453);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (389, '34', 'Sumatera Utara', 'Kabupaten', 'Samosir', 22392);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (390, '11', 'Jawa Timur', 'Kabupaten', 'Sampang', 69219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (391, '12', 'Kalimantan Barat', 'Kabupaten', 'Sanggau', 78557);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (392, '24', 'Papua', 'Kabupaten', 'Sarmi', 99373);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (393, '8', 'Jambi', 'Kabupaten', 'Sarolangun', 37419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (394, '32', 'Sumatera Barat', 'Kota', 'Sawah Lunto', 27416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (395, '12', 'Kalimantan Barat', 'Kabupaten', 'Sekadau', 79583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (396, '28', 'Sulawesi Selatan', 'Kabupaten', 'Selayar (Kepulauan Selayar)', 92812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (397, '4', 'Bengkulu', 'Kabupaten', 'Seluma', 38811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (398, '10', 'Jawa Tengah', 'Kabupaten', 'Semarang', 50511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (399, '10', 'Jawa Tengah', 'Kota', 'Semarang', 50135);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (400, '19', 'Maluku', 'Kabupaten', 'Seram Bagian Barat', 97561);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (401, '19', 'Maluku', 'Kabupaten', 'Seram Bagian Timur', 97581);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (402, '3', 'Banten', 'Kabupaten', 'Serang', 42182);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (403, '3', 'Banten', 'Kota', 'Serang', 42111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (404, '34', 'Sumatera Utara', 'Kabupaten', 'Serdang Bedagai', 20915);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (405, '14', 'Kalimantan Tengah', 'Kabupaten', 'Seruyan', 74211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (406, '26', 'Riau', 'Kabupaten', 'Siak', 28623);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (407, '34', 'Sumatera Utara', 'Kota', 'Sibolga', 22522);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (408, '28', 'Sulawesi Selatan', 'Kabupaten', 'Sidenreng Rappang/Rapang', 91613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (409, '11', 'Jawa Timur', 'Kabupaten', 'Sidoarjo', 61219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (410, '29', 'Sulawesi Tengah', 'Kabupaten', 'Sigi', 94364);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (411, '32', 'Sumatera Barat', 'Kabupaten', 'Sijunjung (Sawah Lunto Sijunjung)', 27511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (412, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sikka', 86121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (413, '34', 'Sumatera Utara', 'Kabupaten', 'Simalungun', 21162);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (414, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Simeulue', 23891);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (415, '12', 'Kalimantan Barat', 'Kota', 'Singkawang', 79117);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (416, '28', 'Sulawesi Selatan', 'Kabupaten', 'Sinjai', 92615);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (417, '12', 'Kalimantan Barat', 'Kabupaten', 'Sintang', 78619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (418, '11', 'Jawa Timur', 'Kabupaten', 'Situbondo', 68316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (419, '5', 'DI Yogyakarta', 'Kabupaten', 'Sleman', 55513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (420, '32', 'Sumatera Barat', 'Kabupaten', 'Solok', 27365);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (421, '32', 'Sumatera Barat', 'Kota', 'Solok', 27315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (422, '32', 'Sumatera Barat', 'Kabupaten', 'Solok Selatan', 27779);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (423, '28', 'Sulawesi Selatan', 'Kabupaten', 'Soppeng', 90812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (424, '25', 'Papua Barat', 'Kabupaten', 'Sorong', 98431);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (425, '25', 'Papua Barat', 'Kota', 'Sorong', 98411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (426, '25', 'Papua Barat', 'Kabupaten', 'Sorong Selatan', 98454);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (427, '10', 'Jawa Tengah', 'Kabupaten', 'Sragen', 57211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (428, '9', 'Jawa Barat', 'Kabupaten', 'Subang', 41215);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (429, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Subulussalam', 24882);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (430, '9', 'Jawa Barat', 'Kabupaten', 'Sukabumi', 43311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (431, '9', 'Jawa Barat', 'Kota', 'Sukabumi', 43114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (432, '14', 'Kalimantan Tengah', 'Kabupaten', 'Sukamara', 74712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (433, '10', 'Jawa Tengah', 'Kabupaten', 'Sukoharjo', 57514);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (434, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Barat', 87219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (435, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Barat Daya', 87453);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (436, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Tengah', 87358);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (437, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Timur', 87112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (438, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Sumbawa', 84315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (439, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Sumbawa Barat', 84419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (440, '9', 'Jawa Barat', 'Kabupaten', 'Sumedang', 45326);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (441, '11', 'Jawa Timur', 'Kabupaten', 'Sumenep', 69413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (442, '8', 'Jambi', 'Kota', 'Sungaipenuh', 37113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (443, '24', 'Papua', 'Kabupaten', 'Supiori', 98164);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (444, '11', 'Jawa Timur', 'Kota', 'Surabaya', 60119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (445, '10', 'Jawa Tengah', 'Kota', 'Surakarta (Solo)', 57113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (446, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tabalong', 71513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (447, '1', 'Bali', 'Kabupaten', 'Tabanan', 82119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (448, '28', 'Sulawesi Selatan', 'Kabupaten', 'Takalar', 92212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (449, '25', 'Papua Barat', 'Kabupaten', 'Tambrauw', 98475);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (450, '16', 'Kalimantan Utara', 'Kabupaten', 'Tana Tidung', 77611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (451, '28', 'Sulawesi Selatan', 'Kabupaten', 'Tana Toraja', 91819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (452, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tanah Bumbu', 72211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (453, '32', 'Sumatera Barat', 'Kabupaten', 'Tanah Datar', 27211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (454, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tanah Laut', 70811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (455, '3', 'Banten', 'Kabupaten', 'Tangerang', 15914);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (456, '3', 'Banten', 'Kota', 'Tangerang', 15111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (457, '3', 'Banten', 'Kota', 'Tangerang Selatan', 15332);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (458, '18', 'Lampung', 'Kabupaten', 'Tanggamus', 35619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (459, '34', 'Sumatera Utara', 'Kota', 'Tanjung Balai', 21321);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (460, '8', 'Jambi', 'Kabupaten', 'Tanjung Jabung Barat', 36513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (461, '8', 'Jambi', 'Kabupaten', 'Tanjung Jabung Timur', 36719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (462, '17', 'Kepulauan Riau', 'Kota', 'Tanjung Pinang', 29111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (463, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Selatan', 22742);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (464, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Tengah', 22611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (465, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Utara', 22414);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (466, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tapin', 71119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (467, '16', 'Kalimantan Utara', 'Kota', 'Tarakan', 77114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (468, '9', 'Jawa Barat', 'Kabupaten', 'Tasikmalaya', 46411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (469, '9', 'Jawa Barat', 'Kota', 'Tasikmalaya', 46116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (470, '34', 'Sumatera Utara', 'Kota', 'Tebing Tinggi', 20632);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (471, '8', 'Jambi', 'Kabupaten', 'Tebo', 37519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (472, '10', 'Jawa Tengah', 'Kabupaten', 'Tegal', 52419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (473, '10', 'Jawa Tengah', 'Kota', 'Tegal', 52114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (474, '25', 'Papua Barat', 'Kabupaten', 'Teluk Bintuni', 98551);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (475, '25', 'Papua Barat', 'Kabupaten', 'Teluk Wondama', 98591);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (476, '10', 'Jawa Tengah', 'Kabupaten', 'Temanggung', 56212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (477, '20', 'Maluku Utara', 'Kota', 'Ternate', 97714);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (478, '20', 'Maluku Utara', 'Kota', 'Tidore Kepulauan', 97815);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (479, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Timor Tengah Selatan', 85562);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (480, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Timor Tengah Utara', 85612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (481, '34', 'Sumatera Utara', 'Kabupaten', 'Toba Samosir', 22316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (482, '29', 'Sulawesi Tengah', 'Kabupaten', 'Tojo Una-Una', 94683);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (483, '29', 'Sulawesi Tengah', 'Kabupaten', 'Toli-Toli', 94542);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (484, '24', 'Papua', 'Kabupaten', 'Tolikara', 99411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (485, '31', 'Sulawesi Utara', 'Kota', 'Tomohon', 95416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (486, '28', 'Sulawesi Selatan', 'Kabupaten', 'Toraja Utara', 91831);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (487, '11', 'Jawa Timur', 'Kabupaten', 'Trenggalek', 66312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (488, '19', 'Maluku', 'Kota', 'Tual', 97612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (489, '11', 'Jawa Timur', 'Kabupaten', 'Tuban', 62319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (490, '18', 'Lampung', 'Kabupaten', 'Tulang Bawang', 34613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (491, '18', 'Lampung', 'Kabupaten', 'Tulang Bawang Barat', 34419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (492, '11', 'Jawa Timur', 'Kabupaten', 'Tulungagung', 66212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (493, '28', 'Sulawesi Selatan', 'Kabupaten', 'Wajo', 90911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (494, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Wakatobi', 93791);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (495, '24', 'Papua', 'Kabupaten', 'Waropen', 98269);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (496, '18', 'Lampung', 'Kabupaten', 'Way Kanan', 34711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (497, '10', 'Jawa Tengah', 'Kabupaten', 'Wonogiri', 57619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (498, '10', 'Jawa Tengah', 'Kabupaten', 'Wonosobo', 56311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (499, '24', 'Papua', 'Kabupaten', 'Yahukimo', 99041);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (500, '24', 'Papua', 'Kabupaten', 'Yalimo', 99481);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (501, '5', 'DI Yogyakarta', 'Kota', 'Yogyakarta', 55222);


#
# TABLE STRUCTURE FOR: sr_mata_pelajaran
#

DROP TABLE IF EXISTS `sr_mata_pelajaran`;

CREATE TABLE `sr_mata_pelajaran` (
  `idmata_pelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `mp_kode` varchar(50) NOT NULL,
  `mp_nama` varchar(255) NOT NULL,
  `mp_kelompok` enum('A','B','C','C1','C2') NOT NULL,
  `mp_urutan` int(11) NOT NULL,
  PRIMARY KEY (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (1, '5', 'PAI', 'Pendidikan Agama Islam', 'A', 1);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (2, '5', 'BIND', 'Bahasa Indonesia', 'A', 3);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (3, '5', 'MTK', 'Matematika', 'A', 5);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (46, '5', 'PKn', 'Pendidikan Kewarganegaraan', 'A', 2);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (47, '5', 'SBdP', 'Seni Budaya dan Prakarya', 'B', 1);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (48, '5', 'PJOK', 'Pendidikan Jasmani, Olahraga dan Kesehatan', 'B', 2);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (49, '5', 'IPA', 'Ilmu Pengetahuan Alam', 'A', 6);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (50, '5', 'IPS', 'Ilmu Pengetahuan Sosial', 'A', 7);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (51, '5', 'BING', 'Bahasa Inggris', 'A', 8);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (63, '5', 'MM', 'Multimedia', 'C1', 13);


#
# TABLE STRUCTURE FOR: sr_mata_pelajaran_guru
#

DROP TABLE IF EXISTS `sr_mata_pelajaran_guru`;

CREATE TABLE `sr_mata_pelajaran_guru` (
  `idmata_pelajaran_guru` int(11) NOT NULL AUTO_INCREMENT,
  `idmata_pelajaran` int(11) NOT NULL,
  `idusers` int(11) unsigned NOT NULL,
  PRIMARY KEY (`idmata_pelajaran_guru`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  KEY `idusers` (`idusers`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (12, 48, 39);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (13, 1, 40);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (14, 51, 41);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (15, 2, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (16, 3, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (17, 49, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (18, 50, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (19, 2, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (20, 3, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (21, 49, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (22, 50, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (23, 2, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (24, 3, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (25, 49, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (26, 50, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (27, 2, 43);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (28, 3, 43);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (29, 49, 43);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (30, 50, 43);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (31, 2, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (32, 3, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (33, 49, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (34, 50, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (35, 2, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (36, 49, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (37, 50, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (38, 3, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (42, 47, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (43, 46, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (44, 46, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (45, 47, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (46, 46, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (47, 47, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (48, 46, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (49, 47, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (50, 46, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (51, 47, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (52, 2, 57);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (53, 51, 57);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (54, 2, 1);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (55, 48, 40);


#
# TABLE STRUCTURE FOR: sr_materi
#

DROP TABLE IF EXISTS `sr_materi`;

CREATE TABLE `sr_materi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `mapel_id` int(11) NOT NULL,
  `kelas_id` varchar(11) NOT NULL,
  `pengajar_id` int(11) DEFAULT NULL,
  `judul` varchar(255) NOT NULL,
  `konten` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `video` text NOT NULL,
  `tgl_posting` datetime NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT 0,
  `views` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `kelas_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (3, '5', 1, '1', 0, 'BAB I - Sejarah', NULL, NULL, 'xVparsxskE0', '2022-04-06 16:35:49', 1, 1);


#
# TABLE STRUCTURE FOR: sr_nilai_keterampilan
#

DROP TABLE IF EXISTS `sr_nilai_keterampilan`;

CREATE TABLE `sr_nilai_keterampilan` (
  `idnilai_keterampilan` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idsiswa` int(11) NOT NULL,
  `idkompetensi_dasar` int(11) NOT NULL,
  `nk_harian` text NOT NULL,
  PRIMARY KEY (`idnilai_keterampilan`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  KEY `idusers` (`idusers`),
  KEY `idkelas` (`idkelas`),
  KEY `idsiswa` (`idsiswa`),
  KEY `idkompetensi_dasar` (`idkompetensi_dasar`)
) ENGINE=InnoDB AUTO_INCREMENT=867 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (286, 1, 2, 42, 1, 11, 31, '77,1,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (287, 1, 2, 42, 1, 12, 31, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (288, 1, 2, 42, 1, 13, 31, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (289, 1, 2, 42, 1, 14, 31, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (290, 1, 2, 42, 1, 15, 31, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (291, 1, 2, 42, 1, 16, 31, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (292, 1, 2, 42, 1, 17, 31, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (293, 1, 2, 42, 1, 18, 31, '88,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (294, 1, 2, 42, 1, 19, 31, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (295, 1, 2, 42, 1, 20, 31, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (296, 1, 2, 42, 1, 21, 31, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (297, 1, 2, 42, 1, 22, 31, '88,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (298, 1, 2, 42, 1, 23, 31, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (299, 1, 2, 42, 1, 24, 31, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (300, 1, 2, 42, 1, 25, 31, '88,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (301, 1, 2, 42, 1, 26, 31, '77,9,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (302, 1, 2, 42, 1, 27, 31, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (303, 1, 2, 42, 1, 28, 31, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (304, 1, 2, 42, 1, 29, 31, '88,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (305, 1, 2, 42, 1, 30, 31, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (306, 1, 2, 42, 1, 31, 31, '88,90,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (307, 1, 2, 42, 1, 11, 32, '77,88,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (308, 1, 2, 42, 1, 12, 32, '99,77,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (309, 1, 2, 42, 1, 13, 32, '88,99,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (310, 1, 2, 42, 1, 14, 32, '77,88,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (311, 1, 2, 42, 1, 15, 32, '99,77,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (312, 1, 2, 42, 1, 16, 32, '88,99,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (313, 1, 2, 42, 1, 17, 32, '77,88,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (314, 1, 2, 42, 1, 18, 32, '99,77,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (315, 1, 2, 42, 1, 19, 32, '88,99,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (316, 1, 2, 42, 1, 20, 32, '77,88,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (317, 1, 2, 42, 1, 21, 32, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (318, 1, 2, 42, 1, 22, 32, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (319, 1, 2, 42, 1, 23, 32, '99,78,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (320, 1, 2, 42, 1, 24, 32, '88,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (321, 1, 2, 42, 1, 25, 32, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (322, 1, 2, 42, 1, 26, 32, '99,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (323, 1, 2, 42, 1, 27, 32, '77,86,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (324, 1, 2, 42, 1, 28, 32, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (325, 1, 2, 42, 1, 29, 32, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (326, 1, 2, 42, 1, 30, 32, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (327, 1, 2, 42, 1, 31, 32, '99,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (328, 1, 49, 42, 1, 11, 35, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (329, 1, 49, 42, 1, 12, 35, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (330, 1, 49, 42, 1, 13, 35, '88,98,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (331, 1, 49, 42, 1, 14, 35, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (332, 1, 49, 42, 1, 15, 35, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (333, 1, 49, 42, 1, 16, 35, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (334, 1, 49, 42, 1, 17, 35, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (335, 1, 49, 42, 1, 18, 35, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (336, 1, 49, 42, 1, 19, 35, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (337, 1, 49, 42, 1, 20, 35, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (338, 1, 49, 42, 1, 21, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (339, 1, 49, 42, 1, 22, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (340, 1, 49, 42, 1, 23, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (341, 1, 49, 42, 1, 24, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (342, 1, 49, 42, 1, 25, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (343, 1, 49, 42, 1, 26, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (344, 1, 49, 42, 1, 27, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (345, 1, 49, 42, 1, 28, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (346, 1, 49, 42, 1, 29, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (347, 1, 49, 42, 1, 30, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (348, 1, 49, 42, 1, 31, 35, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (349, 1, 49, 42, 1, 11, 38, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (350, 1, 49, 42, 1, 12, 38, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (351, 1, 49, 42, 1, 13, 38, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (352, 1, 49, 42, 1, 14, 38, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (353, 1, 49, 42, 1, 15, 38, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (354, 1, 49, 42, 1, 16, 38, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (355, 1, 49, 42, 1, 17, 38, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (356, 1, 49, 42, 1, 18, 38, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (357, 1, 49, 42, 1, 19, 38, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (358, 1, 49, 42, 1, 20, 38, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (359, 1, 49, 42, 1, 21, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (360, 1, 49, 42, 1, 22, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (361, 1, 49, 42, 1, 23, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (362, 1, 49, 42, 1, 24, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (363, 1, 49, 42, 1, 25, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (364, 1, 49, 42, 1, 26, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (365, 1, 49, 42, 1, 27, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (366, 1, 49, 42, 1, 28, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (367, 1, 49, 42, 1, 29, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (368, 1, 49, 42, 1, 30, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (369, 1, 49, 42, 1, 31, 38, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (370, 1, 50, 42, 1, 11, 41, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (371, 1, 50, 42, 1, 12, 41, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (372, 1, 50, 42, 1, 13, 41, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (373, 1, 50, 42, 1, 14, 41, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (374, 1, 50, 42, 1, 15, 41, '99,75,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (375, 1, 50, 42, 1, 16, 41, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (376, 1, 50, 42, 1, 17, 41, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (377, 1, 50, 42, 1, 18, 41, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (378, 1, 50, 42, 1, 19, 41, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (379, 1, 50, 42, 1, 20, 41, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (380, 1, 50, 42, 1, 21, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (381, 1, 50, 42, 1, 22, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (382, 1, 50, 42, 1, 23, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (383, 1, 50, 42, 1, 24, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (384, 1, 50, 42, 1, 25, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (385, 1, 50, 42, 1, 26, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (386, 1, 50, 42, 1, 27, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (387, 1, 50, 42, 1, 28, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (388, 1, 50, 42, 1, 29, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (389, 1, 50, 42, 1, 30, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (390, 1, 50, 42, 1, 31, 41, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (391, 1, 50, 42, 1, 11, 42, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (392, 1, 50, 42, 1, 12, 42, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (393, 1, 50, 42, 1, 13, 42, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (394, 1, 50, 42, 1, 14, 42, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (395, 1, 50, 42, 1, 15, 42, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (396, 1, 50, 42, 1, 16, 42, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (397, 1, 50, 42, 1, 17, 42, '77,86,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (398, 1, 50, 42, 1, 18, 42, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (399, 1, 50, 42, 1, 19, 42, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (400, 1, 50, 42, 1, 20, 42, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (401, 1, 50, 42, 1, 21, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (402, 1, 50, 42, 1, 22, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (403, 1, 50, 42, 1, 23, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (404, 1, 50, 42, 1, 24, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (405, 1, 50, 42, 1, 25, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (406, 1, 50, 42, 1, 26, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (407, 1, 50, 42, 1, 27, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (408, 1, 50, 42, 1, 28, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (409, 1, 50, 42, 1, 29, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (410, 1, 50, 42, 1, 30, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (411, 1, 50, 42, 1, 31, 42, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (412, 1, 3, 42, 1, 11, 45, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (413, 1, 3, 42, 1, 12, 45, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (414, 1, 3, 42, 1, 13, 45, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (415, 1, 3, 42, 1, 14, 45, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (416, 1, 3, 42, 1, 15, 45, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (417, 1, 3, 42, 1, 16, 45, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (418, 1, 3, 42, 1, 17, 45, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (419, 1, 3, 42, 1, 18, 45, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (420, 1, 3, 42, 1, 19, 45, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (421, 1, 3, 42, 1, 20, 45, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (422, 1, 3, 42, 1, 21, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (423, 1, 3, 42, 1, 22, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (424, 1, 3, 42, 1, 23, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (425, 1, 3, 42, 1, 24, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (426, 1, 3, 42, 1, 25, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (427, 1, 3, 42, 1, 26, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (428, 1, 3, 42, 1, 27, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (429, 1, 3, 42, 1, 28, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (430, 1, 3, 42, 1, 29, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (431, 1, 3, 42, 1, 30, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (432, 1, 3, 42, 1, 31, 45, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (433, 1, 3, 42, 1, 11, 46, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (434, 1, 3, 42, 1, 12, 46, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (435, 1, 3, 42, 1, 13, 46, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (436, 1, 3, 42, 1, 14, 46, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (437, 1, 3, 42, 1, 15, 46, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (438, 1, 3, 42, 1, 16, 46, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (439, 1, 3, 42, 1, 17, 46, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (440, 1, 3, 42, 1, 18, 46, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (441, 1, 3, 42, 1, 19, 46, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (442, 1, 3, 42, 1, 20, 46, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (443, 1, 3, 42, 1, 21, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (444, 1, 3, 42, 1, 22, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (445, 1, 3, 42, 1, 23, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (446, 1, 3, 42, 1, 24, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (447, 1, 3, 42, 1, 25, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (448, 1, 3, 42, 1, 26, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (449, 1, 3, 42, 1, 27, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (450, 1, 3, 42, 1, 28, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (451, 1, 3, 42, 1, 29, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (452, 1, 3, 42, 1, 30, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (453, 1, 3, 42, 1, 31, 46, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (454, 1, 46, 42, 1, 11, 49, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (455, 1, 46, 42, 1, 12, 49, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (456, 1, 46, 42, 1, 13, 49, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (457, 1, 46, 42, 1, 14, 49, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (458, 1, 46, 42, 1, 15, 49, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (459, 1, 46, 42, 1, 16, 49, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (460, 1, 46, 42, 1, 17, 49, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (461, 1, 46, 42, 1, 18, 49, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (462, 1, 46, 42, 1, 19, 49, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (463, 1, 46, 42, 1, 20, 49, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (464, 1, 46, 42, 1, 21, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (465, 1, 46, 42, 1, 22, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (466, 1, 46, 42, 1, 23, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (467, 1, 46, 42, 1, 24, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (468, 1, 46, 42, 1, 25, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (469, 1, 46, 42, 1, 26, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (470, 1, 46, 42, 1, 27, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (471, 1, 46, 42, 1, 28, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (472, 1, 46, 42, 1, 29, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (473, 1, 46, 42, 1, 30, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (474, 1, 46, 42, 1, 31, 49, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (475, 1, 46, 42, 1, 11, 50, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (476, 1, 46, 42, 1, 12, 50, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (477, 1, 46, 42, 1, 13, 50, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (478, 1, 46, 42, 1, 14, 50, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (479, 1, 46, 42, 1, 15, 50, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (480, 1, 46, 42, 1, 16, 50, '88,98,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (481, 1, 46, 42, 1, 17, 50, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (482, 1, 46, 42, 1, 18, 50, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (483, 1, 46, 42, 1, 19, 50, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (484, 1, 46, 42, 1, 20, 50, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (485, 1, 46, 42, 1, 21, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (486, 1, 46, 42, 1, 22, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (487, 1, 46, 42, 1, 23, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (488, 1, 46, 42, 1, 24, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (489, 1, 46, 42, 1, 25, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (490, 1, 46, 42, 1, 26, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (491, 1, 46, 42, 1, 27, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (492, 1, 46, 42, 1, 28, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (493, 1, 46, 42, 1, 29, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (494, 1, 46, 42, 1, 30, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (495, 1, 46, 42, 1, 31, 50, '');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (496, 1, 47, 42, 1, 11, 53, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (497, 1, 47, 42, 1, 12, 53, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (498, 1, 47, 42, 1, 13, 53, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (499, 1, 47, 42, 1, 14, 53, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (500, 1, 47, 42, 1, 15, 53, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (501, 1, 47, 42, 1, 16, 53, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (502, 1, 47, 42, 1, 17, 53, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (503, 1, 47, 42, 1, 18, 53, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (504, 1, 47, 42, 1, 19, 53, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (505, 1, 47, 42, 1, 20, 53, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (506, 1, 47, 42, 1, 21, 53, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (507, 1, 47, 42, 1, 22, 53, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (508, 1, 47, 42, 1, 23, 53, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (509, 1, 47, 42, 1, 24, 53, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (510, 1, 47, 42, 1, 25, 53, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (511, 1, 47, 42, 1, 26, 53, '77,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (512, 1, 47, 42, 1, 27, 53, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (513, 1, 47, 42, 1, 28, 53, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (514, 1, 47, 42, 1, 29, 53, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (515, 1, 47, 42, 1, 30, 53, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (516, 1, 47, 42, 1, 31, 53, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (517, 1, 47, 42, 1, 11, 54, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (518, 1, 47, 42, 1, 12, 54, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (519, 1, 47, 42, 1, 13, 54, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (520, 1, 47, 42, 1, 14, 54, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (521, 1, 47, 42, 1, 15, 54, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (522, 1, 47, 42, 1, 16, 54, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (523, 1, 47, 42, 1, 17, 54, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (524, 1, 47, 42, 1, 18, 54, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (525, 1, 47, 42, 1, 19, 54, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (526, 1, 47, 42, 1, 20, 54, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (527, 1, 47, 42, 1, 21, 54, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (528, 1, 47, 42, 1, 22, 54, '99,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (529, 1, 47, 42, 1, 23, 54, '88,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (530, 1, 47, 42, 1, 24, 54, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (531, 1, 47, 42, 1, 25, 54, '88,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (532, 1, 47, 42, 1, 26, 54, '99,75,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (533, 1, 47, 42, 1, 27, 54, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (534, 1, 47, 42, 1, 28, 54, '99,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (535, 1, 47, 42, 1, 29, 54, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (536, 1, 47, 42, 1, 30, 54, '77,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (537, 1, 47, 42, 1, 31, 54, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (538, 1, 1, 40, 1, 11, 57, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (539, 1, 1, 40, 1, 12, 57, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (540, 1, 1, 40, 1, 13, 57, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (541, 1, 1, 40, 1, 14, 57, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (542, 1, 1, 40, 1, 15, 57, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (543, 1, 1, 40, 1, 16, 57, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (544, 1, 1, 40, 1, 17, 57, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (545, 1, 1, 40, 1, 18, 57, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (546, 1, 1, 40, 1, 19, 57, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (547, 1, 1, 40, 1, 20, 57, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (548, 1, 1, 40, 1, 21, 57, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (549, 1, 1, 40, 1, 22, 57, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (550, 1, 1, 40, 1, 23, 57, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (551, 1, 1, 40, 1, 24, 57, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (552, 1, 1, 40, 1, 25, 57, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (553, 1, 1, 40, 1, 26, 57, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (554, 1, 1, 40, 1, 27, 57, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (555, 1, 1, 40, 1, 28, 57, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (556, 1, 1, 40, 1, 29, 57, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (557, 1, 1, 40, 1, 30, 57, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (558, 1, 1, 40, 1, 31, 57, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (559, 1, 1, 40, 1, 11, 58, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (560, 1, 1, 40, 1, 12, 58, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (561, 1, 1, 40, 1, 13, 58, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (562, 1, 1, 40, 1, 14, 58, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (563, 1, 1, 40, 1, 15, 58, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (564, 1, 1, 40, 1, 16, 58, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (565, 1, 1, 40, 1, 17, 58, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (566, 1, 1, 40, 1, 18, 58, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (567, 1, 1, 40, 1, 19, 58, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (568, 1, 1, 40, 1, 20, 58, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (569, 1, 1, 40, 1, 21, 58, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (570, 1, 1, 40, 1, 22, 58, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (571, 1, 1, 40, 1, 23, 58, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (572, 1, 1, 40, 1, 24, 58, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (573, 1, 1, 40, 1, 25, 58, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (574, 1, 1, 40, 1, 26, 58, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (575, 1, 1, 40, 1, 27, 58, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (576, 1, 1, 40, 1, 28, 58, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (577, 1, 1, 40, 1, 29, 58, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (578, 1, 1, 40, 1, 30, 58, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (579, 1, 1, 40, 1, 31, 58, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (580, 1, 48, 39, 1, 11, 60, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (581, 1, 48, 39, 1, 12, 60, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (582, 1, 48, 39, 1, 13, 60, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (583, 1, 48, 39, 1, 14, 60, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (584, 1, 48, 39, 1, 15, 60, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (585, 1, 48, 39, 1, 16, 60, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (586, 1, 48, 39, 1, 17, 60, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (587, 1, 48, 39, 1, 18, 60, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (588, 1, 48, 39, 1, 19, 60, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (589, 1, 48, 39, 1, 20, 60, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (590, 1, 48, 39, 1, 21, 60, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (591, 1, 48, 39, 1, 22, 60, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (592, 1, 48, 39, 1, 23, 60, '99,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (593, 1, 48, 39, 1, 24, 60, '99,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (594, 1, 48, 39, 1, 25, 60, '88,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (595, 1, 48, 39, 1, 26, 60, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (596, 1, 48, 39, 1, 27, 60, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (597, 1, 48, 39, 1, 28, 60, '99,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (598, 1, 48, 39, 1, 29, 60, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (599, 1, 48, 39, 1, 30, 60, '99,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (600, 1, 48, 39, 1, 31, 60, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (601, 1, 51, 41, 1, 11, 62, '78,89,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (602, 1, 51, 41, 1, 12, 62, '87,98,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (603, 1, 51, 41, 1, 13, 62, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (604, 1, 51, 41, 1, 14, 62, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (605, 1, 51, 41, 1, 15, 62, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (606, 1, 51, 41, 1, 16, 62, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (607, 1, 51, 41, 1, 17, 62, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (608, 1, 51, 41, 1, 18, 62, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (609, 1, 51, 41, 1, 19, 62, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (610, 1, 51, 41, 1, 20, 62, '99,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (611, 1, 51, 41, 1, 21, 62, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (612, 1, 51, 41, 1, 22, 62, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (613, 1, 51, 41, 1, 23, 62, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (614, 1, 51, 41, 1, 24, 62, '88,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (615, 1, 51, 41, 1, 25, 62, '99,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (616, 1, 51, 41, 1, 26, 62, '88,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (617, 1, 51, 41, 1, 27, 62, '77,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (618, 1, 51, 41, 1, 28, 62, '97,88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (619, 1, 51, 41, 1, 29, 62, '88,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (620, 1, 51, 41, 1, 30, 62, '88,77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (621, 1, 51, 41, 1, 31, 62, '88,99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (623, 1, 2, 57, 17, 142, 64, '100,100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (624, 1, 51, 57, 17, 142, 66, '100,100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (625, 2, 2, 42, 1, 11, 68, '98,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (626, 2, 2, 42, 1, 12, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (627, 2, 2, 42, 1, 13, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (628, 2, 2, 42, 1, 14, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (629, 2, 2, 42, 1, 15, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (630, 2, 2, 42, 1, 16, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (631, 2, 2, 42, 1, 17, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (632, 2, 2, 42, 1, 18, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (633, 2, 2, 42, 1, 19, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (634, 2, 2, 42, 1, 20, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (635, 2, 2, 42, 1, 21, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (636, 2, 2, 42, 1, 22, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (637, 2, 2, 42, 1, 23, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (638, 2, 2, 42, 1, 24, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (639, 2, 2, 42, 1, 25, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (640, 2, 2, 42, 1, 26, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (641, 2, 2, 42, 1, 27, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (642, 2, 2, 42, 1, 28, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (643, 2, 2, 42, 1, 29, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (644, 2, 2, 42, 1, 30, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (645, 2, 2, 42, 1, 31, 68, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (648, 1, 2, 37, 2, 32, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (649, 1, 2, 37, 2, 33, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (650, 1, 2, 37, 2, 34, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (651, 1, 2, 37, 2, 39, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (652, 1, 2, 37, 2, 40, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (653, 1, 2, 37, 2, 41, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (654, 1, 2, 37, 2, 42, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (655, 1, 2, 37, 2, 43, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (656, 1, 2, 37, 2, 44, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (657, 1, 2, 37, 2, 45, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (658, 1, 2, 37, 2, 46, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (659, 1, 2, 37, 2, 47, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (660, 1, 2, 37, 2, 48, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (661, 1, 2, 37, 2, 49, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (662, 1, 2, 37, 2, 50, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (663, 1, 2, 37, 2, 51, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (664, 1, 2, 37, 2, 52, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (665, 1, 2, 37, 2, 53, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (666, 1, 2, 37, 2, 54, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (667, 1, 2, 37, 2, 55, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (668, 1, 2, 37, 2, 56, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (669, 1, 2, 37, 2, 57, 72, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (670, 1, 49, 37, 2, 32, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (671, 1, 49, 37, 2, 33, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (672, 1, 49, 37, 2, 34, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (673, 1, 49, 37, 2, 39, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (674, 1, 49, 37, 2, 40, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (675, 1, 49, 37, 2, 41, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (676, 1, 49, 37, 2, 42, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (677, 1, 49, 37, 2, 43, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (678, 1, 49, 37, 2, 44, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (679, 1, 49, 37, 2, 45, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (680, 1, 49, 37, 2, 46, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (681, 1, 49, 37, 2, 47, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (682, 1, 49, 37, 2, 48, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (683, 1, 49, 37, 2, 49, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (684, 1, 49, 37, 2, 50, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (685, 1, 49, 37, 2, 51, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (686, 1, 49, 37, 2, 52, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (687, 1, 49, 37, 2, 53, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (688, 1, 49, 37, 2, 54, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (689, 1, 49, 37, 2, 55, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (690, 1, 49, 37, 2, 56, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (691, 1, 49, 37, 2, 57, 74, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (692, 1, 50, 37, 2, 32, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (693, 1, 50, 37, 2, 33, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (694, 1, 50, 37, 2, 34, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (695, 1, 50, 37, 2, 39, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (696, 1, 50, 37, 2, 40, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (697, 1, 50, 37, 2, 41, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (698, 1, 50, 37, 2, 42, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (699, 1, 50, 37, 2, 43, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (700, 1, 50, 37, 2, 44, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (701, 1, 50, 37, 2, 45, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (702, 1, 50, 37, 2, 46, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (703, 1, 50, 37, 2, 47, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (704, 1, 50, 37, 2, 48, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (705, 1, 50, 37, 2, 49, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (706, 1, 50, 37, 2, 50, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (707, 1, 50, 37, 2, 51, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (708, 1, 50, 37, 2, 52, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (709, 1, 50, 37, 2, 53, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (710, 1, 50, 37, 2, 54, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (711, 1, 50, 37, 2, 55, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (712, 1, 50, 37, 2, 56, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (713, 1, 50, 37, 2, 57, 76, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (714, 1, 3, 37, 2, 32, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (715, 1, 3, 37, 2, 33, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (716, 1, 3, 37, 2, 34, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (717, 1, 3, 37, 2, 39, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (718, 1, 3, 37, 2, 40, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (719, 1, 3, 37, 2, 41, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (720, 1, 3, 37, 2, 42, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (721, 1, 3, 37, 2, 43, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (722, 1, 3, 37, 2, 44, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (723, 1, 3, 37, 2, 45, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (724, 1, 3, 37, 2, 46, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (725, 1, 3, 37, 2, 47, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (726, 1, 3, 37, 2, 48, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (727, 1, 3, 37, 2, 49, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (728, 1, 3, 37, 2, 50, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (729, 1, 3, 37, 2, 51, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (730, 1, 3, 37, 2, 52, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (731, 1, 3, 37, 2, 53, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (732, 1, 3, 37, 2, 54, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (733, 1, 3, 37, 2, 55, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (734, 1, 3, 37, 2, 56, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (735, 1, 3, 37, 2, 57, 78, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (736, 1, 46, 37, 2, 32, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (737, 1, 46, 37, 2, 33, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (738, 1, 46, 37, 2, 34, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (739, 1, 46, 37, 2, 39, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (740, 1, 46, 37, 2, 40, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (741, 1, 46, 37, 2, 41, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (742, 1, 46, 37, 2, 42, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (743, 1, 46, 37, 2, 43, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (744, 1, 46, 37, 2, 44, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (745, 1, 46, 37, 2, 45, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (746, 1, 46, 37, 2, 46, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (747, 1, 46, 37, 2, 47, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (748, 1, 46, 37, 2, 48, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (749, 1, 46, 37, 2, 49, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (750, 1, 46, 37, 2, 50, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (751, 1, 46, 37, 2, 51, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (752, 1, 46, 37, 2, 52, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (753, 1, 46, 37, 2, 53, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (754, 1, 46, 37, 2, 54, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (755, 1, 46, 37, 2, 55, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (756, 1, 46, 37, 2, 56, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (757, 1, 46, 37, 2, 57, 80, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (758, 1, 47, 37, 2, 32, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (759, 1, 47, 37, 2, 33, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (760, 1, 47, 37, 2, 34, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (761, 1, 47, 37, 2, 39, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (762, 1, 47, 37, 2, 40, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (763, 1, 47, 37, 2, 41, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (764, 1, 47, 37, 2, 42, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (765, 1, 47, 37, 2, 43, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (766, 1, 47, 37, 2, 44, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (767, 1, 47, 37, 2, 45, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (768, 1, 47, 37, 2, 46, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (769, 1, 47, 37, 2, 47, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (770, 1, 47, 37, 2, 48, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (771, 1, 47, 37, 2, 49, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (772, 1, 47, 37, 2, 50, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (773, 1, 47, 37, 2, 51, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (774, 1, 47, 37, 2, 52, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (775, 1, 47, 37, 2, 53, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (776, 1, 47, 37, 2, 54, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (777, 1, 47, 37, 2, 55, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (778, 1, 47, 37, 2, 56, 82, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (779, 1, 47, 37, 2, 57, 82, '1,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (780, 1, 1, 40, 2, 32, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (781, 1, 1, 40, 2, 33, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (782, 1, 1, 40, 2, 34, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (783, 1, 1, 40, 2, 39, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (784, 1, 1, 40, 2, 40, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (785, 1, 1, 40, 2, 41, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (786, 1, 1, 40, 2, 42, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (787, 1, 1, 40, 2, 43, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (788, 1, 1, 40, 2, 44, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (789, 1, 1, 40, 2, 45, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (790, 1, 1, 40, 2, 46, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (791, 1, 1, 40, 2, 47, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (792, 1, 1, 40, 2, 48, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (793, 1, 1, 40, 2, 49, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (794, 1, 1, 40, 2, 50, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (795, 1, 1, 40, 2, 51, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (796, 1, 1, 40, 2, 52, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (797, 1, 1, 40, 2, 53, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (798, 1, 1, 40, 2, 54, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (799, 1, 1, 40, 2, 55, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (800, 1, 1, 40, 2, 56, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (801, 1, 1, 40, 2, 57, 84, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (802, 1, 51, 41, 2, 32, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (803, 1, 51, 41, 2, 33, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (804, 1, 51, 41, 2, 34, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (805, 1, 51, 41, 2, 39, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (806, 1, 51, 41, 2, 40, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (807, 1, 51, 41, 2, 41, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (808, 1, 51, 41, 2, 42, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (809, 1, 51, 41, 2, 43, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (810, 1, 51, 41, 2, 44, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (811, 1, 51, 41, 2, 45, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (812, 1, 51, 41, 2, 46, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (813, 1, 51, 41, 2, 47, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (814, 1, 51, 41, 2, 48, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (815, 1, 51, 41, 2, 49, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (816, 1, 51, 41, 2, 50, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (817, 1, 51, 41, 2, 51, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (818, 1, 51, 41, 2, 52, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (819, 1, 51, 41, 2, 53, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (820, 1, 51, 41, 2, 54, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (821, 1, 51, 41, 2, 55, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (822, 1, 51, 41, 2, 56, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (823, 1, 51, 41, 2, 57, 86, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (824, 1, 48, 39, 2, 32, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (825, 1, 48, 39, 2, 33, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (826, 1, 48, 39, 2, 34, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (827, 1, 48, 39, 2, 39, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (828, 1, 48, 39, 2, 40, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (829, 1, 48, 39, 2, 41, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (830, 1, 48, 39, 2, 42, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (831, 1, 48, 39, 2, 43, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (832, 1, 48, 39, 2, 44, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (833, 1, 48, 39, 2, 45, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (834, 1, 48, 39, 2, 46, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (835, 1, 48, 39, 2, 47, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (836, 1, 48, 39, 2, 48, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (837, 1, 48, 39, 2, 49, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (838, 1, 48, 39, 2, 50, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (839, 1, 48, 39, 2, 51, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (840, 1, 48, 39, 2, 52, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (841, 1, 48, 39, 2, 53, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (842, 1, 48, 39, 2, 54, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (843, 1, 48, 39, 2, 55, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (844, 1, 48, 39, 2, 56, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (845, 1, 48, 39, 2, 57, 88, '100,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (846, 2, 49, 42, 1, 11, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (847, 2, 49, 42, 1, 12, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (848, 2, 49, 42, 1, 13, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (849, 2, 49, 42, 1, 14, 90, '99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (850, 2, 49, 42, 1, 15, 90, '99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (851, 2, 49, 42, 1, 16, 90, '99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (852, 2, 49, 42, 1, 17, 90, '99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (853, 2, 49, 42, 1, 18, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (854, 2, 49, 42, 1, 19, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (855, 2, 49, 42, 1, 20, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (856, 2, 49, 42, 1, 21, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (857, 2, 49, 42, 1, 22, 90, '99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (858, 2, 49, 42, 1, 23, 90, '77,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (859, 2, 49, 42, 1, 24, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (860, 2, 49, 42, 1, 25, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (861, 2, 49, 42, 1, 26, 90, '99,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (862, 2, 49, 42, 1, 27, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (863, 2, 49, 42, 1, 28, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (864, 2, 49, 42, 1, 29, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (865, 2, 49, 42, 1, 30, 90, '88,');
INSERT INTO `sr_nilai_keterampilan` (`idnilai_keterampilan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `nk_harian`) VALUES (866, 2, 49, 42, 1, 31, 90, '99,');


#
# TABLE STRUCTURE FOR: sr_nilai_pengetahuan
#

DROP TABLE IF EXISTS `sr_nilai_pengetahuan`;

CREATE TABLE `sr_nilai_pengetahuan` (
  `idnilai_pengetahuan` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `idusers` int(11) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idsiswa` int(11) NOT NULL,
  `idkompetensi_dasar` int(11) NOT NULL,
  `np_harian` text DEFAULT NULL,
  PRIMARY KEY (`idnilai_pengetahuan`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idusers` (`idusers`),
  KEY `idkelas` (`idkelas`),
  KEY `idsiswa` (`idsiswa`),
  KEY `idkompetensi_dasar` (`idkompetensi_dasar`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=2712 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2099, 1, 2, 42, 1, 11, 29, '77,88,1,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2100, 1, 2, 42, 1, 12, 29, '88,88,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2101, 1, 2, 42, 1, 13, 29, '99,77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2102, 1, 2, 42, 1, 14, 29, '99,77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2103, 1, 2, 42, 1, 15, 29, '88,77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2104, 1, 2, 42, 1, 16, 29, '88,99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2105, 1, 2, 42, 1, 17, 29, '99,88,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2106, 1, 2, 42, 1, 18, 29, '77,77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2107, 1, 2, 42, 1, 19, 29, '99,77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2108, 1, 2, 42, 1, 20, 29, '77,77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2109, 1, 2, 42, 1, 21, 29, '88,99,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2110, 1, 2, 42, 1, 22, 29, '77,88,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2111, 1, 2, 42, 1, 23, 29, '78,98,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2112, 1, 2, 42, 1, 24, 29, '89,87,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2113, 1, 2, 42, 1, 25, 29, '78,78,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2114, 1, 2, 42, 1, 26, 29, '77,88,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2115, 1, 2, 42, 1, 27, 29, '88,99,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2116, 1, 2, 42, 1, 28, 29, '77,88,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2117, 1, 2, 42, 1, 29, 29, '99,77,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2118, 1, 2, 42, 1, 30, 29, '78,89,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2119, 1, 2, 42, 1, 31, 29, '78,98,98,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2120, 1, 2, 42, 1, 11, 30, '89,88,1,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2121, 1, 2, 42, 1, 12, 30, '88,79,1,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2122, 1, 2, 42, 1, 13, 30, '88,88,1,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2123, 1, 2, 42, 1, 14, 30, '78,78,1,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2124, 1, 2, 42, 1, 15, 30, '99,77,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2125, 1, 2, 42, 1, 16, 30, '77,99,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2126, 1, 2, 42, 1, 17, 30, '78,99,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2127, 1, 2, 42, 1, 18, 30, '78,89,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2128, 1, 2, 42, 1, 19, 30, '88,99,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2129, 1, 2, 42, 1, 20, 30, '87,77,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2130, 1, 2, 42, 1, 21, 30, '87,77,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2131, 1, 2, 42, 1, 22, 30, '98,88,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2132, 1, 2, 42, 1, 23, 30, '98,88,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2133, 1, 2, 42, 1, 24, 30, '98,79,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2134, 1, 2, 42, 1, 25, 30, '98,98,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2135, 1, 2, 42, 1, 26, 30, '98,98,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2136, 1, 2, 42, 1, 27, 30, '98,87,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2137, 1, 2, 42, 1, 28, 30, '87,87,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2138, 1, 2, 42, 1, 29, 30, '78,89,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2139, 1, 2, 42, 1, 30, 30, '78,98,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2140, 1, 2, 42, 1, 31, 30, '87,99,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2141, 1, 49, 42, 1, 11, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2142, 1, 49, 42, 1, 12, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2143, 1, 49, 42, 1, 13, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2144, 1, 49, 42, 1, 14, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2145, 1, 49, 42, 1, 15, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2146, 1, 49, 42, 1, 16, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2147, 1, 49, 42, 1, 17, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2148, 1, 49, 42, 1, 18, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2149, 1, 49, 42, 1, 19, 33, '77,88,91,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2150, 1, 49, 42, 1, 20, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2151, 1, 49, 42, 1, 21, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2152, 1, 49, 42, 1, 22, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2153, 1, 49, 42, 1, 23, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2154, 1, 49, 42, 1, 24, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2155, 1, 49, 42, 1, 25, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2156, 1, 49, 42, 1, 26, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2157, 1, 49, 42, 1, 27, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2158, 1, 49, 42, 1, 28, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2159, 1, 49, 42, 1, 29, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2160, 1, 49, 42, 1, 30, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2161, 1, 49, 42, 1, 31, 33, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2162, 1, 49, 42, 1, 11, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2163, 1, 49, 42, 1, 12, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2164, 1, 49, 42, 1, 13, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2165, 1, 49, 42, 1, 14, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2166, 1, 49, 42, 1, 15, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2167, 1, 49, 42, 1, 16, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2168, 1, 49, 42, 1, 17, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2169, 1, 49, 42, 1, 18, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2170, 1, 49, 42, 1, 19, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2171, 1, 49, 42, 1, 20, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2172, 1, 49, 42, 1, 21, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2173, 1, 49, 42, 1, 22, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2174, 1, 49, 42, 1, 23, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2175, 1, 49, 42, 1, 24, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2176, 1, 49, 42, 1, 25, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2177, 1, 49, 42, 1, 26, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2178, 1, 49, 42, 1, 27, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2179, 1, 49, 42, 1, 28, 34, '88,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2180, 1, 49, 42, 1, 29, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2181, 1, 49, 42, 1, 30, 34, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2182, 1, 49, 42, 1, 31, 34, '77,77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2183, 1, 50, 42, 1, 11, 39, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2184, 1, 50, 42, 1, 12, 39, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2185, 1, 50, 42, 1, 13, 39, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2186, 1, 50, 42, 1, 14, 39, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2187, 1, 50, 42, 1, 15, 39, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2188, 1, 50, 42, 1, 16, 39, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2189, 1, 50, 42, 1, 17, 39, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2190, 1, 50, 42, 1, 18, 39, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2191, 1, 50, 42, 1, 19, 39, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2192, 1, 50, 42, 1, 20, 39, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2193, 1, 50, 42, 1, 21, 39, '77,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2194, 1, 50, 42, 1, 22, 39, '78,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2195, 1, 50, 42, 1, 23, 39, '88,98,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2196, 1, 50, 42, 1, 24, 39, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2197, 1, 50, 42, 1, 25, 39, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2198, 1, 50, 42, 1, 26, 39, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2199, 1, 50, 42, 1, 27, 39, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2200, 1, 50, 42, 1, 28, 39, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2201, 1, 50, 42, 1, 29, 39, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2202, 1, 50, 42, 1, 30, 39, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2203, 1, 50, 42, 1, 31, 39, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2204, 1, 50, 42, 1, 11, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2205, 1, 50, 42, 1, 12, 40, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2206, 1, 50, 42, 1, 13, 40, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2207, 1, 50, 42, 1, 14, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2208, 1, 50, 42, 1, 15, 40, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2209, 1, 50, 42, 1, 16, 40, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2210, 1, 50, 42, 1, 17, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2211, 1, 50, 42, 1, 18, 40, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2212, 1, 50, 42, 1, 19, 40, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2213, 1, 50, 42, 1, 20, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2214, 1, 50, 42, 1, 21, 40, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2215, 1, 50, 42, 1, 22, 40, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2216, 1, 50, 42, 1, 23, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2217, 1, 50, 42, 1, 24, 40, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2218, 1, 50, 42, 1, 25, 40, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2219, 1, 50, 42, 1, 26, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2220, 1, 50, 42, 1, 27, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2221, 1, 50, 42, 1, 28, 40, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2222, 1, 50, 42, 1, 29, 40, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2223, 1, 50, 42, 1, 30, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2224, 1, 50, 42, 1, 31, 40, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2225, 1, 3, 42, 1, 11, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2226, 1, 3, 42, 1, 12, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2227, 1, 3, 42, 1, 13, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2228, 1, 3, 42, 1, 14, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2229, 1, 3, 42, 1, 15, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2230, 1, 3, 42, 1, 16, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2231, 1, 3, 42, 1, 17, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2232, 1, 3, 42, 1, 18, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2233, 1, 3, 42, 1, 19, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2234, 1, 3, 42, 1, 20, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2235, 1, 3, 42, 1, 21, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2236, 1, 3, 42, 1, 22, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2237, 1, 3, 42, 1, 23, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2238, 1, 3, 42, 1, 24, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2239, 1, 3, 42, 1, 25, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2240, 1, 3, 42, 1, 26, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2241, 1, 3, 42, 1, 27, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2242, 1, 3, 42, 1, 28, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2243, 1, 3, 42, 1, 29, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2244, 1, 3, 42, 1, 30, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2245, 1, 3, 42, 1, 31, 43, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2246, 1, 3, 42, 1, 11, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2247, 1, 3, 42, 1, 12, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2248, 1, 3, 42, 1, 13, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2249, 1, 3, 42, 1, 14, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2250, 1, 3, 42, 1, 15, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2251, 1, 3, 42, 1, 16, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2252, 1, 3, 42, 1, 17, 44, '77,088,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2253, 1, 3, 42, 1, 18, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2254, 1, 3, 42, 1, 19, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2255, 1, 3, 42, 1, 20, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2256, 1, 3, 42, 1, 21, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2257, 1, 3, 42, 1, 22, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2258, 1, 3, 42, 1, 23, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2259, 1, 3, 42, 1, 24, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2260, 1, 3, 42, 1, 25, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2261, 1, 3, 42, 1, 26, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2262, 1, 3, 42, 1, 27, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2263, 1, 3, 42, 1, 28, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2264, 1, 3, 42, 1, 29, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2265, 1, 3, 42, 1, 30, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2266, 1, 3, 42, 1, 31, 44, '77,88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2267, 1, 46, 42, 1, 11, 47, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2268, 1, 46, 42, 1, 12, 47, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2269, 1, 46, 42, 1, 13, 47, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2270, 1, 46, 42, 1, 14, 47, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2271, 1, 46, 42, 1, 15, 47, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2272, 1, 46, 42, 1, 16, 47, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2273, 1, 46, 42, 1, 17, 47, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2274, 1, 46, 42, 1, 18, 47, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2275, 1, 46, 42, 1, 19, 47, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2276, 1, 46, 42, 1, 20, 47, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2277, 1, 46, 42, 1, 21, 47, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2278, 1, 46, 42, 1, 22, 47, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2279, 1, 46, 42, 1, 23, 47, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2280, 1, 46, 42, 1, 24, 47, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2281, 1, 46, 42, 1, 25, 47, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2282, 1, 46, 42, 1, 26, 47, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2283, 1, 46, 42, 1, 27, 47, '77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2284, 1, 46, 42, 1, 28, 47, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2285, 1, 46, 42, 1, 29, 47, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2286, 1, 46, 42, 1, 30, 47, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2287, 1, 46, 42, 1, 31, 47, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2288, 1, 46, 42, 1, 11, 48, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2289, 1, 46, 42, 1, 12, 48, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2290, 1, 46, 42, 1, 13, 48, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2291, 1, 46, 42, 1, 14, 48, '98,98,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2292, 1, 46, 42, 1, 15, 48, '78,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2293, 1, 46, 42, 1, 16, 48, '89,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2294, 1, 46, 42, 1, 17, 48, '87,78,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2295, 1, 46, 42, 1, 18, 48, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2296, 1, 46, 42, 1, 19, 48, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2297, 1, 46, 42, 1, 20, 48, '99,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2298, 1, 46, 42, 1, 21, 48, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2299, 1, 46, 42, 1, 22, 48, '88,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2300, 1, 46, 42, 1, 23, 48, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2301, 1, 46, 42, 1, 24, 48, '77,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2302, 1, 46, 42, 1, 25, 48, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2303, 1, 46, 42, 1, 26, 48, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2304, 1, 46, 42, 1, 27, 48, '99,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2305, 1, 46, 42, 1, 28, 48, '88,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2306, 1, 46, 42, 1, 29, 48, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2307, 1, 46, 42, 1, 30, 48, '88,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2308, 1, 46, 42, 1, 31, 48, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2309, 1, 47, 42, 1, 11, 51, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2310, 1, 47, 42, 1, 12, 51, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2311, 1, 47, 42, 1, 13, 51, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2312, 1, 47, 42, 1, 14, 51, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2313, 1, 47, 42, 1, 15, 51, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2314, 1, 47, 42, 1, 16, 51, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2315, 1, 47, 42, 1, 17, 51, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2316, 1, 47, 42, 1, 18, 51, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2317, 1, 47, 42, 1, 19, 51, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2318, 1, 47, 42, 1, 20, 51, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2319, 1, 47, 42, 1, 21, 51, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2320, 1, 47, 42, 1, 22, 51, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2321, 1, 47, 42, 1, 23, 51, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2322, 1, 47, 42, 1, 24, 51, '88,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2323, 1, 47, 42, 1, 25, 51, '66,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2324, 1, 47, 42, 1, 26, 51, '88,66,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2325, 1, 47, 42, 1, 27, 51, '66,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2326, 1, 47, 42, 1, 28, 51, '99,75,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2327, 1, 47, 42, 1, 29, 51, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2328, 1, 47, 42, 1, 30, 51, '77,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2329, 1, 47, 42, 1, 31, 51, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2330, 1, 47, 42, 1, 11, 52, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2331, 1, 47, 42, 1, 12, 52, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2332, 1, 47, 42, 1, 13, 52, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2333, 1, 47, 42, 1, 14, 52, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2334, 1, 47, 42, 1, 15, 52, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2335, 1, 47, 42, 1, 16, 52, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2336, 1, 47, 42, 1, 17, 52, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2337, 1, 47, 42, 1, 18, 52, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2338, 1, 47, 42, 1, 19, 52, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2339, 1, 47, 42, 1, 20, 52, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2340, 1, 47, 42, 1, 21, 52, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2341, 1, 47, 42, 1, 22, 52, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2342, 1, 47, 42, 1, 23, 52, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2343, 1, 47, 42, 1, 24, 52, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2344, 1, 47, 42, 1, 25, 52, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2345, 1, 47, 42, 1, 26, 52, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2346, 1, 47, 42, 1, 27, 52, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2347, 1, 47, 42, 1, 28, 52, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2348, 1, 47, 42, 1, 29, 52, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2349, 1, 47, 42, 1, 30, 52, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2350, 1, 47, 42, 1, 31, 52, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2351, 1, 1, 40, 1, 11, 55, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2352, 1, 1, 40, 1, 12, 55, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2353, 1, 1, 40, 1, 13, 55, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2354, 1, 1, 40, 1, 14, 55, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2355, 1, 1, 40, 1, 15, 55, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2356, 1, 1, 40, 1, 16, 55, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2357, 1, 1, 40, 1, 17, 55, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2358, 1, 1, 40, 1, 18, 55, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2359, 1, 1, 40, 1, 19, 55, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2360, 1, 1, 40, 1, 20, 55, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2361, 1, 1, 40, 1, 21, 55, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2362, 1, 1, 40, 1, 22, 55, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2363, 1, 1, 40, 1, 23, 55, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2364, 1, 1, 40, 1, 24, 55, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2365, 1, 1, 40, 1, 25, 55, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2366, 1, 1, 40, 1, 26, 55, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2367, 1, 1, 40, 1, 27, 55, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2368, 1, 1, 40, 1, 28, 55, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2369, 1, 1, 40, 1, 29, 55, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2370, 1, 1, 40, 1, 30, 55, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2371, 1, 1, 40, 1, 31, 55, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2372, 1, 1, 40, 1, 11, 56, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2373, 1, 1, 40, 1, 12, 56, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2374, 1, 1, 40, 1, 13, 56, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2375, 1, 1, 40, 1, 14, 56, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2376, 1, 1, 40, 1, 15, 56, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2377, 1, 1, 40, 1, 16, 56, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2378, 1, 1, 40, 1, 17, 56, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2379, 1, 1, 40, 1, 18, 56, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2380, 1, 1, 40, 1, 19, 56, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2381, 1, 1, 40, 1, 20, 56, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2382, 1, 1, 40, 1, 21, 56, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2383, 1, 1, 40, 1, 22, 56, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2384, 1, 1, 40, 1, 23, 56, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2385, 1, 1, 40, 1, 24, 56, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2386, 1, 1, 40, 1, 25, 56, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2387, 1, 1, 40, 1, 26, 56, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2388, 1, 1, 40, 1, 27, 56, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2389, 1, 1, 40, 1, 28, 56, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2390, 1, 1, 40, 1, 29, 56, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2391, 1, 1, 40, 1, 30, 56, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2392, 1, 1, 40, 1, 31, 56, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2393, 1, 48, 39, 1, 11, 59, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2394, 1, 48, 39, 1, 12, 59, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2395, 1, 48, 39, 1, 13, 59, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2396, 1, 48, 39, 1, 14, 59, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2397, 1, 48, 39, 1, 15, 59, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2398, 1, 48, 39, 1, 16, 59, '77,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2399, 1, 48, 39, 1, 17, 59, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2400, 1, 48, 39, 1, 18, 59, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2401, 1, 48, 39, 1, 19, 59, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2402, 1, 48, 39, 1, 20, 59, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2403, 1, 48, 39, 1, 21, 59, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2404, 1, 48, 39, 1, 22, 59, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2405, 1, 48, 39, 1, 23, 59, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2406, 1, 48, 39, 1, 24, 59, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2407, 1, 48, 39, 1, 25, 59, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2408, 1, 48, 39, 1, 26, 59, '77,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2409, 1, 48, 39, 1, 27, 59, '77,98,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2410, 1, 48, 39, 1, 28, 59, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2411, 1, 48, 39, 1, 29, 59, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2412, 1, 48, 39, 1, 30, 59, '88,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2413, 1, 48, 39, 1, 31, 59, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2414, 1, 51, 41, 1, 11, 61, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2415, 1, 51, 41, 1, 12, 61, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2416, 1, 51, 41, 1, 13, 61, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2417, 1, 51, 41, 1, 14, 61, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2418, 1, 51, 41, 1, 15, 61, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2419, 1, 51, 41, 1, 16, 61, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2420, 1, 51, 41, 1, 17, 61, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2421, 1, 51, 41, 1, 18, 61, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2422, 1, 51, 41, 1, 19, 61, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2423, 1, 51, 41, 1, 20, 61, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2424, 1, 51, 41, 1, 21, 61, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2425, 1, 51, 41, 1, 22, 61, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2426, 1, 51, 41, 1, 23, 61, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2427, 1, 51, 41, 1, 24, 61, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2428, 1, 51, 41, 1, 25, 61, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2429, 1, 51, 41, 1, 26, 61, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2430, 1, 51, 41, 1, 27, 61, '99,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2431, 1, 51, 41, 1, 28, 61, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2432, 1, 51, 41, 1, 29, 61, '88,86,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2433, 1, 51, 41, 1, 30, 61, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2434, 1, 51, 41, 1, 31, 61, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2438, 2, 2, 42, 1, 11, 67, '80,80,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2439, 2, 2, 42, 1, 12, 67, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2440, 2, 2, 42, 1, 13, 67, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2441, 2, 2, 42, 1, 14, 67, '77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2442, 2, 2, 42, 1, 15, 67, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2443, 2, 2, 42, 1, 16, 67, '77,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2444, 2, 2, 42, 1, 17, 67, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2445, 2, 2, 42, 1, 18, 67, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2446, 2, 2, 42, 1, 19, 67, '75,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2447, 2, 2, 42, 1, 20, 67, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2448, 2, 2, 42, 1, 21, 67, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2449, 2, 2, 42, 1, 22, 67, '88,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2450, 2, 2, 42, 1, 23, 67, '77,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2451, 2, 2, 42, 1, 24, 67, '77,99,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2452, 2, 2, 42, 1, 25, 67, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2453, 2, 2, 42, 1, 26, 67, '77,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2454, 2, 2, 42, 1, 27, 67, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2455, 2, 2, 42, 1, 28, 67, '99,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2456, 2, 2, 42, 1, 29, 67, '76,77,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2457, 2, 2, 42, 1, 30, 67, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2458, 2, 2, 42, 1, 31, 67, '88,88,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2469, 1, 2, 57, 17, 142, 63, '100,100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2470, 1, 51, 57, 17, 142, 65, '100,100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2478, 1, 2, 37, 2, 32, 71, '1,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2479, 1, 2, 37, 2, 33, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2480, 1, 2, 37, 2, 34, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2481, 1, 2, 37, 2, 39, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2482, 1, 2, 37, 2, 40, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2483, 1, 2, 37, 2, 41, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2484, 1, 2, 37, 2, 42, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2485, 1, 2, 37, 2, 43, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2486, 1, 2, 37, 2, 44, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2487, 1, 2, 37, 2, 45, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2488, 1, 2, 37, 2, 46, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2489, 1, 2, 37, 2, 47, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2490, 1, 2, 37, 2, 48, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2491, 1, 2, 37, 2, 49, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2492, 1, 2, 37, 2, 50, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2493, 1, 2, 37, 2, 51, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2494, 1, 2, 37, 2, 52, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2495, 1, 2, 37, 2, 53, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2496, 1, 2, 37, 2, 54, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2497, 1, 2, 37, 2, 55, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2498, 1, 2, 37, 2, 56, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2499, 1, 2, 37, 2, 57, 71, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2500, 1, 49, 37, 2, 32, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2501, 1, 49, 37, 2, 33, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2502, 1, 49, 37, 2, 34, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2503, 1, 49, 37, 2, 39, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2504, 1, 49, 37, 2, 40, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2505, 1, 49, 37, 2, 41, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2506, 1, 49, 37, 2, 42, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2507, 1, 49, 37, 2, 43, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2508, 1, 49, 37, 2, 44, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2509, 1, 49, 37, 2, 45, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2510, 1, 49, 37, 2, 46, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2511, 1, 49, 37, 2, 47, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2512, 1, 49, 37, 2, 48, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2513, 1, 49, 37, 2, 49, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2514, 1, 49, 37, 2, 50, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2515, 1, 49, 37, 2, 51, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2516, 1, 49, 37, 2, 52, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2517, 1, 49, 37, 2, 53, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2518, 1, 49, 37, 2, 54, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2519, 1, 49, 37, 2, 55, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2520, 1, 49, 37, 2, 56, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2521, 1, 49, 37, 2, 57, 73, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2522, 1, 50, 37, 2, 32, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2523, 1, 50, 37, 2, 33, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2524, 1, 50, 37, 2, 34, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2525, 1, 50, 37, 2, 39, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2526, 1, 50, 37, 2, 40, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2527, 1, 50, 37, 2, 41, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2528, 1, 50, 37, 2, 42, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2529, 1, 50, 37, 2, 43, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2530, 1, 50, 37, 2, 44, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2531, 1, 50, 37, 2, 45, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2532, 1, 50, 37, 2, 46, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2533, 1, 50, 37, 2, 47, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2534, 1, 50, 37, 2, 48, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2535, 1, 50, 37, 2, 49, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2536, 1, 50, 37, 2, 50, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2537, 1, 50, 37, 2, 51, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2538, 1, 50, 37, 2, 52, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2539, 1, 50, 37, 2, 53, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2540, 1, 50, 37, 2, 54, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2541, 1, 50, 37, 2, 55, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2542, 1, 50, 37, 2, 56, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2543, 1, 50, 37, 2, 57, 75, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2544, 1, 3, 37, 2, 32, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2545, 1, 3, 37, 2, 33, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2546, 1, 3, 37, 2, 34, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2547, 1, 3, 37, 2, 39, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2548, 1, 3, 37, 2, 40, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2549, 1, 3, 37, 2, 41, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2550, 1, 3, 37, 2, 42, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2551, 1, 3, 37, 2, 43, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2552, 1, 3, 37, 2, 44, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2553, 1, 3, 37, 2, 45, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2554, 1, 3, 37, 2, 46, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2555, 1, 3, 37, 2, 47, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2556, 1, 3, 37, 2, 48, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2557, 1, 3, 37, 2, 49, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2558, 1, 3, 37, 2, 50, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2559, 1, 3, 37, 2, 51, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2560, 1, 3, 37, 2, 52, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2561, 1, 3, 37, 2, 53, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2562, 1, 3, 37, 2, 54, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2563, 1, 3, 37, 2, 55, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2564, 1, 3, 37, 2, 56, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2565, 1, 3, 37, 2, 57, 77, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2566, 1, 46, 37, 2, 32, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2567, 1, 46, 37, 2, 33, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2568, 1, 46, 37, 2, 34, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2569, 1, 46, 37, 2, 39, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2570, 1, 46, 37, 2, 40, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2571, 1, 46, 37, 2, 41, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2572, 1, 46, 37, 2, 42, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2573, 1, 46, 37, 2, 43, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2574, 1, 46, 37, 2, 44, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2575, 1, 46, 37, 2, 45, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2576, 1, 46, 37, 2, 46, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2577, 1, 46, 37, 2, 47, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2578, 1, 46, 37, 2, 48, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2579, 1, 46, 37, 2, 49, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2580, 1, 46, 37, 2, 50, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2581, 1, 46, 37, 2, 51, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2582, 1, 46, 37, 2, 52, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2583, 1, 46, 37, 2, 53, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2584, 1, 46, 37, 2, 54, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2585, 1, 46, 37, 2, 55, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2586, 1, 46, 37, 2, 56, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2587, 1, 46, 37, 2, 57, 79, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2588, 1, 47, 37, 2, 32, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2589, 1, 47, 37, 2, 33, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2590, 1, 47, 37, 2, 34, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2591, 1, 47, 37, 2, 39, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2592, 1, 47, 37, 2, 40, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2593, 1, 47, 37, 2, 41, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2594, 1, 47, 37, 2, 42, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2595, 1, 47, 37, 2, 43, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2596, 1, 47, 37, 2, 44, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2597, 1, 47, 37, 2, 45, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2598, 1, 47, 37, 2, 46, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2599, 1, 47, 37, 2, 47, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2600, 1, 47, 37, 2, 48, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2601, 1, 47, 37, 2, 49, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2602, 1, 47, 37, 2, 50, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2603, 1, 47, 37, 2, 51, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2604, 1, 47, 37, 2, 52, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2605, 1, 47, 37, 2, 53, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2606, 1, 47, 37, 2, 54, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2607, 1, 47, 37, 2, 55, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2608, 1, 47, 37, 2, 56, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2609, 1, 47, 37, 2, 57, 81, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2610, 1, 1, 40, 2, 32, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2611, 1, 1, 40, 2, 33, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2612, 1, 1, 40, 2, 34, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2613, 1, 1, 40, 2, 39, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2614, 1, 1, 40, 2, 40, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2615, 1, 1, 40, 2, 41, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2616, 1, 1, 40, 2, 42, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2617, 1, 1, 40, 2, 43, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2618, 1, 1, 40, 2, 44, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2619, 1, 1, 40, 2, 45, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2620, 1, 1, 40, 2, 46, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2621, 1, 1, 40, 2, 47, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2622, 1, 1, 40, 2, 48, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2623, 1, 1, 40, 2, 49, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2624, 1, 1, 40, 2, 50, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2625, 1, 1, 40, 2, 51, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2626, 1, 1, 40, 2, 52, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2627, 1, 1, 40, 2, 53, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2628, 1, 1, 40, 2, 54, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2629, 1, 1, 40, 2, 55, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2630, 1, 1, 40, 2, 56, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2631, 1, 1, 40, 2, 57, 83, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2632, 1, 51, 41, 2, 32, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2633, 1, 51, 41, 2, 33, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2634, 1, 51, 41, 2, 34, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2635, 1, 51, 41, 2, 39, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2636, 1, 51, 41, 2, 40, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2637, 1, 51, 41, 2, 41, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2638, 1, 51, 41, 2, 42, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2639, 1, 51, 41, 2, 43, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2640, 1, 51, 41, 2, 44, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2641, 1, 51, 41, 2, 45, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2642, 1, 51, 41, 2, 46, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2643, 1, 51, 41, 2, 47, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2644, 1, 51, 41, 2, 48, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2645, 1, 51, 41, 2, 49, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2646, 1, 51, 41, 2, 50, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2647, 1, 51, 41, 2, 51, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2648, 1, 51, 41, 2, 52, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2649, 1, 51, 41, 2, 53, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2650, 1, 51, 41, 2, 54, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2651, 1, 51, 41, 2, 55, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2652, 1, 51, 41, 2, 56, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2653, 1, 51, 41, 2, 57, 85, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2654, 1, 48, 39, 2, 32, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2655, 1, 48, 39, 2, 33, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2656, 1, 48, 39, 2, 34, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2657, 1, 48, 39, 2, 39, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2658, 1, 48, 39, 2, 40, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2659, 1, 48, 39, 2, 41, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2660, 1, 48, 39, 2, 42, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2661, 1, 48, 39, 2, 43, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2662, 1, 48, 39, 2, 44, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2663, 1, 48, 39, 2, 45, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2664, 1, 48, 39, 2, 46, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2665, 1, 48, 39, 2, 47, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2666, 1, 48, 39, 2, 48, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2667, 1, 48, 39, 2, 49, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2668, 1, 48, 39, 2, 50, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2669, 1, 48, 39, 2, 51, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2670, 1, 48, 39, 2, 52, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2671, 1, 48, 39, 2, 53, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2672, 1, 48, 39, 2, 54, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2673, 1, 48, 39, 2, 55, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2674, 1, 48, 39, 2, 56, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2675, 1, 48, 39, 2, 57, 87, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2676, 2, 49, 42, 1, 11, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2677, 2, 49, 42, 1, 12, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2678, 2, 49, 42, 1, 13, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2679, 2, 49, 42, 1, 14, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2680, 2, 49, 42, 1, 15, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2681, 2, 49, 42, 1, 16, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2682, 2, 49, 42, 1, 17, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2683, 2, 49, 42, 1, 18, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2684, 2, 49, 42, 1, 19, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2685, 2, 49, 42, 1, 20, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2686, 2, 49, 42, 1, 21, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2687, 2, 49, 42, 1, 22, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2688, 2, 49, 42, 1, 23, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2689, 2, 49, 42, 1, 24, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2690, 2, 49, 42, 1, 25, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2691, 2, 49, 42, 1, 26, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2692, 2, 49, 42, 1, 27, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2693, 2, 49, 42, 1, 28, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2694, 2, 49, 42, 1, 29, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2695, 2, 49, 42, 1, 30, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2696, 2, 49, 42, 1, 31, 89, '100,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2697, 1, 2, 44, 5, 109, 91, '12,12,12,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2698, 1, 2, 44, 5, 110, 91, '12,12,12,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2699, 1, 2, 44, 5, 111, 91, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2700, 1, 2, 44, 5, 112, 91, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2701, 1, 2, 44, 5, 113, 91, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2702, 1, 2, 44, 5, 114, 91, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2703, 1, 2, 44, 5, 115, 91, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2704, 1, 2, 44, 5, 116, 91, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2705, 1, 2, 44, 5, 117, 91, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2706, 1, 2, 44, 5, 118, 91, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2707, 1, 2, 44, 5, 119, 91, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2708, 1, 2, 44, 5, 120, 91, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2709, 1, 2, 44, 5, 121, 91, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2710, 1, 2, 44, 5, 122, 91, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2711, 1, 2, 44, 5, 123, 91, '');


#
# TABLE STRUCTURE FOR: sr_pajak_keuangan
#

DROP TABLE IF EXISTS `sr_pajak_keuangan`;

CREATE TABLE `sr_pajak_keuangan` (
  `id_pajak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pajak` varchar(200) NOT NULL,
  `besaran_pajak` varchar(100) NOT NULL,
  PRIMARY KEY (`id_pajak`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pajak_keuangan` (`id_pajak`, `nama_pajak`, `besaran_pajak`) VALUES (6, 'sdf', '10');


#
# TABLE STRUCTURE FOR: sr_paketsoal
#

DROP TABLE IF EXISTS `sr_paketsoal`;

CREATE TABLE `sr_paketsoal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_guru` int(10) NOT NULL,
  `id_mapel` int(10) NOT NULL,
  `nama_paket` varchar(100) NOT NULL,
  `jumlah_soal` int(5) NOT NULL,
  `unit` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_paketsoal` (`id`, `id_guru`, `id_mapel`, `nama_paket`, `jumlah_soal`, `unit`) VALUES (8, 1, 3, 'Matematika', 10, 5);
INSERT INTO `sr_paketsoal` (`id`, `id_guru`, `id_mapel`, `nama_paket`, `jumlah_soal`, `unit`) VALUES (9, 1, 3, 'ujian matematika', 10, 5);


#
# TABLE STRUCTURE FOR: sr_pembayaran_bebas
#

DROP TABLE IF EXISTS `sr_pembayaran_bebas`;

CREATE TABLE `sr_pembayaran_bebas` (
  `id_pembayaran_bebas` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `tanggal` varchar(30) DEFAULT NULL,
  `bayar` float(30,0) DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran_bebas`)
) ENGINE=InnoDB AUTO_INCREMENT=158 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_pembayaran_bulanan
#

DROP TABLE IF EXISTS `sr_pembayaran_bulanan`;

CREATE TABLE `sr_pembayaran_bulanan` (
  `id_pembayaran_bulanan` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `bulan` varchar(15) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `bayar` float DEFAULT 0,
  `tanggal` varchar(20) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran_bulanan`)
) ENGINE=InnoDB AUTO_INCREMENT=5149 DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_pengaduan
#

DROP TABLE IF EXISTS `sr_pengaduan`;

CREATE TABLE `sr_pengaduan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `what` varchar(100) NOT NULL,
  `where` varchar(100) NOT NULL,
  `when` varchar(100) NOT NULL,
  `how` varchar(225) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `bukti` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_pengumuman
#

DROP TABLE IF EXISTS `sr_pengumuman`;

CREATE TABLE `sr_pengumuman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `konten` text NOT NULL,
  `tgl_tampil` date NOT NULL,
  `tgl_tutup` date NOT NULL,
  `tampil_siswa` tinyint(1) NOT NULL DEFAULT 1,
  `tampil_pengajar` tinyint(1) NOT NULL DEFAULT 1,
  `pengajar_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pengajar_id` (`pengajar_id`),
  KEY `pengajar_id_2` (`pengajar_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `sr_pengumuman` (`id`, `judul`, `konten`, `tgl_tampil`, `tgl_tutup`, `tampil_siswa`, `tampil_pengajar`, `pengajar_id`) VALUES (6, 'imlek', '<p>Kepada seluruh SISWA, Libur <strong>IMLEK </strong>akan tiba!</p>\r\n', '2022-01-01', '2022-02-19', 1, 1, 1);


#
# TABLE STRUCTURE FOR: sr_perpusbiaya
#

DROP TABLE IF EXISTS `sr_perpusbiaya`;

CREATE TABLE `sr_perpusbiaya` (
  `id_biaya_denda` int(11) NOT NULL AUTO_INCREMENT,
  `harga_denda` varchar(255) NOT NULL,
  `stat` varchar(255) NOT NULL,
  `tgl_tetap` varchar(255) NOT NULL,
  PRIMARY KEY (`id_biaya_denda`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusbiaya` (`id_biaya_denda`, `harga_denda`, `stat`, `tgl_tetap`) VALUES (1, '40005', 'Aktif', '2019-11-23');


#
# TABLE STRUCTURE FOR: sr_perpusbuku
#

DROP TABLE IF EXISTS `sr_perpusbuku`;

CREATE TABLE `sr_perpusbuku` (
  `id_buku` int(11) NOT NULL AUTO_INCREMENT,
  `buku_id` varchar(255) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_rak` int(11) NOT NULL,
  `sampul` varchar(255) DEFAULT NULL,
  `isbn` varchar(255) DEFAULT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `penerbit` varchar(255) DEFAULT NULL,
  `pengarang` varchar(255) DEFAULT NULL,
  `thn_buku` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `jml` int(11) DEFAULT NULL,
  `tgl_masuk` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_buku`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusbuku` (`id_buku`, `buku_id`, `id_kategori`, `id_rak`, `sampul`, `isbn`, `lampiran`, `title`, `penerbit`, `pengarang`, `thn_buku`, `isi`, `jml`, `tgl_masuk`) VALUES (8, 'BK008', 2, 1, '0', '132-123-234-231', '0', 'CARA MUDAH BELAJAR PEMROGRAMAN C++', 'INFORMATIKA BANDUNG', 'BUDI RAHARJO ', '2012', '<table class=\"table table-bordered\" style=\"background-color: rgb(255, 255, 255); width: 653px; color: rgb(51, 51, 51);\"><tbody><tr><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Tipe Buku</td><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Kertas</td></tr><tr><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Bahasa</td><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Indonesia</td></tr></tbody></table>', 23, '2019-11-23 11:49:57');
INSERT INTO `sr_perpusbuku` (`id_buku`, `buku_id`, `id_kategori`, `id_rak`, `sampul`, `isbn`, `lampiran`, `title`, `penerbit`, `pengarang`, `thn_buku`, `isi`, `jml`, `tgl_masuk`) VALUES (9, 'BK009', 2, 1, NULL, '121-163-214-231', NULL, 'Perkembangan Tekhnologi WEB 2.0', 'Maju Haya', 'Reza Lesmana', '2022', NULL, 121, '2019-11-23 11:49:57');


#
# TABLE STRUCTURE FOR: sr_perpusdenda
#

DROP TABLE IF EXISTS `sr_perpusdenda`;

CREATE TABLE `sr_perpusdenda` (
  `id_denda` int(11) NOT NULL AUTO_INCREMENT,
  `pinjam_id` varchar(255) NOT NULL,
  `denda` varchar(255) NOT NULL,
  `lama_waktu` int(11) NOT NULL,
  `tgl_denda` varchar(255) NOT NULL,
  PRIMARY KEY (`id_denda`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (3, 'PJ001', '0', 0, '2020-05-20');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (5, 'PJ009', '0', 0, '2020-05-20');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (6, 'PJ0012', '0', 0, '2022-03-14');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (7, 'PJ0011', '0', 0, '2022-03-14');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (8, 'PJ0013', '0', 0, '2022-03-14');


#
# TABLE STRUCTURE FOR: sr_perpuskategori
#

DROP TABLE IF EXISTS `sr_perpuskategori`;

CREATE TABLE `sr_perpuskategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (2, 'Pemrograman');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (3, 'Kamus');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (4, 'Almanak');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (5, 'Direktori');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (6, 'Ensiklopedia');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (7, 'Buku Ajar');


#
# TABLE STRUCTURE FOR: sr_perpuspinjam
#

DROP TABLE IF EXISTS `sr_perpuspinjam`;

CREATE TABLE `sr_perpuspinjam` (
  `id_pinjam` int(11) NOT NULL AUTO_INCREMENT,
  `pinjam_id` varchar(255) NOT NULL,
  `anggota_id` varchar(255) NOT NULL,
  `buku_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `tgl_pinjam` varchar(255) NOT NULL,
  `lama_pinjam` int(11) NOT NULL,
  `tgl_balik` varchar(255) NOT NULL,
  `tgl_kembali` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_pinjam`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (11, 'PJ0011', '11', 'BK009', 'Di Kembalikan', '2022-03-14', 2, '2022-03-16', '2022-03-14');
INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (12, 'PJ0012', '11', 'BK009', 'Di Kembalikan', '2022-03-14', 2, '2022-03-16', '2022-03-14');
INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (13, 'PJ0013', '14', 'BK009', 'Di Kembalikan', '2022-03-14', 5, '2022-03-19', '2022-03-14');


#
# TABLE STRUCTURE FOR: sr_perpusrak
#

DROP TABLE IF EXISTS `sr_perpusrak`;

CREATE TABLE `sr_perpusrak` (
  `id_rak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_rak` varchar(255) NOT NULL,
  PRIMARY KEY (`id_rak`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusrak` (`id_rak`, `nama_rak`) VALUES (1, 'Rak Buku 1');
INSERT INTO `sr_perpusrak` (`id_rak`, `nama_rak`) VALUES (3, 'Rak Buku 2');


#
# TABLE STRUCTURE FOR: sr_pos_pembayaran
#

DROP TABLE IF EXISTS `sr_pos_pembayaran`;

CREATE TABLE `sr_pos_pembayaran` (
  `id_pos` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `kode_akun` varchar(5) DEFAULT NULL,
  `akun_piutang` varchar(5) DEFAULT NULL,
  `nama_pos` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  PRIMARY KEY (`id_pos`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pos_pembayaran` (`id_pos`, `unit`, `kode_akun`, `akun_piutang`, `nama_pos`, `keterangan`) VALUES (1, '5', '62265', '62265', 'SPP', 'Sumbangan Pendanaan Pendidikan');
INSERT INTO `sr_pos_pembayaran` (`id_pos`, `unit`, `kode_akun`, `akun_piutang`, `nama_pos`, `keterangan`) VALUES (2, '5', '1', '62265', 'Biaya Bangunan', 'Bangunan Sekolah');
INSERT INTO `sr_pos_pembayaran` (`id_pos`, `unit`, `kode_akun`, `akun_piutang`, `nama_pos`, `keterangan`) VALUES (3, '5', '62264', '62265', 'Buku Paket', 'Paket SMA');


#
# TABLE STRUCTURE FOR: sr_ppdb
#

DROP TABLE IF EXISTS `sr_ppdb`;

CREATE TABLE `sr_ppdb` (
  `id_ppdb` int(10) NOT NULL AUTO_INCREMENT,
  `no_pendaftaran` varchar(30) DEFAULT NULL,
  `nik` varchar(25) DEFAULT NULL,
  `jenis_pendaftaran` varchar(25) DEFAULT NULL,
  `jalur_pendaftaran` varchar(25) DEFAULT NULL,
  `hobi` varchar(55) DEFAULT NULL,
  `cita_cita` varchar(55) DEFAULT NULL,
  `nama_siswa` varchar(100) DEFAULT NULL,
  `jenis_kelamin` varchar(15) DEFAULT NULL,
  `tempat_lahir` varchar(55) DEFAULT NULL,
  `tanggal_lahir` varchar(15) DEFAULT NULL,
  `agama` varchar(15) DEFAULT NULL,
  `alamat` varchar(155) DEFAULT NULL,
  `rt` varchar(4) DEFAULT NULL,
  `rw` varchar(4) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kota` varchar(100) DEFAULT NULL,
  `kode_pos` varchar(15) DEFAULT NULL,
  `tempat_tinggal` varchar(55) DEFAULT NULL,
  `transportasi` varchar(15) DEFAULT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `kewarganegaraan` varchar(15) DEFAULT NULL,
  `foto` varchar(155) DEFAULT NULL,
  `tinggi_badan` varchar(3) DEFAULT NULL,
  `berat_badan` varchar(3) DEFAULT NULL,
  `jarak_ke_sekolah` varchar(4) DEFAULT NULL,
  `waktu_tempuh_ke_sekolah` varchar(4) DEFAULT NULL,
  `jumlah_saudara` varchar(2) DEFAULT NULL,
  `asal_sekolah` varchar(255) NOT NULL,
  `alamat_sekolah_asal` varchar(255) NOT NULL,
  `nama_ayah` varchar(55) DEFAULT NULL,
  `tahun_lahir_ayah` varchar(4) DEFAULT NULL,
  `pendidikan_ayah` varchar(15) DEFAULT NULL,
  `pekerjaan_ayah` varchar(55) DEFAULT NULL,
  `penghasilan_ayah` varchar(55) DEFAULT NULL,
  `nama_ibu` varchar(55) DEFAULT NULL,
  `tahun_lahir_ibu` varchar(4) DEFAULT NULL,
  `pendidikan_ibu` varchar(15) DEFAULT NULL,
  `pekerjaan_ibu` varchar(55) DEFAULT NULL,
  `penghasilan_ibu` varchar(55) DEFAULT NULL,
  `nama_wali` varchar(55) DEFAULT NULL,
  `tahun_lahir_wali` varchar(4) DEFAULT NULL,
  `pendidikan_wali` varchar(15) DEFAULT NULL,
  `pekerjaan_wali` varchar(55) DEFAULT NULL,
  `penghasilan_wali` varchar(50) DEFAULT NULL,
  `status` char(1) DEFAULT '0',
  `tanggal_daftar` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_ppdb`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `sr_ppdb` (`id_ppdb`, `no_pendaftaran`, `nik`, `jenis_pendaftaran`, `jalur_pendaftaran`, `hobi`, `cita_cita`, `nama_siswa`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `agama`, `alamat`, `rt`, `rw`, `provinsi`, `kota`, `kode_pos`, `tempat_tinggal`, `transportasi`, `no_hp`, `email`, `kewarganegaraan`, `foto`, `tinggi_badan`, `berat_badan`, `jarak_ke_sekolah`, `waktu_tempuh_ke_sekolah`, `jumlah_saudara`, `asal_sekolah`, `alamat_sekolah_asal`, `nama_ayah`, `tahun_lahir_ayah`, `pendidikan_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nama_ibu`, `tahun_lahir_ibu`, `pendidikan_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nama_wali`, `tahun_lahir_wali`, `pendidikan_wali`, `pekerjaan_wali`, `penghasilan_wali`, `status`, `tanggal_daftar`) VALUES (3, 'PPDB.20220325-0001', '3275100211000012', 'Baru', 'Umum', 'berenang', 'masinis', 'Riska Bunga', 'Laki-laki', 'Jakarta', '1992-01-22', 'Islam', 'Jl.pertengahan Gg.kramat4', '01', '14', 'Kepulauan Riau', NULL, '13770', 'Kos', '', '081280462650', 'rzalvaero@gmail.com', 'WNI', '', '170', '50', '12', '', '3', 'smp malahayati', 'Jl Jatimakmur', 'Andriansyah', '', 'Pendidikan', 'Pekerjaan', 'Pendapatan', '', '', 'Pendidikan', 'Pekerjaan', 'Pendapatan', '', '', NULL, 'Pekerjaan', 'Pendapatan', '0', '2022-03-25 09:48:07');


#
# TABLE STRUCTURE FOR: sr_prota
#

DROP TABLE IF EXISTS `sr_prota`;

CREATE TABLE `sr_prota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `semester` varchar(100) NOT NULL,
  `pengetahuan` varchar(255) NOT NULL,
  `keterampilan` varchar(225) NOT NULL,
  `waktu` varchar(100) NOT NULL,
  `ket` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_prota` (`id`, `unit`, `semester`, `pengetahuan`, `keterampilan`, `waktu`, `ket`) VALUES (1, '5', '2021/2022-2', 'Pengetahuan Dasar', 'Keterampilan Dasar', '3 Pertemuan / 3 x 40', 'Keterngan');


#
# TABLE STRUCTURE FOR: sr_provinsi
#

DROP TABLE IF EXISTS `sr_provinsi`;

CREATE TABLE `sr_provinsi` (
  `province_id` int(11) NOT NULL,
  `province` varchar(100) NOT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (1, 'Bali');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (2, 'Bangka Belitung');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (3, 'Banten');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (4, 'Bengkulu');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (5, 'DI Yogyakarta');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (6, 'DKI Jakarta');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (7, 'Gorontalo');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (8, 'Jambi');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (9, 'Jawa Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (10, 'Jawa Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (11, 'Jawa Timur');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (12, 'Kalimantan Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (13, 'Kalimantan Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (14, 'Kalimantan Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (15, 'Kalimantan Timur');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (16, 'Kalimantan Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (17, 'Kepulauan Riau');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (18, 'Lampung');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (19, 'Maluku');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (20, 'Maluku Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (21, 'Nanggroe Aceh Darussalam (NAD)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (22, 'Nusa Tenggara Barat (NTB)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (23, 'Nusa Tenggara Timur (NTT)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (24, 'Papua');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (25, 'Papua Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (26, 'Riau');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (27, 'Sulawesi Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (28, 'Sulawesi Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (29, 'Sulawesi Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (30, 'Sulawesi Tenggara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (31, 'Sulawesi Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (32, 'Sumatera Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (33, 'Sumatera Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (34, 'Sumatera Utara');


#
# TABLE STRUCTURE FOR: sr_rencana_kd_keterampilan
#

DROP TABLE IF EXISTS `sr_rencana_kd_keterampilan`;

CREATE TABLE `sr_rencana_kd_keterampilan` (
  `idrencana_kd_keterampilan` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `rkdk_penilaian_harian` int(11) NOT NULL,
  PRIMARY KEY (`idrencana_kd_keterampilan`),
  KEY `idusers` (`idusers`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idkelas` (`idkelas`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_rencana_kd_keterampilan_ibfk_1` FOREIGN KEY (`idtahun_pelajaran`) REFERENCES `sr_tahun_pelajaran` (`idtahun_pelajaran`),
  CONSTRAINT `sr_rencana_kd_keterampilan_ibfk_2` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`),
  CONSTRAINT `sr_rencana_kd_keterampilan_ibfk_3` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`),
  CONSTRAINT `sr_rencana_kd_keterampilan_ibfk_4` FOREIGN KEY (`idmata_pelajaran`) REFERENCES `sr_mata_pelajaran` (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (11, 1, 42, 1, 2, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (12, 1, 42, 1, 49, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (13, 1, 42, 1, 50, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (14, 1, 42, 1, 3, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (15, 1, 42, 1, 46, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (16, 1, 42, 1, 47, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (17, 1, 40, 1, 1, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (18, 1, 39, 1, 48, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (19, 1, 41, 1, 51, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (20, 1, 57, 17, 2, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (21, 1, 57, 17, 51, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (22, 2, 42, 1, 2, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (24, 1, 37, 2, 2, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (25, 1, 37, 2, 49, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (26, 1, 37, 2, 50, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (27, 1, 37, 2, 3, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (28, 1, 37, 2, 46, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (29, 1, 37, 2, 47, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (30, 1, 40, 2, 1, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (31, 1, 41, 2, 51, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (32, 1, 39, 2, 48, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (33, 2, 42, 1, 49, 1);


#
# TABLE STRUCTURE FOR: sr_rencana_kd_pengetahuan
#

DROP TABLE IF EXISTS `sr_rencana_kd_pengetahuan`;

CREATE TABLE `sr_rencana_kd_pengetahuan` (
  `idrencana_kd_pengetahuan` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `rkdp_penilaian_harian` int(11) NOT NULL,
  PRIMARY KEY (`idrencana_kd_pengetahuan`),
  KEY `idusers` (`idusers`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idkelas` (`idkelas`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_rencana_kd_pengetahuan_ibfk_1` FOREIGN KEY (`idtahun_pelajaran`) REFERENCES `sr_tahun_pelajaran` (`idtahun_pelajaran`),
  CONSTRAINT `sr_rencana_kd_pengetahuan_ibfk_2` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`),
  CONSTRAINT `sr_rencana_kd_pengetahuan_ibfk_3` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`),
  CONSTRAINT `sr_rencana_kd_pengetahuan_ibfk_4` FOREIGN KEY (`idmata_pelajaran`) REFERENCES `sr_mata_pelajaran` (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (23, 1, 42, 1, 2, 3);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (24, 1, 42, 1, 49, 3);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (25, 1, 42, 1, 50, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (26, 1, 42, 1, 3, 3);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (27, 1, 42, 1, 46, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (28, 1, 42, 1, 47, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (29, 1, 40, 1, 1, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (30, 1, 39, 1, 48, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (31, 1, 41, 1, 51, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (33, 1, 57, 17, 2, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (34, 1, 57, 17, 51, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (35, 2, 42, 1, 2, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (37, 1, 37, 2, 2, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (38, 1, 37, 2, 49, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (39, 1, 37, 2, 50, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (40, 1, 37, 2, 3, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (41, 1, 37, 2, 46, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (42, 1, 37, 2, 47, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (43, 1, 40, 2, 1, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (44, 1, 41, 2, 51, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (45, 1, 39, 2, 48, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (46, 2, 42, 1, 49, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (47, 1, 44, 5, 2, 3);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (48, 6, 41, 3, 51, 10);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (49, 6, 41, 1, 51, 4);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (50, 6, 41, 2, 51, 1);


#
# TABLE STRUCTURE FOR: sr_rpp
#

DROP TABLE IF EXISTS `sr_rpp`;

CREATE TABLE `sr_rpp` (
  `idkompetensi_dasar` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `idtahun_pelajaran` varchar(100) NOT NULL,
  `idusers` int(11) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `mata_pelajaran` varchar(100) NOT NULL,
  `kd_kategori` enum('Pengetahuan','Keterampilan') NOT NULL,
  `kd_nama` text NOT NULL,
  `kd_status` enum('Y','N') NOT NULL,
  `alokasi` varchar(100) DEFAULT NULL,
  `tujuan` varchar(255) NOT NULL,
  `materi` varchar(255) NOT NULL,
  `metode` varchar(255) NOT NULL,
  `media` varchar(255) NOT NULL,
  `sumber` varchar(255) NOT NULL,
  `penilaian` varchar(255) NOT NULL,
  PRIMARY KEY (`idkompetensi_dasar`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idusers` (`idusers`),
  KEY `idmata_pelajaran` (`mata_pelajaran`),
  KEY `idkelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_rpp` (`idkompetensi_dasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `mata_pelajaran`, `kd_kategori`, `kd_nama`, `kd_status`, `alokasi`, `tujuan`, `materi`, `metode`, `media`, `sumber`, `penilaian`) VALUES (1, '5', '2021/2022-2', 0, 1, 'Bahasa Indonesia', 'Pengetahuan', 'RPP - Teks Prosedur ', 'Y', '3 Pertemuan / 3 x 40', '<p>Setelah kegiatan belajar mengajar selesai, peserta didik dapat :</p>\r\n\r\n<ol>\r\n	<li>Mengonstruksikan informasi;</li>\r\n	<li>Merancang pernyataan umum dan tahapan-tahapan;</li>\r\n	<li>Menganalisis struktur dan isi teks prosedur; dan</li>\r\n	<li>Mengembangka', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Konsep</td>\r\n			<td>Prinsip</td>\r\n			<td>Prosedur</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<ul>\r\n				<li>Isi Teks Prosedur</li>\r\n			</ul>\r\n			</td>\r\n			<td>\r\n			<ul>', '<p><em>Pendekatan : Saintifik Model </em></p>\r\n\r\n<p><em>Pembelajaran : Discovery learning</em></p>\r\n', '<p>HP atau Laptop</p>\r\n', '<ul>\r\n	<li>Buku penunjang kurikulum 2013 mata pelajaran Bahasa Indonesia Kelas XI Kemendikbud, 2017</li>\r\n	<li>Pengalaman peserta didik dan guru</li>\r\n</ul>\r\n', '<ul>\r\n	<li>a) Penilaian Sikap a. Ketepatan pegumpulan tugas (disiplin) b. Kejujuran pekerjaan (tidak plagiat)</li>\r\n	<li>b) Pengetahuan a. Pertanyaan tugas di googleclassroom</li>\r\n	<li>c) Keterampilan a. Tampilan tugas (guru sudah meminta agar tugas dike');
INSERT INTO `sr_rpp` (`idkompetensi_dasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `mata_pelajaran`, `kd_kategori`, `kd_nama`, `kd_status`, `alokasi`, `tujuan`, `materi`, `metode`, `media`, `sumber`, `penilaian`) VALUES (3, '5', '2021/2022-2', 0, 4, 'Multimedia', 'Keterampilan', 'RPP - Kesehatan, Keselamatan Kerja dan Lingkungan Hidup', 'Y', '3 Pertemuan / 3 x 40', '<p>Peserta didik mampu:</p>\r\n\r\n<ul>\r\n	<li>&nbsp;Menjelaskan perbedaan kesehatan dan keselamatan kerja</li>\r\n	<li>Menjelaskan peraturan dasar umum keselamatan kerja</li>\r\n	<li>Mengetahui macam-macam perlengkapan alat dan bahan dalam bekerja</li>\r\n</ul>\r\n', '<ol>\r\n	<li>a. Menjelaskan deskripsi Kesehatan, Keselamatan Kerja dan Lingkungan Hidup</li>\r\n	<li>b. Menjelaskan apa saja peralatan yang digunakan sebagai pelindung dalam keselamatan kerja</li>\r\n</ol>\r\n', '<ol>\r\n	<li>Model Pembelajaran</li>\r\n	<li>Kooperatif Learning</li>\r\n	<li>Direct Intruction (DI)</li>\r\n</ol>\r\n', '<p>Handphone / Tulis</p>\r\n', '<p>- Modul</p>\r\n\r\n<p>- Web-based IT</p>\r\n\r\n<p>- Buku teks kesehatan dan keselamatan kerja</p>\r\n', '<p>a. Teknik Penilaian : Tertulis, Lisan</p>\r\n\r\n<p>b. Bentuk instrumen : Tes lisan, Uji tulis</p>\r\n');


#
# TABLE STRUCTURE FOR: sr_setting_gaji
#

DROP TABLE IF EXISTS `sr_setting_gaji`;

CREATE TABLE `sr_setting_gaji` (
  `id_setting_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `nip` varchar(5) DEFAULT NULL,
  `nama` varchar(5) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `status_kepegawaian` varchar(20) DEFAULT NULL,
  `jenjang` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_setting_gaji`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_setting_pendapatan_lain_lain
#

DROP TABLE IF EXISTS `sr_setting_pendapatan_lain_lain`;

CREATE TABLE `sr_setting_pendapatan_lain_lain` (
  `id_setting_pendapatan_lain_lain` int(11) NOT NULL AUTO_INCREMENT,
  `nama_setting_pendapatan_lain_lain` varchar(50) NOT NULL,
  `nominal_setting_pendapatan_lain_lain` varchar(30) NOT NULL,
  PRIMARY KEY (`id_setting_pendapatan_lain_lain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_setting_pendapatan_lain_lain` (`id_setting_pendapatan_lain_lain`, `nama_setting_pendapatan_lain_lain`, `nominal_setting_pendapatan_lain_lain`) VALUES (1, 'Bonus THR', '100000');


#
# TABLE STRUCTURE FOR: sr_setting_potongan
#

DROP TABLE IF EXISTS `sr_setting_potongan`;

CREATE TABLE `sr_setting_potongan` (
  `id_setting_potongan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_setting_potongan` varchar(50) NOT NULL,
  `nominal_setting_potongan` varchar(30) NOT NULL,
  PRIMARY KEY (`id_setting_potongan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_setting_potongan` (`id_setting_potongan`, `nama_setting_potongan`, `nominal_setting_potongan`) VALUES (1, 'BPJS Kesehatan1', '1000000');
INSERT INTO `sr_setting_potongan` (`id_setting_potongan`, `nama_setting_potongan`, `nominal_setting_potongan`) VALUES (2, 'makan', '2000');


#
# TABLE STRUCTURE FOR: sr_setting_tunjangan
#

DROP TABLE IF EXISTS `sr_setting_tunjangan`;

CREATE TABLE `sr_setting_tunjangan` (
  `id_setting_tunjangan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_setting_tunjangan` varchar(50) NOT NULL,
  `nominal_setting_tunjangan` varchar(30) NOT NULL,
  PRIMARY KEY (`id_setting_tunjangan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_setting_tunjangan` (`id_setting_tunjangan`, `nama_setting_tunjangan`, `nominal_setting_tunjangan`) VALUES (2, 'Tunjangan Anak', '100000');


#
# TABLE STRUCTURE FOR: sr_sikap
#

DROP TABLE IF EXISTS `sr_sikap`;

CREATE TABLE `sr_sikap` (
  `id_sikap` int(11) NOT NULL AUTO_INCREMENT,
  `nama_sikap` varchar(200) NOT NULL,
  PRIMARY KEY (`id_sikap`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_sikap` (`id_sikap`, `nama_sikap`) VALUES (2, 'jujur');
INSERT INTO `sr_sikap` (`id_sikap`, `nama_sikap`) VALUES (3, 'bersih');


#
# TABLE STRUCTURE FOR: sr_silabus
#

DROP TABLE IF EXISTS `sr_silabus`;

CREATE TABLE `sr_silabus` (
  `idsilabus` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(100) NOT NULL,
  `kompetensi_dasar` varchar(100) NOT NULL,
  `indikator_kd` text NOT NULL,
  `materi_pembelajaran_kd` text NOT NULL,
  `kegiatan_pembelajaran_kd` text NOT NULL,
  `tk_kd` varchar(200) NOT NULL,
  `bi_kd` varchar(200) NOT NULL,
  `in_kd` varchar(200) NOT NULL,
  `alokasi` varchar(200) NOT NULL,
  `sumber` varchar(255) NOT NULL,
  PRIMARY KEY (`idsilabus`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_silabus` (`idsilabus`, `unit`, `kompetensi_dasar`, `indikator_kd`, `materi_pembelajaran_kd`, `kegiatan_pembelajaran_kd`, `tk_kd`, `bi_kd`, `in_kd`, `alokasi`, `sumber`) VALUES (11, '5', 'Mendiskripsikan fungsi \nkonsumsi dan \nfungsi \ntabungan', '<p><strong>Kognitif Konten</strong></p><ol><li>Mendiskripsikan hubungan konsumsi dan pendapatan</li><li>Menghitung kecenderungan konsumsi</li><li>Mengidentifikasi faktor yang mempengaruh konsumsi</li></ol>', '<ol><li>1. Konsumsi</li><li>1.1. Hubungan fungsional konsumsi dan pendapatan</li><li>1.2. Kecenderngan konsumsi</li><li>1.3. Faktor yang mempengaruhi konsumsi</li><li>1.4. kurva konsumsi</li></ol>', '<p>Mengamati, menghitung, menggambar, merumuskan dan memprediksi fungsi konsumsi</p>', 'Tes tertulis', 'Pilihan  ganda Essei', 'LP 1 Hubungan C  dan Y, kecenderung an, faktor,  kurva dan  fungsi  konsusi', '4 Pertemuan / 4 x 40', '<ul><li>Materi Ajar Fungsi Konsumsi dan Fungsi Tabungan</li><li>Power point 1-25</li><li>Lembar Penilaian</li><li>Kunci LP 1-3</li></ul>');


#
# TABLE STRUCTURE FOR: sr_siswa
#

DROP TABLE IF EXISTS `sr_siswa`;

CREATE TABLE `sr_siswa` (
  `idsiswa` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `s_nisn` varchar(50) NOT NULL,
  `s_nama` varchar(100) NOT NULL,
  `s_nik` varchar(255) NOT NULL,
  `s_jenis_kelamin` enum('P','L') NOT NULL,
  `s_tl_idprovinsi` int(11) NOT NULL,
  `s_tl_idkota` int(11) NOT NULL,
  `s_tanggal_lahir` date NOT NULL,
  `idkelas` int(11) NOT NULL,
  `s_email` varchar(255) NOT NULL,
  `s_telepon` varchar(20) NOT NULL,
  `s_wali` varchar(255) NOT NULL,
  `s_dusun` varchar(255) NOT NULL,
  `s_desa` varchar(255) NOT NULL,
  `s_kecamatan` varchar(255) NOT NULL,
  `s_domisili` enum('Dalam','Luar') NOT NULL,
  `s_abk` enum('Ya','Tidak') NOT NULL,
  `s_bsm_pip` enum('Ya','Tidak') NOT NULL,
  `s_keluarga_miskin` enum('Ya','Tidak') NOT NULL,
  `s_code_generator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idsiswa`),
  KEY `s_tl_idprovinsi` (`s_tl_idprovinsi`),
  KEY `s_tl_idkota` (`s_tl_idkota`),
  KEY `idkelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (11, '5', '204035871360', 'Aji Putra Arshavin ', '3401120912120001', 'L', 5, 210, '2012-01-09', 1, 'mas.ghaly88@gmail.com', '081977700271', 'Sulistyono', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', '');
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (12, '5', '204035871361', 'Alya Zafaranie Rahman', '3401124304130003', 'P', 5, 210, '2013-04-13', 1, 'lorin.enjubella88@gmail.com', '0819928822', 'Fauzur Rahman', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', '716258');
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (13, '5', '204035871362', 'Bintang Rakha Raqila', '3401120711120001', 'L', 5, 210, '2012-11-07', 1, '', '', 'Haryadi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (14, '5', '204035871363', 'Damar Lestari', '3401126504130001', 'P', 5, 210, '2013-04-25', 1, '', '', 'Nuryanto', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (15, '5', '204035871364', 'Dava Bayu Setiawan', '3401122106130001', 'L', 5, 210, '2013-06-21', 1, '', '', 'Kumara', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (16, '5', '204035871365', 'Faris Husnul Arfan', '3401120805130001', 'P', 5, 210, '2013-05-08', 1, '', '', 'Madiyono', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (17, '5', '204035871366', 'Hasna Khaira Nadhiva', '3401125209120001', 'P', 5, 210, '2012-09-12', 1, '', '', 'Sutriyono', 'KLANGON', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (18, '5', '204035871367', 'Lafida Dwi Saputri', '3401126310120001', 'P', 5, 210, '2012-10-23', 1, '', '', 'Hajib Ja&#039;far', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (19, '5', '204035871368', 'Muhammad Barik Al-Bani', '3401120202130001', 'L', 5, 210, '2013-02-02', 1, '', '', 'Slamet Sulbani', 'SEMAWUNG', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (20, '5', '204035871369', 'Muhammad Haidar Yaqdhan', '3401121806130001', 'L', 5, 210, '2013-06-18', 1, '', '', 'Isdadi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (21, '5', '204035871370', 'Muhammad Nehru Wiratama', '3310032711120002', 'L', 10, 196, '2012-11-27', 1, '', '', 'Bachtiar Bakriyanto', 'KARANGLO', 'TANJUNGAN', 'KEC. WEDI', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (22, '5', '204035871371', 'Rani Prasetya Mawardi', '3401126604130002', 'P', 5, 210, '2015-04-16', 1, '', '', 'Mawardi', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (23, '5', '204035871372', 'Raviola Eka Valentina', '3315136901130001', 'P', 10, 134, '2013-01-29', 1, '', '', 'Muhdaryanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (24, '5', '204035871373', 'Reza Rahardyan Firmansyah', '3401121101130001', 'L', 5, 210, '2013-01-11', 1, '', '', 'Hariyanto', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (25, '5', '204035871374', 'Saffa Arumi Ghaisani', '3205306505130002', 'P', 9, 126, '2013-05-25', 1, '', '', 'Ramdani', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (26, '5', '204035871375', 'Salma Safira', '3401125404130001', 'P', 5, 210, '2013-12-04', 1, '', '', 'Porwanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (27, '5', '204035871376', 'Shella Hikmatul Hidayah', '3401124902130001', 'P', 5, 210, '2013-09-02', 1, '', '', 'Haryanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (28, '5', '204035871377', 'Syakira Rizka Prawestri', '3401125109120001', 'P', 5, 210, '2012-11-09', 1, '', '', 'Walmuji', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (29, '5', '204035871378', 'Taufiq Hidayat', '3401122006130001', 'L', 5, 210, '2013-06-20', 1, '', '', 'Edi Hartanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (30, '5', '204035871379', 'Zahra Dian Salsabilla', '3401124203130001', 'P', 5, 210, '2013-03-02', 1, '', '', 'Muhdi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (31, '5', '204035871380', 'Zahwa Adina Putri', '3308036006130001', 'P', 10, 249, '2013-06-20', 1, '', '', 'Afda Setiawan', 'GANJURAN', 'PLOSOGEDE', 'KEC. NGLUWAR', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (32, '5', '0119228271', 'Andhika Rohman Indra Wijaya', '3401122805110003', 'L', 5, 210, '2011-05-28', 2, '', '', 'Agus Anwari', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (33, '5', '0111065143', 'Adit Hendryawan', '3401121812110001', 'L', 5, 210, '2011-12-18', 2, '', '', 'SARJONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (34, '5', '0111566716', 'Alvino Bagus Hendrawan', '3308040907110003', 'L', 10, 249, '2011-07-09', 2, '', '', 'Muh Fahrudin', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (39, '5', '0123535887', 'Anissa Rizki Maulidza', '3401124302120001', 'P', 5, 210, '2012-02-03', 2, '', '', 'NARPANDI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (40, '5', '0117476280', 'Asmawa Fastina Artanti', '3401124302120001', 'P', 10, 476, '2011-08-19', 2, '', '', 'SUDIYANTO', 'KLANGON', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (41, '5', '0108250622', 'Hafidz Nurul Ikhsan', '3401121410100002', 'L', 5, 210, '2010-10-14', 2, '', '', 'MUJIYANTA', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (42, '5', '0129187164', 'Hafiz il Sya&#039;bana', '3401120207120002', 'L', 5, 210, '2012-07-02', 2, '', '', 'UDIYANTO', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (43, '5', '0123340033', 'Haikal Daffa Salman Faiz', '3401121006120001', 'L', 5, 210, '2012-06-10', 2, '', '', 'GUNTORO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (44, '5', '0112159539', 'Hammam Razka Pradipta', '3401120712110001', 'L', 5, 210, '2011-12-07', 2, '', '', 'AGUNG BUDIAJI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (45, '5', '0111083351', 'Heevan Alyansyah Alfajr', '6302151410110001', 'L', 13, 203, '2011-10-14', 2, '', '', 'SYAHRUL FUJIANSYAH', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (46, '5', '0125752767', 'Najwa Zalfa Khoirunnisa', '3401126004120001', 'P', 5, 210, '2012-04-20', 2, '', '', 'OTANG HATAMI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (47, '5', '0117400693', 'Nungraeni Desy Safira Putri', '3401124612110001', 'P', 5, 210, '2011-12-08', 2, '', '', 'SUTARI', 'PANTOG WETAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (48, '5', '0123596402', 'Nur Alifa Loveana Anjani', '3401125101120002', 'P', 5, 210, '2012-01-11', 2, '', '', 'NURKOYIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (49, '5', '0117452080', 'Oktaviar Alhuwa Mufid', '3401120710110001', 'L', 5, 210, '2011-10-07', 2, '', '', 'MUHYIDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (50, '5', '0112830228', 'Qalitza Zahwa Khairani', '3401126509110001', 'P', 5, 210, '2011-09-15', 2, '', '', 'SUNGKONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (51, '5', '0121515850', 'Raffa Ahmad Sholikhin', '3401120803120001', 'L', 5, 210, '2012-03-08', 2, '', '', 'TOHA RUDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (52, '5', '0121854845', 'Rendita Febriana Saputri', '3401124702120002', 'P', 5, 210, '2012-02-07', 2, '', '', 'YULI SUSANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (53, '5', '0114655050', 'Reyhan Saputra', '3308081508120003', 'L', 10, 249, '2011-08-15', 2, '', '', 'FAJAR SETIADI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (54, '5', '0124032295', 'Risky Putra Wahyu Pratama', '3401121602120004', 'L', 5, 210, '2012-02-16', 2, '', '', 'TRI YULIANA', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (55, '5', '0113120197', 'Tedy Ahmad Santoso', '3401120210110001', 'L', 5, 210, '2011-10-02', 2, '', '', 'SUYOTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (56, '5', '0129915965', 'Tsania Zahra Maulida', '3401125602120001', 'P', 5, 210, '2012-02-16', 2, '', '', 'SISWANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (57, '5', '0125805929', 'Wanda Febriani Wulandari', '3211226902120002', 'P', 9, 440, '2012-02-29', 2, '', '', 'MUHROSID', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (58, '5', '0106708074', 'Ananda Aulia', '3401124611100001', 'P', 5, 210, '2010-11-06', 3, '', '', 'SUYADI', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (59, '5', '0108998849', 'Andini Nur Rahmawati', '3401124107100001', 'P', 5, 210, '2010-07-01', 3, '', '', 'YANI FATMAWATI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (60, '5', '0111353064', 'Annas Hamid', '3401121804110001', 'L', 5, 210, '2011-04-18', 3, '', '', 'SURATIN', 'BANJARAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (61, '5', '0118767416', 'As Syifa Dwi Pradayanti  ', '3401124905110002', 'P', 5, 210, '2011-05-09', 3, '', '', 'SUPARNO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (62, '5', '0082175383', 'Astri Widya Pramesti', '3401125408080002', 'P', 10, 196, '2008-08-14', 3, '', '', 'PRAWOTO SUHARYONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (63, '5', '0103368264', 'Bayu Ardhan Handaru', '3401120209100001', 'L', 5, 210, '2010-09-02', 3, '', '', 'KOMARUDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (64, '5', '0103094001', 'Bintara Ardyama Saputra', '3401120907100001', 'L', 5, 210, '2010-07-09', 3, '', '', 'PARJIMIN', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (65, '5', '0107104381', 'Dava Jiffin Adelino Romadi', '3401121110100001', 'L', 5, 210, '2010-10-11', 3, '', '', 'EKA ROMADI', 'DUWET III', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (66, '5', '0102553662', 'Dayinta Kumala Wijaya Esti', '3401124607100002', 'P', 5, 210, '2010-07-06', 3, '', '', 'SUPRIYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (67, '5', '0117972015', 'Fendy Adinata Wicaksono', '3401122103110001', 'L', 5, 210, '2011-03-21', 3, '', '', 'MARWANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (68, '5', '0101989546', 'Ghiffara Najwa Azzahra', '3401126508100001', 'P', 5, 210, '2010-08-25', 3, '', '', 'ASHARIHIDAYAT', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (69, '5', '0106111309', 'Hasna Nur Afifah', '3401125911100001', 'P', 5, 210, '2010-11-19', 3, '', '', 'SUBARDI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (70, '5', '0111549550', 'Iin Wulan Safa Yanunisa', '3401126001110001', 'P', 5, 210, '2011-01-20', 3, '', '', 'AHMAD SUPRIYADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (71, '5', '0164045268', 'Imam Santoso', '3401120505090001', 'L', 5, 210, '2009-05-05', 3, '', '', 'NURROHMAN', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (72, '5', '0111117352', 'Irma Aprilia Fatmawati', '3401127103110001', 'P', 5, 210, '2011-03-31', 3, '', '', 'SUPARTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (73, '5', '0103650256', 'Khanif Choiru Rochman', '3401122407110001', 'L', 5, 210, '2010-07-24', 3, '', '', 'MUH AHMAD BANI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (74, '5', '0103523847', 'Misbachul Lubab', '3401122907100001', 'L', 5, 210, '2010-07-29', 3, '', '', 'SUWITA', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (75, '5', '0105356940', 'Muhammad Abdul Azis Ramadhan', '3401120409100001', 'L', 5, 210, '2010-09-04', 3, '', '', 'SUDARYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (76, '5', '0122709840', 'Muvida Shobrina', '3401126608110001', 'P', 5, 210, '2012-08-26', 3, '', '', 'SUROTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (77, '5', '0113062348', 'Putri Khansa Udtiana Nafeeza', '3401124203110002', 'P', 5, 210, '2011-03-02', 3, '', '', 'DUL MASHUD', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (78, '5', '0102233405', 'Renata Okta Anjaini', '3401126210100002', 'P', 5, 210, '2010-10-22', 3, '', '', 'NURYANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (79, '5', '0119158123', 'Rendra Alfirkhan Nakholid', '3401121504110001', 'L', 5, 210, '2011-04-15', 3, '', '', 'IDIK IRYANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (80, '5', '0115192584', 'Rifqi Ahmad Yanuarivan', '3401120901110001', 'L', 5, 210, '2011-01-09', 3, '', '', 'MUH AHMAD', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (81, '5', '0112461768', 'Risnawati', '3401125606110001', 'P', 5, 210, '2011-06-26', 3, '', '', 'RISNAWATI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (82, '5', '0096993456', 'Sri Astuti', '3401120407090001', 'P', 5, 210, '2009-07-04', 3, '', '', 'SITI KALIMAH', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (83, '5', '0111138060', 'Syifa Nuriasari', '3401126802110001', 'P', 5, 210, '2011-02-28', 3, '', '', 'NUR AKHABAH ZAIBAN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (84, '5', '0114478714', 'Tri Ega Saputra', '3401122003110002', 'L', 5, 210, '2011-03-20', 3, '', '', 'SUKIDI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (85, '5', '0109611361', 'Yumna Aulia Zulfa', '3401124110100001', 'P', 5, 210, '2010-10-01', 3, '', '', 'FARID PRATIKNA', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (86, '5', '0112997704', 'Adnanda Galih Yudistira', '3401120305110001', 'L', 5, 210, '2011-05-03', 3, '', '', 'HERIYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (87, '5', '0097073468', 'Adnan Rangga Kurniawan', '3401120103090001', 'L', 5, 210, '2009-03-01', 4, '', '', 'SUWARTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (88, '5', '0104677724', 'Ahmad Muthohar', '3401120301100001', 'L', 5, 210, '2010-01-03', 4, '', '', 'SUPRANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (89, '5', '0108115939', 'Delia Anggraeni', '3401126604100001', 'P', 5, 210, '2010-04-26', 4, '', '', 'BADARI', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (90, '5', '0094626840', 'Destin Siti Arofah', '3401124112090001', 'P', 5, 210, '2009-12-01', 4, '', '', 'TUGIMIN', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (91, '5', '0103683075', 'Dwi Yuliana Putri', '3401124307100002', 'P', 5, 210, '2010-07-03', 4, '', '', 'MULYONO', 'BANJARAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (92, '5', '0103048390', 'Emeldy Bunga Astuti', '3308085205100003', 'P', 10, 250, '2010-05-12', 4, '', '', 'EDI SUPRAYITNO', 'NGABLAK', 'KEJI', 'KEC. MUNTILAN', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (93, '5', '0098885960', 'Evandra Emeraldgi Pratama', '3401120310090001', 'L', 5, 210, '2009-10-03', 4, '', '', 'NURWIYONO', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (94, '5', '0075465499', 'Fauziah Ardelinda', '3401127001070001', 'P', 5, 210, '2007-01-30', 4, '', '', 'SUPARMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (95, '5', '0109742705', 'Galih Reza Oktaviano', '3401120505100001', 'L', 5, 210, '2010-05-05', 4, '', '', 'RIYANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (96, '5', '0086716698', 'Galih Kurniawan', '3401122812080001', 'L', 5, 210, '2008-12-28', 4, '', '', 'SUMARWOTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (97, '5', '0082921451', 'Hesti Andriyani', '3401125004080001', 'P', 5, 210, '2008-04-10', 4, '', '', 'SUROTO', 'KEMPONG', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (98, '5', '0091536451', 'Hibban Adib Murthada', '3401122010090001', 'L', 5, 210, '2009-10-20', 4, '', '', 'MUHAMAD NASIR', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (99, '5', '0157442061', 'Latifa Ramadhani', '3401126808090001', 'P', 5, 210, '2009-08-28', 4, '', '', 'ALIYADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (100, '5', '0103142489', 'Mardianty Putri Anggraeny', '3401124603100001', 'P', 5, 210, '2010-03-06', 4, '', '', 'SUDARMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (101, '5', '0168301632', 'Muhammad Khoiruman Kafa', '3308090203100001', 'L', 10, 250, '2009-03-02', 4, '', '', 'MUHAMMAD BAEDHOWI', 'SARAGAN', 'RAMBEANAK', 'KEC. MUNGKID', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (102, '5', '0098955268', 'Muhammad Minan Fauzi', '3401122107090001', 'L', 5, 210, '2009-07-21', 4, '', '', 'SLAMET', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (103, '5', '0097560656', 'Naufal Hakim', '3401123010090001', 'L', 5, 210, '2009-10-30', 4, '', '', 'SUPNGATI WIDANIYAH', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (104, '5', '0093830651', 'Oktavia Arya Damayanti', '3401125210090001', 'P', 5, 210, '2010-10-12', 4, '', '', 'WAKIJAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (105, '5', '0098381033', 'Raffi Ahmad Afifudin', '3401121704090001', 'L', 5, 210, '2009-04-17', 4, '', '', 'NASRODIN', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (106, '5', '02040412029', 'Shafira Mutiara Valen', '3401125502100001', 'P', 5, 210, '2010-02-15', 4, '', '', 'NOFIYALDI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (107, '5', '0093846102', 'Yuda Edi Wahyana', '3401120108090003', 'L', 5, 210, '2009-08-01', 4, '', '', 'PUTRI JAZIMAH', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (108, '5', '0082840617', 'Yusuf Pamungkas', '3401122804080001', 'L', 5, 210, '2008-04-28', 4, '', '', 'RAHMADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (109, '5', '0153278170', 'Afif Rafiudin', '3401122708090001', 'L', 5, 210, '2009-06-27', 5, '', '', 'JUDARDIN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (110, '5', '088476284', 'Ahmad Faiq Athaya', '3401122802080001', 'L', 10, 249, '2008-02-28', 5, '', '', 'Ahmad Baehaqi', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (111, '5', '083034124', 'Amira Zerlinda', '3308026211080004', 'P', 34, 278, '2008-11-22', 5, '', '', 'Muhammad Zuamar', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (112, '5', '0072961067', 'Andrian Putra Pangestu', '3401122206070001', 'L', 5, 210, '2007-06-22', 5, '', '', 'SURAHMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (113, '5', '0086534500', 'Gresiya Suma Safitri', '3401125010080002', 'P', 5, 210, '2008-10-10', 5, '', '', 'DUL JALIL', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (114, '5', '0095912960', 'Hasna Fathitya Sabrina', '3401126909090002', 'P', 5, 210, '2009-09-29', 5, '', '', 'EKO NURAHMAN SUROJO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (115, '5', '0083313497', 'Indah Fitria Ningrum', '3401124210080001', 'P', 5, 210, '2008-10-02', 5, '', '', 'SUTARI', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (116, '5', '0087301623', 'Muhammad Ilham Sarifuddin', '3401122103080002', 'L', 5, 210, '2008-03-21', 5, '', '', 'NURCHOLIS', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (117, '5', '0155408388', 'Muhammad Raditya Ainul Yaqin', '3401121607080001', 'L', 5, 210, '2008-07-16', 5, '', '', 'FARIKIN', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (118, '5', '0095231681', 'Muhammad Shulhan Al-farisi', '3401120106090001', 'L', 5, 210, '2009-06-01', 5, '', '', 'SLAMET SULBANI', 'SEMAWUNG', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (119, '5', '0153200473', 'Novaris Dwi Firmansyah', '3401121711080002', 'L', 10, 249, '2008-11-17', 5, '', '', 'SARYANTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (120, '5', '0072706748', 'Oktafiya Duwi Safitri', '3401125510070001', 'P', 5, 210, '2007-10-15', 5, '', '', 'SUNARDI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (121, '5', '0083690882', 'Prastika Guntur Firmansyah', '3401120307080002', 'L', 5, 210, '2008-07-03', 5, '', '', 'KALIM', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (122, '5', '0098488467', 'Siti Musyafiani', '3401124901090001', 'P', 5, 210, '2009-09-10', 5, '', '', 'ZURISAM', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (123, '5', '0158891388', 'Tegar Arya Pangestu', '3401121308080001', 'L', 5, 210, '2008-08-13', 5, '', '', 'HARYADI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (124, '5', '0081232726', 'Adi Bagus Saputra', '3401120703080001', 'L', 5, 210, '2008-03-07', 6, '', '', 'Suwita', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (125, '5', '0071776993', 'Ageng Ratri Dewi', '340112591207002', 'P', 5, 210, '2007-12-19', 6, '', '', 'Sudarman', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (126, '5', '0077101667', 'Ahmad Hidayat', '3401122701070002', 'L', 5, 210, '2007-01-27', 6, '', '', 'Masicun', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (127, '5', '0074217306', 'Ahmad Mirza Arvinudin', '3401121612070001', 'L', 5, 210, '2007-12-16', 6, '', '', 'Muh Ahmad', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (128, '5', '0074203935', 'Aqila Chusnia Mu&#039;mina', '3204156509070001', 'P', 9, 22, '2007-09-25', 6, '', '', 'Heru Gunadi', 'POTRONALAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (129, '5', '0072510958', 'Ardian Ramadhan', '3401122209070001', 'L', 5, 210, '2007-09-22', 6, '', '', 'Widodo', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (130, '5', '0089913911', 'Arif Duwiyanto', '3401122303090001', 'L', 5, 210, '2008-03-23', 6, '', '', 'Muh Ahmad Bani', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (131, '5', '0085552671', 'Choiriatunnisa Tsani Hasya', '3401126707080002', 'P', 5, 210, '2008-07-27', 6, '', '', 'Riyadi', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (132, '5', '0071429595', 'Febriana Alfiyani', '3401124806810002', 'P', 5, 210, '2007-02-24', 6, '', '', 'Alfandi', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (133, '5', '0066771589', 'Fitri Andriani', '3401125510060002', 'P', 5, 210, '2006-10-15', 6, '', '', 'Suroto', 'KEMPONG', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (134, '5', '0082016833', 'Iqbal Dzaky Reevansyah', '6302152103080001', 'L', 15, 215, '2008-03-21', 6, '', '', 'Fujiansyah', 'POTRONALAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (135, '5', '0077252994', 'Junita Adinda Suryandika', '3401126606070001', 'P', 5, 210, '2007-06-26', 6, '', '', 'Suroto', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (136, '5', '0077859964', 'Nabil Chandra Susilo Nugroho', '3401123011070001', 'L', 5, 210, '2007-11-30', 6, '', '', 'Sucipto Susilo', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (137, '5', '0074539804', 'Revania Oktaviani', '3401126610070001', 'P', 5, 210, '2007-10-26', 6, '', '', 'Abidin', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (138, '5', '0078559059', 'Zulfa Ulya', '3401126807070001', 'P', 5, 210, '2007-07-28', 6, '', '', 'Sudaryanto', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (140, '5', '11111', '11111', '111', 'L', 2, 56, '2021-01-16', 11, 'ghalyfadhillah@gmail.com', '087722777245', 'Gunadi Abdullah', 'ASDASD', 'ASDASD', 'ASDASD', 'Dalam', 'Tidak', 'Ya', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (141, '5', '3243', '44334', '34243342', 'P', 10, 169, '2021-01-18', 16, 'saddsa@sadads.com', '2332', 'dassad', 'SADASD', 'SADSAD', 'SADASD', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (142, '5', '323242', '3243443', '232434', 'P', 8, 393, '2021-01-26', 17, 'dasdas@dsadsa.com', '432342', 'asddsa', 'SADASD', 'SADASD', 'ASDAS', 'Luar', 'Ya', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (143, '5', '11314141441', 'Jumaidi Saputraaaa', '14141413141', 'L', 6, 151, '1999-10-19', 2, 'jumaidi@gmail.com', '08937272728128', 'Budi', '-', '-', 'PONDOK AREN', 'Dalam', 'Ya', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (144, '5', '2131231231123', 'Ade Sentosah', '3175052605970002', 'L', 1, 94, '2022-02-22', 21, 'ade@gmail.com', '0819990281214', '', '', '', '', 'Dalam', 'Ya', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (145, '5', '12321423434', 'galuh ', '12443545459999090', 'L', 9, 115, '2009-12-23', 4, 'saka87aja@gmail.com', '081290191541', 'Asep', '', '', '', 'Dalam', 'Ya', 'Ya', 'Ya', NULL);


#
# TABLE STRUCTURE FOR: sr_soal
#

DROP TABLE IF EXISTS `sr_soal`;

CREATE TABLE `sr_soal` (
  `id_soal` int(11) NOT NULL AUTO_INCREMENT,
  `idmata_pelajaran` int(11) DEFAULT NULL,
  `idkelas` int(11) DEFAULT NULL,
  `idusers` int(11) DEFAULT NULL,
  `unit` int(10) NOT NULL,
  PRIMARY KEY (`id_soal`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

INSERT INTO `sr_soal` (`id_soal`, `idmata_pelajaran`, `idkelas`, `idusers`, `unit`) VALUES (50, 3, 3, 1, 5);
INSERT INTO `sr_soal` (`id_soal`, `idmata_pelajaran`, `idkelas`, `idusers`, `unit`) VALUES (51, 3, 3, 1, 5);


#
# TABLE STRUCTURE FOR: sr_soaldetail
#

DROP TABLE IF EXISTS `sr_soaldetail`;

CREATE TABLE `sr_soaldetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_soal` int(5) NOT NULL,
  `soal` text DEFAULT NULL,
  `gambar_soal` varchar(200) DEFAULT NULL,
  `opsi_a` text DEFAULT NULL,
  `opsi_b` text DEFAULT NULL,
  `opsi_c` text DEFAULT NULL,
  `opsi_d` text DEFAULT NULL,
  `opsi_e` text DEFAULT NULL,
  `jawaban` varchar(1) NOT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (26, 50, 'Hasil dari 7.598 - 1.637 - 2.893 + 4.716 adalah', NULL, '7.784', '7.812', '7.856', '7.903', '7.901', 'A', 0);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (27, 51, 'Hasil pengerjaan dari 64 x 826 : 28 adalah ....', NULL, '1.678', '1.762', '1.888', '1.916', '1.915', 'C', 0);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (28, 51, 'Suhu udara di puncak gunung pada pukul 03.00 adalah -10° C. Setelah matahari terbit,\r\nenergi matahari menaikkan suhu udara di puncak gunung tersebut. Jika setiap jam suhu\r\nudara di puncak guning naik 5° C, suhu udara pada pukul 15.00 menjadi .... C°', NULL, '23', '24', '26', '28', '29', 'C', 1);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (29, 51, 'Bus Harapan Jaya berangkat dari terminal setiap 30 menit sekali. Bus Pelita Indah berangkat\r\ndari terminal setiap 45 menit sekali, dan bus Barokah berangkat setiap 60 menit sekali. Jika\r\n\r\nketiga bus berangkat bersama-sama pada pukul 05.00, ketiga bus akan berangkat bersama-\r\nsama lagi pada pukul ....', NULL, '07.00', '08.00', '09.00', '10.00', '11.00', 'B', 0);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (30, 51, 'Herlina ingin membuat gelang. Ia membeli manik-manik warna merah 80 butir, hijau 75\r\nbutir, dan biru 50 butir. Herlina akan membuat gelang dari manik-manik tersebut dengan\r\nbagian warna yang sama. Banyaknya manik-manik pada setiap gelang adalah', NULL, 'manik-manik merah 20, manik-manik hijau 15, manik-manik biru 10', 'manik-manik merah 18, manik-manik hijau 16, manik-manik biru 12', 'manik-manik merah 18, manik-manik hijau 15, manik-manik biru 10', 'manik-manik merah 16, manik-manik hijau 15, manik-manik biru 10', 'manik-manik merah 16, manik-manik hijau 15, manik-manik biru 11', 'D', 1);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (31, 51, 'KPK dari 85, 90, dan 125 dalam bentuk faktorisasi prima adalah ....', NULL, '2 x 3 x 52', '2 x 32 x 52', '2 x 33 x 52', '2 x 32 x 53', '2 x 32 x 54', 'D', 0);


#
# TABLE STRUCTURE FOR: sr_tahun_pelajaran
#

DROP TABLE IF EXISTS `sr_tahun_pelajaran`;

CREATE TABLE `sr_tahun_pelajaran` (
  `idtahun_pelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `tp_tahun` varchar(20) NOT NULL,
  PRIMARY KEY (`idtahun_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (1, '2019/2020-1');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (2, '2019/2020-2');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (3, '2020/2021-1');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (4, '2020/2021-2');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (5, '2021/2022-1');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (6, '2021/2022-2');


#
# TABLE STRUCTURE FOR: sr_tanggal_gaji
#

DROP TABLE IF EXISTS `sr_tanggal_gaji`;

CREATE TABLE `sr_tanggal_gaji` (
  `idtanggal_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` varchar(255) NOT NULL,
  `unit` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idtanggal_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tanggal_gaji` (`idtanggal_gaji`, `tanggal`, `unit`) VALUES (1, '2022-04-06', '5');
INSERT INTO `sr_tanggal_gaji` (`idtanggal_gaji`, `tanggal`, `unit`) VALUES (3, '2022-03-30', '2 ');


#
# TABLE STRUCTURE FOR: sr_tarif_gaji_user
#

DROP TABLE IF EXISTS `sr_tarif_gaji_user`;

CREATE TABLE `sr_tarif_gaji_user` (
  `id_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `id_user` varchar(10) DEFAULT NULL,
  `id_tunjangan` varchar(200) DEFAULT NULL,
  `deskripsi` varchar(20) DEFAULT NULL,
  `id_potongan` int(11) DEFAULT NULL,
  `id_lain` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (8, '5', '40', '2', 'gaji_pokok', NULL, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (9, '5', '40', '2', 'gaji_pokok', NULL, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (10, '5', '40', '2', 'gaji_pokok', NULL, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (11, '5', '40', '2', 'gaji_pokok', NULL, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (16, '5', '40', NULL, 'potongan', 2, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (21, '5', '40', NULL, 'lain', NULL, '1');


#
# TABLE STRUCTURE FOR: sr_tarif_unit_pos
#

DROP TABLE IF EXISTS `sr_tarif_unit_pos`;

CREATE TABLE `sr_tarif_unit_pos` (
  `id_tarif_unit_pos` int(11) NOT NULL AUTO_INCREMENT,
  `id_unit_pos` varchar(10) DEFAULT NULL,
  `unit` varchar(11) DEFAULT NULL,
  `id_kode_akun` varchar(20) DEFAULT NULL,
  `tipe` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_tarif_unit_pos`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tarif_unit_pos` (`id_tarif_unit_pos`, `id_unit_pos`, `unit`, `id_kode_akun`, `tipe`) VALUES (5, '3', '5', '1', 'pendapatan');


#
# TABLE STRUCTURE FOR: sr_tr_paketsoal
#

DROP TABLE IF EXISTS `sr_tr_paketsoal`;

CREATE TABLE `sr_tr_paketsoal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_soal` int(10) NOT NULL,
  `id_paket` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (22, 25, 7);
INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (23, 24, 7);
INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (24, 28, 9);
INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (25, 30, 9);
INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (26, 30, 8);


#
# TABLE STRUCTURE FOR: sr_unit_pos
#

DROP TABLE IF EXISTS `sr_unit_pos`;

CREATE TABLE `sr_unit_pos` (
  `id_unit_pos` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `nama_unit_pos` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_unit_pos`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_unit_pos` (`id_unit_pos`, `unit`, `nama_unit_pos`) VALUES (3, '5', 'Catering');
INSERT INTO `sr_unit_pos` (`id_unit_pos`, `unit`, `nama_unit_pos`) VALUES (4, '5', 'SPP');


#
# TABLE STRUCTURE FOR: sr_users
#

DROP TABLE IF EXISTS `sr_users`;

CREATE TABLE `sr_users` (
  `idusers` int(11) unsigned NOT NULL,
  `unit` varchar(11) NOT NULL,
  `u_nbm_nip` varchar(255) NOT NULL,
  `u_nuptk_nuks` varchar(255) DEFAULT NULL,
  `u_tl_idprovinsi` int(11) NOT NULL,
  `u_tl_idkota` int(11) NOT NULL,
  `u_tanggal_lahir` date NOT NULL,
  `u_jenis_kelamin` enum('P','L') NOT NULL,
  `u_status_pegawai` varchar(100) NOT NULL,
  `u_tunjangan_apbd` varchar(100) DEFAULT NULL,
  `u_tugas_tambahan` varchar(100) DEFAULT NULL,
  `u_jenjang` varchar(50) NOT NULL,
  `u_perguruan_tinggi` varchar(255) NOT NULL,
  `u_jurusan` varchar(100) DEFAULT NULL,
  `u_tahun_lulus` varchar(20) NOT NULL,
  `u_npwp` varchar(255) DEFAULT NULL,
  `u_sertifikasi` enum('Sudah','Belum') NOT NULL,
  `u_sertifikasi_tahun` year(4) DEFAULT NULL,
  `u_prestasi` text DEFAULT NULL,
  `u_honor` int(11) NOT NULL,
  `u_kerja_pasangan` varchar(255) DEFAULT NULL,
  `u_alamat_tinggal` text NOT NULL,
  `u_photo` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idusers`),
  KEY `idusers` (`idusers`),
  KEY `u_tl_idprovinsi` (`u_tl_idprovinsi`),
  KEY `u_tl_idkota` (`u_tl_idkota`),
  KEY `idusers_2` (`idusers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (1, '5', '954033', '3433754656300012 / 16023L0010404122016516', 6, 153, '1987-02-13', 'L', 'GTY', '', '4', 'S1', 'Undip', 'Sistem Informasi', '2010', '66.907.985.7-544.000', 'Sudah', '2013', 'Guru Teladan tahun 2015', 2600000, 'Pegawai Swasta', 'Lenteng Agung, Jagakarsa, Jakarta Selatan', '3454bd5004b1bd6d20a9ff3f633a37d1.png', 1);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (37, '5', '992052', '9060760662300003', 5, 210, '1982-07-28', 'P', 'GTY', 'PTTD', '5', 'S1', 'Univ Terbuka Yogyakarta', 'PGSD', '2018', '', 'Belum', '0000', '', 1000000, 'Swasta', 'Demangan, Banjarharjo, Kalibawang', 'f5b05744233acca3b73d179279d83ff4.jpg', 1);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (38, '5', '1062801', '', 5, 210, '1985-01-07', 'L', 'GTY', '', 'Guru Kelas IV', 'S1', 'Univ Sanata Dharma', 'PGSD', '2010', '91.003.379.4-544.000', 'Belum', '0000', '', 400000, 'Swasta', 'Duwet 3, Banjarharjo, Kalibawang', 'ef2cbde3636968a2bbb9f76a5df7909e.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (39, '5', '1295422', '', 5, 210, '1992-07-19', 'L', 'GTT', '', 'Guru Penjasorkes', 'S1', 'Univ Ahmad Dahlan', 'PBSI', '2012', '', 'Belum', '0000', '', 350000, '', 'Paras, Banjarasri, Kalibawang', '9f23f5e97972e5e98537f51b76db76ec.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (40, '5', '19671206 198903 1 003', '2538745647110043', 5, 210, '1967-12-06', 'L', 'PNS KEMENAG', '', 'Guru PAI', 'D2', 'UIN Sunan Kalij Jaga Yogyakarta', 'Pend. Agama Islam', '1993', '', 'Sudah', '2013', '', 4200000, 'IRT', 'Gunungmojo, Argosari, Sedayu, Bantul', '42ef1ac722851008e5e9bcb35351827c.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (41, '5', '1335358', '', 9, 115, '1994-04-04', 'P', 'GTT', '', 'Operator', 'S1', 'UIN Raden Fatah Palembang', 'Pend. Bahasa Inggris', '2017', '', 'Belum', '0000', '', 150000, 'Swasta', 'Salam, Banjarharjo, Kalibawang', 'e20f5b298a4d05cb1d22977403f73062.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (42, '5', '1335360', '', 5, 210, '1993-02-07', 'P', 'GTT', '', 'Guru Kelas I', 'S1', 'Univ Terbuka Banten', 'PGSD', '2018', '', 'Belum', '0000', '', 300000, 'Swasta', 'Pranan, Banjaroya, Kalibawang', '7079eeff453c257d36b51af9413281ec.jpeg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (43, '5', '1314346', '', 5, 210, '1974-10-27', 'P', 'GTT', '', 'Guru Kelas III', 'S1', 'Univ Widya Mataram Yogyakarta', 'Teknologi pertanian', '1998', '', 'Belum', '0000', '', 300000, 'Karyawan', 'Kedondong 1, Banjararum, Kalibawang', '373f490ef28c28450a359b46e73525d7.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (44, '5', '1295423', '', 5, 210, '1987-04-15', 'P', 'GTT', '', 'Guru Kelas V', 'S1', 'Univ Indraprasta PGRI Jakarta', 'Pendidikan Matematika', '2011', '', 'Belum', '0000', '', 350000, 'Swasta', 'Semawung, Banjarharjo, Kalibawang', '17773abbb91433f028f4183bc51c80de.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (45, '5', '1187611', '', 5, 210, '1991-05-08', 'P', 'GTY', '', 'Guru Kelas VI', 'S1', 'Univ PGRI Yogyakarta', 'Pendidikan Matematika', '2013', '', 'Belum', '0000', '', 400000, '', 'Semaken 3, Banjararum, Kalibawang', '785a17c1772c4c0ed74a372bffca962f.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (57, '5', '104352', '10435342456', 2, 56, '2021-01-18', 'L', 'GTY', '', 'Operator', 'S1', 'Universitas Amikom Yogyakarta', 'Sistem Informasi', '2021', '9999999999999', 'Belum', '0000', 'Pegawai Terganteng', 5300000, 'Kepala Dinas Pariwisata', 'Jln Bintara RT 12 RW 09', 'fb9a0bb598302e966995357ef0d12ab8.png', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (59, '5', '104353', '10435342457', 6, 153, '1987-12-23', 'L', 'GTY', '0', 'Kepala Program', 'S1', 'Universitas Indra Prasta PGRI', 'Pendidikan Ekonomi', '2017', '12.345.76543', 'Belum', '0000', '0', 1400000, '0', 'Jl. Rawa Sari', '8b1746b499eea7a042bf6bd4ffb35f80.png', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (64, '2', '', NULL, 0, 0, '0000-00-00', 'P', '', NULL, NULL, '', '', NULL, '', NULL, 'Sudah', NULL, NULL, 0, NULL, '', NULL, 0);


#
# TABLE STRUCTURE FOR: sr_virtualclass
#

DROP TABLE IF EXISTS `sr_virtualclass`;

CREATE TABLE `sr_virtualclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `pengajar_id` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `url` text NOT NULL,
  `libur` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (1, '', 0, 0, 'Tahun Baru Masehi', '2022-01-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (2, '', 0, 0, 'Hari Siwa Ratri', '2022-01-1', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (3, '', 0, 0, 'Tahun Baru Imlek 2573 Kongzili', '2022-02-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (4, '', 0, 0, 'Isra Mikraj Nabi Muhammad SAW', '2022-02-28', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (5, '', 0, 0, 'Hari Raya Nyepi', '2022-03-3', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (6, '', 0, 0, 'Hari Saraswati', '2022-03-26', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (7, '', 0, 0, 'Wafat Isa Al Masih', '2022-04-15', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (8, '', 0, 0, 'Hari Buruh Internasional', '2022-05-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (9, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-2', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (10, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-3', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (11, '', 0, 0, 'Hari Raya Waisak 2566', '2022-05-16', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (12, '', 0, 0, 'Kenaikan Isa Al Masih', '2022-05-26', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (13, '', 0, 0, 'Hari Lahirnya Pancasila', '2022-06-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (14, '', 0, 0, 'Penampahan Galungan', '2022-06-7', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (15, '', 0, 0, 'Hari Raya Galungan', '2022-06-8', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (16, '', 0, 0, 'Umanis Galungan', '2022-06-9', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (17, '', 0, 0, 'Hari Raya Kuningan', '2022-06-18', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (18, '', 0, 0, 'Hari Raya Idul Adha 1443 Hijriyah', '2022-07-9', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (19, '', 0, 0, 'Tahun Baru Islam 1444 Hijriyah', '2022-07-30', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (20, '', 0, 0, 'Hari Proklamasi Kemerdekaan RI', '2022-08-17', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (21, '', 0, 0, 'Maulid Nabi Muhammad SAW', '2022-10-8', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (22, '', 0, 0, 'Hari Saraswati', '2022-10-22', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (23, '', 0, 0, 'Hari Raya Natal', '2022-12-25', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (24, '5', 1, 1, 'BAB I - Adminstrasi Perkantoran Dasar', '2022-03-22', 'https://meet.jit.si/Lekum', '');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (35, '5', 1, 1, 'BAB 1 - Membuat Company Profile', '2022-02-22', 'https://meet.jit.si/hQPtq', '');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `multirole` enum('Y','N') DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (1, '5', '127.0.0.1', '$2y$12$DPBC0GqrE7QhiYgWOBdbW.c/jZQ0qD7KS7mO8z5HtaiPa35WwuxyK', 'sutan.daulay@gmail.com', 1268889823, 1645102751, 1, 'N', 'Sutan', 'Daulay, S.Kom', '081283960337');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (37, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'h.yuliajie@gmail.com', 1604316790, 1611518343, 1, 'Y', 'Heri', 'Yuli Astuti, S.Pd.', '081802637311');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (38, '5', '127.0.0.1', '$2y$10$3Hfg3GDUGrnqzRJeFO1L0u3tHe.jEvBjl0AUi3GGOeYcLKUDwI60a', 'foreverbarca24@gmail.com', 1604324461, 1640778495, 1, 'Y', 'Eka', 'Romadi, S.Pd.', '087719045202');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (39, '5', '127.0.0.1', '$2y$10$P1fNQaXHq7SDMI89fVyeAuNtbskbLbS6X9GzuvqLhyOpYGjb2jr66', 'prodocid.id@gmail.com', 1604404981, 1611515571, 1, 'N', 'Muhammad ', 'Yuli Nugroho, S.Pd.', '081328086524');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (40, '5', '127.0.0.1', '$2y$10$eICdXdcDjiUKA7ieNqHTueuCVl47eLEkdCzHccWoip7HvN4Sx7sa2', 'foreverbarca17@gmail.com', 1604405357, 1640675168, 1, 'N', 'Ahwanto, A.Ma', '', '081328579072');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (41, '5', '127.0.0.1', '$2y$10$ZlApEjZiUXuUQvPrelvWWOjqIlCK6mWlgyZAtskny353GxpATj6.O', 'trilestari40@yahoo.com', 1604405791, 1645100999, 1, 'N', 'Tri ', 'Lestari, S.Pd', '085279657826');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (42, '5', '127.0.0.1', '$2y$10$26FP8tRR/0UwORH8tI5eS.RNTMs3.RnIbZ7ldxy0PhIO/n94g2Jpe', 'widayatiasih93@gmail.com', 1604406384, 1645101063, 1, 'Y', 'Widayati ', 'Asih Rusilah, S.Pd', '087877633339');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (43, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'tripuji298@gmail.com', 1604406639, NULL, 1, 'Y', 'Tri ', 'Puji Lestari, S.TP', '081225422320');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (44, '5', '127.0.0.1', '$2y$10$vyeEuY7OB3ECbYUTZiBGnuCsW5GXcTrbxiB6NDON7oZkUA0/bKUEy', 'tutikrahayu086@gmail.com', 1604407059, 1645100832, 1, 'Y', 'Tutik ', 'Rahayu, S.Pd.', '087738264098');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (45, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'fulileo.astuti06@gmail.com', 1604407243, NULL, 1, 'Y', 'Tri ', 'Fuji Astuti, S.Pd.', '085764945075');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (57, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'ghalyfadhillah@gmail.com', 1610969508, 1612615966, 1, 'Y', 'Ghaly', 'Fadhillah, S.Kom', '087722777245');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (59, '5', '103.119.141.186', '$2y$10$ztlP7HXx3yYRbbcldtK7V.dNLDzFirPis1LJ96KI6yftEFMBGS7py', 'saka87aja@gmail.com', 1640777850, NULL, 1, 'N', 'Galuh', 'Saka Twinta S.pd', '0838654876342');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (64, '2', '::1', '$2y$10$38UHPhu.ge7KZfs4jmLsLukZyuK27j0rTOJBxvzdKQpCZKdIMabR6', 'rzalvaero@gmail.com', 4294967295, NULL, 1, 'N', 'Reza', 'Lesmana Putra A.md', '081280462659');


#
# TABLE STRUCTURE FOR: web_backup
#

DROP TABLE IF EXISTS `web_backup`;

CREATE TABLE `web_backup` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `datestamp` varchar(100) NOT NULL,
  `filedata` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (5, '2022-02-19 14:41:34', 'backup-220219-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (6, '2022-02-20 17:07:15', 'backup-220220-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (7, '2022-02-22 14:13:51', 'backup-220222-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (8, '2022-02-23 15:17:49', 'backup-220223-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (9, '2022-03-02 10:02:40', 'backup-220302-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (10, '2022-03-09 09:55:35', 'backup-220309-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (11, '2022-03-09 17:18:41', 'backup-220309-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (12, '2022-03-10 10:46:56', 'backup-220310-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (13, '2022-03-10 19:27:32', 'backup-220310-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (14, '2022-03-22 10:40:55', 'backup-220322-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (15, '2022-04-06 23:29:46', 'backup-220406-db.zip');


#
# TABLE STRUCTURE FOR: web_calender
#

DROP TABLE IF EXISTS `web_calender`;

CREATE TABLE `web_calender` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `created` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `url` text NOT NULL,
  `libur` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (1, '', 0, 0, 'Tahun Baru Masehi', '2022-01-1', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (2, '', 0, 0, 'Hari Siwa Ratri', '2022-01-1', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (3, '', 0, 0, 'Tahun Baru Imlek 2573 Kongzili', '2022-02-1', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (4, '', 0, 0, 'Isra Mikraj Nabi Muhammad SAW', '2022-02-28', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (5, '', 0, 0, 'Hari Raya Nyepi', '2022-03-3', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (6, '', 0, 0, 'Hari Saraswati', '2022-03-26', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (7, '', 0, 0, 'Wafat Isa Al Masih', '2022-04-15', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (8, '', 0, 0, 'Hari Buruh Internasional', '2022-05-1', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (9, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-2', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (10, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-3', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (11, '', 0, 0, 'Hari Raya Waisak 2566', '2022-05-16', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (12, '', 0, 0, 'Kenaikan Isa Al Masih', '2022-05-26', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (13, '', 0, 0, 'Hari Lahirnya Pancasila', '2022-06-1', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (14, '', 0, 0, 'Penampahan Galungan', '2022-06-7', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (15, '', 0, 0, 'Hari Raya Galungan', '2022-06-8', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (16, '', 0, 0, 'Umanis Galungan', '2022-06-9', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (17, '', 0, 0, 'Hari Raya Kuningan', '2022-06-18', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (18, '', 0, 0, 'Hari Raya Idul Adha 1443 Hijriyah', '2022-07-9', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (19, '', 0, 0, 'Tahun Baru Islam 1444 Hijriyah', '2022-07-30', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (20, '', 0, 0, 'Hari Proklamasi Kemerdekaan RI', '2022-08-17', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (21, '', 0, 0, 'Maulid Nabi Muhammad SAW', '2022-10-8', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (22, '', 0, 0, 'Hari Saraswati', '2022-10-22', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (23, '', 0, 0, 'Hari Raya Natal', '2022-12-25', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (24, '5', 1, 1, 'BAB I - Adminstrasi Perkantoran Dasar', '2022-03-22', 'https://meet.jit.si/Lekum', '');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (35, '5', 1, 1, 'BAB 1 - Membuat Company Profile', '2022-02-22', 'https://meet.jit.si/hQPtq', '');


#
# TABLE STRUCTURE FOR: web_default
#

DROP TABLE IF EXISTS `web_default`;

CREATE TABLE `web_default` (
  `id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `maintenance` enum('tidak','iya') NOT NULL,
  `whatsapp_group` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `web_default` (`id`, `url`, `title`, `logo`, `description`, `email`, `maintenance`, `whatsapp_group`, `whatsapp`) VALUES (1, 'https://www.proschool.id/', 'PROschool by DesaTech', 'logo.png', 'Elearning by ProSchool for a Smart Learning for Student in New Era! ', 'admin@proschool.id', 'tidak', '#', '6281280462650');


#
# TABLE STRUCTURE FOR: web_log
#

DROP TABLE IF EXISTS `web_log`;

CREATE TABLE `web_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `idusers` varchar(11) DEFAULT NULL,
  `datestamp` varchar(50) NOT NULL,
  `note` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (1, '5', 'siswa', '11', '2022-02-20 17:02:55', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (2, '5', 'guru', '1', '2022-02-20 17:06:20', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (3, '5', 'guru', '1', '2022-02-22 10:08:16', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (4, '5', 'siswa', '11', '2022-02-22 12:16:16', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (5, '5', 'guru', '1', '2022-02-22 13:05:25', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (6, '5', 'siswa', '11', '2022-02-22 15:13:52', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (7, '5', 'guru', '1', '2022-02-22 15:53:42', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (8, '5', 'siswa', '11', '2022-02-22 16:12:33', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (9, '5', 'guru', '1', '2022-02-22 16:27:36', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (10, '5', 'siswa', '11', '2022-02-22 16:43:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (11, '5', 'guru', '1', '2022-02-22 16:50:10', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (12, '5', 'siswa', '11', '2022-02-22 16:51:40', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (13, '5', 'siswa', '11', '2022-02-22 21:25:17', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (14, '5', 'siswa', '11', '2022-02-22 21:27:06', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (15, '5', 'guru', '1', '2022-02-22 21:34:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (16, '5', 'guru', '1', '2022-02-22 21:34:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (17, '5', 'guru', '1', '2022-02-23 10:23:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (18, '5', 'guru', '1', '2022-02-23 12:29:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (19, '5', 'siswa', '11', '2022-02-23 14:13:27', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (20, '5', 'siswa', '11', '2022-02-23 14:13:31', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (21, '5', 'siswa', '11', '2022-02-23 14:13:51', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (22, '5', 'siswa', '11', '2022-02-23 14:14:46', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (23, '5', 'guru', '1', '2022-02-23 14:15:21', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (24, '5', 'siswa', '11', '2022-02-23 15:18:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (25, '5', 'siswa', '11', '2022-02-23 15:18:50', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (26, '5', 'guru', '1', '2022-02-23 15:20:38', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (27, '5', 'guru', '1', '2022-02-23 15:40:07', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (28, '5', 'siswa', '11', '2022-02-23 17:23:27', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (29, '5', 'siswa', '11', '2022-02-23 17:23:30', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (30, '5', 'siswa', '11', '2022-02-23 17:23:33', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (31, '5', 'guru', '1', '2022-02-23 17:27:12', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (32, '5', 'guru', '1', '2022-02-23 19:50:24', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (33, '5', 'guru', '1', '2022-02-24 15:46:59', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (34, '', 'siswa', '11', '2022-03-02 09:56:45', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (35, '', 'guru', '1', '2022-03-02 09:59:59', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (36, '', 'guru', '1', '2022-03-02 11:19:45', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (37, '', 'guru', '1', '2022-03-02 11:36:54', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (38, '', 'guru', '1', '2022-03-04 15:54:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (39, '5', 'guru', '1', '2022-03-09 09:40:18', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (40, '5', 'guru', '1', '2022-03-09 09:49:38', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (41, '5', 'guru', '1', '2022-03-09 09:55:00', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (42, '5', 'guru', '1', '2022-03-09 11:00:58', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (43, '', 'siswa', '11', '2022-03-09 11:02:22', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (44, '5', 'guru', '1', '2022-03-09 14:07:52', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (45, '5', 'guru', '1', '2022-03-09 14:23:43', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (46, '5', 'guru', '1', '2022-03-09 15:10:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (47, '', 'siswa', '11', '2022-03-09 15:10:39', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (48, '5', 'guru', '1', '2022-03-09 15:58:41', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (49, '5', 'guru', '1', '2022-03-10 10:42:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (50, '5', 'guru', '1', '2022-03-10 11:43:13', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (51, '5', 'guru', '1', '2022-03-10 11:43:20', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (52, '5', 'guru', '1', '2022-03-10 11:43:30', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (53, '5', 'guru', '1', '2022-03-10 11:45:48', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (54, '5', 'guru', '1', '2022-03-10 11:46:09', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (55, '5', 'guru', '1', '2022-03-10 14:57:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (56, '5', 'guru', '1', '2022-03-10 15:52:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (57, '5', 'guru', '1', '2022-03-10 16:38:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (58, '', 'siswa', '11', '2022-03-11 11:34:57', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (59, '', 'siswa', '11', '2022-03-14 15:16:01', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (60, '5', 'guru', '1', '2022-03-14 15:18:18', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (61, '', 'siswa', '11', '2022-03-14 15:18:45', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (62, '5', 'guru', '1', '2022-03-14 15:56:24', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (63, '', 'siswa', '11', '2022-03-21 16:07:47', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (64, '5', 'guru', '1', '2022-03-22 11:09:37', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (65, '5', 'guru', '1', '2022-03-25 11:53:07', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (66, '5', 'guru', '1', '2022-04-04 15:28:31', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (67, '', 'siswa', '19', '2022-04-04 21:48:00', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (68, '', 'siswa', NULL, '2022-04-04 21:57:45', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (69, '', 'siswa', NULL, '2022-04-04 21:58:38', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (70, '5', 'guru', '1', '2022-04-05 13:45:51', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (71, '', 'siswa', '11', '2022-04-05 15:03:12', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (72, '5', 'guru', '1', '2022-04-05 15:07:56', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (73, '5', 'guru', '1', '2022-04-05 15:58:59', 'Anda melakukan login dengan \"182.0.241.74\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (74, '', 'siswa', NULL, '2022-04-05 16:23:00', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (75, '', 'siswa', '145', '2022-04-05 16:37:42', 'Anda melakukan login dengan \"182.0.241.74\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (76, '', 'siswa', '145', '2022-04-05 16:50:10', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (77, '', 'siswa', '145', '2022-04-05 16:59:30', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (78, '5', 'guru', '1', '2022-04-06 16:11:14', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (79, '', 'siswa', '11', '2022-04-06 16:12:39', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (80, '5', 'guru', '1', '2022-04-06 16:18:58', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (81, '', 'siswa', '11', '2022-04-06 16:20:26', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (82, '5', 'guru', '1', '2022-04-06 16:35:16', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (83, '', 'siswa', '11', '2022-04-06 16:36:41', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (84, '5', 'guru', '1', '2022-04-06 16:38:40', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (85, '', 'siswa', '11', '2022-04-06 21:33:09', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (86, '', 'siswa', '11', '2022-04-06 21:33:32', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (87, '5', 'guru', '1', '2022-04-06 21:40:46', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (88, '5', 'guru', '1', '2022-04-06 22:34:59', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (89, '', 'siswa', '11', '2022-04-07 02:18:37', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (90, '', 'siswa', '11', '2022-04-07 08:48:49', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (91, '', 'siswa', '11', '2022-04-07 09:05:27', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (92, '5', 'guru', '1', '2022-04-07 11:05:20', 'Anda melakukan login dengan \"103.119.140.138\"');


#
# TABLE STRUCTURE FOR: web_sekolah
#

DROP TABLE IF EXISTS `web_sekolah`;

CREATE TABLE `web_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `nama_sekolah` varchar(100) DEFAULT NULL,
  `kepsek` varchar(100) NOT NULL,
  `npsn` varchar(50) DEFAULT NULL,
  `nss` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kodepos` varchar(15) DEFAULT NULL,
  `no_telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `ttd` varchar(100) NOT NULL,
  `stampel` varchar(100) NOT NULL,
  `design` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (1, '1', 'SD ProSchool', 'Sutan Daulay', '20108989', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'tk@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (2, '2', 'SMP ProSchool', 'Panji Nugraha', '20108997', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'sd@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (3, '3', 'SMP ProSchool', 'Damara', '20108990', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'smp@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (4, '4', 'SMA ProSchool', 'Andre Taulany', '20108812', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'sma@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (5, '5', 'SMK ProSchool', 'Reza Lesmana', '20108813', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'smk@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');


#
# TABLE STRUCTURE FOR: web_setting
#

DROP TABLE IF EXISTS `web_setting`;

CREATE TABLE `web_setting` (
  `id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `maintenance` enum('tidak','iya') NOT NULL,
  `whatsapp_group` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `web_setting` (`id`, `url`, `title`, `logo`, `description`, `email`, `maintenance`, `whatsapp_group`, `whatsapp`) VALUES (1, 'https://www.proschool.id/', 'PROschool by DesaTech', 'logo.png', 'Elearning by ProSchool for a Smart Learning for Student in New Era! ', 'admin@proschool.id', 'tidak', '#', '6281280462650');


#
# TABLE STRUCTURE FOR: web_unit
#

DROP TABLE IF EXISTS `web_unit`;

CREATE TABLE `web_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_unit` (`id`, `nama`) VALUES (1, 'TK');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (2, 'SD');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (3, 'SMP');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (4, 'SMA');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (5, 'SMK');


#
# TABLE STRUCTURE FOR: web_visitor
#

DROP TABLE IF EXISTS `web_visitor`;

CREATE TABLE `web_visitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(26) NOT NULL,
  `date` date NOT NULL,
  `hits` int(11) NOT NULL,
  `online` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (1, '::1', '2022-02-18', 2, '1645176744', '2022-02-18 16:31:40');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (2, '::1', '2022-02-19', 31, '1645256376', '2022-02-19 11:16:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (3, '::1', '2022-02-20', 4, '1645351663', '2022-02-20 17:00:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (4, '::1', '2022-02-22', 127, '1645541912', '2022-02-22 10:08:17');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (5, '::1', '2022-02-23', 20, '1645620624', '2022-02-23 10:23:03');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (6, '::1', '2022-02-24', 2, '1645694578', '2022-02-24 15:46:59');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (7, '::1', '2022-03-02', 88, '1646211941', '2022-03-02 09:56:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (8, '::1', '2022-03-04', 11, '1646386633', '2022-03-04 14:46:36');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (9, '::1', '2022-03-07', 9, '1646644603', '2022-03-07 10:15:52');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (10, '::1', '2022-03-09', 107, '1646817882', '2022-03-09 09:40:18');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (11, '::1', '2022-03-10', 27, '1646915630', '2022-03-10 10:39:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (12, '::1', '2022-03-11', 12, '1646993633', '2022-03-11 09:02:06');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (13, '::1', '2022-03-14', 25, '1647250952', '2022-03-14 09:43:53');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (14, '::1', '2022-03-15', 7, '1647317290', '2022-03-15 09:29:17');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (15, '::1', '2022-03-17', 6, '1647495518', '2022-03-17 09:40:46');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (16, '::1', '2022-03-18', 4, '1647575703', '2022-03-18 10:37:35');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (17, '::1', '2022-03-21', 17, '1647854259', '2022-03-21 09:22:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (18, '::1', '2022-03-22', 20, '1647960899', '2022-03-22 08:55:55');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (19, '::1', '2022-03-24', 3, '1648107873', '2022-03-24 12:04:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (20, '::1', '2022-03-25', 8, '1648197338', '2022-03-25 09:53:23');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (21, '::1', '2022-03-28', 4, '1648450552', '2022-03-28 09:16:06');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (22, '::1', '2022-03-29', 2, '1648534395', '2022-03-29 10:38:38');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (23, '::1', '2022-03-30', 5, '1648612601', '2022-03-30 08:53:33');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (24, '::1', '2022-04-02', 1, '1648879777', '2022-04-02 13:09:37');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (25, '::1', '2022-04-04', 44, '1649084372', '2022-04-04 09:56:21');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (26, '::1', '2022-04-05', 32, '1649148728', '2022-04-05 10:00:14');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (27, '182.0.241.74', '2022-04-05', 91, '1649160146', '2022-04-05 15:55:30');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (28, '182.0.214.17', '2022-04-05', 5, '1649153971', '2022-04-05 16:59:20');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (29, '103.119.140.138', '2022-04-05', 8, '1649171555', '2022-04-05 19:47:44');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (30, '103.208.205.90', '2022-04-06', 14, '1649262777', '2022-04-06 02:03:03');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (31, '103.119.140.138', '2022-04-06', 19, '1649237921', '2022-04-06 16:04:28');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (32, '103.82.15.129', '2022-04-06', 2, '1649263585', '2022-04-06 23:29:38');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (33, '103.208.205.90', '2022-04-07', 92, '1649297313', '2022-04-07 01:15:33');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (34, '103.119.140.138', '2022-04-07', 12, '1649304320', '2022-04-07 10:29:47');


