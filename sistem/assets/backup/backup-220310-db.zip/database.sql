#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`id`, `nama`, `email`, `username`, `password`) VALUES (1, 'Administrator', 'admin@admin.com', 'admin', '$2y$10$8SoPqIecyMythHypIhN90OUrIFpvazbImXIgBcKZQenn9SVcD47fS');


#
# TABLE STRUCTURE FOR: sr_account
#

DROP TABLE IF EXISTS `sr_account`;

CREATE TABLE `sr_account` (
  `id_akun` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `kode_akun` varchar(20) DEFAULT NULL,
  `jenis_akun` int(20) DEFAULT NULL,
  `kategori` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `modul_keuangan` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_akun`)
) ENGINE=InnoDB AUTO_INCREMENT=622657 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (1, '5', '1-1000', 1, 'utama', 'AKTIVA', NULL);
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622655, '5', '1-1100', 2, 'keuangan', 'Kas Tunai SMA', 'aset');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622656, '5', '1-1900', 2, 'keuangan', 'Piutang', 'aset');


#
# TABLE STRUCTURE FOR: sr_bulan
#

DROP TABLE IF EXISTS `sr_bulan`;

CREATE TABLE `sr_bulan` (
  `id_bulan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bulan` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id_bulan`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (1, 'Juli');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (2, 'Agustus');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (3, 'September');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (4, 'Oktober');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (5, 'November');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (6, 'Desember');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (7, 'Januari');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (8, 'Febuari');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (9, 'Maret');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (10, 'April');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (11, 'Mei');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (12, 'Juni');


#
# TABLE STRUCTURE FOR: sr_jenis_bayar
#

DROP TABLE IF EXISTS `sr_jenis_bayar`;

CREATE TABLE `sr_jenis_bayar` (
  `id_jenis_bayar` int(11) NOT NULL AUTO_INCREMENT,
  `id_pos` varchar(20) DEFAULT NULL,
  `tingkat` varchar(20) DEFAULT NULL,
  `tipe` varchar(20) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_jenis_bayar`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_jenis_bayar` (`id_jenis_bayar`, `id_pos`, `tingkat`, `tipe`, `unit`) VALUES (2, '1', '2022', 'bulanan', '5');


#
# TABLE STRUCTURE FOR: sr_kelas
#

DROP TABLE IF EXISTS `sr_kelas`;

CREATE TABLE `sr_kelas` (
  `idkelas` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `k_tingkat` int(11) NOT NULL,
  `k_romawi` varchar(20) NOT NULL,
  `k_keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (1, '5', 10, 'X - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (2, '5', 10, 'X - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (3, '5', 10, 'X - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (4, '5', 10, 'X - MM', 'Multimedia');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (5, '5', 11, 'XI - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (6, '5', 11, 'XI - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (11, '5', 11, 'XI - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (16, '5', 11, 'XI - MM', 'Multimedia');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (17, '5', 12, 'XII - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (19, '5', 12, 'XII - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (20, '5', 12, 'XII - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (21, '5', 12, 'XII - MM', 'Multimedia');


#
# TABLE STRUCTURE FOR: sr_kelas_guru
#

DROP TABLE IF EXISTS `sr_kelas_guru`;

CREATE TABLE `sr_kelas_guru` (
  `idkelas_guru` int(11) NOT NULL AUTO_INCREMENT,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  PRIMARY KEY (`idkelas_guru`),
  KEY `idusers` (`idusers`),
  KEY `idkelas` (`idkelas`),
  CONSTRAINT `sr_kelas_guru_ibfk_1` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`),
  CONSTRAINT `sr_kelas_guru_ibfk_2` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (17, 37, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (18, 38, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (22, 39, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (23, 39, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (24, 39, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (25, 39, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (26, 39, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (27, 39, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (28, 40, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (29, 41, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (30, 41, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (31, 41, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (32, 41, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (33, 41, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (34, 41, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (35, 40, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (36, 40, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (37, 40, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (38, 40, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (39, 40, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (40, 42, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (41, 43, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (42, 44, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (43, 45, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (50, 57, 17);


#
# TABLE STRUCTURE FOR: sr_kode_kelompok
#

DROP TABLE IF EXISTS `sr_kode_kelompok`;

CREATE TABLE `sr_kode_kelompok` (
  `id_kode_kelompok` int(11) NOT NULL,
  `unit` varchar(11) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `kode` varchar(2) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_kota
#

DROP TABLE IF EXISTS `sr_kota`;

CREATE TABLE `sr_kota` (
  `city_id` int(11) NOT NULL,
  `province_id` varchar(11) NOT NULL,
  `province` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `postal_code` int(11) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (1, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Barat', 23681);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (2, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Barat Daya', 23764);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (3, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Besar', 23951);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (4, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Jaya', 23654);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (5, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Selatan', 23719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (6, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Singkil', 24785);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (7, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tamiang', 24476);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (8, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tengah', 24511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (9, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tenggara', 24611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (10, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Timur', 24454);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (11, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Utara', 24382);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (12, '32', 'Sumatera Barat', 'Kabupaten', 'Agam', 26411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (13, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Alor', 85811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (14, '19', 'Maluku', 'Kota', 'Ambon', 97222);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (15, '34', 'Sumatera Utara', 'Kabupaten', 'Asahan', 21214);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (16, '24', 'Papua', 'Kabupaten', 'Asmat', 99777);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (17, '1', 'Bali', 'Kabupaten', 'Badung', 80351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (18, '13', 'Kalimantan Selatan', 'Kabupaten', 'Balangan', 71611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (19, '15', 'Kalimantan Timur', 'Kota', 'Balikpapan', 76111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (20, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Banda Aceh', 23238);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (21, '18', 'Lampung', 'Kota', 'Bandar Lampung', 35139);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (22, '9', 'Jawa Barat', 'Kabupaten', 'Bandung', 40311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (23, '9', 'Jawa Barat', 'Kota', 'Bandung', 40111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (24, '9', 'Jawa Barat', 'Kabupaten', 'Bandung Barat', 40721);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (25, '29', 'Sulawesi Tengah', 'Kabupaten', 'Banggai', 94711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (26, '29', 'Sulawesi Tengah', 'Kabupaten', 'Banggai Kepulauan', 94881);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (27, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka', 33212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (28, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Barat', 33315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (29, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Selatan', 33719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (30, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Tengah', 33613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (31, '11', 'Jawa Timur', 'Kabupaten', 'Bangkalan', 69118);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (32, '1', 'Bali', 'Kabupaten', 'Bangli', 80619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (33, '13', 'Kalimantan Selatan', 'Kabupaten', 'Banjar', 70619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (34, '9', 'Jawa Barat', 'Kota', 'Banjar', 46311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (35, '13', 'Kalimantan Selatan', 'Kota', 'Banjarbaru', 70712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (36, '13', 'Kalimantan Selatan', 'Kota', 'Banjarmasin', 70117);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (37, '10', 'Jawa Tengah', 'Kabupaten', 'Banjarnegara', 53419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (38, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bantaeng', 92411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (39, '5', 'DI Yogyakarta', 'Kabupaten', 'Bantul', 55715);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (40, '33', 'Sumatera Selatan', 'Kabupaten', 'Banyuasin', 30911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (41, '10', 'Jawa Tengah', 'Kabupaten', 'Banyumas', 53114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (42, '11', 'Jawa Timur', 'Kabupaten', 'Banyuwangi', 68416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (43, '13', 'Kalimantan Selatan', 'Kabupaten', 'Barito Kuala', 70511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (44, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Selatan', 73711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (45, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Timur', 73671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (46, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Utara', 73881);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (47, '28', 'Sulawesi Selatan', 'Kabupaten', 'Barru', 90719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (48, '17', 'Kepulauan Riau', 'Kota', 'Batam', 29413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (49, '10', 'Jawa Tengah', 'Kabupaten', 'Batang', 51211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (50, '8', 'Jambi', 'Kabupaten', 'Batang Hari', 36613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (51, '11', 'Jawa Timur', 'Kota', 'Batu', 65311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (52, '34', 'Sumatera Utara', 'Kabupaten', 'Batu Bara', 21655);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (53, '30', 'Sulawesi Tenggara', 'Kota', 'Bau-Bau', 93719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (54, '9', 'Jawa Barat', 'Kabupaten', 'Bekasi', 17837);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (55, '9', 'Jawa Barat', 'Kota', 'Bekasi', 17121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (56, '2', 'Bangka Belitung', 'Kabupaten', 'Belitung', 33419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (57, '2', 'Bangka Belitung', 'Kabupaten', 'Belitung Timur', 33519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (58, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Belu', 85711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (59, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Bener Meriah', 24581);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (60, '26', 'Riau', 'Kabupaten', 'Bengkalis', 28719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (61, '12', 'Kalimantan Barat', 'Kabupaten', 'Bengkayang', 79213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (62, '4', 'Bengkulu', 'Kota', 'Bengkulu', 38229);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (63, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Selatan', 38519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (64, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Tengah', 38319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (65, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Utara', 38619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (66, '15', 'Kalimantan Timur', 'Kabupaten', 'Berau', 77311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (67, '24', 'Papua', 'Kabupaten', 'Biak Numfor', 98119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (68, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Bima', 84171);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (69, '22', 'Nusa Tenggara Barat (NTB)', 'Kota', 'Bima', 84139);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (70, '34', 'Sumatera Utara', 'Kota', 'Binjai', 20712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (71, '17', 'Kepulauan Riau', 'Kabupaten', 'Bintan', 29135);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (72, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Bireuen', 24219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (73, '31', 'Sulawesi Utara', 'Kota', 'Bitung', 95512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (74, '11', 'Jawa Timur', 'Kabupaten', 'Blitar', 66171);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (75, '11', 'Jawa Timur', 'Kota', 'Blitar', 66124);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (76, '10', 'Jawa Tengah', 'Kabupaten', 'Blora', 58219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (77, '7', 'Gorontalo', 'Kabupaten', 'Boalemo', 96319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (78, '9', 'Jawa Barat', 'Kabupaten', 'Bogor', 16911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (79, '9', 'Jawa Barat', 'Kota', 'Bogor', 16119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (80, '11', 'Jawa Timur', 'Kabupaten', 'Bojonegoro', 62119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (81, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow (Bolmong)', 95755);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (82, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Selatan', 95774);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (83, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Timur', 95783);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (84, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Utara', 95765);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (85, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Bombana', 93771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (86, '11', 'Jawa Timur', 'Kabupaten', 'Bondowoso', 68219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (87, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bone', 92713);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (88, '7', 'Gorontalo', 'Kabupaten', 'Bone Bolango', 96511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (89, '15', 'Kalimantan Timur', 'Kota', 'Bontang', 75313);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (90, '24', 'Papua', 'Kabupaten', 'Boven Digoel', 99662);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (91, '10', 'Jawa Tengah', 'Kabupaten', 'Boyolali', 57312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (92, '10', 'Jawa Tengah', 'Kabupaten', 'Brebes', 52212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (93, '32', 'Sumatera Barat', 'Kota', 'Bukittinggi', 26115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (94, '1', 'Bali', 'Kabupaten', 'Buleleng', 81111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (95, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bulukumba', 92511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (96, '16', 'Kalimantan Utara', 'Kabupaten', 'Bulungan (Bulongan)', 77211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (97, '8', 'Jambi', 'Kabupaten', 'Bungo', 37216);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (98, '29', 'Sulawesi Tengah', 'Kabupaten', 'Buol', 94564);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (99, '19', 'Maluku', 'Kabupaten', 'Buru', 97371);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (100, '19', 'Maluku', 'Kabupaten', 'Buru Selatan', 97351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (101, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Buton', 93754);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (102, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Buton Utara', 93745);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (103, '9', 'Jawa Barat', 'Kabupaten', 'Ciamis', 46211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (104, '9', 'Jawa Barat', 'Kabupaten', 'Cianjur', 43217);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (105, '10', 'Jawa Tengah', 'Kabupaten', 'Cilacap', 53211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (106, '3', 'Banten', 'Kota', 'Cilegon', 42417);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (107, '9', 'Jawa Barat', 'Kota', 'Cimahi', 40512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (108, '9', 'Jawa Barat', 'Kabupaten', 'Cirebon', 45611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (109, '9', 'Jawa Barat', 'Kota', 'Cirebon', 45116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (110, '34', 'Sumatera Utara', 'Kabupaten', 'Dairi', 22211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (111, '24', 'Papua', 'Kabupaten', 'Deiyai (Deliyai)', 98784);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (112, '34', 'Sumatera Utara', 'Kabupaten', 'Deli Serdang', 20511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (113, '10', 'Jawa Tengah', 'Kabupaten', 'Demak', 59519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (114, '1', 'Bali', 'Kota', 'Denpasar', 80227);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (115, '9', 'Jawa Barat', 'Kota', 'Depok', 16416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (116, '32', 'Sumatera Barat', 'Kabupaten', 'Dharmasraya', 27612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (117, '24', 'Papua', 'Kabupaten', 'Dogiyai', 98866);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (118, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Dompu', 84217);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (119, '29', 'Sulawesi Tengah', 'Kabupaten', 'Donggala', 94341);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (120, '26', 'Riau', 'Kota', 'Dumai', 28811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (121, '33', 'Sumatera Selatan', 'Kabupaten', 'Empat Lawang', 31811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (122, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Ende', 86351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (123, '28', 'Sulawesi Selatan', 'Kabupaten', 'Enrekang', 91719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (124, '25', 'Papua Barat', 'Kabupaten', 'Fakfak', 98651);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (125, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Flores Timur', 86213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (126, '9', 'Jawa Barat', 'Kabupaten', 'Garut', 44126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (127, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Gayo Lues', 24653);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (128, '1', 'Bali', 'Kabupaten', 'Gianyar', 80519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (129, '7', 'Gorontalo', 'Kabupaten', 'Gorontalo', 96218);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (130, '7', 'Gorontalo', 'Kota', 'Gorontalo', 96115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (131, '7', 'Gorontalo', 'Kabupaten', 'Gorontalo Utara', 96611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (132, '28', 'Sulawesi Selatan', 'Kabupaten', 'Gowa', 92111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (133, '11', 'Jawa Timur', 'Kabupaten', 'Gresik', 61115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (134, '10', 'Jawa Tengah', 'Kabupaten', 'Grobogan', 58111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (135, '5', 'DI Yogyakarta', 'Kabupaten', 'Gunung Kidul', 55812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (136, '14', 'Kalimantan Tengah', 'Kabupaten', 'Gunung Mas', 74511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (137, '34', 'Sumatera Utara', 'Kota', 'Gunungsitoli', 22813);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (138, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Barat', 97757);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (139, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Selatan', 97911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (140, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Tengah', 97853);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (141, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Timur', 97862);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (142, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Utara', 97762);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (143, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Selatan', 71212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (144, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Tengah', 71313);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (145, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Utara', 71419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (146, '34', 'Sumatera Utara', 'Kabupaten', 'Humbang Hasundutan', 22457);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (147, '26', 'Riau', 'Kabupaten', 'Indragiri Hilir', 29212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (148, '26', 'Riau', 'Kabupaten', 'Indragiri Hulu', 29319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (149, '9', 'Jawa Barat', 'Kabupaten', 'Indramayu', 45214);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (150, '24', 'Papua', 'Kabupaten', 'Intan Jaya', 98771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (151, '6', 'DKI Jakarta', 'Kota', 'Jakarta Barat', 11220);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (152, '6', 'DKI Jakarta', 'Kota', 'Jakarta Pusat', 10540);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (153, '6', 'DKI Jakarta', 'Kota', 'Jakarta Selatan', 12230);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (154, '6', 'DKI Jakarta', 'Kota', 'Jakarta Timur', 13330);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (155, '6', 'DKI Jakarta', 'Kota', 'Jakarta Utara', 14140);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (156, '8', 'Jambi', 'Kota', 'Jambi', 36111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (157, '24', 'Papua', 'Kabupaten', 'Jayapura', 99352);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (158, '24', 'Papua', 'Kota', 'Jayapura', 99114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (159, '24', 'Papua', 'Kabupaten', 'Jayawijaya', 99511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (160, '11', 'Jawa Timur', 'Kabupaten', 'Jember', 68113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (161, '1', 'Bali', 'Kabupaten', 'Jembrana', 82251);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (162, '28', 'Sulawesi Selatan', 'Kabupaten', 'Jeneponto', 92319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (163, '10', 'Jawa Tengah', 'Kabupaten', 'Jepara', 59419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (164, '11', 'Jawa Timur', 'Kabupaten', 'Jombang', 61415);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (165, '25', 'Papua Barat', 'Kabupaten', 'Kaimana', 98671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (166, '26', 'Riau', 'Kabupaten', 'Kampar', 28411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (167, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kapuas', 73583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (168, '12', 'Kalimantan Barat', 'Kabupaten', 'Kapuas Hulu', 78719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (169, '10', 'Jawa Tengah', 'Kabupaten', 'Karanganyar', 57718);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (170, '1', 'Bali', 'Kabupaten', 'Karangasem', 80819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (171, '9', 'Jawa Barat', 'Kabupaten', 'Karawang', 41311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (172, '17', 'Kepulauan Riau', 'Kabupaten', 'Karimun', 29611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (173, '34', 'Sumatera Utara', 'Kabupaten', 'Karo', 22119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (174, '14', 'Kalimantan Tengah', 'Kabupaten', 'Katingan', 74411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (175, '4', 'Bengkulu', 'Kabupaten', 'Kaur', 38911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (176, '12', 'Kalimantan Barat', 'Kabupaten', 'Kayong Utara', 78852);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (177, '10', 'Jawa Tengah', 'Kabupaten', 'Kebumen', 54319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (178, '11', 'Jawa Timur', 'Kabupaten', 'Kediri', 64184);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (179, '11', 'Jawa Timur', 'Kota', 'Kediri', 64125);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (180, '24', 'Papua', 'Kabupaten', 'Keerom', 99461);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (181, '10', 'Jawa Tengah', 'Kabupaten', 'Kendal', 51314);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (182, '30', 'Sulawesi Tenggara', 'Kota', 'Kendari', 93126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (183, '4', 'Bengkulu', 'Kabupaten', 'Kepahiang', 39319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (184, '17', 'Kepulauan Riau', 'Kabupaten', 'Kepulauan Anambas', 29991);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (185, '19', 'Maluku', 'Kabupaten', 'Kepulauan Aru', 97681);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (186, '32', 'Sumatera Barat', 'Kabupaten', 'Kepulauan Mentawai', 25771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (187, '26', 'Riau', 'Kabupaten', 'Kepulauan Meranti', 28791);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (188, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Sangihe', 95819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (189, '6', 'DKI Jakarta', 'Kabupaten', 'Kepulauan Seribu', 14550);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (190, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Siau Tagulandang Biaro (Sitaro)', 95862);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (191, '20', 'Maluku Utara', 'Kabupaten', 'Kepulauan Sula', 97995);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (192, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Talaud', 95885);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (193, '24', 'Papua', 'Kabupaten', 'Kepulauan Yapen (Yapen Waropen)', 98211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (194, '8', 'Jambi', 'Kabupaten', 'Kerinci', 37167);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (195, '12', 'Kalimantan Barat', 'Kabupaten', 'Ketapang', 78874);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (196, '10', 'Jawa Tengah', 'Kabupaten', 'Klaten', 57411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (197, '1', 'Bali', 'Kabupaten', 'Klungkung', 80719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (198, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Kolaka', 93511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (199, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Kolaka Utara', 93911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (200, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe', 93411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (201, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe Selatan', 93811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (202, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe Utara', 93311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (203, '13', 'Kalimantan Selatan', 'Kabupaten', 'Kotabaru', 72119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (204, '31', 'Sulawesi Utara', 'Kota', 'Kotamobagu', 95711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (205, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kotawaringin Barat', 74119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (206, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kotawaringin Timur', 74364);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (207, '26', 'Riau', 'Kabupaten', 'Kuantan Singingi', 29519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (208, '12', 'Kalimantan Barat', 'Kabupaten', 'Kubu Raya', 78311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (209, '10', 'Jawa Tengah', 'Kabupaten', 'Kudus', 59311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (210, '5', 'DI Yogyakarta', 'Kabupaten', 'Kulon Progo', 55611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (211, '9', 'Jawa Barat', 'Kabupaten', 'Kuningan', 45511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (212, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Kupang', 85362);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (213, '23', 'Nusa Tenggara Timur (NTT)', 'Kota', 'Kupang', 85119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (214, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Barat', 75711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (215, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Kartanegara', 75511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (216, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Timur', 75611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (217, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu', 21412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (218, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu Selatan', 21511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (219, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu Utara', 21711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (220, '33', 'Sumatera Selatan', 'Kabupaten', 'Lahat', 31419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (221, '14', 'Kalimantan Tengah', 'Kabupaten', 'Lamandau', 74611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (222, '11', 'Jawa Timur', 'Kabupaten', 'Lamongan', 64125);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (223, '18', 'Lampung', 'Kabupaten', 'Lampung Barat', 34814);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (224, '18', 'Lampung', 'Kabupaten', 'Lampung Selatan', 35511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (225, '18', 'Lampung', 'Kabupaten', 'Lampung Tengah', 34212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (226, '18', 'Lampung', 'Kabupaten', 'Lampung Timur', 34319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (227, '18', 'Lampung', 'Kabupaten', 'Lampung Utara', 34516);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (228, '12', 'Kalimantan Barat', 'Kabupaten', 'Landak', 78319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (229, '34', 'Sumatera Utara', 'Kabupaten', 'Langkat', 20811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (230, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Langsa', 24412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (231, '24', 'Papua', 'Kabupaten', 'Lanny Jaya', 99531);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (232, '3', 'Banten', 'Kabupaten', 'Lebak', 42319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (233, '4', 'Bengkulu', 'Kabupaten', 'Lebong', 39264);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (234, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Lembata', 86611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (235, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Lhokseumawe', 24352);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (236, '32', 'Sumatera Barat', 'Kabupaten', 'Lima Puluh Koto/Kota', 26671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (237, '17', 'Kepulauan Riau', 'Kabupaten', 'Lingga', 29811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (238, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Barat', 83311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (239, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Tengah', 83511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (240, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Timur', 83612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (241, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Utara', 83711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (242, '33', 'Sumatera Selatan', 'Kota', 'Lubuk Linggau', 31614);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (243, '11', 'Jawa Timur', 'Kabupaten', 'Lumajang', 67319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (244, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu', 91994);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (245, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu Timur', 92981);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (246, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu Utara', 92911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (247, '11', 'Jawa Timur', 'Kabupaten', 'Madiun', 63153);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (248, '11', 'Jawa Timur', 'Kota', 'Madiun', 63122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (249, '10', 'Jawa Tengah', 'Kabupaten', 'Magelang', 56519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (250, '10', 'Jawa Tengah', 'Kota', 'Magelang', 56133);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (251, '11', 'Jawa Timur', 'Kabupaten', 'Magetan', 63314);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (252, '9', 'Jawa Barat', 'Kabupaten', 'Majalengka', 45412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (253, '27', 'Sulawesi Barat', 'Kabupaten', 'Majene', 91411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (254, '28', 'Sulawesi Selatan', 'Kota', 'Makassar', 90111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (255, '11', 'Jawa Timur', 'Kabupaten', 'Malang', 65163);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (256, '11', 'Jawa Timur', 'Kota', 'Malang', 65112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (257, '16', 'Kalimantan Utara', 'Kabupaten', 'Malinau', 77511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (258, '19', 'Maluku', 'Kabupaten', 'Maluku Barat Daya', 97451);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (259, '19', 'Maluku', 'Kabupaten', 'Maluku Tengah', 97513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (260, '19', 'Maluku', 'Kabupaten', 'Maluku Tenggara', 97651);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (261, '19', 'Maluku', 'Kabupaten', 'Maluku Tenggara Barat', 97465);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (262, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamasa', 91362);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (263, '24', 'Papua', 'Kabupaten', 'Mamberamo Raya', 99381);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (264, '24', 'Papua', 'Kabupaten', 'Mamberamo Tengah', 99553);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (265, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamuju', 91519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (266, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamuju Utara', 91571);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (267, '31', 'Sulawesi Utara', 'Kota', 'Manado', 95247);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (268, '34', 'Sumatera Utara', 'Kabupaten', 'Mandailing Natal', 22916);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (269, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai', 86551);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (270, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai Barat', 86711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (271, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai Timur', 86811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (272, '25', 'Papua Barat', 'Kabupaten', 'Manokwari', 98311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (273, '25', 'Papua Barat', 'Kabupaten', 'Manokwari Selatan', 98355);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (274, '24', 'Papua', 'Kabupaten', 'Mappi', 99853);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (275, '28', 'Sulawesi Selatan', 'Kabupaten', 'Maros', 90511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (276, '22', 'Nusa Tenggara Barat (NTB)', 'Kota', 'Mataram', 83131);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (277, '25', 'Papua Barat', 'Kabupaten', 'Maybrat', 98051);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (278, '34', 'Sumatera Utara', 'Kota', 'Medan', 20228);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (279, '12', 'Kalimantan Barat', 'Kabupaten', 'Melawi', 78619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (280, '8', 'Jambi', 'Kabupaten', 'Merangin', 37319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (281, '24', 'Papua', 'Kabupaten', 'Merauke', 99613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (282, '18', 'Lampung', 'Kabupaten', 'Mesuji', 34911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (283, '18', 'Lampung', 'Kota', 'Metro', 34111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (284, '24', 'Papua', 'Kabupaten', 'Mimika', 99962);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (285, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa', 95614);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (286, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Selatan', 95914);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (287, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Tenggara', 95995);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (288, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Utara', 95316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (289, '11', 'Jawa Timur', 'Kabupaten', 'Mojokerto', 61382);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (290, '11', 'Jawa Timur', 'Kota', 'Mojokerto', 61316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (291, '29', 'Sulawesi Tengah', 'Kabupaten', 'Morowali', 94911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (292, '33', 'Sumatera Selatan', 'Kabupaten', 'Muara Enim', 31315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (293, '8', 'Jambi', 'Kabupaten', 'Muaro Jambi', 36311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (294, '4', 'Bengkulu', 'Kabupaten', 'Muko Muko', 38715);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (295, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Muna', 93611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (296, '14', 'Kalimantan Tengah', 'Kabupaten', 'Murung Raya', 73911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (297, '33', 'Sumatera Selatan', 'Kabupaten', 'Musi Banyuasin', 30719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (298, '33', 'Sumatera Selatan', 'Kabupaten', 'Musi Rawas', 31661);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (299, '24', 'Papua', 'Kabupaten', 'Nabire', 98816);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (300, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Nagan Raya', 23674);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (301, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Nagekeo', 86911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (302, '17', 'Kepulauan Riau', 'Kabupaten', 'Natuna', 29711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (303, '24', 'Papua', 'Kabupaten', 'Nduga', 99541);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (304, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Ngada', 86413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (305, '11', 'Jawa Timur', 'Kabupaten', 'Nganjuk', 64414);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (306, '11', 'Jawa Timur', 'Kabupaten', 'Ngawi', 63219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (307, '34', 'Sumatera Utara', 'Kabupaten', 'Nias', 22876);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (308, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Barat', 22895);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (309, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Selatan', 22865);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (310, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Utara', 22856);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (311, '16', 'Kalimantan Utara', 'Kabupaten', 'Nunukan', 77421);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (312, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Ilir', 30811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (313, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ilir', 30618);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (314, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu', 32112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (315, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu Selatan', 32211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (316, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu Timur', 32312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (317, '11', 'Jawa Timur', 'Kabupaten', 'Pacitan', 63512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (318, '32', 'Sumatera Barat', 'Kota', 'Padang', 25112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (319, '34', 'Sumatera Utara', 'Kabupaten', 'Padang Lawas', 22763);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (320, '34', 'Sumatera Utara', 'Kabupaten', 'Padang Lawas Utara', 22753);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (321, '32', 'Sumatera Barat', 'Kota', 'Padang Panjang', 27122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (322, '32', 'Sumatera Barat', 'Kabupaten', 'Padang Pariaman', 25583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (323, '34', 'Sumatera Utara', 'Kota', 'Padang Sidempuan', 22727);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (324, '33', 'Sumatera Selatan', 'Kota', 'Pagar Alam', 31512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (325, '34', 'Sumatera Utara', 'Kabupaten', 'Pakpak Bharat', 22272);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (326, '14', 'Kalimantan Tengah', 'Kota', 'Palangka Raya', 73112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (327, '33', 'Sumatera Selatan', 'Kota', 'Palembang', 31512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (328, '28', 'Sulawesi Selatan', 'Kota', 'Palopo', 91911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (329, '29', 'Sulawesi Tengah', 'Kota', 'Palu', 94111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (330, '11', 'Jawa Timur', 'Kabupaten', 'Pamekasan', 69319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (331, '3', 'Banten', 'Kabupaten', 'Pandeglang', 42212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (332, '9', 'Jawa Barat', 'Kabupaten', 'Pangandaran', 46511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (333, '28', 'Sulawesi Selatan', 'Kabupaten', 'Pangkajene Kepulauan', 90611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (334, '2', 'Bangka Belitung', 'Kota', 'Pangkal Pinang', 33115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (335, '24', 'Papua', 'Kabupaten', 'Paniai', 98765);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (336, '28', 'Sulawesi Selatan', 'Kota', 'Parepare', 91123);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (337, '32', 'Sumatera Barat', 'Kota', 'Pariaman', 25511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (338, '29', 'Sulawesi Tengah', 'Kabupaten', 'Parigi Moutong', 94411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (339, '32', 'Sumatera Barat', 'Kabupaten', 'Pasaman', 26318);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (340, '32', 'Sumatera Barat', 'Kabupaten', 'Pasaman Barat', 26511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (341, '15', 'Kalimantan Timur', 'Kabupaten', 'Paser', 76211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (342, '11', 'Jawa Timur', 'Kabupaten', 'Pasuruan', 67153);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (343, '11', 'Jawa Timur', 'Kota', 'Pasuruan', 67118);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (344, '10', 'Jawa Tengah', 'Kabupaten', 'Pati', 59114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (345, '32', 'Sumatera Barat', 'Kota', 'Payakumbuh', 26213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (346, '25', 'Papua Barat', 'Kabupaten', 'Pegunungan Arfak', 98354);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (347, '24', 'Papua', 'Kabupaten', 'Pegunungan Bintang', 99573);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (348, '10', 'Jawa Tengah', 'Kabupaten', 'Pekalongan', 51161);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (349, '10', 'Jawa Tengah', 'Kota', 'Pekalongan', 51122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (350, '26', 'Riau', 'Kota', 'Pekanbaru', 28112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (351, '26', 'Riau', 'Kabupaten', 'Pelalawan', 28311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (352, '10', 'Jawa Tengah', 'Kabupaten', 'Pemalang', 52319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (353, '34', 'Sumatera Utara', 'Kota', 'Pematang Siantar', 21126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (354, '15', 'Kalimantan Timur', 'Kabupaten', 'Penajam Paser Utara', 76311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (355, '18', 'Lampung', 'Kabupaten', 'Pesawaran', 35312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (356, '18', 'Lampung', 'Kabupaten', 'Pesisir Barat', 35974);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (357, '32', 'Sumatera Barat', 'Kabupaten', 'Pesisir Selatan', 25611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (358, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Pidie', 24116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (359, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Pidie Jaya', 24186);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (360, '28', 'Sulawesi Selatan', 'Kabupaten', 'Pinrang', 91251);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (361, '7', 'Gorontalo', 'Kabupaten', 'Pohuwato', 96419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (362, '27', 'Sulawesi Barat', 'Kabupaten', 'Polewali Mandar', 91311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (363, '11', 'Jawa Timur', 'Kabupaten', 'Ponorogo', 63411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (364, '12', 'Kalimantan Barat', 'Kabupaten', 'Pontianak', 78971);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (365, '12', 'Kalimantan Barat', 'Kota', 'Pontianak', 78112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (366, '29', 'Sulawesi Tengah', 'Kabupaten', 'Poso', 94615);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (367, '33', 'Sumatera Selatan', 'Kota', 'Prabumulih', 31121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (368, '18', 'Lampung', 'Kabupaten', 'Pringsewu', 35719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (369, '11', 'Jawa Timur', 'Kabupaten', 'Probolinggo', 67282);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (370, '11', 'Jawa Timur', 'Kota', 'Probolinggo', 67215);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (371, '14', 'Kalimantan Tengah', 'Kabupaten', 'Pulang Pisau', 74811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (372, '20', 'Maluku Utara', 'Kabupaten', 'Pulau Morotai', 97771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (373, '24', 'Papua', 'Kabupaten', 'Puncak', 98981);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (374, '24', 'Papua', 'Kabupaten', 'Puncak Jaya', 98979);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (375, '10', 'Jawa Tengah', 'Kabupaten', 'Purbalingga', 53312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (376, '9', 'Jawa Barat', 'Kabupaten', 'Purwakarta', 41119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (377, '10', 'Jawa Tengah', 'Kabupaten', 'Purworejo', 54111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (378, '25', 'Papua Barat', 'Kabupaten', 'Raja Ampat', 98489);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (379, '4', 'Bengkulu', 'Kabupaten', 'Rejang Lebong', 39112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (380, '10', 'Jawa Tengah', 'Kabupaten', 'Rembang', 59219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (381, '26', 'Riau', 'Kabupaten', 'Rokan Hilir', 28992);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (382, '26', 'Riau', 'Kabupaten', 'Rokan Hulu', 28511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (383, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Rote Ndao', 85982);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (384, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Sabang', 23512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (385, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sabu Raijua', 85391);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (386, '10', 'Jawa Tengah', 'Kota', 'Salatiga', 50711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (387, '15', 'Kalimantan Timur', 'Kota', 'Samarinda', 75133);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (388, '12', 'Kalimantan Barat', 'Kabupaten', 'Sambas', 79453);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (389, '34', 'Sumatera Utara', 'Kabupaten', 'Samosir', 22392);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (390, '11', 'Jawa Timur', 'Kabupaten', 'Sampang', 69219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (391, '12', 'Kalimantan Barat', 'Kabupaten', 'Sanggau', 78557);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (392, '24', 'Papua', 'Kabupaten', 'Sarmi', 99373);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (393, '8', 'Jambi', 'Kabupaten', 'Sarolangun', 37419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (394, '32', 'Sumatera Barat', 'Kota', 'Sawah Lunto', 27416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (395, '12', 'Kalimantan Barat', 'Kabupaten', 'Sekadau', 79583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (396, '28', 'Sulawesi Selatan', 'Kabupaten', 'Selayar (Kepulauan Selayar)', 92812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (397, '4', 'Bengkulu', 'Kabupaten', 'Seluma', 38811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (398, '10', 'Jawa Tengah', 'Kabupaten', 'Semarang', 50511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (399, '10', 'Jawa Tengah', 'Kota', 'Semarang', 50135);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (400, '19', 'Maluku', 'Kabupaten', 'Seram Bagian Barat', 97561);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (401, '19', 'Maluku', 'Kabupaten', 'Seram Bagian Timur', 97581);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (402, '3', 'Banten', 'Kabupaten', 'Serang', 42182);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (403, '3', 'Banten', 'Kota', 'Serang', 42111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (404, '34', 'Sumatera Utara', 'Kabupaten', 'Serdang Bedagai', 20915);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (405, '14', 'Kalimantan Tengah', 'Kabupaten', 'Seruyan', 74211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (406, '26', 'Riau', 'Kabupaten', 'Siak', 28623);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (407, '34', 'Sumatera Utara', 'Kota', 'Sibolga', 22522);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (408, '28', 'Sulawesi Selatan', 'Kabupaten', 'Sidenreng Rappang/Rapang', 91613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (409, '11', 'Jawa Timur', 'Kabupaten', 'Sidoarjo', 61219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (410, '29', 'Sulawesi Tengah', 'Kabupaten', 'Sigi', 94364);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (411, '32', 'Sumatera Barat', 'Kabupaten', 'Sijunjung (Sawah Lunto Sijunjung)', 27511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (412, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sikka', 86121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (413, '34', 'Sumatera Utara', 'Kabupaten', 'Simalungun', 21162);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (414, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Simeulue', 23891);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (415, '12', 'Kalimantan Barat', 'Kota', 'Singkawang', 79117);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (416, '28', 'Sulawesi Selatan', 'Kabupaten', 'Sinjai', 92615);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (417, '12', 'Kalimantan Barat', 'Kabupaten', 'Sintang', 78619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (418, '11', 'Jawa Timur', 'Kabupaten', 'Situbondo', 68316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (419, '5', 'DI Yogyakarta', 'Kabupaten', 'Sleman', 55513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (420, '32', 'Sumatera Barat', 'Kabupaten', 'Solok', 27365);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (421, '32', 'Sumatera Barat', 'Kota', 'Solok', 27315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (422, '32', 'Sumatera Barat', 'Kabupaten', 'Solok Selatan', 27779);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (423, '28', 'Sulawesi Selatan', 'Kabupaten', 'Soppeng', 90812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (424, '25', 'Papua Barat', 'Kabupaten', 'Sorong', 98431);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (425, '25', 'Papua Barat', 'Kota', 'Sorong', 98411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (426, '25', 'Papua Barat', 'Kabupaten', 'Sorong Selatan', 98454);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (427, '10', 'Jawa Tengah', 'Kabupaten', 'Sragen', 57211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (428, '9', 'Jawa Barat', 'Kabupaten', 'Subang', 41215);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (429, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Subulussalam', 24882);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (430, '9', 'Jawa Barat', 'Kabupaten', 'Sukabumi', 43311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (431, '9', 'Jawa Barat', 'Kota', 'Sukabumi', 43114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (432, '14', 'Kalimantan Tengah', 'Kabupaten', 'Sukamara', 74712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (433, '10', 'Jawa Tengah', 'Kabupaten', 'Sukoharjo', 57514);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (434, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Barat', 87219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (435, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Barat Daya', 87453);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (436, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Tengah', 87358);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (437, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Timur', 87112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (438, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Sumbawa', 84315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (439, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Sumbawa Barat', 84419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (440, '9', 'Jawa Barat', 'Kabupaten', 'Sumedang', 45326);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (441, '11', 'Jawa Timur', 'Kabupaten', 'Sumenep', 69413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (442, '8', 'Jambi', 'Kota', 'Sungaipenuh', 37113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (443, '24', 'Papua', 'Kabupaten', 'Supiori', 98164);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (444, '11', 'Jawa Timur', 'Kota', 'Surabaya', 60119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (445, '10', 'Jawa Tengah', 'Kota', 'Surakarta (Solo)', 57113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (446, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tabalong', 71513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (447, '1', 'Bali', 'Kabupaten', 'Tabanan', 82119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (448, '28', 'Sulawesi Selatan', 'Kabupaten', 'Takalar', 92212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (449, '25', 'Papua Barat', 'Kabupaten', 'Tambrauw', 98475);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (450, '16', 'Kalimantan Utara', 'Kabupaten', 'Tana Tidung', 77611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (451, '28', 'Sulawesi Selatan', 'Kabupaten', 'Tana Toraja', 91819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (452, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tanah Bumbu', 72211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (453, '32', 'Sumatera Barat', 'Kabupaten', 'Tanah Datar', 27211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (454, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tanah Laut', 70811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (455, '3', 'Banten', 'Kabupaten', 'Tangerang', 15914);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (456, '3', 'Banten', 'Kota', 'Tangerang', 15111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (457, '3', 'Banten', 'Kota', 'Tangerang Selatan', 15332);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (458, '18', 'Lampung', 'Kabupaten', 'Tanggamus', 35619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (459, '34', 'Sumatera Utara', 'Kota', 'Tanjung Balai', 21321);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (460, '8', 'Jambi', 'Kabupaten', 'Tanjung Jabung Barat', 36513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (461, '8', 'Jambi', 'Kabupaten', 'Tanjung Jabung Timur', 36719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (462, '17', 'Kepulauan Riau', 'Kota', 'Tanjung Pinang', 29111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (463, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Selatan', 22742);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (464, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Tengah', 22611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (465, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Utara', 22414);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (466, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tapin', 71119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (467, '16', 'Kalimantan Utara', 'Kota', 'Tarakan', 77114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (468, '9', 'Jawa Barat', 'Kabupaten', 'Tasikmalaya', 46411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (469, '9', 'Jawa Barat', 'Kota', 'Tasikmalaya', 46116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (470, '34', 'Sumatera Utara', 'Kota', 'Tebing Tinggi', 20632);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (471, '8', 'Jambi', 'Kabupaten', 'Tebo', 37519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (472, '10', 'Jawa Tengah', 'Kabupaten', 'Tegal', 52419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (473, '10', 'Jawa Tengah', 'Kota', 'Tegal', 52114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (474, '25', 'Papua Barat', 'Kabupaten', 'Teluk Bintuni', 98551);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (475, '25', 'Papua Barat', 'Kabupaten', 'Teluk Wondama', 98591);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (476, '10', 'Jawa Tengah', 'Kabupaten', 'Temanggung', 56212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (477, '20', 'Maluku Utara', 'Kota', 'Ternate', 97714);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (478, '20', 'Maluku Utara', 'Kota', 'Tidore Kepulauan', 97815);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (479, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Timor Tengah Selatan', 85562);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (480, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Timor Tengah Utara', 85612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (481, '34', 'Sumatera Utara', 'Kabupaten', 'Toba Samosir', 22316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (482, '29', 'Sulawesi Tengah', 'Kabupaten', 'Tojo Una-Una', 94683);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (483, '29', 'Sulawesi Tengah', 'Kabupaten', 'Toli-Toli', 94542);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (484, '24', 'Papua', 'Kabupaten', 'Tolikara', 99411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (485, '31', 'Sulawesi Utara', 'Kota', 'Tomohon', 95416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (486, '28', 'Sulawesi Selatan', 'Kabupaten', 'Toraja Utara', 91831);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (487, '11', 'Jawa Timur', 'Kabupaten', 'Trenggalek', 66312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (488, '19', 'Maluku', 'Kota', 'Tual', 97612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (489, '11', 'Jawa Timur', 'Kabupaten', 'Tuban', 62319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (490, '18', 'Lampung', 'Kabupaten', 'Tulang Bawang', 34613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (491, '18', 'Lampung', 'Kabupaten', 'Tulang Bawang Barat', 34419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (492, '11', 'Jawa Timur', 'Kabupaten', 'Tulungagung', 66212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (493, '28', 'Sulawesi Selatan', 'Kabupaten', 'Wajo', 90911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (494, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Wakatobi', 93791);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (495, '24', 'Papua', 'Kabupaten', 'Waropen', 98269);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (496, '18', 'Lampung', 'Kabupaten', 'Way Kanan', 34711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (497, '10', 'Jawa Tengah', 'Kabupaten', 'Wonogiri', 57619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (498, '10', 'Jawa Tengah', 'Kabupaten', 'Wonosobo', 56311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (499, '24', 'Papua', 'Kabupaten', 'Yahukimo', 99041);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (500, '24', 'Papua', 'Kabupaten', 'Yalimo', 99481);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (501, '5', 'DI Yogyakarta', 'Kota', 'Yogyakarta', 55222);


#
# TABLE STRUCTURE FOR: sr_mata_pelajaran
#

DROP TABLE IF EXISTS `sr_mata_pelajaran`;

CREATE TABLE `sr_mata_pelajaran` (
  `idmata_pelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `mp_kode` varchar(50) NOT NULL,
  `mp_nama` varchar(255) NOT NULL,
  `mp_kelompok` enum('A','B','C','C1','C2') NOT NULL,
  `mp_urutan` int(11) NOT NULL,
  PRIMARY KEY (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (1, '5', 'PAI', 'Pendidikan Agama Islam', 'A', 1);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (2, '5', 'BIND', 'Bahasa Indonesia', 'A', 3);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (3, '5', 'MTK', 'Matematika', 'A', 5);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (46, '5', 'PKn', 'Pendidikan Kewarganegaraan', 'A', 2);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (47, '5', 'SBdP', 'Seni Budaya dan Prakarya', 'B', 1);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (48, '5', 'PJOK', 'Pendidikan Jasmani, Olahraga dan Kesehatan', 'B', 2);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (49, '5', 'IPA', 'Ilmu Pengetahuan Alam', 'A', 6);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (50, '5', 'IPS', 'Ilmu Pengetahuan Sosial', 'A', 7);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (51, '5', 'BING', 'Bahasa Inggris', 'A', 8);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (63, '5', 'MM', 'Multimedia', 'C1', 13);


#
# TABLE STRUCTURE FOR: sr_materi
#

DROP TABLE IF EXISTS `sr_materi`;

CREATE TABLE `sr_materi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `mapel_id` int(11) NOT NULL,
  `pengajar_id` int(11) DEFAULT NULL,
  `judul` varchar(255) NOT NULL,
  `konten` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `video` text NOT NULL,
  `tgl_posting` datetime NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT 0,
  `views` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (1, '5', 3, 1, 'Trigonometri Matematika', '<p>Test trigonometri</p>\r\n', NULL, '', '2021-12-08 00:13:45', 1, 6);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (2, '5', 4, 1, 'Excel MOS', NULL, 'excel_mos_1638897335.xlsx', '', '2021-12-08 00:15:35', 1, 2);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (3, '5', 1, 1, 'hhhh', NULL, 'hhhh_1639155245.png', '', '2021-12-10 23:54:05', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (4, '5', 12, 3, 'test', NULL, 'test_1639439137.jpg', '', '2021-12-14 06:45:41', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (5, '5', 13, 3, 'eaeae', NULL, 'eaeae_1639439314.jpg', '', '2021-12-14 06:48:34', 0, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (6, '5', 20, 3, 'yeaah', NULL, '1', '', '2021-12-14 07:01:52', 0, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (7, '5', 13, 3, 'test', 'https://www.youtube.com/watch?v=e86xyGaP6Ow', '1', '', '2021-12-14 07:24:50', 0, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (8, '5', 13, 3, 'dsaadsadsds', 'https://www.youtube.com/watch?v=YRAImdAcl5g', '1', 'https://www.youtube.com/watch?v=YRAImdAcl5g', '2021-12-14 07:36:13', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (9, '5', 13, 4, 'Belajar Dasar - Dasar Programming', NULL, '1', 'https://www.youtube.com/watch?v=sKrri__gMIQ', '2021-12-14 09:16:46', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (10, '5', 20, 12, 'test', NULL, '1', 'https://www.youtube.com/watch?v=X5E61YavZqA', '2021-12-14 23:03:17', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (11, '5', 16, 41, 'Materi Tentang Dasar-Dasar PHP dan Laravel', NULL, '1', 'https://www.youtube.com/watch?v=TaBWhb5SPfc', '2022-01-09 21:48:51', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (12, '5', 16, 33, 'Dasar-Dasar Programming Laravel Dan PHP', NULL, '1', 'https://www.youtube.com/watch?v=eRZFGSCkAnw&t=7s', '2022-01-10 12:16:42', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (13, '5', 16, 27, 'Pembelajaran Dasar - Dasar Programming Laravel', NULL, '1', 'https://www.youtube.com/watch?v=eRZFGSCkAnw', '2022-01-12 14:12:26', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (14, '5', 17, 36, 'test', NULL, '1', 'https://www.youtube.com/watch?v=X5E61YavZqA', '2022-01-12 14:37:42', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (15, '5', 17, 39, 'TEST', NULL, '1', 'https://www.youtube.com/watch?v=X5E61YavZqA', '2022-01-12 15:12:14', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (16, '5', 15, 42, 'Test', NULL, '1', 'https://www.youtube.com/watch?v=X5E61YavZqA', '2022-01-12 15:22:21', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (17, '5', 46, 26, 'damara', NULL, '1', 'https://www.youtube.com/watch?v=67l76EQWzGk', '2022-01-12 18:02:50', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (18, '5', 16, 47, 'Dasar-Dasar Programming Laravel', NULL, '1', 'https://www.youtube.com/watch?v=eRZFGSCkAnw&t=3s', '2022-01-18 12:17:25', 1, 1);


#
# TABLE STRUCTURE FOR: sr_pajak_keuangan
#

DROP TABLE IF EXISTS `sr_pajak_keuangan`;

CREATE TABLE `sr_pajak_keuangan` (
  `id_pajak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pajak` varchar(200) NOT NULL,
  `besaran_pajak` varchar(100) NOT NULL,
  PRIMARY KEY (`id_pajak`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pajak_keuangan` (`id_pajak`, `nama_pajak`, `besaran_pajak`) VALUES (4, 'PPN', '20');
INSERT INTO `sr_pajak_keuangan` (`id_pajak`, `nama_pajak`, `besaran_pajak`) VALUES (5, 'PPH 20', '20');


#
# TABLE STRUCTURE FOR: sr_pembayaran_bebas
#

DROP TABLE IF EXISTS `sr_pembayaran_bebas`;

CREATE TABLE `sr_pembayaran_bebas` (
  `id_pembayaran_bebas` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran_bebas`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_pembayaran_bulanan
#

DROP TABLE IF EXISTS `sr_pembayaran_bulanan`;

CREATE TABLE `sr_pembayaran_bulanan` (
  `id_pembayaran_bulanan` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `bulan` varchar(15) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `bayar` float DEFAULT 0,
  `tanggal` date NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran_bulanan`)
) ENGINE=InnoDB AUTO_INCREMENT=2641 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2353, 2, 32, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2354, 2, 32, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2355, 2, 32, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2356, 2, 32, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2357, 2, 32, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2358, 2, 32, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2359, 2, 32, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2360, 2, 32, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2361, 2, 32, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2362, 2, 32, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2363, 2, 32, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2364, 2, 32, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2365, 2, 33, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2366, 2, 33, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2367, 2, 33, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2368, 2, 33, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2369, 2, 33, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2370, 2, 33, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2371, 2, 33, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2372, 2, 33, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2373, 2, 33, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2374, 2, 33, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2375, 2, 33, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2376, 2, 33, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2377, 2, 34, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2378, 2, 34, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2379, 2, 34, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2380, 2, 34, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2381, 2, 34, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2382, 2, 34, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2383, 2, 34, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2384, 2, 34, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2385, 2, 34, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2386, 2, 34, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2387, 2, 34, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2388, 2, 34, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2389, 2, 39, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2390, 2, 39, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2391, 2, 39, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2392, 2, 39, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2393, 2, 39, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2394, 2, 39, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2395, 2, 39, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2396, 2, 39, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2397, 2, 39, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2398, 2, 39, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2399, 2, 39, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2400, 2, 39, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2401, 2, 40, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2402, 2, 40, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2403, 2, 40, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2404, 2, 40, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2405, 2, 40, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2406, 2, 40, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2407, 2, 40, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2408, 2, 40, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2409, 2, 40, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2410, 2, 40, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2411, 2, 40, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2412, 2, 40, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2413, 2, 41, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2414, 2, 41, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2415, 2, 41, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2416, 2, 41, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2417, 2, 41, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2418, 2, 41, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2419, 2, 41, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2420, 2, 41, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2421, 2, 41, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2422, 2, 41, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2423, 2, 41, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2424, 2, 41, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2425, 2, 42, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2426, 2, 42, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2427, 2, 42, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2428, 2, 42, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2429, 2, 42, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2430, 2, 42, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2431, 2, 42, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2432, 2, 42, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2433, 2, 42, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2434, 2, 42, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2435, 2, 42, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2436, 2, 42, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2437, 2, 43, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2438, 2, 43, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2439, 2, 43, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2440, 2, 43, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2441, 2, 43, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2442, 2, 43, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2443, 2, 43, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2444, 2, 43, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2445, 2, 43, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2446, 2, 43, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2447, 2, 43, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2448, 2, 43, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2449, 2, 44, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2450, 2, 44, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2451, 2, 44, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2452, 2, 44, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2453, 2, 44, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2454, 2, 44, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2455, 2, 44, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2456, 2, 44, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2457, 2, 44, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2458, 2, 44, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2459, 2, 44, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2460, 2, 44, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2461, 2, 45, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2462, 2, 45, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2463, 2, 45, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2464, 2, 45, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2465, 2, 45, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2466, 2, 45, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2467, 2, 45, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2468, 2, 45, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2469, 2, 45, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2470, 2, 45, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2471, 2, 45, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2472, 2, 45, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2473, 2, 46, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2474, 2, 46, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2475, 2, 46, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2476, 2, 46, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2477, 2, 46, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2478, 2, 46, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2479, 2, 46, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2480, 2, 46, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2481, 2, 46, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2482, 2, 46, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2483, 2, 46, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2484, 2, 46, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2485, 2, 47, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2486, 2, 47, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2487, 2, 47, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2488, 2, 47, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2489, 2, 47, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2490, 2, 47, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2491, 2, 47, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2492, 2, 47, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2493, 2, 47, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2494, 2, 47, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2495, 2, 47, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2496, 2, 47, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2497, 2, 48, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2498, 2, 48, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2499, 2, 48, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2500, 2, 48, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2501, 2, 48, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2502, 2, 48, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2503, 2, 48, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2504, 2, 48, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2505, 2, 48, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2506, 2, 48, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2507, 2, 48, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2508, 2, 48, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2509, 2, 49, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2510, 2, 49, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2511, 2, 49, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2512, 2, 49, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2513, 2, 49, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2514, 2, 49, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2515, 2, 49, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2516, 2, 49, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2517, 2, 49, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2518, 2, 49, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2519, 2, 49, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2520, 2, 49, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2521, 2, 50, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2522, 2, 50, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2523, 2, 50, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2524, 2, 50, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2525, 2, 50, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2526, 2, 50, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2527, 2, 50, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2528, 2, 50, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2529, 2, 50, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2530, 2, 50, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2531, 2, 50, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2532, 2, 50, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2533, 2, 51, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2534, 2, 51, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2535, 2, 51, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2536, 2, 51, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2537, 2, 51, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2538, 2, 51, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2539, 2, 51, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2540, 2, 51, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2541, 2, 51, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2542, 2, 51, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2543, 2, 51, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2544, 2, 51, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2545, 2, 52, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2546, 2, 52, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2547, 2, 52, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2548, 2, 52, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2549, 2, 52, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2550, 2, 52, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2551, 2, 52, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2552, 2, 52, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2553, 2, 52, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2554, 2, 52, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2555, 2, 52, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2556, 2, 52, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2557, 2, 53, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2558, 2, 53, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2559, 2, 53, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2560, 2, 53, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2561, 2, 53, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2562, 2, 53, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2563, 2, 53, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2564, 2, 53, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2565, 2, 53, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2566, 2, 53, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2567, 2, 53, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2568, 2, 53, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2569, 2, 54, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2570, 2, 54, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2571, 2, 54, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2572, 2, 54, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2573, 2, 54, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2574, 2, 54, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2575, 2, 54, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2576, 2, 54, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2577, 2, 54, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2578, 2, 54, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2579, 2, 54, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2580, 2, 54, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2581, 2, 55, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2582, 2, 55, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2583, 2, 55, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2584, 2, 55, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2585, 2, 55, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2586, 2, 55, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2587, 2, 55, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2588, 2, 55, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2589, 2, 55, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2590, 2, 55, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2591, 2, 55, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2592, 2, 55, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2593, 2, 56, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2594, 2, 56, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2595, 2, 56, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2596, 2, 56, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2597, 2, 56, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2598, 2, 56, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2599, 2, 56, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2600, 2, 56, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2601, 2, 56, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2602, 2, 56, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2603, 2, 56, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2604, 2, 56, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2605, 2, 57, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2606, 2, 57, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2607, 2, 57, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2608, 2, 57, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2609, 2, 57, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2610, 2, 57, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2611, 2, 57, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2612, 2, 57, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2613, 2, 57, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2614, 2, 57, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2615, 2, 57, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2616, 2, 57, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2617, 2, 143, 2, 'Juli', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2618, 2, 143, 2, 'Agustus', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2619, 2, 143, 2, 'September', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2620, 2, 143, 2, 'Oktober', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2621, 2, 143, 2, 'November', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2622, 2, 143, 2, 'Desember', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2623, 2, 143, 2, 'Januari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2624, 2, 143, 2, 'Febuari', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2625, 2, 143, 2, 'Maret', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2626, 2, 143, 2, 'April', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2627, 2, 143, 2, 'Mei', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2628, 2, 143, 2, 'Juni', '1000000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2629, 2, 116, 5, 'Juli', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2630, 2, 116, 5, 'Agustus', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2631, 2, 116, 5, 'September', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2632, 2, 116, 5, 'Oktober', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2633, 2, 116, 5, 'November', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2634, 2, 116, 5, 'Desember', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2635, 2, 116, 5, 'Januari', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2636, 2, 116, 5, 'Febuari', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2637, 2, 116, 5, 'Maret', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2638, 2, 116, 5, 'April', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2639, 2, 116, 5, 'Mei', '2500000', '0', '0000-00-00', NULL);
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`) VALUES (2640, 2, 116, 5, 'Juni', '2500000', '0', '0000-00-00', NULL);


#
# TABLE STRUCTURE FOR: sr_pengumuman
#

DROP TABLE IF EXISTS `sr_pengumuman`;

CREATE TABLE `sr_pengumuman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `konten` text NOT NULL,
  `tgl_tampil` date NOT NULL,
  `tgl_tutup` date NOT NULL,
  `tampil_siswa` tinyint(1) NOT NULL DEFAULT 1,
  `tampil_pengajar` tinyint(1) NOT NULL DEFAULT 1,
  `pengajar_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pengajar_id` (`pengajar_id`),
  KEY `pengajar_id_2` (`pengajar_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `sr_pengumuman` (`id`, `judul`, `konten`, `tgl_tampil`, `tgl_tutup`, `tampil_siswa`, `tampil_pengajar`, `pengajar_id`) VALUES (6, 'imlek', '<p>Kepada seluruh SISWA, Libur <strong>IMLEK </strong>akan tiba!</p>\r\n', '2022-01-01', '2022-02-19', 1, 1, 1);


#
# TABLE STRUCTURE FOR: sr_perpusbiaya
#

DROP TABLE IF EXISTS `sr_perpusbiaya`;

CREATE TABLE `sr_perpusbiaya` (
  `id_biaya_denda` int(11) NOT NULL AUTO_INCREMENT,
  `harga_denda` varchar(255) NOT NULL,
  `stat` varchar(255) NOT NULL,
  `tgl_tetap` varchar(255) NOT NULL,
  PRIMARY KEY (`id_biaya_denda`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusbiaya` (`id_biaya_denda`, `harga_denda`, `stat`, `tgl_tetap`) VALUES (1, '4000', 'Aktif', '2019-11-23');


#
# TABLE STRUCTURE FOR: sr_perpusbuku
#

DROP TABLE IF EXISTS `sr_perpusbuku`;

CREATE TABLE `sr_perpusbuku` (
  `id_buku` int(11) NOT NULL AUTO_INCREMENT,
  `buku_id` varchar(255) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_rak` int(11) NOT NULL,
  `sampul` varchar(255) DEFAULT NULL,
  `isbn` varchar(255) DEFAULT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `penerbit` varchar(255) DEFAULT NULL,
  `pengarang` varchar(255) DEFAULT NULL,
  `thn_buku` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `jml` int(11) DEFAULT NULL,
  `tgl_masuk` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_buku`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusbuku` (`id_buku`, `buku_id`, `id_kategori`, `id_rak`, `sampul`, `isbn`, `lampiran`, `title`, `penerbit`, `pengarang`, `thn_buku`, `isi`, `jml`, `tgl_masuk`) VALUES (8, 'BK008', 2, 1, '0', '132-123-234-231', '0', 'CARA MUDAH BELAJAR PEMROGRAMAN C++', 'INFORMATIKA BANDUNG', 'BUDI RAHARJO ', '2012', '<table class=\"table table-bordered\" style=\"background-color: rgb(255, 255, 255); width: 653px; color: rgb(51, 51, 51);\"><tbody><tr><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Tipe Buku</td><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Kertas</td></tr><tr><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Bahasa</td><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Indonesia</td></tr></tbody></table>', 23, '2019-11-23 11:49:57');
INSERT INTO `sr_perpusbuku` (`id_buku`, `buku_id`, `id_kategori`, `id_rak`, `sampul`, `isbn`, `lampiran`, `title`, `penerbit`, `pengarang`, `thn_buku`, `isi`, `jml`, `tgl_masuk`) VALUES (9, 'BK009', 2, 1, NULL, '121-163-214-231', NULL, 'Perkembangan Tekhnologi WEB 2.0', 'Maju Haya', 'Reza Lesmana', '2022', NULL, 121, NULL);


#
# TABLE STRUCTURE FOR: sr_perpusdenda
#

DROP TABLE IF EXISTS `sr_perpusdenda`;

CREATE TABLE `sr_perpusdenda` (
  `id_denda` int(11) NOT NULL AUTO_INCREMENT,
  `pinjam_id` varchar(255) NOT NULL,
  `denda` varchar(255) NOT NULL,
  `lama_waktu` int(11) NOT NULL,
  `tgl_denda` varchar(255) NOT NULL,
  PRIMARY KEY (`id_denda`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (3, 'PJ001', '0', 0, '2020-05-20');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (5, 'PJ009', '0', 0, '2020-05-20');


#
# TABLE STRUCTURE FOR: sr_perpuskategori
#

DROP TABLE IF EXISTS `sr_perpuskategori`;

CREATE TABLE `sr_perpuskategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (2, 'Pemrograman');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (3, 'Kamus');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (4, 'Almanak');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (5, 'Direktori');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (6, 'Ensiklopedia');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (7, 'Buku Ajar');


#
# TABLE STRUCTURE FOR: sr_perpuspinjam
#

DROP TABLE IF EXISTS `sr_perpuspinjam`;

CREATE TABLE `sr_perpuspinjam` (
  `id_pinjam` int(11) NOT NULL AUTO_INCREMENT,
  `pinjam_id` varchar(255) NOT NULL,
  `anggota_id` varchar(255) NOT NULL,
  `buku_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `tgl_pinjam` varchar(255) NOT NULL,
  `lama_pinjam` int(11) NOT NULL,
  `tgl_balik` varchar(255) NOT NULL,
  `tgl_kembali` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_pinjam`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (8, 'PJ001', 'AG002', 'BK008', 'Di Kembalikan', '2020-05-19', 1, '2020-05-20', '2020-05-20');
INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (10, 'PJ009', 'AG002', 'BK008', 'Di Kembalikan', '2020-05-20', 1, '2020-05-21', '2020-05-20');


#
# TABLE STRUCTURE FOR: sr_perpusrak
#

DROP TABLE IF EXISTS `sr_perpusrak`;

CREATE TABLE `sr_perpusrak` (
  `id_rak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_rak` varchar(255) NOT NULL,
  PRIMARY KEY (`id_rak`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusrak` (`id_rak`, `nama_rak`) VALUES (1, 'Rak Buku 1');
INSERT INTO `sr_perpusrak` (`id_rak`, `nama_rak`) VALUES (3, 'Rak Buku 2');


#
# TABLE STRUCTURE FOR: sr_pos_pembayaran
#

DROP TABLE IF EXISTS `sr_pos_pembayaran`;

CREATE TABLE `sr_pos_pembayaran` (
  `id_pos` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `kode_akun` varchar(5) DEFAULT NULL,
  `akun_piutang` varchar(5) DEFAULT NULL,
  `nama_pos` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  PRIMARY KEY (`id_pos`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pos_pembayaran` (`id_pos`, `unit`, `kode_akun`, `akun_piutang`, `nama_pos`, `keterangan`) VALUES (1, '5', '62265', '62265', 'SPP', 'Sumbangan Pendanaan Pendidikan');
INSERT INTO `sr_pos_pembayaran` (`id_pos`, `unit`, `kode_akun`, `akun_piutang`, `nama_pos`, `keterangan`) VALUES (2, '5', '1', '62265', 'Biaya Bangunan', 'Bangunan Sekolah');


#
# TABLE STRUCTURE FOR: sr_provinsi
#

DROP TABLE IF EXISTS `sr_provinsi`;

CREATE TABLE `sr_provinsi` (
  `province_id` int(11) NOT NULL,
  `province` varchar(100) NOT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (1, 'Bali');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (2, 'Bangka Belitung');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (3, 'Banten');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (4, 'Bengkulu');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (5, 'DI Yogyakarta');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (6, 'DKI Jakarta');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (7, 'Gorontalo');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (8, 'Jambi');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (9, 'Jawa Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (10, 'Jawa Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (11, 'Jawa Timur');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (12, 'Kalimantan Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (13, 'Kalimantan Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (14, 'Kalimantan Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (15, 'Kalimantan Timur');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (16, 'Kalimantan Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (17, 'Kepulauan Riau');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (18, 'Lampung');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (19, 'Maluku');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (20, 'Maluku Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (21, 'Nanggroe Aceh Darussalam (NAD)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (22, 'Nusa Tenggara Barat (NTB)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (23, 'Nusa Tenggara Timur (NTT)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (24, 'Papua');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (25, 'Papua Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (26, 'Riau');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (27, 'Sulawesi Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (28, 'Sulawesi Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (29, 'Sulawesi Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (30, 'Sulawesi Tenggara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (31, 'Sulawesi Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (32, 'Sumatera Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (33, 'Sumatera Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (34, 'Sumatera Utara');


#
# TABLE STRUCTURE FOR: sr_setting_gaji
#

DROP TABLE IF EXISTS `sr_setting_gaji`;

CREATE TABLE `sr_setting_gaji` (
  `id_setting_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `nip` varchar(5) DEFAULT NULL,
  `nama` varchar(5) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `status_kepegawaian` varchar(20) DEFAULT NULL,
  `jenjang` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_setting_gaji`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_siswa
#

DROP TABLE IF EXISTS `sr_siswa`;

CREATE TABLE `sr_siswa` (
  `idsiswa` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `s_nisn` varchar(50) NOT NULL,
  `s_nama` varchar(100) NOT NULL,
  `s_nik` varchar(255) NOT NULL,
  `s_jenis_kelamin` enum('P','L') NOT NULL,
  `s_tl_idprovinsi` int(11) NOT NULL,
  `s_tl_idkota` int(11) NOT NULL,
  `s_tanggal_lahir` date NOT NULL,
  `idkelas` int(11) NOT NULL,
  `s_email` varchar(255) NOT NULL,
  `s_telepon` varchar(20) NOT NULL,
  `s_wali` varchar(255) NOT NULL,
  `s_dusun` varchar(255) NOT NULL,
  `s_desa` varchar(255) NOT NULL,
  `s_kecamatan` varchar(255) NOT NULL,
  `s_domisili` enum('Dalam','Luar') NOT NULL,
  `s_abk` enum('Ya','Tidak') NOT NULL,
  `s_bsm_pip` enum('Ya','Tidak') NOT NULL,
  `s_keluarga_miskin` enum('Ya','Tidak') NOT NULL,
  `s_code_generator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idsiswa`),
  KEY `s_tl_idprovinsi` (`s_tl_idprovinsi`),
  KEY `s_tl_idkota` (`s_tl_idkota`),
  KEY `idkelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (11, '5', '204035871360', 'Aji Putra Arshavin ', '3401120912120001', 'L', 5, 210, '2012-01-09', 1, 'mas.ghaly88@gmail.com', '081977700271', 'Sulistyo', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', '');
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (12, '5', '204035871361', 'Alya Zafaranie Rahman', '3401124304130003', 'P', 5, 210, '2013-04-13', 1, 'lorin.enjubella88@gmail.com', '0819928822', 'Fauzur Rahman', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', '716258');
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (13, '5', '204035871362', 'Bintang Rakha Raqila', '3401120711120001', 'L', 5, 210, '2012-11-07', 1, '', '', 'Haryadi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (14, '5', '204035871363', 'Damar Lestari', '3401126504130001', 'P', 5, 210, '2013-04-25', 1, '', '', 'Nuryanto', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (15, '5', '204035871364', 'Dava Bayu Setiawan', '3401122106130001', 'L', 5, 210, '2013-06-21', 1, '', '', 'Kumara', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (16, '5', '204035871365', 'Faris Husnul Arfan', '3401120805130001', 'P', 5, 210, '2013-05-08', 1, '', '', 'Madiyono', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (17, '5', '204035871366', 'Hasna Khaira Nadhiva', '3401125209120001', 'P', 5, 210, '2012-09-12', 1, '', '', 'Sutriyono', 'KLANGON', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (18, '5', '204035871367', 'Lafida Dwi Saputri', '3401126310120001', 'P', 5, 210, '2012-10-23', 1, '', '', 'Hajib Ja&#039;far', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (19, '5', '204035871368', 'Muhammad Barik Al-Bani', '3401120202130001', 'L', 5, 210, '2013-02-02', 1, '', '', 'Slamet Sulbani', 'SEMAWUNG', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (20, '5', '204035871369', 'Muhammad Haidar Yaqdhan', '3401121806130001', 'L', 5, 210, '2013-06-18', 1, '', '', 'Isdadi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (21, '5', '204035871370', 'Muhammad Nehru Wiratama', '3310032711120002', 'L', 10, 196, '2012-11-27', 1, '', '', 'Bachtiar Bakriyanto', 'KARANGLO', 'TANJUNGAN', 'KEC. WEDI', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (22, '5', '204035871371', 'Rani Prasetya Mawardi', '3401126604130002', 'P', 5, 210, '2015-04-16', 1, '', '', 'Mawardi', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (23, '5', '204035871372', 'Raviola Eka Valentina', '3315136901130001', 'P', 10, 134, '2013-01-29', 1, '', '', 'Muhdaryanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (24, '5', '204035871373', 'Reza Rahardyan Firmansyah', '3401121101130001', 'L', 5, 210, '2013-01-11', 1, '', '', 'Hariyanto', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (25, '5', '204035871374', 'Saffa Arumi Ghaisani', '3205306505130002', 'P', 9, 126, '2013-05-25', 1, '', '', 'Ramdani', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (26, '5', '204035871375', 'Salma Safira', '3401125404130001', 'P', 5, 210, '2013-12-04', 1, '', '', 'Porwanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (27, '5', '204035871376', 'Shella Hikmatul Hidayah', '3401124902130001', 'P', 5, 210, '2013-09-02', 1, '', '', 'Haryanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (28, '5', '204035871377', 'Syakira Rizka Prawestri', '3401125109120001', 'P', 5, 210, '2012-11-09', 1, '', '', 'Walmuji', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (29, '5', '204035871378', 'Taufiq Hidayat', '3401122006130001', 'L', 5, 210, '2013-06-20', 1, '', '', 'Edi Hartanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (30, '5', '204035871379', 'Zahra Dian Salsabilla', '3401124203130001', 'P', 5, 210, '2013-03-02', 1, '', '', 'Muhdi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (31, '5', '204035871380', 'Zahwa Adina Putri', '3308036006130001', 'P', 10, 249, '2013-06-20', 1, '', '', 'Afda Setiawan', 'GANJURAN', 'PLOSOGEDE', 'KEC. NGLUWAR', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (32, '5', '0119228271', 'Andhika Rohman Indra Wijaya', '3401122805110003', 'L', 5, 210, '2011-05-28', 2, '', '', 'Agus Anwari', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (33, '5', '0111065143', 'Adit Hendryawan', '3401121812110001', 'L', 5, 210, '2011-12-18', 2, '', '', 'SARJONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (34, '5', '0111566716', 'Alvino Bagus Hendrawan', '3308040907110003', 'L', 10, 249, '2011-07-09', 2, '', '', 'Muh Fahrudin', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (39, '5', '0123535887', 'Anissa Rizki Maulidza', '3401124302120001', 'P', 5, 210, '2012-02-03', 2, '', '', 'NARPANDI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (40, '5', '0117476280', 'Asmawa Fastina Artanti', '3401124302120001', 'P', 10, 476, '2011-08-19', 2, '', '', 'SUDIYANTO', 'KLANGON', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (41, '5', '0108250622', 'Hafidz Nurul Ikhsan', '3401121410100002', 'L', 5, 210, '2010-10-14', 2, '', '', 'MUJIYANTA', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (42, '5', '0129187164', 'Hafiz il Sya&#039;bana', '3401120207120002', 'L', 5, 210, '2012-07-02', 2, '', '', 'UDIYANTO', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (43, '5', '0123340033', 'Haikal Daffa Salman Faiz', '3401121006120001', 'L', 5, 210, '2012-06-10', 2, '', '', 'GUNTORO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (44, '5', '0112159539', 'Hammam Razka Pradipta', '3401120712110001', 'L', 5, 210, '2011-12-07', 2, '', '', 'AGUNG BUDIAJI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (45, '5', '0111083351', 'Heevan Alyansyah Alfajr', '6302151410110001', 'L', 13, 203, '2011-10-14', 2, '', '', 'SYAHRUL FUJIANSYAH', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (46, '5', '0125752767', 'Najwa Zalfa Khoirunnisa', '3401126004120001', 'P', 5, 210, '2012-04-20', 2, '', '', 'OTANG HATAMI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (47, '5', '0117400693', 'Nungraeni Desy Safira Putri', '3401124612110001', 'P', 5, 210, '2011-12-08', 2, '', '', 'SUTARI', 'PANTOG WETAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (48, '5', '0123596402', 'Nur Alifa Loveana Anjani', '3401125101120002', 'P', 5, 210, '2012-01-11', 2, '', '', 'NURKOYIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (49, '5', '0117452080', 'Oktaviar Alhuwa Mufid', '3401120710110001', 'L', 5, 210, '2011-10-07', 2, '', '', 'MUHYIDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (50, '5', '0112830228', 'Qalitza Zahwa Khairani', '3401126509110001', 'P', 5, 210, '2011-09-15', 2, '', '', 'SUNGKONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (51, '5', '0121515850', 'Raffa Ahmad Sholikhin', '3401120803120001', 'L', 5, 210, '2012-03-08', 2, '', '', 'TOHA RUDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (52, '5', '0121854845', 'Rendita Febriana Saputri', '3401124702120002', 'P', 5, 210, '2012-02-07', 2, '', '', 'YULI SUSANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (53, '5', '0114655050', 'Reyhan Saputra', '3308081508120003', 'L', 10, 249, '2011-08-15', 2, '', '', 'FAJAR SETIADI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (54, '5', '0124032295', 'Risky Putra Wahyu Pratama', '3401121602120004', 'L', 5, 210, '2012-02-16', 2, '', '', 'TRI YULIANA', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (55, '5', '0113120197', 'Tedy Ahmad Santoso', '3401120210110001', 'L', 5, 210, '2011-10-02', 2, '', '', 'SUYOTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (56, '5', '0129915965', 'Tsania Zahra Maulida', '3401125602120001', 'P', 5, 210, '2012-02-16', 2, '', '', 'SISWANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (57, '5', '0125805929', 'Wanda Febriani Wulandari', '3211226902120002', 'P', 9, 440, '2012-02-29', 2, '', '', 'MUHROSID', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (58, '5', '0106708074', 'Ananda Aulia', '3401124611100001', 'P', 5, 210, '2010-11-06', 3, '', '', 'SUYADI', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (59, '5', '0108998849', 'Andini Nur Rahmawati', '3401124107100001', 'P', 5, 210, '2010-07-01', 3, '', '', 'YANI FATMAWATI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (60, '5', '0111353064', 'Annas Hamid', '3401121804110001', 'L', 5, 210, '2011-04-18', 3, '', '', 'SURATIN', 'BANJARAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (61, '5', '0118767416', 'As Syifa Dwi Pradayanti  ', '3401124905110002', 'P', 5, 210, '2011-05-09', 3, '', '', 'SUPARNO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (62, '5', '0082175383', 'Astri Widya Pramesti', '3401125408080002', 'P', 10, 196, '2008-08-14', 3, '', '', 'PRAWOTO SUHARYONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (63, '5', '0103368264', 'Bayu Ardhan Handaru', '3401120209100001', 'L', 5, 210, '2010-09-02', 3, '', '', 'KOMARUDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (64, '5', '0103094001', 'Bintara Ardyama Saputra', '3401120907100001', 'L', 5, 210, '2010-07-09', 3, '', '', 'PARJIMIN', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (65, '5', '0107104381', 'Dava Jiffin Adelino Romadi', '3401121110100001', 'L', 5, 210, '2010-10-11', 3, '', '', 'EKA ROMADI', 'DUWET III', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (66, '5', '0102553662', 'Dayinta Kumala Wijaya Esti', '3401124607100002', 'P', 5, 210, '2010-07-06', 3, '', '', 'SUPRIYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (67, '5', '0117972015', 'Fendy Adinata Wicaksono', '3401122103110001', 'L', 5, 210, '2011-03-21', 3, '', '', 'MARWANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (68, '5', '0101989546', 'Ghiffara Najwa Azzahra', '3401126508100001', 'P', 5, 210, '2010-08-25', 3, '', '', 'ASHARIHIDAYAT', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (69, '5', '0106111309', 'Hasna Nur Afifah', '3401125911100001', 'P', 5, 210, '2010-11-19', 3, '', '', 'SUBARDI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (70, '5', '0111549550', 'Iin Wulan Safa Yanunisa', '3401126001110001', 'P', 5, 210, '2011-01-20', 3, '', '', 'AHMAD SUPRIYADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (71, '5', '0164045268', 'Imam Santoso', '3401120505090001', 'L', 5, 210, '2009-05-05', 3, '', '', 'NURROHMAN', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (72, '5', '0111117352', 'Irma Aprilia Fatmawati', '3401127103110001', 'P', 5, 210, '2011-03-31', 3, '', '', 'SUPARTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (73, '5', '0103650256', 'Khanif Choiru Rochman', '3401122407110001', 'L', 5, 210, '2010-07-24', 3, '', '', 'MUH AHMAD BANI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (74, '5', '0103523847', 'Misbachul Lubab', '3401122907100001', 'L', 5, 210, '2010-07-29', 3, '', '', 'SUWITA', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (75, '5', '0105356940', 'Muhammad Abdul Azis Ramadhan', '3401120409100001', 'L', 5, 210, '2010-09-04', 3, '', '', 'SUDARYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (76, '5', '0122709840', 'Muvida Shobrina', '3401126608110001', 'P', 5, 210, '2012-08-26', 3, '', '', 'SUROTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (77, '5', '0113062348', 'Putri Khansa Udtiana Nafeeza', '3401124203110002', 'P', 5, 210, '2011-03-02', 3, '', '', 'DUL MASHUD', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (78, '5', '0102233405', 'Renata Okta Anjaini', '3401126210100002', 'P', 5, 210, '2010-10-22', 3, '', '', 'NURYANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (79, '5', '0119158123', 'Rendra Alfirkhan Nakholid', '3401121504110001', 'L', 5, 210, '2011-04-15', 3, '', '', 'IDIK IRYANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (80, '5', '0115192584', 'Rifqi Ahmad Yanuarivan', '3401120901110001', 'L', 5, 210, '2011-01-09', 3, '', '', 'MUH AHMAD', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (81, '5', '0112461768', 'Risnawati', '3401125606110001', 'P', 5, 210, '2011-06-26', 3, '', '', 'RISNAWATI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (82, '5', '0096993456', 'Sri Astuti', '3401120407090001', 'P', 5, 210, '2009-07-04', 3, '', '', 'SITI KALIMAH', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (83, '5', '0111138060', 'Syifa Nuriasari', '3401126802110001', 'P', 5, 210, '2011-02-28', 3, '', '', 'NUR AKHABAH ZAIBAN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (84, '5', '0114478714', 'Tri Ega Saputra', '3401122003110002', 'L', 5, 210, '2011-03-20', 3, '', '', 'SUKIDI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (85, '5', '0109611361', 'Yumna Aulia Zulfa', '3401124110100001', 'P', 5, 210, '2010-10-01', 3, '', '', 'FARID PRATIKNA', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (86, '5', '0112997704', 'Adnanda Galih Yudistira', '3401120305110001', 'L', 5, 210, '2011-05-03', 3, '', '', 'HERIYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (87, '5', '0097073468', 'Adnan Rangga Kurniawan', '3401120103090001', 'L', 5, 210, '2009-03-01', 4, '', '', 'SUWARTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (88, '5', '0104677724', 'Ahmad Muthohar', '3401120301100001', 'L', 5, 210, '2010-01-03', 4, '', '', 'SUPRANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (89, '5', '0108115939', 'Delia Anggraeni', '3401126604100001', 'P', 5, 210, '2010-04-26', 4, '', '', 'BADARI', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (90, '5', '0094626840', 'Destin Siti Arofah', '3401124112090001', 'P', 5, 210, '2009-12-01', 4, '', '', 'TUGIMIN', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (91, '5', '0103683075', 'Dwi Yuliana Putri', '3401124307100002', 'P', 5, 210, '2010-07-03', 4, '', '', 'MULYONO', 'BANJARAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (92, '5', '0103048390', 'Emeldy Bunga Astuti', '3308085205100003', 'P', 10, 250, '2010-05-12', 4, '', '', 'EDI SUPRAYITNO', 'NGABLAK', 'KEJI', 'KEC. MUNTILAN', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (93, '5', '0098885960', 'Evandra Emeraldgi Pratama', '3401120310090001', 'L', 5, 210, '2009-10-03', 4, '', '', 'NURWIYONO', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (94, '5', '0075465499', 'Fauziah Ardelinda', '3401127001070001', 'P', 5, 210, '2007-01-30', 4, '', '', 'SUPARMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (95, '5', '0109742705', 'Galih Reza Oktaviano', '3401120505100001', 'L', 5, 210, '2010-05-05', 4, '', '', 'RIYANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (96, '5', '0086716698', 'Galih Kurniawan', '3401122812080001', 'L', 5, 210, '2008-12-28', 4, '', '', 'SUMARWOTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (97, '5', '0082921451', 'Hesti Andriyani', '3401125004080001', 'P', 5, 210, '2008-04-10', 4, '', '', 'SUROTO', 'KEMPONG', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (98, '5', '0091536451', 'Hibban Adib Murthada', '3401122010090001', 'L', 5, 210, '2009-10-20', 4, '', '', 'MUHAMAD NASIR', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (99, '5', '0157442061', 'Latifa Ramadhani', '3401126808090001', 'P', 5, 210, '2009-08-28', 4, '', '', 'ALIYADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (100, '5', '0103142489', 'Mardianty Putri Anggraeny', '3401124603100001', 'P', 5, 210, '2010-03-06', 4, '', '', 'SUDARMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (101, '5', '0168301632', 'Muhammad Khoiruman Kafa', '3308090203100001', 'L', 10, 250, '2009-03-02', 4, '', '', 'MUHAMMAD BAEDHOWI', 'SARAGAN', 'RAMBEANAK', 'KEC. MUNGKID', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (102, '5', '0098955268', 'Muhammad Minan Fauzi', '3401122107090001', 'L', 5, 210, '2009-07-21', 4, '', '', 'SLAMET', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (103, '5', '0097560656', 'Naufal Hakim', '3401123010090001', 'L', 5, 210, '2009-10-30', 4, '', '', 'SUPNGATI WIDANIYAH', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (104, '5', '0093830651', 'Oktavia Arya Damayanti', '3401125210090001', 'P', 5, 210, '2010-10-12', 4, '', '', 'WAKIJAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (105, '5', '0098381033', 'Raffi Ahmad Afifudin', '3401121704090001', 'L', 5, 210, '2009-04-17', 4, '', '', 'NASRODIN', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (106, '5', '02040412029', 'Shafira Mutiara Valen', '3401125502100001', 'P', 5, 210, '2010-02-15', 4, '', '', 'NOFIYALDI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (107, '5', '0093846102', 'Yuda Edi Wahyana', '3401120108090003', 'L', 5, 210, '2009-08-01', 4, '', '', 'PUTRI JAZIMAH', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (108, '5', '0082840617', 'Yusuf Pamungkas', '3401122804080001', 'L', 5, 210, '2008-04-28', 4, '', '', 'RAHMADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (109, '5', '0153278170', 'Afif Rafiudin', '3401122708090001', 'L', 5, 210, '2009-06-27', 5, '', '', 'JUDARDIN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (110, '5', '088476284', 'Ahmad Faiq Athaya', '3401122802080001', 'L', 10, 249, '2008-02-28', 5, '', '', 'Ahmad Baehaqi', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (111, '5', '083034124', 'Amira Zerlinda', '3308026211080004', 'P', 34, 278, '2008-11-22', 5, '', '', 'Muhammad Zuamar', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (112, '5', '0072961067', 'Andrian Putra Pangestu', '3401122206070001', 'L', 5, 210, '2007-06-22', 5, '', '', 'SURAHMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (113, '5', '0086534500', 'Gresiya Suma Safitri', '3401125010080002', 'P', 5, 210, '2008-10-10', 5, '', '', 'DUL JALIL', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (114, '5', '0095912960', 'Hasna Fathitya Sabrina', '3401126909090002', 'P', 5, 210, '2009-09-29', 5, '', '', 'EKO NURAHMAN SUROJO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (115, '5', '0083313497', 'Indah Fitria Ningrum', '3401124210080001', 'P', 5, 210, '2008-10-02', 5, '', '', 'SUTARI', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (116, '5', '0087301623', 'Muhammad Ilham Sarifuddin', '3401122103080002', 'L', 5, 210, '2008-03-21', 5, '', '', 'NURCHOLIS', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (117, '5', '0155408388', 'Muhammad Raditya Ainul Yaqin', '3401121607080001', 'L', 5, 210, '2008-07-16', 5, '', '', 'FARIKIN', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (118, '5', '0095231681', 'Muhammad Shulhan Al-farisi', '3401120106090001', 'L', 5, 210, '2009-06-01', 5, '', '', 'SLAMET SULBANI', 'SEMAWUNG', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (119, '5', '0153200473', 'Novaris Dwi Firmansyah', '3401121711080002', 'L', 10, 249, '2008-11-17', 5, '', '', 'SARYANTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (120, '5', '0072706748', 'Oktafiya Duwi Safitri', '3401125510070001', 'P', 5, 210, '2007-10-15', 5, '', '', 'SUNARDI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (121, '5', '0083690882', 'Prastika Guntur Firmansyah', '3401120307080002', 'L', 5, 210, '2008-07-03', 5, '', '', 'KALIM', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (122, '5', '0098488467', 'Siti Musyafiani', '3401124901090001', 'P', 5, 210, '2009-09-10', 5, '', '', 'ZURISAM', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (123, '5', '0158891388', 'Tegar Arya Pangestu', '3401121308080001', 'L', 5, 210, '2008-08-13', 5, '', '', 'HARYADI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (124, '5', '0081232726', 'Adi Bagus Saputra', '3401120703080001', 'L', 5, 210, '2008-03-07', 6, '', '', 'Suwita', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (125, '5', '0071776993', 'Ageng Ratri Dewi', '340112591207002', 'P', 5, 210, '2007-12-19', 6, '', '', 'Sudarman', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (126, '5', '0077101667', 'Ahmad Hidayat', '3401122701070002', 'L', 5, 210, '2007-01-27', 6, '', '', 'Masicun', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (127, '5', '0074217306', 'Ahmad Mirza Arvinudin', '3401121612070001', 'L', 5, 210, '2007-12-16', 6, '', '', 'Muh Ahmad', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (128, '5', '0074203935', 'Aqila Chusnia Mu&#039;mina', '3204156509070001', 'P', 9, 22, '2007-09-25', 6, '', '', 'Heru Gunadi', 'POTRONALAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (129, '5', '0072510958', 'Ardian Ramadhan', '3401122209070001', 'L', 5, 210, '2007-09-22', 6, '', '', 'Widodo', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (130, '5', '0089913911', 'Arif Duwiyanto', '3401122303090001', 'L', 5, 210, '2008-03-23', 6, '', '', 'Muh Ahmad Bani', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (131, '5', '0085552671', 'Choiriatunnisa Tsani Hasya', '3401126707080002', 'P', 5, 210, '2008-07-27', 6, '', '', 'Riyadi', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (132, '5', '0071429595', 'Febriana Alfiyani', '3401124806810002', 'P', 5, 210, '2007-02-24', 6, '', '', 'Alfandi', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (133, '5', '0066771589', 'Fitri Andriani', '3401125510060002', 'P', 5, 210, '2006-10-15', 6, '', '', 'Suroto', 'KEMPONG', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (134, '5', '0082016833', 'Iqbal Dzaky Reevansyah', '6302152103080001', 'L', 15, 215, '2008-03-21', 6, '', '', 'Fujiansyah', 'POTRONALAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (135, '5', '0077252994', 'Junita Adinda Suryandika', '3401126606070001', 'P', 5, 210, '2007-06-26', 6, '', '', 'Suroto', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (136, '5', '0077859964', 'Nabil Chandra Susilo Nugroho', '3401123011070001', 'L', 5, 210, '2007-11-30', 6, '', '', 'Sucipto Susilo', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (137, '5', '0074539804', 'Revania Oktaviani', '3401126610070001', 'P', 5, 210, '2007-10-26', 6, '', '', 'Abidin', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (138, '5', '0078559059', 'Zulfa Ulya', '3401126807070001', 'P', 5, 210, '2007-07-28', 6, '', '', 'Sudaryanto', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (140, '5', '11111', '11111', '111', 'L', 2, 56, '2021-01-16', 11, 'ghalyfadhillah@gmail.com', '087722777245', 'Gunadi Abdullah', 'ASDASD', 'ASDASD', 'ASDASD', 'Dalam', 'Tidak', 'Ya', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (141, '5', '3243', '44334', '34243342', 'P', 10, 169, '2021-01-18', 16, 'saddsa@sadads.com', '2332', 'dassad', 'SADASD', 'SADSAD', 'SADASD', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (142, '5', '323242', '3243443', '232434', 'P', 8, 393, '2021-01-26', 17, 'dasdas@dsadsa.com', '432342', 'asddsa', 'SADASD', 'SADASD', 'ASDAS', 'Luar', 'Ya', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (143, '5', '11314141441', 'Jumaidi Saputraaaa', '14141413141', 'L', 6, 151, '1999-10-19', 2, 'jumaidi@gmail.com', '08937272728128', 'Budi', '-', '-', 'PONDOK AREN', 'Dalam', 'Ya', 'Ya', 'Ya', NULL);


#
# TABLE STRUCTURE FOR: sr_users
#

DROP TABLE IF EXISTS `sr_users`;

CREATE TABLE `sr_users` (
  `idusers` int(11) unsigned NOT NULL,
  `unit` varchar(11) NOT NULL,
  `u_nbm_nip` varchar(255) NOT NULL,
  `u_nuptk_nuks` varchar(255) DEFAULT NULL,
  `u_tl_idprovinsi` int(11) NOT NULL,
  `u_tl_idkota` int(11) NOT NULL,
  `u_tanggal_lahir` date NOT NULL,
  `u_jenis_kelamin` enum('P','L') NOT NULL,
  `u_status_pegawai` varchar(100) NOT NULL,
  `u_tunjangan_apbd` varchar(100) DEFAULT NULL,
  `u_tugas_tambahan` varchar(100) DEFAULT NULL,
  `u_jenjang` varchar(50) NOT NULL,
  `u_perguruan_tinggi` varchar(255) NOT NULL,
  `u_jurusan` varchar(100) DEFAULT NULL,
  `u_tahun_lulus` varchar(20) NOT NULL,
  `u_npwp` varchar(255) DEFAULT NULL,
  `u_sertifikasi` enum('Sudah','Belum') NOT NULL,
  `u_sertifikasi_tahun` year(4) DEFAULT NULL,
  `u_prestasi` text DEFAULT NULL,
  `u_honor` int(11) NOT NULL,
  `u_kerja_pasangan` varchar(255) DEFAULT NULL,
  `u_alamat_tinggal` text NOT NULL,
  `u_photo` text DEFAULT NULL,
  PRIMARY KEY (`idusers`),
  KEY `idusers` (`idusers`),
  KEY `u_tl_idprovinsi` (`u_tl_idprovinsi`),
  KEY `u_tl_idkota` (`u_tl_idkota`),
  KEY `idusers_2` (`idusers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (1, '5', '954033', '3433754656300012 / 16023L0010404122016516', 6, 153, '1987-02-13', 'L', 'GTY', '', 'Kepala Sekolah', 'S1', 'Undip', 'Sistem Informasi', '2010', '66.907.985.7-544.000', 'Sudah', '2013', 'Guru Teladan tahun 2015', 2600000, 'Pegawai Swasta', 'Lenteng Agung, Jagakarsa, Jakarta Selatan', '3454bd5004b1bd6d20a9ff3f633a37d1.png');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (37, '5', '992052', '9060760662300003', 5, 210, '1982-07-28', 'P', 'GTY', 'PTTD', 'Guru Kelas II', 'S1', 'Univ Terbuka Yogyakarta', 'PGSD', '2018', '', 'Belum', '0000', '', 1000000, 'Swasta', 'Demangan, Banjarharjo, Kalibawang', 'f5b05744233acca3b73d179279d83ff4.jpg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (38, '5', '1062801', '', 5, 210, '1985-01-07', 'L', 'GTY', '', 'Guru Kelas IV', 'S1', 'Univ Sanata Dharma', 'PGSD', '2010', '91.003.379.4-544.000', 'Belum', '0000', '', 400000, 'Swasta', 'Duwet 3, Banjarharjo, Kalibawang', 'ef2cbde3636968a2bbb9f76a5df7909e.jpg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (39, '5', '1295422', '', 5, 210, '1992-07-19', 'L', 'GTT', '', 'Guru Penjasorkes', 'S1', 'Univ Ahmad Dahlan', 'PBSI', '2012', '', 'Belum', '0000', '', 350000, '', 'Paras, Banjarasri, Kalibawang', '9f23f5e97972e5e98537f51b76db76ec.jpg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (40, '5', '19671206 198903 1 003', '2538745647110043', 5, 210, '1967-12-06', 'L', 'PNS KEMENAG', '', 'Guru PAI', 'D2', 'UIN Sunan Kalij Jaga Yogyakarta', 'Pend. Agama Islam', '1993', '', 'Sudah', '2013', '', 4200000, 'IRT', 'Gunungmojo, Argosari, Sedayu, Bantul', '42ef1ac722851008e5e9bcb35351827c.jpg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (41, '5', '1335358', '', 9, 115, '1994-04-04', 'P', 'GTT', '', 'Operator', 'S1', 'UIN Raden Fatah Palembang', 'Pend. Bahasa Inggris', '2017', '', 'Belum', '0000', '', 150000, 'Swasta', 'Salam, Banjarharjo, Kalibawang', 'e20f5b298a4d05cb1d22977403f73062.jpg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (42, '5', '1335360', '', 5, 210, '1993-02-07', 'P', 'GTT', '', 'Guru Kelas I', 'S1', 'Univ Terbuka Banten', 'PGSD', '2018', '', 'Belum', '0000', '', 300000, 'Swasta', 'Pranan, Banjaroya, Kalibawang', '7079eeff453c257d36b51af9413281ec.jpeg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (43, '5', '1314346', '', 5, 210, '1974-10-27', 'P', 'GTT', '', 'Guru Kelas III', 'S1', 'Univ Widya Mataram Yogyakarta', 'Teknologi pertanian', '1998', '', 'Belum', '0000', '', 300000, 'Karyawan', 'Kedondong 1, Banjararum, Kalibawang', '373f490ef28c28450a359b46e73525d7.jpg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (44, '5', '1295423', '', 5, 210, '1987-04-15', 'P', 'GTT', '', 'Guru Kelas V', 'S1', 'Univ Indraprasta PGRI Jakarta', 'Pendidikan Matematika', '2011', '', 'Belum', '0000', '', 350000, 'Swasta', 'Semawung, Banjarharjo, Kalibawang', '17773abbb91433f028f4183bc51c80de.jpg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (45, '5', '1187611', '', 5, 210, '1991-05-08', 'P', 'GTY', '', 'Guru Kelas VI', 'S1', 'Univ PGRI Yogyakarta', 'Pendidikan Matematika', '2013', '', 'Belum', '0000', '', 400000, '', 'Semaken 3, Banjararum, Kalibawang', '785a17c1772c4c0ed74a372bffca962f.jpg');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (57, '5', '104352', '10435342456', 2, 56, '2021-01-18', 'L', 'GTY', '', 'Operator', 'S1', 'Universitas Amikom Yogyakarta', 'Sistem Informasi', '2021', '9999999999999', 'Belum', '0000', 'Pegawai Terganteng', 5300000, 'Kepala Dinas Pariwisata', 'Jln Bintara RT 12 RW 09', 'fb9a0bb598302e966995357ef0d12ab8.png');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (59, '5', '104353', '10435342457', 6, 153, '1987-12-23', 'L', 'GTY', '0', 'Kepala Program', 'S1', 'Universitas Indra Prasta PGRI', 'Pendidikan Ekonomi', '2017', '12.345.76543', 'Belum', '0000', '0', 1400000, '0', 'Jl. Rawa Sari', '8b1746b499eea7a042bf6bd4ffb35f80.png');
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (62, '1', '21212', '24124124', 6, 154, '1997-05-26', 'L', '', NULL, NULL, 'D3', 'LP3I Pondok Gede', 'Management Informatika', '2018', '85.326.425.7-009.000', '', NULL, NULL, 0, NULL, 'Jl Pertengahan Gg Kramat 4', NULL);


#
# TABLE STRUCTURE FOR: sr_virtualclass
#

DROP TABLE IF EXISTS `sr_virtualclass`;

CREATE TABLE `sr_virtualclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `pengajar_id` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `url` text NOT NULL,
  `libur` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (1, '', 0, 0, 'Tahun Baru Masehi', '2022-01-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (2, '', 0, 0, 'Hari Siwa Ratri', '2022-01-1', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (3, '', 0, 0, 'Tahun Baru Imlek 2573 Kongzili', '2022-02-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (4, '', 0, 0, 'Isra Mikraj Nabi Muhammad SAW', '2022-02-28', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (5, '', 0, 0, 'Hari Raya Nyepi', '2022-03-3', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (6, '', 0, 0, 'Hari Saraswati', '2022-03-26', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (7, '', 0, 0, 'Wafat Isa Al Masih', '2022-04-15', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (8, '', 0, 0, 'Hari Buruh Internasional', '2022-05-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (9, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-2', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (10, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-3', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (11, '', 0, 0, 'Hari Raya Waisak 2566', '2022-05-16', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (12, '', 0, 0, 'Kenaikan Isa Al Masih', '2022-05-26', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (13, '', 0, 0, 'Hari Lahirnya Pancasila', '2022-06-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (14, '', 0, 0, 'Penampahan Galungan', '2022-06-7', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (15, '', 0, 0, 'Hari Raya Galungan', '2022-06-8', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (16, '', 0, 0, 'Umanis Galungan', '2022-06-9', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (17, '', 0, 0, 'Hari Raya Kuningan', '2022-06-18', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (18, '', 0, 0, 'Hari Raya Idul Adha 1443 Hijriyah', '2022-07-9', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (19, '', 0, 0, 'Tahun Baru Islam 1444 Hijriyah', '2022-07-30', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (20, '', 0, 0, 'Hari Proklamasi Kemerdekaan RI', '2022-08-17', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (21, '', 0, 0, 'Maulid Nabi Muhammad SAW', '2022-10-8', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (22, '', 0, 0, 'Hari Saraswati', '2022-10-22', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (23, '', 0, 0, 'Hari Raya Natal', '2022-12-25', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (24, '5', 1, 1, 'BAB I - Adminstrasi Perkantoran Dasar', '2022-03-22', 'https://meet.jit.si/Lekum', '');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (35, '5', 1, 1, 'BAB 1 - Membuat Company Profile', '2022-02-22', 'https://meet.jit.si/hQPtq', '');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `multirole` enum('Y','N') DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (1, '5', '127.0.0.1', '$2y$12$DPBC0GqrE7QhiYgWOBdbW.c/jZQ0qD7KS7mO8z5HtaiPa35WwuxyK', 'sutan.daulay@gmail.com', 1268889823, 1645102751, 1, 'N', 'Sutan', 'Daulay, S.Kom', '081283960337');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (37, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'h.yuliajie@gmail.com', 1604316790, 1611518343, 1, 'Y', 'Heri', 'Yuli Astuti, S.Pd.', '081802637311');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (38, '5', '127.0.0.1', '$2y$10$3Hfg3GDUGrnqzRJeFO1L0u3tHe.jEvBjl0AUi3GGOeYcLKUDwI60a', 'foreverbarca24@gmail.com', 1604324461, 1640778495, 1, 'Y', 'Eka', 'Romadi, S.Pd.', '087719045202');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (39, '5', '127.0.0.1', '$2y$10$P1fNQaXHq7SDMI89fVyeAuNtbskbLbS6X9GzuvqLhyOpYGjb2jr66', 'prodocid.id@gmail.com', 1604404981, 1611515571, 1, 'N', 'Muhammad ', 'Yuli Nugroho, S.Pd.', '081328086524');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (40, '5', '127.0.0.1', '$2y$10$eICdXdcDjiUKA7ieNqHTueuCVl47eLEkdCzHccWoip7HvN4Sx7sa2', 'foreverbarca17@gmail.com', 1604405357, 1640675168, 1, 'N', 'Ahwanto, A.Ma', '', '081328579072');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (41, '5', '127.0.0.1', '$2y$10$ZlApEjZiUXuUQvPrelvWWOjqIlCK6mWlgyZAtskny353GxpATj6.O', 'trilestari40@yahoo.com', 1604405791, 1645100999, 1, 'N', 'Tri ', 'Lestari, S.Pd', '085279657826');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (42, '5', '127.0.0.1', '$2y$10$26FP8tRR/0UwORH8tI5eS.RNTMs3.RnIbZ7ldxy0PhIO/n94g2Jpe', 'widayatiasih93@gmail.com', 1604406384, 1645101063, 1, 'Y', 'Widayati ', 'Asih Rusilah, S.Pd', '087877633339');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (43, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'tripuji298@gmail.com', 1604406639, NULL, 1, 'Y', 'Tri ', 'Puji Lestari, S.TP', '081225422320');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (44, '5', '127.0.0.1', '$2y$10$vyeEuY7OB3ECbYUTZiBGnuCsW5GXcTrbxiB6NDON7oZkUA0/bKUEy', 'tutikrahayu086@gmail.com', 1604407059, 1645100832, 1, 'Y', 'Tutik ', 'Rahayu, S.Pd.', '087738264098');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (45, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'fulileo.astuti06@gmail.com', 1604407243, NULL, 1, 'Y', 'Tri ', 'Fuji Astuti, S.Pd.', '085764945075');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (57, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'ghalyfadhillah@gmail.com', 1610969508, 1612615966, 1, 'Y', 'Ghaly', 'Fadhillah, S.Kom', '087722777245');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (59, '5', '103.119.141.186', '$2y$10$ztlP7HXx3yYRbbcldtK7V.dNLDzFirPis1LJ96KI6yftEFMBGS7py', 'saka87aja@gmail.com', 1640777850, NULL, 1, 'N', 'Galuh', 'Saka Twinta S.pd', '0838654876342');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (62, '1', '::1', 'komputer7', 'rzalvaero@gmail.com', 4294967295, NULL, NULL, NULL, 'Reza', 'Lesmana A.md', '081280462650');


#
# TABLE STRUCTURE FOR: web_backup
#

DROP TABLE IF EXISTS `web_backup`;

CREATE TABLE `web_backup` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `datestamp` varchar(100) NOT NULL,
  `filedata` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (5, '2022-02-19 14:41:34', 'backup-220219-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (6, '2022-02-20 17:07:15', 'backup-220220-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (7, '2022-02-22 14:13:51', 'backup-220222-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (8, '2022-02-23 15:17:49', 'backup-220223-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (9, '2022-03-02 10:02:40', 'backup-220302-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (10, '2022-03-09 09:55:35', 'backup-220309-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (11, '2022-03-09 17:18:41', 'backup-220309-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (12, '2022-03-10 10:46:56', 'backup-220310-db.zip');


#
# TABLE STRUCTURE FOR: web_calender
#

DROP TABLE IF EXISTS `web_calender`;

CREATE TABLE `web_calender` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `tanggal` varchar(50) NOT NULL,
  `libur` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (1, 'Tahun Baru Masehi', '2022-01-1', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (2, 'Hari Siwa Ratri', '2022-01-1', '');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (3, 'Tahun Baru Imlek 2573 Kongzili', '2022-02-1', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (4, 'Isra Mikraj Nabi Muhammad SAW', '2022-02-28', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (5, 'Hari Raya Nyepi', '2022-03-3', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (6, 'Hari Saraswati', '2022-03-26', '');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (7, 'Wafat Isa Al Masih', '2022-04-15', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (8, 'Hari Buruh Internasional', '2022-05-1', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (9, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-2', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (10, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-3', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (11, 'Hari Raya Waisak 2566', '2022-05-16', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (12, 'Kenaikan Isa Al Masih', '2022-05-26', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (13, 'Hari Lahirnya Pancasila', '2022-06-1', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (14, 'Penampahan Galungan', '2022-06-7', '');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (15, 'Hari Raya Galungan', '2022-06-8', '');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (16, 'Umanis Galungan', '2022-06-9', '');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (17, 'Hari Raya Kuningan', '2022-06-18', '');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (18, 'Hari Raya Idul Adha 1443 Hijriyah', '2022-07-9', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (19, 'Tahun Baru Islam 1444 Hijriyah', '2022-07-30', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (20, 'Hari Proklamasi Kemerdekaan RI', '2022-08-17', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (21, 'Maulid Nabi Muhammad SAW', '2022-10-8', '1');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (22, 'Hari Saraswati', '2022-10-22', '');
INSERT INTO `web_calender` (`id`, `nama`, `tanggal`, `libur`) VALUES (23, 'Hari Raya Natal', '2022-12-25', '1');


#
# TABLE STRUCTURE FOR: web_default
#

DROP TABLE IF EXISTS `web_default`;

CREATE TABLE `web_default` (
  `id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `maintenance` enum('tidak','iya') NOT NULL,
  `whatsapp_group` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `web_default` (`id`, `url`, `title`, `logo`, `description`, `email`, `maintenance`, `whatsapp_group`, `whatsapp`) VALUES (1, 'https://www.proschool.id/', 'PROschool by DesaTech', 'logo.png', 'Elearning by ProSchool for a Smart Learning for Student in New Era! ', 'admin@proschool.id', 'tidak', '#', '6281280462650');


#
# TABLE STRUCTURE FOR: web_log
#

DROP TABLE IF EXISTS `web_log`;

CREATE TABLE `web_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `idusers` varchar(11) NOT NULL,
  `datestamp` varchar(50) NOT NULL,
  `note` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (1, '5', 'siswa', '11', '2022-02-20 17:02:55', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (2, '5', 'guru', '1', '2022-02-20 17:06:20', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (3, '5', 'guru', '1', '2022-02-22 10:08:16', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (4, '5', 'siswa', '11', '2022-02-22 12:16:16', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (5, '5', 'guru', '1', '2022-02-22 13:05:25', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (6, '5', 'siswa', '11', '2022-02-22 15:13:52', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (7, '5', 'guru', '1', '2022-02-22 15:53:42', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (8, '5', 'siswa', '11', '2022-02-22 16:12:33', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (9, '5', 'guru', '1', '2022-02-22 16:27:36', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (10, '5', 'siswa', '11', '2022-02-22 16:43:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (11, '5', 'guru', '1', '2022-02-22 16:50:10', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (12, '5', 'siswa', '11', '2022-02-22 16:51:40', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (13, '5', 'siswa', '11', '2022-02-22 21:25:17', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (14, '5', 'siswa', '11', '2022-02-22 21:27:06', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (15, '5', 'guru', '1', '2022-02-22 21:34:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (16, '5', 'guru', '1', '2022-02-22 21:34:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (17, '5', 'guru', '1', '2022-02-23 10:23:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (18, '5', 'guru', '1', '2022-02-23 12:29:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (19, '5', 'siswa', '11', '2022-02-23 14:13:27', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (20, '5', 'siswa', '11', '2022-02-23 14:13:31', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (21, '5', 'siswa', '11', '2022-02-23 14:13:51', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (22, '5', 'siswa', '11', '2022-02-23 14:14:46', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (23, '5', 'guru', '1', '2022-02-23 14:15:21', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (24, '5', 'siswa', '11', '2022-02-23 15:18:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (25, '5', 'siswa', '11', '2022-02-23 15:18:50', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (26, '5', 'guru', '1', '2022-02-23 15:20:38', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (27, '5', 'guru', '1', '2022-02-23 15:40:07', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (28, '5', 'siswa', '11', '2022-02-23 17:23:27', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (29, '5', 'siswa', '11', '2022-02-23 17:23:30', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (30, '5', 'siswa', '11', '2022-02-23 17:23:33', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (31, '5', 'guru', '1', '2022-02-23 17:27:12', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (32, '5', 'guru', '1', '2022-02-23 19:50:24', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (33, '5', 'guru', '1', '2022-02-24 15:46:59', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (34, '', 'siswa', '11', '2022-03-02 09:56:45', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (35, '', 'guru', '1', '2022-03-02 09:59:59', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (36, '', 'guru', '1', '2022-03-02 11:19:45', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (37, '', 'guru', '1', '2022-03-02 11:36:54', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (38, '', 'guru', '1', '2022-03-04 15:54:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (39, '5', 'guru', '1', '2022-03-09 09:40:18', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (40, '5', 'guru', '1', '2022-03-09 09:49:38', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (41, '5', 'guru', '1', '2022-03-09 09:55:00', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (42, '5', 'guru', '1', '2022-03-09 11:00:58', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (43, '', 'siswa', '11', '2022-03-09 11:02:22', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (44, '5', 'guru', '1', '2022-03-09 14:07:52', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (45, '5', 'guru', '1', '2022-03-09 14:23:43', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (46, '5', 'guru', '1', '2022-03-09 15:10:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (47, '', 'siswa', '11', '2022-03-09 15:10:39', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (48, '5', 'guru', '1', '2022-03-09 15:58:41', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (49, '5', 'guru', '1', '2022-03-10 10:42:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (50, '5', 'guru', '1', '2022-03-10 11:43:13', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (51, '5', 'guru', '1', '2022-03-10 11:43:20', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (52, '5', 'guru', '1', '2022-03-10 11:43:30', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (53, '5', 'guru', '1', '2022-03-10 11:45:48', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (54, '5', 'guru', '1', '2022-03-10 11:46:09', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (55, '5', 'guru', '1', '2022-03-10 14:57:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (56, '5', 'guru', '1', '2022-03-10 15:52:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (57, '5', 'guru', '1', '2022-03-10 16:38:46', 'Anda melakukan login dengan \"::1\"');


#
# TABLE STRUCTURE FOR: web_sekolah
#

DROP TABLE IF EXISTS `web_sekolah`;

CREATE TABLE `web_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `nama_sekolah` varchar(100) DEFAULT NULL,
  `kepsek` varchar(100) NOT NULL,
  `npsn` varchar(50) DEFAULT NULL,
  `nss` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kodepos` varchar(15) DEFAULT NULL,
  `no_telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `ttd` varchar(100) NOT NULL,
  `stampel` varchar(100) NOT NULL,
  `design` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (1, '1', 'SD ProSchool', 'Sutan Daulay', '20108989', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'tk@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (2, '2', 'SMP ProSchool', 'Panji Nugraha', '20108997', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'sd@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (3, '3', 'SMP ProSchool', 'Damara', '20108990', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'smp@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (4, '4', 'SMA ProSchool', 'Andre Taulany', '20108812', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'sma@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (5, '5', 'SMK ProSchool', 'Reza Lesmana', '20108813', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'smk@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');


#
# TABLE STRUCTURE FOR: web_setting
#

DROP TABLE IF EXISTS `web_setting`;

CREATE TABLE `web_setting` (
  `id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `maintenance` enum('tidak','iya') NOT NULL,
  `whatsapp_group` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `web_setting` (`id`, `url`, `title`, `logo`, `description`, `email`, `maintenance`, `whatsapp_group`, `whatsapp`) VALUES (1, 'https://www.proschool.id/', 'PROschool by DesaTech', 'logo.png', 'Elearning by ProSchool for a Smart Learning for Student in New Era! ', 'admin@proschool.id', 'tidak', '#', '6281280462650');


#
# TABLE STRUCTURE FOR: web_unit
#

DROP TABLE IF EXISTS `web_unit`;

CREATE TABLE `web_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_unit` (`id`, `nama`) VALUES (1, 'TK');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (2, 'SD');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (3, 'SMP');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (4, 'SMA');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (5, 'SMK');


#
# TABLE STRUCTURE FOR: web_visitor
#

DROP TABLE IF EXISTS `web_visitor`;

CREATE TABLE `web_visitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(26) NOT NULL,
  `date` date NOT NULL,
  `hits` int(11) NOT NULL,
  `online` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (1, '::1', '2022-02-18', 2, '1645176744', '2022-02-18 16:31:40');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (2, '::1', '2022-02-19', 31, '1645256376', '2022-02-19 11:16:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (3, '::1', '2022-02-20', 4, '1645351663', '2022-02-20 17:00:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (4, '::1', '2022-02-22', 127, '1645541912', '2022-02-22 10:08:17');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (5, '::1', '2022-02-23', 20, '1645620624', '2022-02-23 10:23:03');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (6, '::1', '2022-02-24', 2, '1645694578', '2022-02-24 15:46:59');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (7, '::1', '2022-03-02', 88, '1646211941', '2022-03-02 09:56:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (8, '::1', '2022-03-04', 11, '1646386633', '2022-03-04 14:46:36');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (9, '::1', '2022-03-07', 9, '1646644603', '2022-03-07 10:15:52');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (10, '::1', '2022-03-09', 107, '1646817882', '2022-03-09 09:40:18');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (11, '::1', '2022-03-10', 20, '1646915199', '2022-03-10 10:39:58');


