#
# TABLE STRUCTURE FOR: sr_kelas
#

DROP TABLE IF EXISTS `sr_kelas`;

CREATE TABLE `sr_kelas` (
  `idkelas` int(11) NOT NULL AUTO_INCREMENT,
  `k_tingkat` int(11) NOT NULL,
  `k_romawi` varchar(20) NOT NULL,
  `k_keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (1, 10, 'X - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (2, 10, 'X - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (3, 10, 'X - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (4, 10, 'X - MM', 'Multimedia');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (5, 11, 'XI - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (6, 11, 'XI - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (11, 11, 'XI - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (16, 11, 'XI - MM', 'Multimedia');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (17, 12, 'XII - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (19, 12, 'XII - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (20, 12, 'XII - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (21, 12, 'XII - MM', 'Multimedia');


#
# TABLE STRUCTURE FOR: sr_mata_pelajaran
#

DROP TABLE IF EXISTS `sr_mata_pelajaran`;

CREATE TABLE `sr_mata_pelajaran` (
  `idmata_pelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `mp_kode` varchar(50) NOT NULL,
  `mp_nama` varchar(255) NOT NULL,
  `mp_kelompok` enum('A','B','C','C1','C2') NOT NULL,
  `mp_urutan` int(11) NOT NULL,
  PRIMARY KEY (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=64 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (1, 'PAI', 'Pendidikan Agama Islam', 'A', 1);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (2, 'BIND', 'Bahasa Indonesia', 'A', 3);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (3, 'MTK', 'Matematika', 'A', 5);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (46, 'PKn', 'Pendidikan Kewarganegaraan', 'A', 2);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (47, 'SBdP', 'Seni Budaya dan Prakarya', 'B', 1);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (48, 'PJOK', 'Pendidikan Jasmani, Olahraga dan Kesehatan', 'B', 2);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (49, 'IPA', 'Ilmu Pengetahuan Alam', 'A', 6);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (50, 'IPS', 'Ilmu Pengetahuan Sosial', 'A', 7);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (51, 'BING', 'Bahasa Inggris', 'A', 8);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (63, 'MM', 'Multimedia', 'C1', 13);


#
# TABLE STRUCTURE FOR: sr_materi
#

DROP TABLE IF EXISTS `sr_materi`;

CREATE TABLE `sr_materi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mapel_id` int(11) NOT NULL,
  `pengajar_id` int(11) DEFAULT NULL,
  `judul` varchar(255) NOT NULL,
  `konten` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `video` text NOT NULL,
  `tgl_posting` datetime NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT 0,
  `views` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;

INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (1, 3, 1, 'Trigonometri Matematika', '<p>Test trigonometri</p>\r\n', NULL, '', '2021-12-08 00:13:45', 1, 6);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (2, 4, 1, 'Excel MOS', NULL, 'excel_mos_1638897335.xlsx', '', '2021-12-08 00:15:35', 1, 2);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (3, 1, 1, 'hhhh', NULL, 'hhhh_1639155245.png', '', '2021-12-10 23:54:05', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (4, 12, 3, 'test', NULL, 'test_1639439137.jpg', '', '2021-12-14 06:45:41', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (5, 13, 3, 'eaeae', NULL, 'eaeae_1639439314.jpg', '', '2021-12-14 06:48:34', 0, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (6, 20, 3, 'yeaah', NULL, '1', '', '2021-12-14 07:01:52', 0, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (7, 13, 3, 'test', 'https://www.youtube.com/watch?v=e86xyGaP6Ow', '1', '', '2021-12-14 07:24:50', 0, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (8, 13, 3, 'dsaadsadsds', 'https://www.youtube.com/watch?v=YRAImdAcl5g', '1', 'https://www.youtube.com/watch?v=YRAImdAcl5g', '2021-12-14 07:36:13', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (9, 13, 4, 'Belajar Dasar - Dasar Programming', NULL, '1', 'https://www.youtube.com/watch?v=sKrri__gMIQ', '2021-12-14 09:16:46', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (10, 20, 12, 'test', NULL, '1', 'https://www.youtube.com/watch?v=X5E61YavZqA', '2021-12-14 23:03:17', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (11, 16, 41, 'Materi Tentang Dasar-Dasar PHP dan Laravel', NULL, '1', 'https://www.youtube.com/watch?v=TaBWhb5SPfc', '2022-01-09 21:48:51', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (12, 16, 33, 'Dasar-Dasar Programming Laravel Dan PHP', NULL, '1', 'https://www.youtube.com/watch?v=eRZFGSCkAnw&t=7s', '2022-01-10 12:16:42', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (13, 16, 27, 'Pembelajaran Dasar - Dasar Programming Laravel', NULL, '1', 'https://www.youtube.com/watch?v=eRZFGSCkAnw', '2022-01-12 14:12:26', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (14, 17, 36, 'test', NULL, '1', 'https://www.youtube.com/watch?v=X5E61YavZqA', '2022-01-12 14:37:42', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (15, 17, 39, 'TEST', NULL, '1', 'https://www.youtube.com/watch?v=X5E61YavZqA', '2022-01-12 15:12:14', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (16, 15, 42, 'Test', NULL, '1', 'https://www.youtube.com/watch?v=X5E61YavZqA', '2022-01-12 15:22:21', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (17, 46, 26, 'damara', NULL, '1', 'https://www.youtube.com/watch?v=67l76EQWzGk', '2022-01-12 18:02:50', 1, 1);
INSERT INTO `sr_materi` (`id`, `mapel_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (18, 16, 47, 'Dasar-Dasar Programming Laravel', NULL, '1', 'https://www.youtube.com/watch?v=eRZFGSCkAnw&t=3s', '2022-01-18 12:17:25', 1, 1);


#
# TABLE STRUCTURE FOR: sr_pengumuman
#

DROP TABLE IF EXISTS `sr_pengumuman`;

CREATE TABLE `sr_pengumuman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `konten` text NOT NULL,
  `tgl_tampil` date NOT NULL,
  `tgl_tutup` date NOT NULL,
  `tampil_siswa` tinyint(1) NOT NULL DEFAULT 1,
  `tampil_pengajar` tinyint(1) NOT NULL DEFAULT 1,
  `pengajar_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pengajar_id` (`pengajar_id`),
  KEY `pengajar_id_2` (`pengajar_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

INSERT INTO `sr_pengumuman` (`id`, `judul`, `konten`, `tgl_tampil`, `tgl_tutup`, `tampil_siswa`, `tampil_pengajar`, `pengajar_id`) VALUES (6, 'imlek', '<p>Kepada seluruh SISWA, Libur <strong>IMLEK </strong>akan tiba!</p>\r\n', '2022-01-01', '2022-02-19', 1, 1, 1);


#
# TABLE STRUCTURE FOR: sr_siswa
#

DROP TABLE IF EXISTS `sr_siswa`;

CREATE TABLE `sr_siswa` (
  `idsiswa` int(11) NOT NULL AUTO_INCREMENT,
  `s_nisn` varchar(50) NOT NULL,
  `s_nama` varchar(100) NOT NULL,
  `s_nik` varchar(255) NOT NULL,
  `s_jenis_kelamin` enum('P','L') NOT NULL,
  `s_tl_idprovinsi` int(11) NOT NULL,
  `s_tl_idkota` int(11) NOT NULL,
  `s_tanggal_lahir` date NOT NULL,
  `idkelas` int(11) NOT NULL,
  `s_email` varchar(255) NOT NULL,
  `s_telepon` varchar(20) NOT NULL,
  `s_wali` varchar(255) NOT NULL,
  `s_dusun` varchar(255) NOT NULL,
  `s_desa` varchar(255) NOT NULL,
  `s_kecamatan` varchar(255) NOT NULL,
  `s_domisili` enum('Dalam','Luar') NOT NULL,
  `s_abk` enum('Ya','Tidak') NOT NULL,
  `s_bsm_pip` enum('Ya','Tidak') NOT NULL,
  `s_keluarga_miskin` enum('Ya','Tidak') NOT NULL,
  `s_code_generator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idsiswa`),
  KEY `s_tl_idprovinsi` (`s_tl_idprovinsi`),
  KEY `s_tl_idkota` (`s_tl_idkota`),
  KEY `idkelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (11, '204035871360', 'Aji Putra Arshavin ', '3401120912120001', 'L', 5, 210, '2012-01-09', 1, 'mas.ghaly88@gmail.com', '081977700271', 'Sulistyo', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', '');
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (12, '204035871361', 'Alya Zafaranie Rahman', '3401124304130003', 'P', 5, 210, '2013-04-13', 1, 'lorin.enjubella88@gmail.com', '0819928822', 'Fauzur Rahman', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', '716258');
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (13, '204035871362', 'Bintang Rakha Raqila', '3401120711120001', 'L', 5, 210, '2012-11-07', 1, '', '', 'Haryadi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (14, '204035871363', 'Damar Lestari', '3401126504130001', 'P', 5, 210, '2013-04-25', 1, '', '', 'Nuryanto', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (15, '204035871364', 'Dava Bayu Setiawan', '3401122106130001', 'L', 5, 210, '2013-06-21', 1, '', '', 'Kumara', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (16, '204035871365', 'Faris Husnul Arfan', '3401120805130001', 'P', 5, 210, '2013-05-08', 1, '', '', 'Madiyono', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (17, '204035871366', 'Hasna Khaira Nadhiva', '3401125209120001', 'P', 5, 210, '2012-09-12', 1, '', '', 'Sutriyono', 'KLANGON', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (18, '204035871367', 'Lafida Dwi Saputri', '3401126310120001', 'P', 5, 210, '2012-10-23', 1, '', '', 'Hajib Ja&#039;far', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (19, '204035871368', 'Muhammad Barik Al-Bani', '3401120202130001', 'L', 5, 210, '2013-02-02', 1, '', '', 'Slamet Sulbani', 'SEMAWUNG', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (20, '204035871369', 'Muhammad Haidar Yaqdhan', '3401121806130001', 'L', 5, 210, '2013-06-18', 1, '', '', 'Isdadi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (21, '204035871370', 'Muhammad Nehru Wiratama', '3310032711120002', 'L', 10, 196, '2012-11-27', 1, '', '', 'Bachtiar Bakriyanto', 'KARANGLO', 'TANJUNGAN', 'KEC. WEDI', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (22, '204035871371', 'Rani Prasetya Mawardi', '3401126604130002', 'P', 5, 210, '2015-04-16', 1, '', '', 'Mawardi', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (23, '204035871372', 'Raviola Eka Valentina', '3315136901130001', 'P', 10, 134, '2013-01-29', 1, '', '', 'Muhdaryanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (24, '204035871373', 'Reza Rahardyan Firmansyah', '3401121101130001', 'L', 5, 210, '2013-01-11', 1, '', '', 'Hariyanto', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (25, '204035871374', 'Saffa Arumi Ghaisani', '3205306505130002', 'P', 9, 126, '2013-05-25', 1, '', '', 'Ramdani', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (26, '204035871375', 'Salma Safira', '3401125404130001', 'P', 5, 210, '2013-12-04', 1, '', '', 'Porwanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (27, '204035871376', 'Shella Hikmatul Hidayah', '3401124902130001', 'P', 5, 210, '2013-09-02', 1, '', '', 'Haryanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (28, '204035871377', 'Syakira Rizka Prawestri', '3401125109120001', 'P', 5, 210, '2012-11-09', 1, '', '', 'Walmuji', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (29, '204035871378', 'Taufiq Hidayat', '3401122006130001', 'L', 5, 210, '2013-06-20', 1, '', '', 'Edi Hartanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (30, '204035871379', 'Zahra Dian Salsabilla', '3401124203130001', 'P', 5, 210, '2013-03-02', 1, '', '', 'Muhdi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (31, '204035871380', 'Zahwa Adina Putri', '3308036006130001', 'P', 10, 249, '2013-06-20', 1, '', '', 'Afda Setiawan', 'GANJURAN', 'PLOSOGEDE', 'KEC. NGLUWAR', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (32, '0119228271', 'Andhika Rohman Indra Wijaya', '3401122805110003', 'L', 5, 210, '2011-05-28', 2, '', '', 'Agus Anwari', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (33, '0111065143', 'Adit Hendryawan', '3401121812110001', 'L', 5, 210, '2011-12-18', 2, '', '', 'SARJONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (34, '0111566716', 'Alvino Bagus Hendrawan', '3308040907110003', 'L', 10, 249, '2011-07-09', 2, '', '', 'Muh Fahrudin', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (39, '0123535887', 'Anissa Rizki Maulidza', '3401124302120001', 'P', 5, 210, '2012-02-03', 2, '', '', 'NARPANDI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (40, '0117476280', 'Asmawa Fastina Artanti', '3401124302120001', 'P', 10, 476, '2011-08-19', 2, '', '', 'SUDIYANTO', 'KLANGON', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (41, '0108250622', 'Hafidz Nurul Ikhsan', '3401121410100002', 'L', 5, 210, '2010-10-14', 2, '', '', 'MUJIYANTA', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (42, '0129187164', 'Hafiz il Sya&#039;bana', '3401120207120002', 'L', 5, 210, '2012-07-02', 2, '', '', 'UDIYANTO', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (43, '0123340033', 'Haikal Daffa Salman Faiz', '3401121006120001', 'L', 5, 210, '2012-06-10', 2, '', '', 'GUNTORO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (44, '0112159539', 'Hammam Razka Pradipta', '3401120712110001', 'L', 5, 210, '2011-12-07', 2, '', '', 'AGUNG BUDIAJI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (45, '0111083351', 'Heevan Alyansyah Alfajr', '6302151410110001', 'L', 13, 203, '2011-10-14', 2, '', '', 'SYAHRUL FUJIANSYAH', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (46, '0125752767', 'Najwa Zalfa Khoirunnisa', '3401126004120001', 'P', 5, 210, '2012-04-20', 2, '', '', 'OTANG HATAMI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (47, '0117400693', 'Nungraeni Desy Safira Putri', '3401124612110001', 'P', 5, 210, '2011-12-08', 2, '', '', 'SUTARI', 'PANTOG WETAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (48, '0123596402', 'Nur Alifa Loveana Anjani', '3401125101120002', 'P', 5, 210, '2012-01-11', 2, '', '', 'NURKOYIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (49, '0117452080', 'Oktaviar Alhuwa Mufid', '3401120710110001', 'L', 5, 210, '2011-10-07', 2, '', '', 'MUHYIDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (50, '0112830228', 'Qalitza Zahwa Khairani', '3401126509110001', 'P', 5, 210, '2011-09-15', 2, '', '', 'SUNGKONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (51, '0121515850', 'Raffa Ahmad Sholikhin', '3401120803120001', 'L', 5, 210, '2012-03-08', 2, '', '', 'TOHA RUDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (52, '0121854845', 'Rendita Febriana Saputri', '3401124702120002', 'P', 5, 210, '2012-02-07', 2, '', '', 'YULI SUSANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (53, '0114655050', 'Reyhan Saputra', '3308081508120003', 'L', 10, 249, '2011-08-15', 2, '', '', 'FAJAR SETIADI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (54, '0124032295', 'Risky Putra Wahyu Pratama', '3401121602120004', 'L', 5, 210, '2012-02-16', 2, '', '', 'TRI YULIANA', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (55, '0113120197', 'Tedy Ahmad Santoso', '3401120210110001', 'L', 5, 210, '2011-10-02', 2, '', '', 'SUYOTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (56, '0129915965', 'Tsania Zahra Maulida', '3401125602120001', 'P', 5, 210, '2012-02-16', 2, '', '', 'SISWANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (57, '0125805929', 'Wanda Febriani Wulandari', '3211226902120002', 'P', 9, 440, '2012-02-29', 2, '', '', 'MUHROSID', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (58, '0106708074', 'Ananda Aulia', '3401124611100001', 'P', 5, 210, '2010-11-06', 3, '', '', 'SUYADI', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (59, '0108998849', 'Andini Nur Rahmawati', '3401124107100001', 'P', 5, 210, '2010-07-01', 3, '', '', 'YANI FATMAWATI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (60, '0111353064', 'Annas Hamid', '3401121804110001', 'L', 5, 210, '2011-04-18', 3, '', '', 'SURATIN', 'BANJARAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (61, '0118767416', 'As Syifa Dwi Pradayanti  ', '3401124905110002', 'P', 5, 210, '2011-05-09', 3, '', '', 'SUPARNO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (62, '0082175383', 'Astri Widya Pramesti', '3401125408080002', 'P', 10, 196, '2008-08-14', 3, '', '', 'PRAWOTO SUHARYONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (63, '0103368264', 'Bayu Ardhan Handaru', '3401120209100001', 'L', 5, 210, '2010-09-02', 3, '', '', 'KOMARUDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (64, '0103094001', 'Bintara Ardyama Saputra', '3401120907100001', 'L', 5, 210, '2010-07-09', 3, '', '', 'PARJIMIN', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (65, '0107104381', 'Dava Jiffin Adelino Romadi', '3401121110100001', 'L', 5, 210, '2010-10-11', 3, '', '', 'EKA ROMADI', 'DUWET III', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (66, '0102553662', 'Dayinta Kumala Wijaya Esti', '3401124607100002', 'P', 5, 210, '2010-07-06', 3, '', '', 'SUPRIYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (67, '0117972015', 'Fendy Adinata Wicaksono', '3401122103110001', 'L', 5, 210, '2011-03-21', 3, '', '', 'MARWANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (68, '0101989546', 'Ghiffara Najwa Azzahra', '3401126508100001', 'P', 5, 210, '2010-08-25', 3, '', '', 'ASHARIHIDAYAT', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (69, '0106111309', 'Hasna Nur Afifah', '3401125911100001', 'P', 5, 210, '2010-11-19', 3, '', '', 'SUBARDI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (70, '0111549550', 'Iin Wulan Safa Yanunisa', '3401126001110001', 'P', 5, 210, '2011-01-20', 3, '', '', 'AHMAD SUPRIYADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (71, '0164045268', 'Imam Santoso', '3401120505090001', 'L', 5, 210, '2009-05-05', 3, '', '', 'NURROHMAN', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (72, '0111117352', 'Irma Aprilia Fatmawati', '3401127103110001', 'P', 5, 210, '2011-03-31', 3, '', '', 'SUPARTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (73, '0103650256', 'Khanif Choiru Rochman', '3401122407110001', 'L', 5, 210, '2010-07-24', 3, '', '', 'MUH AHMAD BANI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (74, '0103523847', 'Misbachul Lubab', '3401122907100001', 'L', 5, 210, '2010-07-29', 3, '', '', 'SUWITA', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (75, '0105356940', 'Muhammad Abdul Azis Ramadhan', '3401120409100001', 'L', 5, 210, '2010-09-04', 3, '', '', 'SUDARYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (76, '0122709840', 'Muvida Shobrina', '3401126608110001', 'P', 5, 210, '2012-08-26', 3, '', '', 'SUROTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (77, '0113062348', 'Putri Khansa Udtiana Nafeeza', '3401124203110002', 'P', 5, 210, '2011-03-02', 3, '', '', 'DUL MASHUD', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (78, '0102233405', 'Renata Okta Anjaini', '3401126210100002', 'P', 5, 210, '2010-10-22', 3, '', '', 'NURYANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (79, '0119158123', 'Rendra Alfirkhan Nakholid', '3401121504110001', 'L', 5, 210, '2011-04-15', 3, '', '', 'IDIK IRYANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (80, '0115192584', 'Rifqi Ahmad Yanuarivan', '3401120901110001', 'L', 5, 210, '2011-01-09', 3, '', '', 'MUH AHMAD', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (81, '0112461768', 'Risnawati', '3401125606110001', 'P', 5, 210, '2011-06-26', 3, '', '', 'RISNAWATI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (82, '0096993456', 'Sri Astuti', '3401120407090001', 'P', 5, 210, '2009-07-04', 3, '', '', 'SITI KALIMAH', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (83, '0111138060', 'Syifa Nuriasari', '3401126802110001', 'P', 5, 210, '2011-02-28', 3, '', '', 'NUR AKHABAH ZAIBAN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (84, '0114478714', 'Tri Ega Saputra', '3401122003110002', 'L', 5, 210, '2011-03-20', 3, '', '', 'SUKIDI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (85, '0109611361', 'Yumna Aulia Zulfa', '3401124110100001', 'P', 5, 210, '2010-10-01', 3, '', '', 'FARID PRATIKNA', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (86, '0112997704', 'Adnanda Galih Yudistira', '3401120305110001', 'L', 5, 210, '2011-05-03', 3, '', '', 'HERIYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (87, '0097073468', 'Adnan Rangga Kurniawan', '3401120103090001', 'L', 5, 210, '2009-03-01', 4, '', '', 'SUWARTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (88, '0104677724', 'Ahmad Muthohar', '3401120301100001', 'L', 5, 210, '2010-01-03', 4, '', '', 'SUPRANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (89, '0108115939', 'Delia Anggraeni', '3401126604100001', 'P', 5, 210, '2010-04-26', 4, '', '', 'BADARI', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (90, '0094626840', 'Destin Siti Arofah', '3401124112090001', 'P', 5, 210, '2009-12-01', 4, '', '', 'TUGIMIN', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (91, '0103683075', 'Dwi Yuliana Putri', '3401124307100002', 'P', 5, 210, '2010-07-03', 4, '', '', 'MULYONO', 'BANJARAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (92, '0103048390', 'Emeldy Bunga Astuti', '3308085205100003', 'P', 10, 250, '2010-05-12', 4, '', '', 'EDI SUPRAYITNO', 'NGABLAK', 'KEJI', 'KEC. MUNTILAN', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (93, '0098885960', 'Evandra Emeraldgi Pratama', '3401120310090001', 'L', 5, 210, '2009-10-03', 4, '', '', 'NURWIYONO', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (94, '0075465499', 'Fauziah Ardelinda', '3401127001070001', 'P', 5, 210, '2007-01-30', 4, '', '', 'SUPARMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (95, '0109742705', 'Galih Reza Oktaviano', '3401120505100001', 'L', 5, 210, '2010-05-05', 4, '', '', 'RIYANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (96, '0086716698', 'Galih Kurniawan', '3401122812080001', 'L', 5, 210, '2008-12-28', 4, '', '', 'SUMARWOTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (97, '0082921451', 'Hesti Andriyani', '3401125004080001', 'P', 5, 210, '2008-04-10', 4, '', '', 'SUROTO', 'KEMPONG', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (98, '0091536451', 'Hibban Adib Murthada', '3401122010090001', 'L', 5, 210, '2009-10-20', 4, '', '', 'MUHAMAD NASIR', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (99, '0157442061', 'Latifa Ramadhani', '3401126808090001', 'P', 5, 210, '2009-08-28', 4, '', '', 'ALIYADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (100, '0103142489', 'Mardianty Putri Anggraeny', '3401124603100001', 'P', 5, 210, '2010-03-06', 4, '', '', 'SUDARMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (101, '0168301632', 'Muhammad Khoiruman Kafa', '3308090203100001', 'L', 10, 250, '2009-03-02', 4, '', '', 'MUHAMMAD BAEDHOWI', 'SARAGAN', 'RAMBEANAK', 'KEC. MUNGKID', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (102, '0098955268', 'Muhammad Minan Fauzi', '3401122107090001', 'L', 5, 210, '2009-07-21', 4, '', '', 'SLAMET', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (103, '0097560656', 'Naufal Hakim', '3401123010090001', 'L', 5, 210, '2009-10-30', 4, '', '', 'SUPNGATI WIDANIYAH', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (104, '0093830651', 'Oktavia Arya Damayanti', '3401125210090001', 'P', 5, 210, '2010-10-12', 4, '', '', 'WAKIJAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (105, '0098381033', 'Raffi Ahmad Afifudin', '3401121704090001', 'L', 5, 210, '2009-04-17', 4, '', '', 'NASRODIN', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (106, '02040412029', 'Shafira Mutiara Valen', '3401125502100001', 'P', 5, 210, '2010-02-15', 4, '', '', 'NOFIYALDI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (107, '0093846102', 'Yuda Edi Wahyana', '3401120108090003', 'L', 5, 210, '2009-08-01', 4, '', '', 'PUTRI JAZIMAH', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (108, '0082840617', 'Yusuf Pamungkas', '3401122804080001', 'L', 5, 210, '2008-04-28', 4, '', '', 'RAHMADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (109, '0153278170', 'Afif Rafiudin', '3401122708090001', 'L', 5, 210, '2009-06-27', 5, '', '', 'JUDARDIN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (110, '088476284', 'Ahmad Faiq Athaya', '3401122802080001', 'L', 10, 249, '2008-02-28', 5, '', '', 'Ahmad Baehaqi', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (111, '083034124', 'Amira Zerlinda', '3308026211080004', 'P', 34, 278, '2008-11-22', 5, '', '', 'Muhammad Zuamar', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (112, '0072961067', 'Andrian Putra Pangestu', '3401122206070001', 'L', 5, 210, '2007-06-22', 5, '', '', 'SURAHMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (113, '0086534500', 'Gresiya Suma Safitri', '3401125010080002', 'P', 5, 210, '2008-10-10', 5, '', '', 'DUL JALIL', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (114, '0095912960', 'Hasna Fathitya Sabrina', '3401126909090002', 'P', 5, 210, '2009-09-29', 5, '', '', 'EKO NURAHMAN SUROJO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (115, '0083313497', 'Indah Fitria Ningrum', '3401124210080001', 'P', 5, 210, '2008-10-02', 5, '', '', 'SUTARI', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (116, '0087301623', 'Muhammad Ilham Sarifuddin', '3401122103080002', 'L', 5, 210, '2008-03-21', 5, '', '', 'NURCHOLIS', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (117, '0155408388', 'Muhammad Raditya Ainul Yaqin', '3401121607080001', 'L', 5, 210, '2008-07-16', 5, '', '', 'FARIKIN', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (118, '0095231681', 'Muhammad Shulhan Al-farisi', '3401120106090001', 'L', 5, 210, '2009-06-01', 5, '', '', 'SLAMET SULBANI', 'SEMAWUNG', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (119, '0153200473', 'Novaris Dwi Firmansyah', '3401121711080002', 'L', 10, 249, '2008-11-17', 5, '', '', 'SARYANTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (120, '0072706748', 'Oktafiya Duwi Safitri', '3401125510070001', 'P', 5, 210, '2007-10-15', 5, '', '', 'SUNARDI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (121, '0083690882', 'Prastika Guntur Firmansyah', '3401120307080002', 'L', 5, 210, '2008-07-03', 5, '', '', 'KALIM', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (122, '0098488467', 'Siti Musyafiani', '3401124901090001', 'P', 5, 210, '2009-09-10', 5, '', '', 'ZURISAM', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (123, '0158891388', 'Tegar Arya Pangestu', '3401121308080001', 'L', 5, 210, '2008-08-13', 5, '', '', 'HARYADI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (124, '0081232726', 'Adi Bagus Saputra', '3401120703080001', 'L', 5, 210, '2008-03-07', 6, '', '', 'Suwita', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (125, '0071776993', 'Ageng Ratri Dewi', '340112591207002', 'P', 5, 210, '2007-12-19', 6, '', '', 'Sudarman', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (126, '0077101667', 'Ahmad Hidayat', '3401122701070002', 'L', 5, 210, '2007-01-27', 6, '', '', 'Masicun', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (127, '0074217306', 'Ahmad Mirza Arvinudin', '3401121612070001', 'L', 5, 210, '2007-12-16', 6, '', '', 'Muh Ahmad', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (128, '0074203935', 'Aqila Chusnia Mu&#039;mina', '3204156509070001', 'P', 9, 22, '2007-09-25', 6, '', '', 'Heru Gunadi', 'POTRONALAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (129, '0072510958', 'Ardian Ramadhan', '3401122209070001', 'L', 5, 210, '2007-09-22', 6, '', '', 'Widodo', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (130, '0089913911', 'Arif Duwiyanto', '3401122303090001', 'L', 5, 210, '2008-03-23', 6, '', '', 'Muh Ahmad Bani', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (131, '0085552671', 'Choiriatunnisa Tsani Hasya', '3401126707080002', 'P', 5, 210, '2008-07-27', 6, '', '', 'Riyadi', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (132, '0071429595', 'Febriana Alfiyani', '3401124806810002', 'P', 5, 210, '2007-02-24', 6, '', '', 'Alfandi', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (133, '0066771589', 'Fitri Andriani', '3401125510060002', 'P', 5, 210, '2006-10-15', 6, '', '', 'Suroto', 'KEMPONG', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (134, '0082016833', 'Iqbal Dzaky Reevansyah', '6302152103080001', 'L', 15, 215, '2008-03-21', 6, '', '', 'Fujiansyah', 'POTRONALAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (135, '0077252994', 'Junita Adinda Suryandika', '3401126606070001', 'P', 5, 210, '2007-06-26', 6, '', '', 'Suroto', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (136, '0077859964', 'Nabil Chandra Susilo Nugroho', '3401123011070001', 'L', 5, 210, '2007-11-30', 6, '', '', 'Sucipto Susilo', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (137, '0074539804', 'Revania Oktaviani', '3401126610070001', 'P', 5, 210, '2007-10-26', 6, '', '', 'Abidin', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (138, '0078559059', 'Zulfa Ulya', '3401126807070001', 'P', 5, 210, '2007-07-28', 6, '', '', 'Sudaryanto', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (140, '11111', '11111', '111', 'L', 2, 56, '2021-01-16', 11, 'ghalyfadhillah@gmail.com', '087722777245', 'Gunadi Abdullah', 'ASDASD', 'ASDASD', 'ASDASD', 'Dalam', 'Tidak', 'Ya', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (141, '3243', '44334', '34243342', 'P', 10, 169, '2021-01-18', 16, 'saddsa@sadads.com', '2332', 'dassad', 'SADASD', 'SADSAD', 'SADASD', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (142, '323242', '3243443', '232434', 'P', 8, 393, '2021-01-26', 17, 'dasdas@dsadsa.com', '432342', 'asddsa', 'SADASD', 'SADASD', 'ASDAS', 'Luar', 'Ya', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (143, '11314141441', 'Jumaidi Saputraaaa', '14141413141', 'L', 6, 151, '1999-10-19', 2, 'jumaidi@gmail.com', '08937272728128', 'Budi', '-', '-', 'PONDOK AREN', 'Dalam', 'Ya', 'Ya', 'Ya', NULL);


#
# TABLE STRUCTURE FOR: sr_users
#

DROP TABLE IF EXISTS `sr_users`;

CREATE TABLE `sr_users` (
  `idusers` int(11) unsigned NOT NULL,
  `u_nbm_nip` varchar(255) NOT NULL,
  `u_nuptk_nuks` varchar(255) DEFAULT NULL,
  `u_tl_idprovinsi` int(11) NOT NULL,
  `u_tl_idkota` int(11) NOT NULL,
  `u_tanggal_lahir` date NOT NULL,
  `u_jenis_kelamin` enum('P','L') NOT NULL,
  `u_status_pegawai` varchar(100) NOT NULL,
  `u_tunjangan_apbd` varchar(100) DEFAULT NULL,
  `u_tugas_tambahan` varchar(100) DEFAULT NULL,
  `u_jenjang` varchar(50) NOT NULL,
  `u_perguruan_tinggi` varchar(255) NOT NULL,
  `u_jurusan` varchar(100) DEFAULT NULL,
  `u_tahun_lulus` varchar(20) NOT NULL,
  `u_npwp` varchar(255) DEFAULT NULL,
  `u_sertifikasi` enum('Sudah','Belum') NOT NULL,
  `u_sertifikasi_tahun` year(4) DEFAULT NULL,
  `u_prestasi` text DEFAULT NULL,
  `u_honor` int(11) NOT NULL,
  `u_kerja_pasangan` varchar(255) DEFAULT NULL,
  `u_alamat_tinggal` text NOT NULL,
  `u_photo` text DEFAULT NULL,
  PRIMARY KEY (`idusers`),
  KEY `idusers` (`idusers`),
  KEY `u_tl_idprovinsi` (`u_tl_idprovinsi`),
  KEY `u_tl_idkota` (`u_tl_idkota`),
  KEY `idusers_2` (`idusers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (1, '954033', '3433754656300012 / 16023L0010404122016516', 6, 153, '1987-02-13', 'L', 'GTY', '', 'Kepala Sekolah', 'S1', 'Undip', 'Sistem Informasi', '2010', '66.907.985.7-544.000', 'Sudah', '2013', 'Guru Teladan tahun 2015', 2600000, 'Pegawai Swasta', 'Lenteng Agung, Jagakarsa, Jakarta Selatan', '3454bd5004b1bd6d20a9ff3f633a37d1.png');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (37, '992052', '9060760662300003', 5, 210, '1982-07-28', 'P', 'GTY', 'PTTD', 'Guru Kelas II', 'S1', 'Univ Terbuka Yogyakarta', 'PGSD', '2018', '', 'Belum', '0000', '', 1000000, 'Swasta', 'Demangan, Banjarharjo, Kalibawang', 'f5b05744233acca3b73d179279d83ff4.jpg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (38, '1062801', '', 5, 210, '1985-01-07', 'L', 'GTY', '', 'Guru Kelas IV', 'S1', 'Univ Sanata Dharma', 'PGSD', '2010', '91.003.379.4-544.000', 'Belum', '0000', '', 400000, 'Swasta', 'Duwet 3, Banjarharjo, Kalibawang', 'ef2cbde3636968a2bbb9f76a5df7909e.jpg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (39, '1295422', '', 5, 210, '1992-07-19', 'L', 'GTT', '', 'Guru Penjasorkes', 'S1', 'Univ Ahmad Dahlan', 'PBSI', '2012', '', 'Belum', '0000', '', 350000, '', 'Paras, Banjarasri, Kalibawang', '9f23f5e97972e5e98537f51b76db76ec.jpg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (40, '19671206 198903 1 003', '2538745647110043', 5, 210, '1967-12-06', 'L', 'PNS KEMENAG', '', 'Guru PAI', 'D2', 'UIN Sunan Kalij Jaga Yogyakarta', 'Pend. Agama Islam', '1993', '', 'Sudah', '2013', '', 4200000, 'IRT', 'Gunungmojo, Argosari, Sedayu, Bantul', '42ef1ac722851008e5e9bcb35351827c.jpg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (41, '1335358', '', 9, 115, '1994-04-04', 'P', 'GTT', '', 'Operator', 'S1', 'UIN Raden Fatah Palembang', 'Pend. Bahasa Inggris', '2017', '', 'Belum', '0000', '', 150000, 'Swasta', 'Salam, Banjarharjo, Kalibawang', 'e20f5b298a4d05cb1d22977403f73062.jpg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (42, '1335360', '', 5, 210, '1993-02-07', 'P', 'GTT', '', 'Guru Kelas I', 'S1', 'Univ Terbuka Banten', 'PGSD', '2018', '', 'Belum', '0000', '', 300000, 'Swasta', 'Pranan, Banjaroya, Kalibawang', '7079eeff453c257d36b51af9413281ec.jpeg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (43, '1314346', '', 5, 210, '1974-10-27', 'P', 'GTT', '', 'Guru Kelas III', 'S1', 'Univ Widya Mataram Yogyakarta', 'Teknologi pertanian', '1998', '', 'Belum', '0000', '', 300000, 'Karyawan', 'Kedondong 1, Banjararum, Kalibawang', '373f490ef28c28450a359b46e73525d7.jpg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (44, '1295423', '', 5, 210, '1987-04-15', 'P', 'GTT', '', 'Guru Kelas V', 'S1', 'Univ Indraprasta PGRI Jakarta', 'Pendidikan Matematika', '2011', '', 'Belum', '0000', '', 350000, 'Swasta', 'Semawung, Banjarharjo, Kalibawang', '17773abbb91433f028f4183bc51c80de.jpg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (45, '1187611', '', 5, 210, '1991-05-08', 'P', 'GTY', '', 'Guru Kelas VI', 'S1', 'Univ PGRI Yogyakarta', 'Pendidikan Matematika', '2013', '', 'Belum', '0000', '', 400000, '', 'Semaken 3, Banjararum, Kalibawang', '785a17c1772c4c0ed74a372bffca962f.jpg');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (57, '104352', '10435342456', 2, 56, '2021-01-18', 'L', 'GTY', '', 'Operator', 'S1', 'Universitas Amikom Yogyakarta', 'Sistem Informasi', '2021', '9999999999999', 'Belum', '0000', 'Pegawai Terganteng', 5300000, 'Kepala Dinas Pariwisata', 'Jln Bintara RT 12 RW 09', 'fb9a0bb598302e966995357ef0d12ab8.png');
INSERT INTO `sr_users` (`idusers`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`) VALUES (59, '104353', '10435342457', 6, 153, '1987-12-23', 'L', 'GTY', '0', 'Kepala Program', 'S1', 'Universitas Indra Prasta PGRI', 'Pendidikan Ekonomi', '2017', '12.345.76543', 'Belum', '0000', '0', 1400000, '0', 'Jl. Rawa Sari', '8b1746b499eea7a042bf6bd4ffb35f80.png');


#
# TABLE STRUCTURE FOR: sr_virtualclass
#

DROP TABLE IF EXISTS `sr_virtualclass`;

CREATE TABLE `sr_virtualclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pengajar_id` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `url` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `sr_virtualclass` (`id`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`) VALUES (35, 1, 1, 'BAB 1 - Membuat Company Profile', '2022-02-22', 'https://meet.jit.si/hQPtq');


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `activation_selector` varchar(255) DEFAULT NULL,
  `activation_code` varchar(255) DEFAULT NULL,
  `forgotten_password_selector` varchar(255) DEFAULT NULL,
  `forgotten_password_code` varchar(255) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_selector` varchar(255) DEFAULT NULL,
  `remember_code` varchar(255) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `multirole` enum('Y','N') DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_email` (`email`),
  UNIQUE KEY `uc_activation_selector` (`activation_selector`),
  UNIQUE KEY `uc_forgotten_password_selector` (`forgotten_password_selector`),
  UNIQUE KEY `uc_remember_selector` (`remember_selector`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (1, '127.0.0.1', 'administrator', '$2y$12$DPBC0GqrE7QhiYgWOBdbW.c/jZQ0qD7KS7mO8z5HtaiPa35WwuxyK', 'sutan.daulay@gmail.com', NULL, '', NULL, NULL, NULL, NULL, NULL, 1268889823, 1645102751, 1, 'N', 'Sutan', 'Daulay, S.Kom', 'ADMIN', '081283960337');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (37, '127.0.0.1', NULL, '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'h.yuliajie@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604316790, 1611518343, 1, 'Y', 'Heri', 'Yuli Astuti, S.Pd.', NULL, '081802637311');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (38, '127.0.0.1', 'guru kelas', '$2y$10$3Hfg3GDUGrnqzRJeFO1L0u3tHe.jEvBjl0AUi3GGOeYcLKUDwI60a', 'foreverbarca24@gmail.com', NULL, NULL, 'ab700a2863a956a747d4', '$2y$10$4XYaSh4FpMzIN8nIKtWD8.QItgBZD66jSiCSSoIKa2g8pKZ.9Q4MC', 1642521109, NULL, NULL, 1604324461, 1640778495, 1, 'Y', 'Eka', 'Romadi, S.Pd.', NULL, '087719045202');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (39, '127.0.0.1', NULL, '$2y$10$P1fNQaXHq7SDMI89fVyeAuNtbskbLbS6X9GzuvqLhyOpYGjb2jr66', 'prodocid.id@gmail.com', NULL, NULL, '54aeeeb4ea4657f09db2', '$2y$10$HyKy.P0dBI/lcuypcS02terQOa7JafMKUBudU9WiimL7WgzqArdOi', 1643542940, NULL, NULL, 1604404981, 1611515571, 1, 'N', 'Muhammad ', 'Yuli Nugroho, S.Pd.', NULL, '081328086524');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (40, '127.0.0.1', NULL, '$2y$10$eICdXdcDjiUKA7ieNqHTueuCVl47eLEkdCzHccWoip7HvN4Sx7sa2', 'foreverbarca17@gmail.com', NULL, NULL, '3d9377a7ed26470223ba', '$2y$10$rKlu2.Ys78..AV4P.Vq1Tu4AdGk3goipTz/ebHnm4XxlkQYbGde1.', 1642520837, NULL, NULL, 1604405357, 1640675168, 1, 'N', 'Ahwanto, A.Ma', '', NULL, '081328579072');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (41, '127.0.0.1', NULL, '$2y$10$ZlApEjZiUXuUQvPrelvWWOjqIlCK6mWlgyZAtskny353GxpATj6.O', 'trilestari40@yahoo.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604405791, 1645100999, 1, 'N', 'Tri ', 'Lestari, S.Pd', NULL, '085279657826');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (42, '127.0.0.1', NULL, '$2y$10$26FP8tRR/0UwORH8tI5eS.RNTMs3.RnIbZ7ldxy0PhIO/n94g2Jpe', 'widayatiasih93@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604406384, 1645101063, 1, 'Y', 'Widayati ', 'Asih Rusilah, S.Pd', NULL, '087877633339');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (43, '127.0.0.1', NULL, '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'tripuji298@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604406639, NULL, 1, 'Y', 'Tri ', 'Puji Lestari, S.TP', NULL, '081225422320');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (44, '127.0.0.1', NULL, '$2y$10$vyeEuY7OB3ECbYUTZiBGnuCsW5GXcTrbxiB6NDON7oZkUA0/bKUEy', 'tutikrahayu086@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604407059, 1645100832, 1, 'Y', 'Tutik ', 'Rahayu, S.Pd.', NULL, '087738264098');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (45, '127.0.0.1', NULL, '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'fulileo.astuti06@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1604407243, NULL, 1, 'Y', 'Tri ', 'Fuji Astuti, S.Pd.', NULL, '085764945075');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (57, '127.0.0.1', NULL, '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'ghalyfadhillah@gmail.com', NULL, NULL, '838d051ddf5c27374bf7', '$2y$10$MQ6wxgLA1MQHzgrKlKM7KuRo/pSo02VOb5WsZ59nWxdOMZ064vlcm', 1612625115, NULL, NULL, 1610969508, 1612615966, 1, 'Y', 'Ghaly', 'Fadhillah, S.Kom', NULL, '087722777245');
INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `email`, `activation_selector`, `activation_code`, `forgotten_password_selector`, `forgotten_password_code`, `forgotten_password_time`, `remember_selector`, `remember_code`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `company`, `phone`) VALUES (59, '103.119.141.186', NULL, '$2y$10$ztlP7HXx3yYRbbcldtK7V.dNLDzFirPis1LJ96KI6yftEFMBGS7py', 'saka87aja@gmail.com', NULL, NULL, '8a1fa8d7e23d1bde7cad', '$2y$10$p.ttJHUWLAS2MFPLzzB4mevmFLztDD2hFUUT/qBxjmrSes5JMxeDK', 1642485594, NULL, NULL, 1640777850, NULL, 1, 'N', 'Galuh', 'Saka Twinta S.pd', NULL, '0838654876342');


#
# TABLE STRUCTURE FOR: web_backup
#

DROP TABLE IF EXISTS `web_backup`;

CREATE TABLE `web_backup` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `datestamp` varchar(100) NOT NULL,
  `filedata` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (5, '2022-02-19 14:41:34', 'backup-220219-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (6, '2022-02-20 17:07:15', 'backup-220220-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (7, '2022-02-22 14:13:51', 'backup-220222-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (8, '2022-02-23 15:17:49', 'backup-220223-db.zip');


#
# TABLE STRUCTURE FOR: web_default
#

DROP TABLE IF EXISTS `web_default`;

CREATE TABLE `web_default` (
  `id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `maintenance` enum('tidak','iya') NOT NULL,
  `whatsapp_group` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `web_default` (`id`, `url`, `title`, `logo`, `description`, `email`, `maintenance`, `whatsapp_group`, `whatsapp`) VALUES (1, 'https://www.proschool.id/', 'PROschool by DesaTech', 'logo.png', 'Elearning by ProSchool for a Smart Learning for Student in New Era! ', 'admin@proschool.id', 'tidak', '#', '6281280462650');


#
# TABLE STRUCTURE FOR: web_log
#

DROP TABLE IF EXISTS `web_log`;

CREATE TABLE `web_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL,
  `idusers` varchar(11) NOT NULL,
  `datestamp` varchar(50) NOT NULL,
  `note` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (1, 'siswa', '11', '2022-02-20 17:02:55', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (2, 'guru', '1', '2022-02-20 17:06:20', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (3, 'guru', '1', '2022-02-22 10:08:16', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (4, 'siswa', '11', '2022-02-22 12:16:16', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (5, 'guru', '1', '2022-02-22 13:05:25', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (6, 'siswa', '11', '2022-02-22 15:13:52', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (7, 'guru', '1', '2022-02-22 15:53:42', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (8, 'siswa', '11', '2022-02-22 16:12:33', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (9, 'guru', '1', '2022-02-22 16:27:36', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (10, 'siswa', '11', '2022-02-22 16:43:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (11, 'guru', '1', '2022-02-22 16:50:10', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (12, 'siswa', '11', '2022-02-22 16:51:40', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (13, 'siswa', '11', '2022-02-22 21:25:17', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (14, 'siswa', '11', '2022-02-22 21:27:06', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (15, 'guru', '1', '2022-02-22 21:34:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (16, 'guru', '1', '2022-02-22 21:34:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (17, 'guru', '1', '2022-02-23 10:23:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (18, 'guru', '1', '2022-02-23 12:29:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (19, 'siswa', '11', '2022-02-23 14:13:27', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (20, 'siswa', '11', '2022-02-23 14:13:31', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (21, 'siswa', '11', '2022-02-23 14:13:51', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (22, 'siswa', '11', '2022-02-23 14:14:46', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (23, 'guru', '1', '2022-02-23 14:15:21', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (24, 'siswa', '11', '2022-02-23 15:18:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (25, 'siswa', '11', '2022-02-23 15:18:50', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (26, 'guru', '1', '2022-02-23 15:20:38', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (27, 'guru', '1', '2022-02-23 15:40:07', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (28, 'siswa', '11', '2022-02-23 17:23:27', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (29, 'siswa', '11', '2022-02-23 17:23:30', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (30, 'siswa', '11', '2022-02-23 17:23:33', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (31, 'guru', '1', '2022-02-23 17:27:12', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (32, 'guru', '1', '2022-02-23 19:50:24', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `type`, `idusers`, `datestamp`, `note`) VALUES (33, 'guru', '1', '2022-02-24 15:46:59', 'Anda melakukan login dengan \"::1\"');


#
# TABLE STRUCTURE FOR: web_sekolah
#

DROP TABLE IF EXISTS `web_sekolah`;

CREATE TABLE `web_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_sekolah` varchar(100) DEFAULT NULL,
  `kepsek` varchar(100) NOT NULL,
  `npsn` varchar(50) DEFAULT NULL,
  `nss` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kodepos` varchar(15) DEFAULT NULL,
  `no_telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `ttd` varchar(100) NOT NULL,
  `stampel` varchar(100) NOT NULL,
  `design` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `web_sekolah` (`id`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (1, 'ProSchool', 'Reza Lesmana', '83960337', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'admin@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');


#
# TABLE STRUCTURE FOR: web_setting
#

DROP TABLE IF EXISTS `web_setting`;

CREATE TABLE `web_setting` (
  `id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `maintenance` enum('tidak','iya') NOT NULL,
  `whatsapp_group` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `web_setting` (`id`, `url`, `title`, `logo`, `description`, `email`, `maintenance`, `whatsapp_group`, `whatsapp`) VALUES (1, 'https://www.proschool.id/', 'PROschool by DesaTech', 'logo.png', 'Elearning by ProSchool for a Smart Learning for Student in New Era! ', 'admin@proschool.id', 'tidak', '#', '6281280462650');


#
# TABLE STRUCTURE FOR: web_visitor
#

DROP TABLE IF EXISTS `web_visitor`;

CREATE TABLE `web_visitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(26) NOT NULL,
  `date` date NOT NULL,
  `hits` int(11) NOT NULL,
  `online` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (1, '::1', '2022-02-18', 2, '1645176744', '2022-02-18 16:31:40');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (2, '::1', '2022-02-19', 31, '1645256376', '2022-02-19 11:16:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (3, '::1', '2022-02-20', 4, '1645351663', '2022-02-20 17:00:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (4, '::1', '2022-02-22', 127, '1645541912', '2022-02-22 10:08:17');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (5, '::1', '2022-02-23', 20, '1645620624', '2022-02-23 10:23:03');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (6, '::1', '2022-02-24', 2, '1645694578', '2022-02-24 15:46:59');


