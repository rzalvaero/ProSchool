#
# TABLE STRUCTURE FOR: admin
#

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `admin` (`id`, `nama`, `email`, `username`, `password`) VALUES (1, 'Administrator', 'admin@admin.com', 'admin', '$2y$10$8SoPqIecyMythHypIhN90OUrIFpvazbImXIgBcKZQenn9SVcD47fS');


#
# TABLE STRUCTURE FOR: das_kategori
#

DROP TABLE IF EXISTS `das_kategori`;

CREATE TABLE `das_kategori` (
  `id_das_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_dana` varchar(50) DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  `dana` double DEFAULT NULL,
  `sisa_dana` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  PRIMARY KEY (`id_das_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `das_kategori` (`id_das_kategori`, `jenis_dana`, `tahun_ajaran`, `dana`, `sisa_dana`, `tanggal`) VALUES (1, 'baksos', '2011', '200000', '200000', '2022-04-05');


#
# TABLE STRUCTURE FOR: das_sumber_dana
#

DROP TABLE IF EXISTS `das_sumber_dana`;

CREATE TABLE `das_sumber_dana` (
  `id_das_sumber_dana` int(11) NOT NULL AUTO_INCREMENT,
  `jenis_dana_masuk` varchar(100) DEFAULT NULL,
  `jumlah_dana` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `tahun_ajaran` varchar(9) DEFAULT NULL,
  PRIMARY KEY (`id_das_sumber_dana`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: das_user
#

DROP TABLE IF EXISTS `das_user`;

CREATE TABLE `das_user` (
  `id_das_user` int(11) NOT NULL AUTO_INCREMENT,
  `id_das` int(11) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `total_terima` double DEFAULT NULL,
  `sisa_saldo` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `no_das` varchar(25) NOT NULL,
  `status_das_user` char(1) NOT NULL DEFAULT '0',
  `open` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_das_user`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: das_user_bendahara
#

DROP TABLE IF EXISTS `das_user_bendahara`;

CREATE TABLE `das_user_bendahara` (
  `id_das_user_bendahara` int(11) NOT NULL AUTO_INCREMENT,
  `id_das_bendahara` int(11) DEFAULT NULL,
  `keterangan` varchar(200) DEFAULT NULL,
  `total_terima` double DEFAULT NULL,
  `sisa_saldo` double DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `no_das` varchar(25) DEFAULT NULL,
  `status_das_user` char(1) DEFAULT '0',
  PRIMARY KEY (`id_das_user_bendahara`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: das_user_bendahara_output
#

DROP TABLE IF EXISTS `das_user_bendahara_output`;

CREATE TABLE `das_user_bendahara_output` (
  `id_das_user_bendahara_output` int(11) NOT NULL AUTO_INCREMENT,
  `id_das_user_bendahara` int(11) DEFAULT NULL,
  `jenis_das` varchar(15) DEFAULT NULL,
  `jumlah` double DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `ada_nota` char(1) DEFAULT '0',
  `ada_bku` char(1) DEFAULT '0',
  PRIMARY KEY (`id_das_user_bendahara_output`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: das_user_output
#

DROP TABLE IF EXISTS `das_user_output`;

CREATE TABLE `das_user_output` (
  `id_das_user_output` int(11) NOT NULL AUTO_INCREMENT,
  `id_das_user` int(11) DEFAULT NULL,
  `jenis_das` varchar(50) NOT NULL,
  `jumlah` double DEFAULT NULL,
  `keterangan` varchar(100) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  `ada_nota` char(1) NOT NULL DEFAULT '0',
  `ada_bku` char(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id_das_user_output`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_inventarisasi
#

DROP TABLE IF EXISTS `det_inventarisasi`;

CREATE TABLE `det_inventarisasi` (
  `id_det_inventarisasi` varchar(50) NOT NULL,
  `id_inventarisasi` varchar(50) DEFAULT NULL,
  `id_pengajuan` varchar(50) DEFAULT NULL,
  `id_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_det_inventarisasi`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_pengadaan
#

DROP TABLE IF EXISTS `det_pengadaan`;

CREATE TABLE `det_pengadaan` (
  `id_det_pengadaan` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengadaan` varchar(50) DEFAULT NULL,
  `nama_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `harga_pengadaan` double DEFAULT NULL,
  `harga_realisasi` double DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  PRIMARY KEY (`id_det_pengadaan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_pengelolaan
#

DROP TABLE IF EXISTS `det_pengelolaan`;

CREATE TABLE `det_pengelolaan` (
  `id_det_pengelolaan` int(11) NOT NULL AUTO_INCREMENT,
  `id_pengelolaan` varchar(50) DEFAULT NULL,
  `id_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_det_pengelolaan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_penghapusan
#

DROP TABLE IF EXISTS `det_penghapusan`;

CREATE TABLE `det_penghapusan` (
  `id_det_penghapusan` int(50) NOT NULL AUTO_INCREMENT,
  `id_penghapusan` varchar(50) DEFAULT NULL,
  `id_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `jenis_hapus` varchar(50) DEFAULT NULL,
  `nilai_asset` double DEFAULT NULL,
  PRIMARY KEY (`id_det_penghapusan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: det_perencanaan
#

DROP TABLE IF EXISTS `det_perencanaan`;

CREATE TABLE `det_perencanaan` (
  `id_det_perencanaan` int(11) NOT NULL AUTO_INCREMENT,
  `id_perencanaan` varchar(50) DEFAULT NULL,
  `id_kategori_asset` varchar(50) DEFAULT NULL,
  `id_jenis_asset` varchar(50) DEFAULT NULL,
  `nama_asset` varchar(50) DEFAULT NULL,
  `jumlah` int(11) DEFAULT NULL,
  `harga` double DEFAULT NULL,
  `total_harga` double DEFAULT NULL,
  PRIMARY KEY (`id_det_perencanaan`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: pembayaran_bebas_dt
#

DROP TABLE IF EXISTS `pembayaran_bebas_dt`;

CREATE TABLE `pembayaran_bebas_dt` (
  `id_pembayaran_bebas_dt` int(11) NOT NULL AUTO_INCREMENT,
  `id_pembayaran_bebas` int(11) DEFAULT NULL,
  `bayar` float DEFAULT NULL,
  `tanggal` date NOT NULL,
  PRIMARY KEY (`id_pembayaran_bebas_dt`),
  KEY `id_pembayaran_bebas` (`id_pembayaran_bebas`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: sr_absen
#

DROP TABLE IF EXISTS `sr_absen`;

CREATE TABLE `sr_absen` (
  `id_absen` int(11) NOT NULL AUTO_INCREMENT,
  `idusers` varchar(50) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `tahun_ajaran` varchar(50) DEFAULT NULL,
  `keterangan` enum('SAKIT','IZIN','ALPA') DEFAULT NULL,
  `alasan` varchar(100) DEFAULT NULL,
  `tanggal_absen` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id_absen`)
) ENGINE=InnoDB AUTO_INCREMENT=134 DEFAULT CHARSET=latin1;

INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (118, '11', 'SISWA', '2021/2022-2', NULL, NULL, '2022-04-01');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (119, '11', 'SISWA', '2021/2022-2', NULL, NULL, '2022-04-11');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (122, '11', 'SISWA', '2021/2022-2', NULL, NULL, '2022-04-21');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (123, '11', 'SISWA', '2021/2022-2', NULL, NULL, '2022-04-20');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (124, '1', 'GURU', '2021/2022-2', NULL, NULL, '2022-04-20');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (125, '1', 'GURU', '2021/2022-2', NULL, NULL, '2022-04-21');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (126, '1', 'GURU', '2021/2022-2', NULL, NULL, '2022-04-25');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (127, '1', 'GURU', '2021/2022-2', NULL, NULL, '2022-05-12');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (128, '11', 'SISWA', '2021/2022-2', NULL, NULL, '2022-05-12');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (129, '11', 'SISWA', '2021/2022-2', NULL, NULL, '2022-05-11');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (130, '11', 'SISWA', '2021/2022-2', NULL, NULL, '2022-05-17');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (131, '11', 'SISWA', '2021/2022-2', NULL, NULL, '2022-05-23');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (132, '1', 'GURU', '2021/2022-2', NULL, NULL, '2022-05-23');
INSERT INTO `sr_absen` (`id_absen`, `idusers`, `type`, `tahun_ajaran`, `keterangan`, `alasan`, `tanggal_absen`) VALUES (133, '1', 'GURU', '2021/2022-2', NULL, NULL, '2022-05-25');


#
# TABLE STRUCTURE FOR: sr_account
#

DROP TABLE IF EXISTS `sr_account`;

CREATE TABLE `sr_account` (
  `id_akun` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `kode_akun` varchar(20) DEFAULT NULL,
  `jenis_akun` int(20) DEFAULT NULL,
  `kategori` varchar(255) DEFAULT NULL,
  `keterangan` varchar(255) DEFAULT NULL,
  `modul_keuangan` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_akun`)
) ENGINE=InnoDB AUTO_INCREMENT=622667 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (1, '5', '1-1000', 1, 'utama', 'AKTIVA', NULL);
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622655, '5', '1-1100', 2, 'keuangan', 'Kas Tunai SMA', 'aset');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622656, '5', '1-1900', 2, 'keuangan', 'Piutang', 'aset');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622657, '5', '2-2000', 1, 'utama', 'PASIVA', 'aset');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622658, '5', '4-4000', 1, 'utama', 'Pendapatan', 'pendapatan');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622660, '5', '5-5000', 1, 'utama', 'Beban', 'biaya');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622662, '5', '1-900', 1, 'utama', 'AKTIVA', 'biaya');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622663, '5', '4-4010', 1, 'pendapatan baju SD', 'pendapatan baju SD', 'pendapatan');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622664, '5', '4-4020', 2, 'keuangan', 'pendapatan baju SMP', 'pendapatan');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622665, '', '4-4030', 2, 'pembayaran', 'Pendapatan Buku Paket ', 'pendapatan');
INSERT INTO `sr_account` (`id_akun`, `unit`, `kode_akun`, `jenis_akun`, `kategori`, `keterangan`, `modul_keuangan`) VALUES (622666, '5', '4-4030', 1, 'keuangan', 'Konsumsi SD', 'aset');


#
# TABLE STRUCTURE FOR: sr_akun_gaji
#

DROP TABLE IF EXISTS `sr_akun_gaji`;

CREATE TABLE `sr_akun_gaji` (
  `id_akun_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `akun_gaji` varchar(20) DEFAULT NULL,
  `id_user` varchar(20) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_akun_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_akun_gaji` (`id_akun_gaji`, `akun_gaji`, `id_user`, `unit`) VALUES (1, '622662', '40', '5');
INSERT INTO `sr_akun_gaji` (`id_akun_gaji`, `akun_gaji`, `id_user`, `unit`) VALUES (2, '622662', '38', '5');


#
# TABLE STRUCTURE FOR: sr_bukukerja
#

DROP TABLE IF EXISTS `sr_bukukerja`;

CREATE TABLE `sr_bukukerja` (
  `bukukerja_id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` int(11) NOT NULL,
  `nomer` varchar(100) NOT NULL,
  `matapelajaran` varchar(10) NOT NULL,
  `files` varchar(255) NOT NULL,
  `created` varchar(100) NOT NULL,
  PRIMARY KEY (`bukukerja_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_bukukerja` (`bukukerja_id`, `unit`, `nomer`, `matapelajaran`, `files`, `created`) VALUES (2, 5, 'Buku kerja nomer 1', 'Pendidikan', 'Buku_Kerja_Guru_1.docx', '2022-03-25 15:34:30');
INSERT INTO `sr_bukukerja` (`bukukerja_id`, `unit`, `nomer`, `matapelajaran`, `files`, `created`) VALUES (3, 5, 'Buku kerja nomer 1', 'Bahasa Ind', 'photo-1453728013993-6d66e9c9123a.jpg', '2022-05-27 14:35:08');
INSERT INTO `sr_bukukerja` (`bukukerja_id`, `unit`, `nomer`, `matapelajaran`, `files`, `created`) VALUES (4, 5, 'Buku kerja nomer 2', 'Pendidikan', 'photo-1453728013993-6d66e9c9123a1.jpg', '2022-05-27 15:07:48');
INSERT INTO `sr_bukukerja` (`bukukerja_id`, `unit`, `nomer`, `matapelajaran`, `files`, `created`) VALUES (5, 5, 'Buku kerja nomer 1', 'Pendidikan', 'Gambar.pdf', '2022-05-27 15:14:12');
INSERT INTO `sr_bukukerja` (`bukukerja_id`, `unit`, `nomer`, `matapelajaran`, `files`, `created`) VALUES (6, 5, 'Buku kerja nomer 1', 'Pendidikan', 'file-sample_150kB.pdf', '2022-05-27 15:21:55');
INSERT INTO `sr_bukukerja` (`bukukerja_id`, `unit`, `nomer`, `matapelajaran`, `files`, `created`) VALUES (7, 5, 'Buku kerja nomer 1', 'Matematika', 'screencapture-search-google-search-console-performance-search-analytics-2022-05-27-11_17_24.pdf', '2022-05-27 15:22:20');


#
# TABLE STRUCTURE FOR: sr_bulan
#

DROP TABLE IF EXISTS `sr_bulan`;

CREATE TABLE `sr_bulan` (
  `id_bulan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_bulan` varchar(25) DEFAULT NULL,
  PRIMARY KEY (`id_bulan`),
  UNIQUE KEY `nama_bulan` (`nama_bulan`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (2, 'Agustus');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (10, 'April');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (6, 'Desember');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (8, 'Febuari');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (7, 'Januari');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (1, 'Juli');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (12, 'Juni');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (9, 'Maret');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (11, 'Mei');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (5, 'November');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (4, 'Oktober');
INSERT INTO `sr_bulan` (`id_bulan`, `nama_bulan`) VALUES (3, 'September');


#
# TABLE STRUCTURE FOR: sr_butir_sikap
#

DROP TABLE IF EXISTS `sr_butir_sikap`;

CREATE TABLE `sr_butir_sikap` (
  `idbutir_sikap` int(11) NOT NULL AUTO_INCREMENT,
  `bs_kategori` varchar(10) NOT NULL,
  `bs_kode` varchar(255) NOT NULL,
  `bs_keterangan` text NOT NULL,
  `bs_unit` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idbutir_sikap`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_butir_sikap` (`idbutir_sikap`, `bs_kategori`, `bs_kode`, `bs_keterangan`, `bs_unit`) VALUES (1, '2', 'Jujur (1.1)', 'Tidak mau berbohong atau tidak mencontek', '5');


#
# TABLE STRUCTURE FOR: sr_ekstra
#

DROP TABLE IF EXISTS `sr_ekstra`;

CREATE TABLE `sr_ekstra` (
  `idekstra` int(11) NOT NULL AUTO_INCREMENT,
  `e_nama` varchar(255) NOT NULL,
  `unit` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idekstra`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_ekstra` (`idekstra`, `e_nama`, `unit`) VALUES (2, 'Futsal', '5');
INSERT INTO `sr_ekstra` (`idekstra`, `e_nama`, `unit`) VALUES (3, 'Baca Tulis Al Quran', '5');
INSERT INTO `sr_ekstra` (`idekstra`, `e_nama`, `unit`) VALUES (4, 'Pertanian', '5');
INSERT INTO `sr_ekstra` (`idekstra`, `e_nama`, `unit`) VALUES (5, 'Pramuka', '5');
INSERT INTO `sr_ekstra` (`idekstra`, `e_nama`, `unit`) VALUES (6, 'Qiroah', '5');


#
# TABLE STRUCTURE FOR: sr_gaji_karyawan
#

DROP TABLE IF EXISTS `sr_gaji_karyawan`;

CREATE TABLE `sr_gaji_karyawan` (
  `id_gaji_karyawan` int(11) NOT NULL AUTO_INCREMENT,
  `gaji_pokok` varchar(100) DEFAULT NULL,
  `gaji_potongan` varchar(100) DEFAULT NULL,
  `gaji_pendapatan_lain_lain` varchar(100) DEFAULT NULL,
  `akun` varchar(20) DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  PRIMARY KEY (`id_gaji_karyawan`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_gaji_karyawan` (`id_gaji_karyawan`, `gaji_pokok`, `gaji_potongan`, `gaji_pendapatan_lain_lain`, `akun`, `unit`, `id_user`, `tanggal`) VALUES (9, '400000', '2000', '100000', '622662', '5', 40, '2022-04-07');


#
# TABLE STRUCTURE FOR: sr_gaji_karyawan_perbulan
#

DROP TABLE IF EXISTS `sr_gaji_karyawan_perbulan`;

CREATE TABLE `sr_gaji_karyawan_perbulan` (
  `id_gaji_karyawan` int(11) NOT NULL AUTO_INCREMENT,
  `gaji_pokok` varchar(100) DEFAULT NULL,
  `gaji_potongan` varchar(100) DEFAULT NULL,
  `gaji_pendapatan_lain_lain` varchar(100) DEFAULT NULL,
  `akun` varchar(20) DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `id_user` int(11) DEFAULT NULL,
  `tanggal` date DEFAULT NULL,
  PRIMARY KEY (`id_gaji_karyawan`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_gaji_karyawan_perbulan` (`id_gaji_karyawan`, `gaji_pokok`, `gaji_potongan`, `gaji_pendapatan_lain_lain`, `akun`, `unit`, `id_user`, `tanggal`) VALUES (14, '400000', '2000', '100000', '622662', '5', 40, '2022-04-12');


#
# TABLE STRUCTURE FOR: sr_guestbook
#

DROP TABLE IF EXISTS `sr_guestbook`;

CREATE TABLE `sr_guestbook` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `user_email` varchar(200) NOT NULL,
  `user_visit` varchar(100) NOT NULL,
  `user_phone` varchar(100) NOT NULL,
  `user_created` varchar(100) NOT NULL,
  `user_ip` varchar(20) DEFAULT NULL,
  `user_os` varchar(100) DEFAULT NULL,
  `user_browser` varchar(100) DEFAULT NULL,
  `approve` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

INSERT INTO `sr_guestbook` (`id`, `unit`, `user_name`, `user_email`, `user_visit`, `user_phone`, `user_created`, `user_ip`, `user_os`, `user_browser`, `approve`) VALUES (7, '2', 'Reza Lesmana Putra', 'rzalvaero@gmail.com', '2022-05-20', '088906033372', '2022-03-17 15:00:01', '::1', 'Windows 10', '99.0.4844.51', 0);


#
# TABLE STRUCTURE FOR: sr_guru_tes
#

DROP TABLE IF EXISTS `sr_guru_tes`;

CREATE TABLE `sr_guru_tes` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_guru` int(6) NOT NULL,
  `jenis` enum('acak','paket') NOT NULL,
  `id_mapel` int(6) DEFAULT NULL,
  `id_paket` int(6) DEFAULT NULL,
  `nama_ujian` varchar(200) NOT NULL,
  `jumlah_soal` int(6) DEFAULT NULL,
  `waktu` int(6) NOT NULL,
  `detil_jenis` varchar(200) NOT NULL,
  `tgl_mulai` datetime NOT NULL,
  `terlambat` datetime NOT NULL,
  `token` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (5, 1, 'paket', NULL, 7, 'Ujian Paket ips', 10, 1110, '', '2022-04-02 06:07:00', '2022-04-05 06:07:00', '234');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (7, 1, 'paket', NULL, 9, 'ujian uas', 10, 10, '', '2022-04-04 15:41:00', '2022-04-05 17:41:00', '123');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (8, 1, 'paket', NULL, 8, 'paket baru', 10, 10, '', '2022-04-04 15:49:00', '2022-04-06 16:49:00', '123');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (9, 1, 'paket', NULL, 8, 'paket ujian sd ipa', 10, 15, '', '2022-04-04 16:18:00', '2022-04-06 19:18:00', '123');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (10, 1, 'paket', NULL, 8, 'Ujian Paketyyy', 10, 10, '', '2022-04-05 10:14:00', '2022-04-06 09:14:00', '123');
INSERT INTO `sr_guru_tes` (`id`, `id_guru`, `jenis`, `id_mapel`, `id_paket`, `nama_ujian`, `jumlah_soal`, `waktu`, `detil_jenis`, `tgl_mulai`, `terlambat`, `token`) VALUES (11, 1, 'paket', NULL, 10, 'adadsa', 0, 60, '', '2022-05-23 10:26:00', '2022-05-24 10:26:00', 'asa');


#
# TABLE STRUCTURE FOR: sr_ikut_ujian
#

DROP TABLE IF EXISTS `sr_ikut_ujian`;

CREATE TABLE `sr_ikut_ujian` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_tes` int(6) NOT NULL,
  `id_user` int(6) NOT NULL,
  `jml_benar` int(6) NOT NULL,
  `nilai` decimal(10,2) NOT NULL,
  `nilai_bobot` decimal(10,2) NOT NULL,
  `tgl_mulai` datetime NOT NULL,
  `tgl_selesai` datetime NOT NULL,
  `status` enum('Y','N') NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

INSERT INTO `sr_ikut_ujian` (`id`, `id_tes`, `id_user`, `jml_benar`, `nilai`, `nilai_bobot`, `tgl_mulai`, `tgl_selesai`, `status`) VALUES (28, 7, 11, 2, '100.00', '0.00', '2022-04-04 16:22:46', '2022-04-04 16:32:46', 'N');
INSERT INTO `sr_ikut_ujian` (`id`, `id_tes`, `id_user`, `jml_benar`, `nilai`, `nilai_bobot`, `tgl_mulai`, `tgl_selesai`, `status`) VALUES (29, 9, 12, 0, '0.00', '0.00', '2022-04-05 11:27:11', '2022-04-05 11:42:11', 'N');
INSERT INTO `sr_ikut_ujian` (`id`, `id_tes`, `id_user`, `jml_benar`, `nilai`, `nilai_bobot`, `tgl_mulai`, `tgl_selesai`, `status`) VALUES (30, 7, 12, 0, '0.00', '0.00', '2022-04-05 14:36:39', '2022-04-05 14:46:39', 'N');


#
# TABLE STRUCTURE FOR: sr_ikut_ujian_detil_jawaban
#

DROP TABLE IF EXISTS `sr_ikut_ujian_detil_jawaban`;

CREATE TABLE `sr_ikut_ujian_detil_jawaban` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `id_ikut_ujian` int(10) NOT NULL,
  `id_soal` int(10) NOT NULL,
  `jawaban_user` varchar(1) NOT NULL,
  `status_jawaban` int(1) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (39, 28, 28, 'C', 1, '2022-04-04 16:23:31');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (40, 28, 30, 'D', 1, '2022-04-04 16:23:35');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (41, 29, 30, 'B', 0, '2022-04-05 11:27:16');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (42, 30, 28, 'B', 0, '2022-04-05 14:36:43');
INSERT INTO `sr_ikut_ujian_detil_jawaban` (`id`, `id_ikut_ujian`, `id_soal`, `jawaban_user`, `status_jawaban`, `updated_at`) VALUES (43, 30, 30, 'B', 0, '2022-04-05 14:36:45');


#
# TABLE STRUCTURE FOR: sr_interval_predikat
#

DROP TABLE IF EXISTS `sr_interval_predikat`;

CREATE TABLE `sr_interval_predikat` (
  `idinterval_predikat` int(11) NOT NULL AUTO_INCREMENT,
  `idkkm` int(11) NOT NULL,
  `amin` int(11) NOT NULL,
  `amax` int(11) NOT NULL,
  `bmin` int(11) NOT NULL,
  `bmax` int(11) NOT NULL,
  `cmin` int(11) NOT NULL,
  `cmax` int(11) NOT NULL,
  `dmin` int(11) NOT NULL,
  `dmax` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  PRIMARY KEY (`idinterval_predikat`),
  KEY `idkkm` (`idkkm`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_interval_predikat` (`idinterval_predikat`, `idkkm`, `amin`, `amax`, `bmin`, `bmax`, `cmin`, `cmax`, `dmin`, `dmax`, `unit`) VALUES (6, 2, 88, 100, 79, 87, 65, 78, 0, 64, 5);
INSERT INTO `sr_interval_predikat` (`idinterval_predikat`, `idkkm`, `amin`, `amax`, `bmin`, `bmax`, `cmin`, `cmax`, `dmin`, `dmax`, `unit`) VALUES (7, 3, 80, 100, 75, 85, 60, 70, 10, 50, 5);


#
# TABLE STRUCTURE FOR: sr_invoice
#

DROP TABLE IF EXISTS `sr_invoice`;

CREATE TABLE `sr_invoice` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `code` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `identification` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `custumer` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `service` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `price` int(10) NOT NULL,
  `noreff` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `method` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `email` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `number` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `sistem` enum('Auto','Manual') COLLATE utf8_swedish_ci NOT NULL,
  `status` enum('Pending','Success','Error') COLLATE utf8_swedish_ci NOT NULL,
  `jenis` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `place_from` enum('WEB','API') COLLATE utf8_swedish_ci NOT NULL,
  `date` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `link` varchar(200) COLLATE utf8_swedish_ci DEFAULT NULL,
  `tf` int(2) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

INSERT INTO `sr_invoice` (`id`, `code`, `identification`, `custumer`, `service`, `price`, `noreff`, `method`, `email`, `number`, `sistem`, `status`, `jenis`, `place_from`, `date`, `link`, `tf`) VALUES (31, 'ID-05778', 'REG-20220407-0001', 'Reza Lesmana Putra', 'Pendaftaran PPDB Reza Lesmana Putra - NO Pendaftaran : REG-20220407-0001', 100000, 'D118380JHUHXVSE2XG2GY', 'A1', 'rzalvaero@gmail.com', '081280462650', 'Auto', 'Success', '', 'WEB', '2022-04-07', 'https://sandbox.duitku.com/topup/topupdirectv2.aspx?ref=A115ZUW64YPNHMWDI', 0);


#
# TABLE STRUCTURE FOR: sr_invoice_body
#

DROP TABLE IF EXISTS `sr_invoice_body`;

CREATE TABLE `sr_invoice_body` (
  `id_invoice` int(11) NOT NULL AUTO_INCREMENT,
  `nama_akun` varchar(200) DEFAULT NULL,
  `idusers` varchar(20) DEFAULT NULL,
  `tanggal` varchar(200) DEFAULT NULL,
  `bulan` varchar(200) DEFAULT NULL,
  `akun` varchar(200) DEFAULT NULL,
  `deskripsi` varchar(200) DEFAULT NULL,
  `id_akun` varchar(200) DEFAULT NULL,
  `no_ref` varchar(200) DEFAULT NULL,
  `credit` varchar(200) DEFAULT NULL,
  `status` varchar(200) DEFAULT NULL,
  `jenis` varchar(20) DEFAULT NULL,
  `balance` varchar(200) DEFAULT NULL,
  `pajak` varchar(200) DEFAULT NULL,
  `unit_pos` varchar(200) DEFAULT NULL,
  `nominal` varchar(200) DEFAULT NULL,
  `debet` varchar(200) DEFAULT NULL,
  `akun_kas` varchar(200) DEFAULT NULL,
  `nama_akun_kas` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_invoice`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (17, 'SMK-1-900-AKTIVA', '40', '2022-04-12', '2022-04', 'AKTIVA', 'GajiSMK-1-900-AKTIVA Ahwanto, A.Ma-', '622662', 'GK1204202219671206 198903 1 0032', '498000', 'keluar', 'Gaji', '-498000', '0', '', '498000', '0', '622655', NULL);
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (49, 'SMK-1-900-AKTIVA', NULL, '2022-04-13', '0', 'A', 'Kas KeluarSMK-1-900-AKTIVA-tess', '622662', 'sjkfs', '2000', 'keluar', 'keluar', '-500000', '0', '1', '2000', '0', '622655', 'Kas Tunai SMA');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (50, 'SMK-5-5000-Beban', NULL, '2022-04-13', '0', 'e', 'Kas KeluarSMK-5-5000-Beban-tess', '622660', 'sjkfs', '1000', 'keluar', 'keluar', '-1000', '0', '2', '1000', '0', '622655', 'Kas Tunai SMA');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (51, 'SMK-4-4000-Pendapatan', NULL, '2022-04-13', '0', 'P', 'Kas MasukSMK-4-4000-Pendapatan-sdf', '622658', '2342', '2000', 'masuk', 'masuk', '2000', '0', '1', '2000', '0', '622655', 'Kas Tunai SMA');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (52, 'SMK-4-4010-Pendapatan SPP', NULL, '2022-04-13', '0', 'e', 'Kas MasukSMK-4-4010-Pendapatan SPP-sdf', '0', '2342', '4000', 'masuk', 'masuk', '4000', '0', '2', '4000', '0', '622655', 'Kas Tunai SMA');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (54, '-1-1100-Kas Tunai SMA', NULL, '2022-04-13', '2022-04', 'Kas Tunai SMA', 'SPP--1-1100-Kas Tunai SMA-11111', '622655', 'SPP-2022-04-13-11111', '0', 'masuk', 'SPP', '10000', '0', '', NULL, '10000', '', 'Pendapatan SPP');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (55, 'SMK - test', NULL, '2022-04-14', '2022-04', 'Kas Tunai SMA', 'transfer dari akun Kas Tunai SMA ke akun Piutang', '622655', 'transfer2022-04-14622655-622656', '300000', 'transfer', 'transfer in', '-290000', '0', '', '300000', '0', '622656', 'Piutang');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (56, 'SMK - test', NULL, '2022-04-14', '2022-04', 'Kas Tunai SMA', 'transfer dari akun Kas Tunai SMA ke akun Piutang', '622656', 'transfer2022-04-14622655-622656', '0', 'transfer', 'transfer out', '300000', '0', '', '300000', '300000', '622656', 'Piutang');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (57, 'SMK - TEST', NULL, '2022-04-14', '2022-04', 'Piutang', 'transfer dari akun Piutang ke akun Piutang', '622656', 'transfer2022-04-14622656-622656', '20000', 'transfer', 'transfer in', '280000', '0', '', '20000', '0', '622656', 'Piutang');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (58, 'SMK - TEST', NULL, '2022-04-14', '2022-04', 'Piutang', 'transfer dari akun Piutang ke akun Piutang', '622656', 'transfer2022-04-14622656-622656', '0', 'transfer', 'transfer out', '320000', '0', '', '20000', '20000', '622656', 'Piutang');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (59, '-1-1100-Kas Tunai SMA', NULL, '2022-04-16', '2022-04', 'Kas Tunai SMA', 'SPP--1-1100-Kas Tunai SMA-11111', '622655', 'SPP-2022-04-16-11111', '0', 'masuk', 'SPP', '-280000', '0', '', '10000', '10000', '', 'Pendapatan SPP');
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (60, '-1-1100-Kas Tunai SMA', NULL, '2022-04-17', '2022-04', 'Kas Tunai SMA', 'SPP--1-1100-Kas Tunai SMA-11111', '622655', 'SPP-2022-04-17-11111', '0', 'masuk', 'SPP', '-270000', '0', '', '10000', '10000', '', NULL);
INSERT INTO `sr_invoice_body` (`id_invoice`, `nama_akun`, `idusers`, `tanggal`, `bulan`, `akun`, `deskripsi`, `id_akun`, `no_ref`, `credit`, `status`, `jenis`, `balance`, `pajak`, `unit_pos`, `nominal`, `debet`, `akun_kas`, `nama_akun_kas`) VALUES (61, '-1-1100-Kas Tunai SMA', NULL, '2022-04-17', '2022-04', 'Kas Tunai SMA', 'SPP--1-1100-Kas Tunai SMA-11111', '622655', 'SPP-2022-04-17-11111', '0', 'masuk', 'SPP', '-260000', '0', '', '10000', '10000', '622658', 'Pendapatan');


#
# TABLE STRUCTURE FOR: sr_jabatan
#

DROP TABLE IF EXISTS `sr_jabatan`;

CREATE TABLE `sr_jabatan` (
  `id_jabatan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_jabatan` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_jabatan`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (3, 'Guru');
INSERT INTO `sr_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (4, 'Operator');
INSERT INTO `sr_jabatan` (`id_jabatan`, `nama_jabatan`) VALUES (5, 'Staff Keuangan');


#
# TABLE STRUCTURE FOR: sr_jenis_bayar
#

DROP TABLE IF EXISTS `sr_jenis_bayar`;

CREATE TABLE `sr_jenis_bayar` (
  `id_jenis_bayar` int(11) NOT NULL AUTO_INCREMENT,
  `id_pos` varchar(20) DEFAULT NULL,
  `tingkat` varchar(20) DEFAULT NULL,
  `tipe` varchar(20) DEFAULT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_jenis_bayar`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_jenis_bayar` (`id_jenis_bayar`, `id_pos`, `tingkat`, `tipe`, `unit`) VALUES (2, '3', '2022', 'bulanan', '5');
INSERT INTO `sr_jenis_bayar` (`id_jenis_bayar`, `id_pos`, `tingkat`, `tipe`, `unit`) VALUES (6, '1', '2022', 'bebas', '5');


#
# TABLE STRUCTURE FOR: sr_jenis_pengaduan
#

DROP TABLE IF EXISTS `sr_jenis_pengaduan`;

CREATE TABLE `sr_jenis_pengaduan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_kamar
#

DROP TABLE IF EXISTS `sr_kamar`;

CREATE TABLE `sr_kamar` (
  `id_kamar` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `nama_kamar` varchar(100) NOT NULL,
  `kategori_kamar` varchar(10) NOT NULL,
  `kapasitas_kamar` varchar(10) NOT NULL,
  PRIMARY KEY (`id_kamar`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kamar` (`id_kamar`, `unit`, `nama_kamar`, `kategori_kamar`, `kapasitas_kamar`) VALUES (1, '5', 'MELATI - I', '1', '10');
INSERT INTO `sr_kamar` (`id_kamar`, `unit`, `nama_kamar`, `kategori_kamar`, `kapasitas_kamar`) VALUES (2, '5', 'ANGREK - I', '2', '5');


#
# TABLE STRUCTURE FOR: sr_kamar_kategori
#

DROP TABLE IF EXISTS `sr_kamar_kategori`;

CREATE TABLE `sr_kamar_kategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(100) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kamar_kategori` (`id_kategori`, `nama_kategori`) VALUES (1, 'Regular');
INSERT INTO `sr_kamar_kategori` (`id_kategori`, `nama_kategori`) VALUES (2, 'VIP');
INSERT INTO `sr_kamar_kategori` (`id_kategori`, `nama_kategori`) VALUES (3, 'VVIP\r\n');


#
# TABLE STRUCTURE FOR: sr_kamar_penghuni
#

DROP TABLE IF EXISTS `sr_kamar_penghuni`;

CREATE TABLE `sr_kamar_penghuni` (
  `id_penghuni` int(11) NOT NULL AUTO_INCREMENT,
  `id_kamar` varchar(10) NOT NULL,
  `id_siswa` varchar(10) NOT NULL,
  `unit` varchar(11) NOT NULL,
  `status` int(10) NOT NULL,
  PRIMARY KEY (`id_penghuni`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (1, '1', '11', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (2, '1', '12', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (3, '1', '13', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (4, '2', '14', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (5, '2', '15', '5', 0);
INSERT INTO `sr_kamar_penghuni` (`id_penghuni`, `id_kamar`, `id_siswa`, `unit`, `status`) VALUES (6, '2', '16', '5', 0);


#
# TABLE STRUCTURE FOR: sr_kelas
#

DROP TABLE IF EXISTS `sr_kelas`;

CREATE TABLE `sr_kelas` (
  `idkelas` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `walikelas` varchar(50) NOT NULL,
  `k_tingkat` int(11) NOT NULL,
  `k_romawi` varchar(20) NOT NULL,
  `k_keterangan` varchar(255) NOT NULL,
  PRIMARY KEY (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (1, '5', '1', 10, 'X - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (2, '5', '42', 10, 'X - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (3, '5', '37', 10, 'X - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (4, '5', '38', 10, 'X - MM', 'Multimedia');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (5, '5', '40', 11, 'XI - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (6, '5', '39', 11, 'XI - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (11, '5', '45', 11, 'XI - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (16, '5', '45', 11, 'XI - MM', 'Multimedia');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (17, '5', '44', 12, 'XII - AP', 'Administrasi Perkantoran');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (19, '5', '41', 12, 'XII - AB', 'Administrasi Bisnis');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (20, '5', '59', 12, 'XII - TKJ', 'Tekhnik Komputer Jaringan');
INSERT INTO `sr_kelas` (`idkelas`, `unit`, `walikelas`, `k_tingkat`, `k_romawi`, `k_keterangan`) VALUES (21, '5', '57', 12, 'XII - MM', 'Multimedia');


#
# TABLE STRUCTURE FOR: sr_kelas_guru
#

DROP TABLE IF EXISTS `sr_kelas_guru`;

CREATE TABLE `sr_kelas_guru` (
  `idkelas_guru` int(11) NOT NULL AUTO_INCREMENT,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  PRIMARY KEY (`idkelas_guru`),
  KEY `idusers` (`idusers`),
  KEY `idkelas` (`idkelas`),
  CONSTRAINT `sr_kelas_guru_ibfk_1` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`),
  CONSTRAINT `sr_kelas_guru_ibfk_2` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (17, 37, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (18, 38, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (22, 1, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (23, 39, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (24, 39, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (25, 39, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (26, 39, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (27, 39, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (28, 40, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (29, 41, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (30, 41, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (31, 41, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (32, 41, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (33, 41, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (34, 41, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (35, 40, 2);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (36, 40, 4);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (37, 40, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (38, 40, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (39, 40, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (40, 42, 1);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (41, 43, 3);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (42, 44, 5);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (43, 45, 6);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (50, 57, 17);
INSERT INTO `sr_kelas_guru` (`idkelas_guru`, `idusers`, `idkelas`) VALUES (52, 45, 1);


#
# TABLE STRUCTURE FOR: sr_keluar
#

DROP TABLE IF EXISTS `sr_keluar`;

CREATE TABLE `sr_keluar` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `akun` varchar(50) COLLATE utf8_swedish_ci DEFAULT NULL,
  `total` varchar(50) COLLATE utf8_swedish_ci DEFAULT NULL,
  `keterangan` varchar(50) COLLATE utf8_swedish_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

#
# TABLE STRUCTURE FOR: sr_kesehatan
#

DROP TABLE IF EXISTS `sr_kesehatan`;

CREATE TABLE `sr_kesehatan` (
  `idkesehatan` int(11) NOT NULL AUTO_INCREMENT,
  `ks_aspek` varchar(255) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`idkesehatan`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kesehatan` (`idkesehatan`, `ks_aspek`, `unit`) VALUES (2, 'Penglihatan', '5');
INSERT INTO `sr_kesehatan` (`idkesehatan`, `ks_aspek`, `unit`) VALUES (3, 'Pendengaran', NULL);
INSERT INTO `sr_kesehatan` (`idkesehatan`, `ks_aspek`, `unit`) VALUES (4, 'Penciuman', '3');


#
# TABLE STRUCTURE FOR: sr_kkm
#

DROP TABLE IF EXISTS `sr_kkm`;

CREATE TABLE `sr_kkm` (
  `idkkm` int(11) NOT NULL AUTO_INCREMENT,
  `idkelas` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `k_kkm` int(11) NOT NULL,
  `unit` int(11) DEFAULT NULL,
  PRIMARY KEY (`idkkm`),
  KEY `idkelas` (`idkelas`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_kkm_ibfk_1` FOREIGN KEY (`idmata_pelajaran`) REFERENCES `sr_mata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_kkm_ibfk_2` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kkm` (`idkkm`, `idkelas`, `idmata_pelajaran`, `k_kkm`, `unit`) VALUES (2, 1, 2, 40, 5);
INSERT INTO `sr_kkm` (`idkkm`, `idkelas`, `idmata_pelajaran`, `k_kkm`, `unit`) VALUES (3, 2, 3, 80, 5);


#
# TABLE STRUCTURE FOR: sr_kode_kelompok
#

DROP TABLE IF EXISTS `sr_kode_kelompok`;

CREATE TABLE `sr_kode_kelompok` (
  `id_kode_kelompok` int(11) NOT NULL,
  `unit` varchar(11) NOT NULL,
  `jenis` varchar(50) NOT NULL,
  `kode` varchar(2) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_kompetensi_dasar
#

DROP TABLE IF EXISTS `sr_kompetensi_dasar`;

CREATE TABLE `sr_kompetensi_dasar` (
  `id_kompetensidasar` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idusers` int(11) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `kd_kategori` enum('Pengetahuan','Keterampilan') NOT NULL,
  `kd` varchar(100) NOT NULL,
  `kd_nama` text NOT NULL,
  `kd_status` enum('Y','N') NOT NULL,
  `mata_pelajaran` varchar(100) NOT NULL,
  `bagan` varchar(200) NOT NULL,
  PRIMARY KEY (`id_kompetensidasar`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idusers` (`idusers`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  KEY `idkelas` (`idkelas`),
  CONSTRAINT `sr_kompetensi_dasar_ibfk_2` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`),
  CONSTRAINT `sr_kompetensi_dasar_ibfk_3` FOREIGN KEY (`idmata_pelajaran`) REFERENCES `sr_mata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_kompetensi_dasar_ibfk_4` FOREIGN KEY (`idtahun_pelajaran`) REFERENCES `sr_tahun_pelajaran` (`idtahun_pelajaran`),
  CONSTRAINT `sr_kompetensi_dasar_ibfk_5` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=93 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (29, '5', 1, 1, 1, 2, 'Pengetahuan', '1.1', 'Melafalkan huruf konsonan', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (30, '5', 1, 1, 1, 2, 'Pengetahuan', '1.2', 'Membaca cepat dan tepat', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (31, '5', 1, 42, 1, 2, 'Keterampilan', '1.1', 'Membaca puisi', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (32, '5', 1, 42, 1, 2, 'Keterampilan', '1.2', 'Berpidato tentang hari kemerdekaan', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (33, '5', 1, 42, 1, 49, 'Pengetahuan', '1.1', 'Mengetahui anatomi makhluk hidup', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (34, '5', 1, 42, 1, 49, 'Pengetahuan', '1.2', 'Mengetahui cara fotosintesis', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (35, '5', 1, 42, 1, 49, 'Keterampilan', '1.1', 'Mengamati pertumbuhan kecambah', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (38, '5', 1, 42, 1, 49, 'Keterampilan', '1.2', 'Mengamati struktur lapisan tumbuhan', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (39, '5', 1, 42, 1, 50, 'Pengetahuan', '1.1', 'Mengetahui sejarah kemerdekaan', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (40, '5', 1, 42, 1, 50, 'Pengetahuan', '1.2', 'Mengetahui penjajahan belanda', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (41, '5', 1, 42, 1, 50, 'Keterampilan', '1.1', 'Menghapal isi sumpah pemuda', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (42, '5', 1, 42, 1, 50, 'Keterampilan', '1.2', 'Membaca UUD 1945', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (43, '5', 1, 42, 1, 3, 'Pengetahuan', '1.1', 'Mengetahui algoritma', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (44, '5', 1, 42, 1, 3, 'Pengetahuan', '1.2', 'Mengetahui perhitungan logaritma', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (45, '5', 1, 42, 1, 3, 'Keterampilan', '1.1', 'Menghitung perkalian dan pertambahan', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (46, '5', 1, 42, 1, 3, 'Keterampilan', '1.2', 'Menghitung panjang jalan raya', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (47, '5', 1, 42, 1, 46, 'Pengetahuan', '1.1', 'Memahami isi UUD 1945', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (48, '5', 1, 42, 1, 46, 'Pengetahuan', '1.2', 'Memahami isi pancasila', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (49, '5', 1, 42, 1, 46, 'Keterampilan', '1.1', 'Membaca isi pancasila', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (50, '5', 1, 42, 1, 46, 'Keterampilan', '1.2', 'Membaca UUD 1945', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (51, '5', 1, 42, 1, 47, 'Pengetahuan', '1.1', 'Memahami cara melukis', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (52, '5', 1, 42, 1, 47, 'Pengetahuan', '1.2', 'Memahami tangga nada', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (53, '5', 1, 42, 1, 47, 'Keterampilan', '1.1', 'Memainkan lagu dengan gitar', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (54, '5', 1, 42, 1, 47, 'Keterampilan', '1.2', 'Melukis wajah pahlawan', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (55, '5', 1, 40, 1, 1, 'Pengetahuan', '1.1', 'Mengetahui sejarah Nabi Muhammad SAW', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (56, '5', 1, 40, 1, 1, 'Pengetahuan', '1.2', 'Memahami sejarah Islam ', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (57, '5', 1, 40, 1, 1, 'Keterampilan', '1.1', 'Membaca Al-Qur&#039;an', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (58, '5', 1, 40, 1, 1, 'Keterampilan', '1.2', 'Menulis surah dalam Al-Qur&#039;an', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (59, '5', 1, 39, 1, 48, 'Pengetahuan', '1.1', 'Memahami permainan bola kasti', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (60, '5', 1, 39, 1, 48, 'Keterampilan', '1.1', 'Memainkan bola kasti', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (61, '5', 1, 41, 1, 51, 'Pengetahuan', '1.1', 'Memahami grammer', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (62, '5', 1, 41, 1, 51, 'Keterampilan', '1.1', 'Melaksanakan TOEFL', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (63, '5', 1, 57, 17, 2, 'Pengetahuan', '1.1', '1.1 KD 1 ', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (64, '5', 1, 57, 17, 2, 'Keterampilan', '1.1', 'WKD', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (65, '5', 1, 57, 17, 51, 'Pengetahuan', '1.1', 'sad', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (66, '5', 1, 57, 17, 51, 'Keterampilan', '1.2', 'sadas', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (67, '5', 2, 42, 1, 2, 'Pengetahuan', '1.1', 'asdasd', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (68, '5', 2, 42, 1, 2, 'Keterampilan', '1.2', 'asasddsa', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (71, '5', 1, 37, 2, 2, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (72, '5', 1, 37, 2, 2, 'Keterampilan', '1.1', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (73, '5', 1, 37, 2, 49, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (74, '5', 1, 37, 2, 49, 'Keterampilan', '1.1', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (75, '5', 1, 37, 2, 50, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (76, '5', 1, 37, 2, 50, 'Keterampilan', '1.1', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (77, '5', 1, 37, 2, 3, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (78, '5', 1, 37, 2, 3, 'Keterampilan', '1.1', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (79, '5', 1, 37, 2, 46, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (80, '5', 1, 37, 2, 46, 'Keterampilan', '1.2', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (81, '5', 1, 37, 2, 47, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (82, '5', 1, 37, 2, 47, 'Keterampilan', '1.1', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (83, '5', 1, 40, 2, 1, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (84, '5', 1, 40, 2, 1, 'Keterampilan', '1.1', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (85, '5', 1, 41, 2, 51, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (86, '5', 1, 41, 2, 51, 'Keterampilan', '1.1', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (87, '5', 1, 39, 2, 48, 'Pengetahuan', '1.1', 'kd 1 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (88, '5', 1, 39, 2, 48, 'Keterampilan', '1.1', 'kd 2 kelas 2', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (89, '5', 2, 42, 1, 49, 'Pengetahuan', '1.1', 'kd 1 kelas 1', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (90, '5', 2, 42, 1, 49, 'Keterampilan', '1.1', 'kd 2 kelas 1', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (91, '5', 1, 44, 5, 2, 'Pengetahuan', '1.1', 'tessttt', 'Y', '', '');
INSERT INTO `sr_kompetensi_dasar` (`id_kompetensidasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `kd_kategori`, `kd`, `kd_nama`, `kd_status`, `mata_pelajaran`, `bagan`) VALUES (92, '5', 1, 44, 5, 2, 'Pengetahuan', '1.2', 'kemampuan berpikir', 'Y', '', '');


#
# TABLE STRUCTURE FOR: sr_kompetensi_dasar_lama
#

DROP TABLE IF EXISTS `sr_kompetensi_dasar_lama`;

CREATE TABLE `sr_kompetensi_dasar_lama` (
  `id_kompetensidasar` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `kd` varchar(100) NOT NULL,
  `mata_pelajaran` varchar(100) NOT NULL,
  `bagan` varchar(225) NOT NULL,
  PRIMARY KEY (`id_kompetensidasar`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kompetensi_dasar_lama` (`id_kompetensidasar`, `unit`, `kd`, `mata_pelajaran`, `bagan`) VALUES (1, '5', 'K 3 - Kompetensi inti pengetahuan', 'Seni Budaya dan Prakarya', '<ol><li>Memahami Kompetensi Dasar</li><li>Memahami Konsep Seni</li><li>Memahami Konsep Keindahan</li><li>Menganalisis jenis, fungsi dan unsur seni budaya Nusantara</li><li>Menganalisis perkembangan seni budaya Nusantara</li><');


#
# TABLE STRUCTURE FOR: sr_kompetensi_inti
#

DROP TABLE IF EXISTS `sr_kompetensi_inti`;

CREATE TABLE `sr_kompetensi_inti` (
  `idkompetensiinti` int(11) NOT NULL AUTO_INCREMENT,
  `kode_kd` varchar(100) NOT NULL,
  `nama_kd` text NOT NULL,
  `kategori_kd` enum('Pengetahuan','Keterampilan') NOT NULL,
  PRIMARY KEY (`idkompetensiinti`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_kompetensi_inti` (`idkompetensiinti`, `kode_kd`, `nama_kd`, `kategori_kd`) VALUES (1, 'K 1', 'Kompetensi inti sikap spiritual', 'Pengetahuan');
INSERT INTO `sr_kompetensi_inti` (`idkompetensiinti`, `kode_kd`, `nama_kd`, `kategori_kd`) VALUES (2, 'K 2', 'Kompetensi inti sikap sosial ', 'Pengetahuan');
INSERT INTO `sr_kompetensi_inti` (`idkompetensiinti`, `kode_kd`, `nama_kd`, `kategori_kd`) VALUES (3, 'K 3', 'Kompetensi inti pengetahuan', 'Pengetahuan');
INSERT INTO `sr_kompetensi_inti` (`idkompetensiinti`, `kode_kd`, `nama_kd`, `kategori_kd`) VALUES (4, 'K 4', 'Kompetensi inti keterampilan ', 'Keterampilan');


#
# TABLE STRUCTURE FOR: sr_kota
#

DROP TABLE IF EXISTS `sr_kota`;

CREATE TABLE `sr_kota` (
  `city_id` int(11) NOT NULL,
  `province_id` varchar(11) NOT NULL,
  `province` varchar(100) NOT NULL,
  `type` varchar(100) NOT NULL,
  `city_name` varchar(100) NOT NULL,
  `postal_code` int(11) NOT NULL,
  PRIMARY KEY (`city_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (1, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Barat', 23681);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (2, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Barat Daya', 23764);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (3, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Besar', 23951);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (4, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Jaya', 23654);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (5, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Selatan', 23719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (6, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Singkil', 24785);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (7, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tamiang', 24476);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (8, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tengah', 24511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (9, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Tenggara', 24611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (10, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Timur', 24454);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (11, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Aceh Utara', 24382);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (12, '32', 'Sumatera Barat', 'Kabupaten', 'Agam', 26411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (13, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Alor', 85811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (14, '19', 'Maluku', 'Kota', 'Ambon', 97222);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (15, '34', 'Sumatera Utara', 'Kabupaten', 'Asahan', 21214);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (16, '24', 'Papua', 'Kabupaten', 'Asmat', 99777);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (17, '1', 'Bali', 'Kabupaten', 'Badung', 80351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (18, '13', 'Kalimantan Selatan', 'Kabupaten', 'Balangan', 71611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (19, '15', 'Kalimantan Timur', 'Kota', 'Balikpapan', 76111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (20, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Banda Aceh', 23238);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (21, '18', 'Lampung', 'Kota', 'Bandar Lampung', 35139);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (22, '9', 'Jawa Barat', 'Kabupaten', 'Bandung', 40311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (23, '9', 'Jawa Barat', 'Kota', 'Bandung', 40111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (24, '9', 'Jawa Barat', 'Kabupaten', 'Bandung Barat', 40721);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (25, '29', 'Sulawesi Tengah', 'Kabupaten', 'Banggai', 94711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (26, '29', 'Sulawesi Tengah', 'Kabupaten', 'Banggai Kepulauan', 94881);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (27, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka', 33212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (28, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Barat', 33315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (29, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Selatan', 33719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (30, '2', 'Bangka Belitung', 'Kabupaten', 'Bangka Tengah', 33613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (31, '11', 'Jawa Timur', 'Kabupaten', 'Bangkalan', 69118);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (32, '1', 'Bali', 'Kabupaten', 'Bangli', 80619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (33, '13', 'Kalimantan Selatan', 'Kabupaten', 'Banjar', 70619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (34, '9', 'Jawa Barat', 'Kota', 'Banjar', 46311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (35, '13', 'Kalimantan Selatan', 'Kota', 'Banjarbaru', 70712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (36, '13', 'Kalimantan Selatan', 'Kota', 'Banjarmasin', 70117);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (37, '10', 'Jawa Tengah', 'Kabupaten', 'Banjarnegara', 53419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (38, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bantaeng', 92411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (39, '5', 'DI Yogyakarta', 'Kabupaten', 'Bantul', 55715);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (40, '33', 'Sumatera Selatan', 'Kabupaten', 'Banyuasin', 30911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (41, '10', 'Jawa Tengah', 'Kabupaten', 'Banyumas', 53114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (42, '11', 'Jawa Timur', 'Kabupaten', 'Banyuwangi', 68416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (43, '13', 'Kalimantan Selatan', 'Kabupaten', 'Barito Kuala', 70511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (44, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Selatan', 73711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (45, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Timur', 73671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (46, '14', 'Kalimantan Tengah', 'Kabupaten', 'Barito Utara', 73881);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (47, '28', 'Sulawesi Selatan', 'Kabupaten', 'Barru', 90719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (48, '17', 'Kepulauan Riau', 'Kota', 'Batam', 29413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (49, '10', 'Jawa Tengah', 'Kabupaten', 'Batang', 51211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (50, '8', 'Jambi', 'Kabupaten', 'Batang Hari', 36613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (51, '11', 'Jawa Timur', 'Kota', 'Batu', 65311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (52, '34', 'Sumatera Utara', 'Kabupaten', 'Batu Bara', 21655);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (53, '30', 'Sulawesi Tenggara', 'Kota', 'Bau-Bau', 93719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (54, '9', 'Jawa Barat', 'Kabupaten', 'Bekasi', 17837);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (55, '9', 'Jawa Barat', 'Kota', 'Bekasi', 17121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (56, '2', 'Bangka Belitung', 'Kabupaten', 'Belitung', 33419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (57, '2', 'Bangka Belitung', 'Kabupaten', 'Belitung Timur', 33519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (58, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Belu', 85711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (59, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Bener Meriah', 24581);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (60, '26', 'Riau', 'Kabupaten', 'Bengkalis', 28719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (61, '12', 'Kalimantan Barat', 'Kabupaten', 'Bengkayang', 79213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (62, '4', 'Bengkulu', 'Kota', 'Bengkulu', 38229);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (63, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Selatan', 38519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (64, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Tengah', 38319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (65, '4', 'Bengkulu', 'Kabupaten', 'Bengkulu Utara', 38619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (66, '15', 'Kalimantan Timur', 'Kabupaten', 'Berau', 77311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (67, '24', 'Papua', 'Kabupaten', 'Biak Numfor', 98119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (68, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Bima', 84171);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (69, '22', 'Nusa Tenggara Barat (NTB)', 'Kota', 'Bima', 84139);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (70, '34', 'Sumatera Utara', 'Kota', 'Binjai', 20712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (71, '17', 'Kepulauan Riau', 'Kabupaten', 'Bintan', 29135);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (72, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Bireuen', 24219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (73, '31', 'Sulawesi Utara', 'Kota', 'Bitung', 95512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (74, '11', 'Jawa Timur', 'Kabupaten', 'Blitar', 66171);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (75, '11', 'Jawa Timur', 'Kota', 'Blitar', 66124);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (76, '10', 'Jawa Tengah', 'Kabupaten', 'Blora', 58219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (77, '7', 'Gorontalo', 'Kabupaten', 'Boalemo', 96319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (78, '9', 'Jawa Barat', 'Kabupaten', 'Bogor', 16911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (79, '9', 'Jawa Barat', 'Kota', 'Bogor', 16119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (80, '11', 'Jawa Timur', 'Kabupaten', 'Bojonegoro', 62119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (81, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow (Bolmong)', 95755);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (82, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Selatan', 95774);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (83, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Timur', 95783);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (84, '31', 'Sulawesi Utara', 'Kabupaten', 'Bolaang Mongondow Utara', 95765);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (85, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Bombana', 93771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (86, '11', 'Jawa Timur', 'Kabupaten', 'Bondowoso', 68219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (87, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bone', 92713);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (88, '7', 'Gorontalo', 'Kabupaten', 'Bone Bolango', 96511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (89, '15', 'Kalimantan Timur', 'Kota', 'Bontang', 75313);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (90, '24', 'Papua', 'Kabupaten', 'Boven Digoel', 99662);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (91, '10', 'Jawa Tengah', 'Kabupaten', 'Boyolali', 57312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (92, '10', 'Jawa Tengah', 'Kabupaten', 'Brebes', 52212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (93, '32', 'Sumatera Barat', 'Kota', 'Bukittinggi', 26115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (94, '1', 'Bali', 'Kabupaten', 'Buleleng', 81111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (95, '28', 'Sulawesi Selatan', 'Kabupaten', 'Bulukumba', 92511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (96, '16', 'Kalimantan Utara', 'Kabupaten', 'Bulungan (Bulongan)', 77211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (97, '8', 'Jambi', 'Kabupaten', 'Bungo', 37216);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (98, '29', 'Sulawesi Tengah', 'Kabupaten', 'Buol', 94564);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (99, '19', 'Maluku', 'Kabupaten', 'Buru', 97371);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (100, '19', 'Maluku', 'Kabupaten', 'Buru Selatan', 97351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (101, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Buton', 93754);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (102, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Buton Utara', 93745);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (103, '9', 'Jawa Barat', 'Kabupaten', 'Ciamis', 46211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (104, '9', 'Jawa Barat', 'Kabupaten', 'Cianjur', 43217);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (105, '10', 'Jawa Tengah', 'Kabupaten', 'Cilacap', 53211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (106, '3', 'Banten', 'Kota', 'Cilegon', 42417);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (107, '9', 'Jawa Barat', 'Kota', 'Cimahi', 40512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (108, '9', 'Jawa Barat', 'Kabupaten', 'Cirebon', 45611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (109, '9', 'Jawa Barat', 'Kota', 'Cirebon', 45116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (110, '34', 'Sumatera Utara', 'Kabupaten', 'Dairi', 22211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (111, '24', 'Papua', 'Kabupaten', 'Deiyai (Deliyai)', 98784);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (112, '34', 'Sumatera Utara', 'Kabupaten', 'Deli Serdang', 20511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (113, '10', 'Jawa Tengah', 'Kabupaten', 'Demak', 59519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (114, '1', 'Bali', 'Kota', 'Denpasar', 80227);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (115, '9', 'Jawa Barat', 'Kota', 'Depok', 16416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (116, '32', 'Sumatera Barat', 'Kabupaten', 'Dharmasraya', 27612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (117, '24', 'Papua', 'Kabupaten', 'Dogiyai', 98866);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (118, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Dompu', 84217);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (119, '29', 'Sulawesi Tengah', 'Kabupaten', 'Donggala', 94341);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (120, '26', 'Riau', 'Kota', 'Dumai', 28811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (121, '33', 'Sumatera Selatan', 'Kabupaten', 'Empat Lawang', 31811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (122, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Ende', 86351);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (123, '28', 'Sulawesi Selatan', 'Kabupaten', 'Enrekang', 91719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (124, '25', 'Papua Barat', 'Kabupaten', 'Fakfak', 98651);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (125, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Flores Timur', 86213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (126, '9', 'Jawa Barat', 'Kabupaten', 'Garut', 44126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (127, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Gayo Lues', 24653);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (128, '1', 'Bali', 'Kabupaten', 'Gianyar', 80519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (129, '7', 'Gorontalo', 'Kabupaten', 'Gorontalo', 96218);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (130, '7', 'Gorontalo', 'Kota', 'Gorontalo', 96115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (131, '7', 'Gorontalo', 'Kabupaten', 'Gorontalo Utara', 96611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (132, '28', 'Sulawesi Selatan', 'Kabupaten', 'Gowa', 92111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (133, '11', 'Jawa Timur', 'Kabupaten', 'Gresik', 61115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (134, '10', 'Jawa Tengah', 'Kabupaten', 'Grobogan', 58111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (135, '5', 'DI Yogyakarta', 'Kabupaten', 'Gunung Kidul', 55812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (136, '14', 'Kalimantan Tengah', 'Kabupaten', 'Gunung Mas', 74511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (137, '34', 'Sumatera Utara', 'Kota', 'Gunungsitoli', 22813);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (138, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Barat', 97757);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (139, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Selatan', 97911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (140, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Tengah', 97853);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (141, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Timur', 97862);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (142, '20', 'Maluku Utara', 'Kabupaten', 'Halmahera Utara', 97762);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (143, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Selatan', 71212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (144, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Tengah', 71313);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (145, '13', 'Kalimantan Selatan', 'Kabupaten', 'Hulu Sungai Utara', 71419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (146, '34', 'Sumatera Utara', 'Kabupaten', 'Humbang Hasundutan', 22457);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (147, '26', 'Riau', 'Kabupaten', 'Indragiri Hilir', 29212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (148, '26', 'Riau', 'Kabupaten', 'Indragiri Hulu', 29319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (149, '9', 'Jawa Barat', 'Kabupaten', 'Indramayu', 45214);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (150, '24', 'Papua', 'Kabupaten', 'Intan Jaya', 98771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (151, '6', 'DKI Jakarta', 'Kota', 'Jakarta Barat', 11220);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (152, '6', 'DKI Jakarta', 'Kota', 'Jakarta Pusat', 10540);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (153, '6', 'DKI Jakarta', 'Kota', 'Jakarta Selatan', 12230);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (154, '6', 'DKI Jakarta', 'Kota', 'Jakarta Timur', 13330);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (155, '6', 'DKI Jakarta', 'Kota', 'Jakarta Utara', 14140);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (156, '8', 'Jambi', 'Kota', 'Jambi', 36111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (157, '24', 'Papua', 'Kabupaten', 'Jayapura', 99352);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (158, '24', 'Papua', 'Kota', 'Jayapura', 99114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (159, '24', 'Papua', 'Kabupaten', 'Jayawijaya', 99511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (160, '11', 'Jawa Timur', 'Kabupaten', 'Jember', 68113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (161, '1', 'Bali', 'Kabupaten', 'Jembrana', 82251);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (162, '28', 'Sulawesi Selatan', 'Kabupaten', 'Jeneponto', 92319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (163, '10', 'Jawa Tengah', 'Kabupaten', 'Jepara', 59419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (164, '11', 'Jawa Timur', 'Kabupaten', 'Jombang', 61415);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (165, '25', 'Papua Barat', 'Kabupaten', 'Kaimana', 98671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (166, '26', 'Riau', 'Kabupaten', 'Kampar', 28411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (167, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kapuas', 73583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (168, '12', 'Kalimantan Barat', 'Kabupaten', 'Kapuas Hulu', 78719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (169, '10', 'Jawa Tengah', 'Kabupaten', 'Karanganyar', 57718);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (170, '1', 'Bali', 'Kabupaten', 'Karangasem', 80819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (171, '9', 'Jawa Barat', 'Kabupaten', 'Karawang', 41311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (172, '17', 'Kepulauan Riau', 'Kabupaten', 'Karimun', 29611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (173, '34', 'Sumatera Utara', 'Kabupaten', 'Karo', 22119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (174, '14', 'Kalimantan Tengah', 'Kabupaten', 'Katingan', 74411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (175, '4', 'Bengkulu', 'Kabupaten', 'Kaur', 38911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (176, '12', 'Kalimantan Barat', 'Kabupaten', 'Kayong Utara', 78852);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (177, '10', 'Jawa Tengah', 'Kabupaten', 'Kebumen', 54319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (178, '11', 'Jawa Timur', 'Kabupaten', 'Kediri', 64184);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (179, '11', 'Jawa Timur', 'Kota', 'Kediri', 64125);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (180, '24', 'Papua', 'Kabupaten', 'Keerom', 99461);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (181, '10', 'Jawa Tengah', 'Kabupaten', 'Kendal', 51314);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (182, '30', 'Sulawesi Tenggara', 'Kota', 'Kendari', 93126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (183, '4', 'Bengkulu', 'Kabupaten', 'Kepahiang', 39319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (184, '17', 'Kepulauan Riau', 'Kabupaten', 'Kepulauan Anambas', 29991);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (185, '19', 'Maluku', 'Kabupaten', 'Kepulauan Aru', 97681);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (186, '32', 'Sumatera Barat', 'Kabupaten', 'Kepulauan Mentawai', 25771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (187, '26', 'Riau', 'Kabupaten', 'Kepulauan Meranti', 28791);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (188, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Sangihe', 95819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (189, '6', 'DKI Jakarta', 'Kabupaten', 'Kepulauan Seribu', 14550);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (190, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Siau Tagulandang Biaro (Sitaro)', 95862);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (191, '20', 'Maluku Utara', 'Kabupaten', 'Kepulauan Sula', 97995);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (192, '31', 'Sulawesi Utara', 'Kabupaten', 'Kepulauan Talaud', 95885);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (193, '24', 'Papua', 'Kabupaten', 'Kepulauan Yapen (Yapen Waropen)', 98211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (194, '8', 'Jambi', 'Kabupaten', 'Kerinci', 37167);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (195, '12', 'Kalimantan Barat', 'Kabupaten', 'Ketapang', 78874);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (196, '10', 'Jawa Tengah', 'Kabupaten', 'Klaten', 57411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (197, '1', 'Bali', 'Kabupaten', 'Klungkung', 80719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (198, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Kolaka', 93511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (199, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Kolaka Utara', 93911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (200, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe', 93411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (201, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe Selatan', 93811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (202, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Konawe Utara', 93311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (203, '13', 'Kalimantan Selatan', 'Kabupaten', 'Kotabaru', 72119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (204, '31', 'Sulawesi Utara', 'Kota', 'Kotamobagu', 95711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (205, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kotawaringin Barat', 74119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (206, '14', 'Kalimantan Tengah', 'Kabupaten', 'Kotawaringin Timur', 74364);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (207, '26', 'Riau', 'Kabupaten', 'Kuantan Singingi', 29519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (208, '12', 'Kalimantan Barat', 'Kabupaten', 'Kubu Raya', 78311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (209, '10', 'Jawa Tengah', 'Kabupaten', 'Kudus', 59311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (210, '5', 'DI Yogyakarta', 'Kabupaten', 'Kulon Progo', 55611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (211, '9', 'Jawa Barat', 'Kabupaten', 'Kuningan', 45511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (212, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Kupang', 85362);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (213, '23', 'Nusa Tenggara Timur (NTT)', 'Kota', 'Kupang', 85119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (214, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Barat', 75711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (215, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Kartanegara', 75511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (216, '15', 'Kalimantan Timur', 'Kabupaten', 'Kutai Timur', 75611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (217, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu', 21412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (218, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu Selatan', 21511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (219, '34', 'Sumatera Utara', 'Kabupaten', 'Labuhan Batu Utara', 21711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (220, '33', 'Sumatera Selatan', 'Kabupaten', 'Lahat', 31419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (221, '14', 'Kalimantan Tengah', 'Kabupaten', 'Lamandau', 74611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (222, '11', 'Jawa Timur', 'Kabupaten', 'Lamongan', 64125);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (223, '18', 'Lampung', 'Kabupaten', 'Lampung Barat', 34814);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (224, '18', 'Lampung', 'Kabupaten', 'Lampung Selatan', 35511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (225, '18', 'Lampung', 'Kabupaten', 'Lampung Tengah', 34212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (226, '18', 'Lampung', 'Kabupaten', 'Lampung Timur', 34319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (227, '18', 'Lampung', 'Kabupaten', 'Lampung Utara', 34516);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (228, '12', 'Kalimantan Barat', 'Kabupaten', 'Landak', 78319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (229, '34', 'Sumatera Utara', 'Kabupaten', 'Langkat', 20811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (230, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Langsa', 24412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (231, '24', 'Papua', 'Kabupaten', 'Lanny Jaya', 99531);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (232, '3', 'Banten', 'Kabupaten', 'Lebak', 42319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (233, '4', 'Bengkulu', 'Kabupaten', 'Lebong', 39264);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (234, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Lembata', 86611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (235, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Lhokseumawe', 24352);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (236, '32', 'Sumatera Barat', 'Kabupaten', 'Lima Puluh Koto/Kota', 26671);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (237, '17', 'Kepulauan Riau', 'Kabupaten', 'Lingga', 29811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (238, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Barat', 83311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (239, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Tengah', 83511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (240, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Timur', 83612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (241, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Lombok Utara', 83711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (242, '33', 'Sumatera Selatan', 'Kota', 'Lubuk Linggau', 31614);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (243, '11', 'Jawa Timur', 'Kabupaten', 'Lumajang', 67319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (244, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu', 91994);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (245, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu Timur', 92981);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (246, '28', 'Sulawesi Selatan', 'Kabupaten', 'Luwu Utara', 92911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (247, '11', 'Jawa Timur', 'Kabupaten', 'Madiun', 63153);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (248, '11', 'Jawa Timur', 'Kota', 'Madiun', 63122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (249, '10', 'Jawa Tengah', 'Kabupaten', 'Magelang', 56519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (250, '10', 'Jawa Tengah', 'Kota', 'Magelang', 56133);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (251, '11', 'Jawa Timur', 'Kabupaten', 'Magetan', 63314);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (252, '9', 'Jawa Barat', 'Kabupaten', 'Majalengka', 45412);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (253, '27', 'Sulawesi Barat', 'Kabupaten', 'Majene', 91411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (254, '28', 'Sulawesi Selatan', 'Kota', 'Makassar', 90111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (255, '11', 'Jawa Timur', 'Kabupaten', 'Malang', 65163);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (256, '11', 'Jawa Timur', 'Kota', 'Malang', 65112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (257, '16', 'Kalimantan Utara', 'Kabupaten', 'Malinau', 77511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (258, '19', 'Maluku', 'Kabupaten', 'Maluku Barat Daya', 97451);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (259, '19', 'Maluku', 'Kabupaten', 'Maluku Tengah', 97513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (260, '19', 'Maluku', 'Kabupaten', 'Maluku Tenggara', 97651);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (261, '19', 'Maluku', 'Kabupaten', 'Maluku Tenggara Barat', 97465);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (262, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamasa', 91362);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (263, '24', 'Papua', 'Kabupaten', 'Mamberamo Raya', 99381);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (264, '24', 'Papua', 'Kabupaten', 'Mamberamo Tengah', 99553);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (265, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamuju', 91519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (266, '27', 'Sulawesi Barat', 'Kabupaten', 'Mamuju Utara', 91571);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (267, '31', 'Sulawesi Utara', 'Kota', 'Manado', 95247);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (268, '34', 'Sumatera Utara', 'Kabupaten', 'Mandailing Natal', 22916);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (269, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai', 86551);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (270, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai Barat', 86711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (271, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Manggarai Timur', 86811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (272, '25', 'Papua Barat', 'Kabupaten', 'Manokwari', 98311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (273, '25', 'Papua Barat', 'Kabupaten', 'Manokwari Selatan', 98355);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (274, '24', 'Papua', 'Kabupaten', 'Mappi', 99853);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (275, '28', 'Sulawesi Selatan', 'Kabupaten', 'Maros', 90511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (276, '22', 'Nusa Tenggara Barat (NTB)', 'Kota', 'Mataram', 83131);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (277, '25', 'Papua Barat', 'Kabupaten', 'Maybrat', 98051);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (278, '34', 'Sumatera Utara', 'Kota', 'Medan', 20228);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (279, '12', 'Kalimantan Barat', 'Kabupaten', 'Melawi', 78619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (280, '8', 'Jambi', 'Kabupaten', 'Merangin', 37319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (281, '24', 'Papua', 'Kabupaten', 'Merauke', 99613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (282, '18', 'Lampung', 'Kabupaten', 'Mesuji', 34911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (283, '18', 'Lampung', 'Kota', 'Metro', 34111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (284, '24', 'Papua', 'Kabupaten', 'Mimika', 99962);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (285, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa', 95614);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (286, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Selatan', 95914);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (287, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Tenggara', 95995);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (288, '31', 'Sulawesi Utara', 'Kabupaten', 'Minahasa Utara', 95316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (289, '11', 'Jawa Timur', 'Kabupaten', 'Mojokerto', 61382);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (290, '11', 'Jawa Timur', 'Kota', 'Mojokerto', 61316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (291, '29', 'Sulawesi Tengah', 'Kabupaten', 'Morowali', 94911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (292, '33', 'Sumatera Selatan', 'Kabupaten', 'Muara Enim', 31315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (293, '8', 'Jambi', 'Kabupaten', 'Muaro Jambi', 36311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (294, '4', 'Bengkulu', 'Kabupaten', 'Muko Muko', 38715);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (295, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Muna', 93611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (296, '14', 'Kalimantan Tengah', 'Kabupaten', 'Murung Raya', 73911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (297, '33', 'Sumatera Selatan', 'Kabupaten', 'Musi Banyuasin', 30719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (298, '33', 'Sumatera Selatan', 'Kabupaten', 'Musi Rawas', 31661);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (299, '24', 'Papua', 'Kabupaten', 'Nabire', 98816);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (300, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Nagan Raya', 23674);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (301, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Nagekeo', 86911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (302, '17', 'Kepulauan Riau', 'Kabupaten', 'Natuna', 29711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (303, '24', 'Papua', 'Kabupaten', 'Nduga', 99541);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (304, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Ngada', 86413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (305, '11', 'Jawa Timur', 'Kabupaten', 'Nganjuk', 64414);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (306, '11', 'Jawa Timur', 'Kabupaten', 'Ngawi', 63219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (307, '34', 'Sumatera Utara', 'Kabupaten', 'Nias', 22876);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (308, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Barat', 22895);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (309, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Selatan', 22865);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (310, '34', 'Sumatera Utara', 'Kabupaten', 'Nias Utara', 22856);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (311, '16', 'Kalimantan Utara', 'Kabupaten', 'Nunukan', 77421);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (312, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Ilir', 30811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (313, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ilir', 30618);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (314, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu', 32112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (315, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu Selatan', 32211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (316, '33', 'Sumatera Selatan', 'Kabupaten', 'Ogan Komering Ulu Timur', 32312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (317, '11', 'Jawa Timur', 'Kabupaten', 'Pacitan', 63512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (318, '32', 'Sumatera Barat', 'Kota', 'Padang', 25112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (319, '34', 'Sumatera Utara', 'Kabupaten', 'Padang Lawas', 22763);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (320, '34', 'Sumatera Utara', 'Kabupaten', 'Padang Lawas Utara', 22753);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (321, '32', 'Sumatera Barat', 'Kota', 'Padang Panjang', 27122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (322, '32', 'Sumatera Barat', 'Kabupaten', 'Padang Pariaman', 25583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (323, '34', 'Sumatera Utara', 'Kota', 'Padang Sidempuan', 22727);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (324, '33', 'Sumatera Selatan', 'Kota', 'Pagar Alam', 31512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (325, '34', 'Sumatera Utara', 'Kabupaten', 'Pakpak Bharat', 22272);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (326, '14', 'Kalimantan Tengah', 'Kota', 'Palangka Raya', 73112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (327, '33', 'Sumatera Selatan', 'Kota', 'Palembang', 31512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (328, '28', 'Sulawesi Selatan', 'Kota', 'Palopo', 91911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (329, '29', 'Sulawesi Tengah', 'Kota', 'Palu', 94111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (330, '11', 'Jawa Timur', 'Kabupaten', 'Pamekasan', 69319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (331, '3', 'Banten', 'Kabupaten', 'Pandeglang', 42212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (332, '9', 'Jawa Barat', 'Kabupaten', 'Pangandaran', 46511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (333, '28', 'Sulawesi Selatan', 'Kabupaten', 'Pangkajene Kepulauan', 90611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (334, '2', 'Bangka Belitung', 'Kota', 'Pangkal Pinang', 33115);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (335, '24', 'Papua', 'Kabupaten', 'Paniai', 98765);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (336, '28', 'Sulawesi Selatan', 'Kota', 'Parepare', 91123);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (337, '32', 'Sumatera Barat', 'Kota', 'Pariaman', 25511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (338, '29', 'Sulawesi Tengah', 'Kabupaten', 'Parigi Moutong', 94411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (339, '32', 'Sumatera Barat', 'Kabupaten', 'Pasaman', 26318);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (340, '32', 'Sumatera Barat', 'Kabupaten', 'Pasaman Barat', 26511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (341, '15', 'Kalimantan Timur', 'Kabupaten', 'Paser', 76211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (342, '11', 'Jawa Timur', 'Kabupaten', 'Pasuruan', 67153);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (343, '11', 'Jawa Timur', 'Kota', 'Pasuruan', 67118);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (344, '10', 'Jawa Tengah', 'Kabupaten', 'Pati', 59114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (345, '32', 'Sumatera Barat', 'Kota', 'Payakumbuh', 26213);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (346, '25', 'Papua Barat', 'Kabupaten', 'Pegunungan Arfak', 98354);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (347, '24', 'Papua', 'Kabupaten', 'Pegunungan Bintang', 99573);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (348, '10', 'Jawa Tengah', 'Kabupaten', 'Pekalongan', 51161);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (349, '10', 'Jawa Tengah', 'Kota', 'Pekalongan', 51122);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (350, '26', 'Riau', 'Kota', 'Pekanbaru', 28112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (351, '26', 'Riau', 'Kabupaten', 'Pelalawan', 28311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (352, '10', 'Jawa Tengah', 'Kabupaten', 'Pemalang', 52319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (353, '34', 'Sumatera Utara', 'Kota', 'Pematang Siantar', 21126);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (354, '15', 'Kalimantan Timur', 'Kabupaten', 'Penajam Paser Utara', 76311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (355, '18', 'Lampung', 'Kabupaten', 'Pesawaran', 35312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (356, '18', 'Lampung', 'Kabupaten', 'Pesisir Barat', 35974);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (357, '32', 'Sumatera Barat', 'Kabupaten', 'Pesisir Selatan', 25611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (358, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Pidie', 24116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (359, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Pidie Jaya', 24186);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (360, '28', 'Sulawesi Selatan', 'Kabupaten', 'Pinrang', 91251);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (361, '7', 'Gorontalo', 'Kabupaten', 'Pohuwato', 96419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (362, '27', 'Sulawesi Barat', 'Kabupaten', 'Polewali Mandar', 91311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (363, '11', 'Jawa Timur', 'Kabupaten', 'Ponorogo', 63411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (364, '12', 'Kalimantan Barat', 'Kabupaten', 'Pontianak', 78971);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (365, '12', 'Kalimantan Barat', 'Kota', 'Pontianak', 78112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (366, '29', 'Sulawesi Tengah', 'Kabupaten', 'Poso', 94615);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (367, '33', 'Sumatera Selatan', 'Kota', 'Prabumulih', 31121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (368, '18', 'Lampung', 'Kabupaten', 'Pringsewu', 35719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (369, '11', 'Jawa Timur', 'Kabupaten', 'Probolinggo', 67282);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (370, '11', 'Jawa Timur', 'Kota', 'Probolinggo', 67215);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (371, '14', 'Kalimantan Tengah', 'Kabupaten', 'Pulang Pisau', 74811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (372, '20', 'Maluku Utara', 'Kabupaten', 'Pulau Morotai', 97771);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (373, '24', 'Papua', 'Kabupaten', 'Puncak', 98981);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (374, '24', 'Papua', 'Kabupaten', 'Puncak Jaya', 98979);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (375, '10', 'Jawa Tengah', 'Kabupaten', 'Purbalingga', 53312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (376, '9', 'Jawa Barat', 'Kabupaten', 'Purwakarta', 41119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (377, '10', 'Jawa Tengah', 'Kabupaten', 'Purworejo', 54111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (378, '25', 'Papua Barat', 'Kabupaten', 'Raja Ampat', 98489);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (379, '4', 'Bengkulu', 'Kabupaten', 'Rejang Lebong', 39112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (380, '10', 'Jawa Tengah', 'Kabupaten', 'Rembang', 59219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (381, '26', 'Riau', 'Kabupaten', 'Rokan Hilir', 28992);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (382, '26', 'Riau', 'Kabupaten', 'Rokan Hulu', 28511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (383, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Rote Ndao', 85982);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (384, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Sabang', 23512);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (385, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sabu Raijua', 85391);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (386, '10', 'Jawa Tengah', 'Kota', 'Salatiga', 50711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (387, '15', 'Kalimantan Timur', 'Kota', 'Samarinda', 75133);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (388, '12', 'Kalimantan Barat', 'Kabupaten', 'Sambas', 79453);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (389, '34', 'Sumatera Utara', 'Kabupaten', 'Samosir', 22392);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (390, '11', 'Jawa Timur', 'Kabupaten', 'Sampang', 69219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (391, '12', 'Kalimantan Barat', 'Kabupaten', 'Sanggau', 78557);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (392, '24', 'Papua', 'Kabupaten', 'Sarmi', 99373);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (393, '8', 'Jambi', 'Kabupaten', 'Sarolangun', 37419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (394, '32', 'Sumatera Barat', 'Kota', 'Sawah Lunto', 27416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (395, '12', 'Kalimantan Barat', 'Kabupaten', 'Sekadau', 79583);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (396, '28', 'Sulawesi Selatan', 'Kabupaten', 'Selayar (Kepulauan Selayar)', 92812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (397, '4', 'Bengkulu', 'Kabupaten', 'Seluma', 38811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (398, '10', 'Jawa Tengah', 'Kabupaten', 'Semarang', 50511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (399, '10', 'Jawa Tengah', 'Kota', 'Semarang', 50135);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (400, '19', 'Maluku', 'Kabupaten', 'Seram Bagian Barat', 97561);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (401, '19', 'Maluku', 'Kabupaten', 'Seram Bagian Timur', 97581);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (402, '3', 'Banten', 'Kabupaten', 'Serang', 42182);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (403, '3', 'Banten', 'Kota', 'Serang', 42111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (404, '34', 'Sumatera Utara', 'Kabupaten', 'Serdang Bedagai', 20915);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (405, '14', 'Kalimantan Tengah', 'Kabupaten', 'Seruyan', 74211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (406, '26', 'Riau', 'Kabupaten', 'Siak', 28623);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (407, '34', 'Sumatera Utara', 'Kota', 'Sibolga', 22522);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (408, '28', 'Sulawesi Selatan', 'Kabupaten', 'Sidenreng Rappang/Rapang', 91613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (409, '11', 'Jawa Timur', 'Kabupaten', 'Sidoarjo', 61219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (410, '29', 'Sulawesi Tengah', 'Kabupaten', 'Sigi', 94364);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (411, '32', 'Sumatera Barat', 'Kabupaten', 'Sijunjung (Sawah Lunto Sijunjung)', 27511);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (412, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sikka', 86121);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (413, '34', 'Sumatera Utara', 'Kabupaten', 'Simalungun', 21162);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (414, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kabupaten', 'Simeulue', 23891);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (415, '12', 'Kalimantan Barat', 'Kota', 'Singkawang', 79117);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (416, '28', 'Sulawesi Selatan', 'Kabupaten', 'Sinjai', 92615);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (417, '12', 'Kalimantan Barat', 'Kabupaten', 'Sintang', 78619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (418, '11', 'Jawa Timur', 'Kabupaten', 'Situbondo', 68316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (419, '5', 'DI Yogyakarta', 'Kabupaten', 'Sleman', 55513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (420, '32', 'Sumatera Barat', 'Kabupaten', 'Solok', 27365);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (421, '32', 'Sumatera Barat', 'Kota', 'Solok', 27315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (422, '32', 'Sumatera Barat', 'Kabupaten', 'Solok Selatan', 27779);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (423, '28', 'Sulawesi Selatan', 'Kabupaten', 'Soppeng', 90812);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (424, '25', 'Papua Barat', 'Kabupaten', 'Sorong', 98431);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (425, '25', 'Papua Barat', 'Kota', 'Sorong', 98411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (426, '25', 'Papua Barat', 'Kabupaten', 'Sorong Selatan', 98454);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (427, '10', 'Jawa Tengah', 'Kabupaten', 'Sragen', 57211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (428, '9', 'Jawa Barat', 'Kabupaten', 'Subang', 41215);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (429, '21', 'Nanggroe Aceh Darussalam (NAD)', 'Kota', 'Subulussalam', 24882);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (430, '9', 'Jawa Barat', 'Kabupaten', 'Sukabumi', 43311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (431, '9', 'Jawa Barat', 'Kota', 'Sukabumi', 43114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (432, '14', 'Kalimantan Tengah', 'Kabupaten', 'Sukamara', 74712);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (433, '10', 'Jawa Tengah', 'Kabupaten', 'Sukoharjo', 57514);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (434, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Barat', 87219);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (435, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Barat Daya', 87453);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (436, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Tengah', 87358);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (437, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Sumba Timur', 87112);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (438, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Sumbawa', 84315);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (439, '22', 'Nusa Tenggara Barat (NTB)', 'Kabupaten', 'Sumbawa Barat', 84419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (440, '9', 'Jawa Barat', 'Kabupaten', 'Sumedang', 45326);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (441, '11', 'Jawa Timur', 'Kabupaten', 'Sumenep', 69413);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (442, '8', 'Jambi', 'Kota', 'Sungaipenuh', 37113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (443, '24', 'Papua', 'Kabupaten', 'Supiori', 98164);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (444, '11', 'Jawa Timur', 'Kota', 'Surabaya', 60119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (445, '10', 'Jawa Tengah', 'Kota', 'Surakarta (Solo)', 57113);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (446, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tabalong', 71513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (447, '1', 'Bali', 'Kabupaten', 'Tabanan', 82119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (448, '28', 'Sulawesi Selatan', 'Kabupaten', 'Takalar', 92212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (449, '25', 'Papua Barat', 'Kabupaten', 'Tambrauw', 98475);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (450, '16', 'Kalimantan Utara', 'Kabupaten', 'Tana Tidung', 77611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (451, '28', 'Sulawesi Selatan', 'Kabupaten', 'Tana Toraja', 91819);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (452, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tanah Bumbu', 72211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (453, '32', 'Sumatera Barat', 'Kabupaten', 'Tanah Datar', 27211);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (454, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tanah Laut', 70811);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (455, '3', 'Banten', 'Kabupaten', 'Tangerang', 15914);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (456, '3', 'Banten', 'Kota', 'Tangerang', 15111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (457, '3', 'Banten', 'Kota', 'Tangerang Selatan', 15332);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (458, '18', 'Lampung', 'Kabupaten', 'Tanggamus', 35619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (459, '34', 'Sumatera Utara', 'Kota', 'Tanjung Balai', 21321);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (460, '8', 'Jambi', 'Kabupaten', 'Tanjung Jabung Barat', 36513);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (461, '8', 'Jambi', 'Kabupaten', 'Tanjung Jabung Timur', 36719);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (462, '17', 'Kepulauan Riau', 'Kota', 'Tanjung Pinang', 29111);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (463, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Selatan', 22742);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (464, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Tengah', 22611);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (465, '34', 'Sumatera Utara', 'Kabupaten', 'Tapanuli Utara', 22414);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (466, '13', 'Kalimantan Selatan', 'Kabupaten', 'Tapin', 71119);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (467, '16', 'Kalimantan Utara', 'Kota', 'Tarakan', 77114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (468, '9', 'Jawa Barat', 'Kabupaten', 'Tasikmalaya', 46411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (469, '9', 'Jawa Barat', 'Kota', 'Tasikmalaya', 46116);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (470, '34', 'Sumatera Utara', 'Kota', 'Tebing Tinggi', 20632);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (471, '8', 'Jambi', 'Kabupaten', 'Tebo', 37519);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (472, '10', 'Jawa Tengah', 'Kabupaten', 'Tegal', 52419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (473, '10', 'Jawa Tengah', 'Kota', 'Tegal', 52114);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (474, '25', 'Papua Barat', 'Kabupaten', 'Teluk Bintuni', 98551);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (475, '25', 'Papua Barat', 'Kabupaten', 'Teluk Wondama', 98591);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (476, '10', 'Jawa Tengah', 'Kabupaten', 'Temanggung', 56212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (477, '20', 'Maluku Utara', 'Kota', 'Ternate', 97714);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (478, '20', 'Maluku Utara', 'Kota', 'Tidore Kepulauan', 97815);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (479, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Timor Tengah Selatan', 85562);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (480, '23', 'Nusa Tenggara Timur (NTT)', 'Kabupaten', 'Timor Tengah Utara', 85612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (481, '34', 'Sumatera Utara', 'Kabupaten', 'Toba Samosir', 22316);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (482, '29', 'Sulawesi Tengah', 'Kabupaten', 'Tojo Una-Una', 94683);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (483, '29', 'Sulawesi Tengah', 'Kabupaten', 'Toli-Toli', 94542);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (484, '24', 'Papua', 'Kabupaten', 'Tolikara', 99411);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (485, '31', 'Sulawesi Utara', 'Kota', 'Tomohon', 95416);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (486, '28', 'Sulawesi Selatan', 'Kabupaten', 'Toraja Utara', 91831);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (487, '11', 'Jawa Timur', 'Kabupaten', 'Trenggalek', 66312);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (488, '19', 'Maluku', 'Kota', 'Tual', 97612);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (489, '11', 'Jawa Timur', 'Kabupaten', 'Tuban', 62319);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (490, '18', 'Lampung', 'Kabupaten', 'Tulang Bawang', 34613);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (491, '18', 'Lampung', 'Kabupaten', 'Tulang Bawang Barat', 34419);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (492, '11', 'Jawa Timur', 'Kabupaten', 'Tulungagung', 66212);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (493, '28', 'Sulawesi Selatan', 'Kabupaten', 'Wajo', 90911);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (494, '30', 'Sulawesi Tenggara', 'Kabupaten', 'Wakatobi', 93791);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (495, '24', 'Papua', 'Kabupaten', 'Waropen', 98269);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (496, '18', 'Lampung', 'Kabupaten', 'Way Kanan', 34711);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (497, '10', 'Jawa Tengah', 'Kabupaten', 'Wonogiri', 57619);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (498, '10', 'Jawa Tengah', 'Kabupaten', 'Wonosobo', 56311);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (499, '24', 'Papua', 'Kabupaten', 'Yahukimo', 99041);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (500, '24', 'Papua', 'Kabupaten', 'Yalimo', 99481);
INSERT INTO `sr_kota` (`city_id`, `province_id`, `province`, `type`, `city_name`, `postal_code`) VALUES (501, '5', 'DI Yogyakarta', 'Kota', 'Yogyakarta', 55222);


#
# TABLE STRUCTURE FOR: sr_mapel_kd
#

DROP TABLE IF EXISTS `sr_mapel_kd`;

CREATE TABLE `sr_mapel_kd` (
  `id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `id_guru` int(6) unsigned NOT NULL DEFAULT 0,
  `id_mapel` int(6) NOT NULL,
  `tingkat` int(2) NOT NULL,
  `semester` enum('0','1','2') NOT NULL,
  `no_kd` varchar(5) NOT NULL,
  `jenis` enum('P','K','SSp','SSo') NOT NULL,
  `bobot` int(2) NOT NULL,
  `nama_kd` varchar(100) NOT NULL,
  UNIQUE KEY `id` (`id`),
  KEY `id_mapel` (`id_mapel`),
  KEY `id_guru` (`id_guru`)
) ENGINE=InnoDB AUTO_INCREMENT=1169 DEFAULT CHARSET=latin1;

INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1, 0, 0, 0, '0', '', 'SSo', 0, 'jujur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (2, 0, 0, 0, '0', '', 'SSo', 0, 'disiplin');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (3, 0, 0, 0, '0', '', 'SSo', 0, 'tanggung jawab');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (4, 0, 0, 0, '0', '', 'SSo', 0, 'toleransi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (5, 0, 0, 0, '0', '', 'SSo', 0, 'gotong royong');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (6, 0, 0, 0, '0', '', 'SSo', 0, 'santun');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (7, 0, 0, 0, '0', '', 'SSo', 0, 'percaya diri');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (8, 0, 0, 0, '0', '', 'SSp', 0, 'berdoa sebelum dan sesudah melakukan kegiatan		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (9, 0, 0, 0, '0', '', 'SSp', 0, 'menjalankan ibadah sesuai dengan agamanya		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (10, 0, 0, 0, '0', '', 'SSp', 0, 'memberi salam pada saat awal dan akhir kegiatan		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (11, 0, 0, 0, '0', '', 'SSp', 0, 'bersyukur atas nikmat dan karunia Tuhan Yang Maha Esa		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (12, 0, 0, 0, '0', '', 'SSp', 0, 'mensyukuri kemampuan manusia dalam mengendalikan diri		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (13, 0, 0, 0, '0', '', 'SSp', 0, 'bersyukur ketika berhasil mengerjakan sesuatu		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (14, 0, 0, 0, '0', '', 'SSp', 0, 'berserah diri (tawakal) kepada Tuhan setelah berikhtiar atau melakukan usaha		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (15, 0, 0, 0, '0', '', 'SSp', 0, 'memelihara hubungan baik dengan sesama umat		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (16, 0, 0, 0, '0', '', 'SSp', 0, 'bersyukur sebagai bangsa Indonesia		');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (17, 0, 0, 0, '0', '', 'SSp', 0, 'menghormati orang lain yang menjalankan ibadah sesuai dengan agamanya		\r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (18, 16, 2, 7, '1', 'K01', 'P', 0, 'Memahami dalil, dasar dan tujuan akidah Islam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (19, 16, 2, 7, '1', 'K01', 'K', 0, 'Menyajikan fakta dan fenomena kebenaran akidah Islam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (20, 16, 2, 7, '1', 'K02', 'P', 0, 'Mengidentifikasi sifat-sifat wajib Allah yang nafsiyah, salbiyah, ma\"ani dan ma\"nawiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (21, 16, 2, 7, '1', 'K02', 'K', 0, 'Menyajikan contoh fenomena kehidupan yang muncul sebagai bukti dari sifat wajib, mustahil, jaiz');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (22, 16, 2, 7, '1', 'K03', 'P', 0, 'Memahami pengertian contoh dan dampak positif sifat ikhlas, taat, khauf dan taubat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (25, 16, 9, 7, '1', 'K01', 'K', 0, 'Ketrampilan 1');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (26, 16, 9, 7, '1', 'K02', 'K', 0, 'Kompetensi Ketrampilan 2');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (28, 16, 2, 7, '1', 'K04', 'P', 0, 'Memahami adab shalat dan dzikir');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (29, 10, 9, 8, '1', 'K01', 'P', 0, 'memahami sistem gerak pada manusia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (30, 10, 9, 8, '1', 'K01', 'K', 0, 'membuat tulisan berbagai gangguanpada sistem gerak manusia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (33, 11, 8, 9, '1', 'Kd1', 'P', 0, 'Memahami sifat dan operasi aljabar  pada bilangan berpangkat dan bentuk akar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (34, 11, 8, 9, '1', 'Kd2', 'P', 0, 'memahami perbandingan bertingkat dan persentase serta mendiskripsikan permasalahan menggunakan tabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (38, 15, 10, 7, '1', 'kd 01', 'P', 0, 'Memahami konsep ruang dan interaksi antar ruang di Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (40, 5, 5, 7, '1', 'k01', 'P', 0, 'memahami sejarah komitmen');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (41, 15, 10, 7, '1', 'KD02', 'P', 0, 'mengidentifikasi interaksi sosial dalam ruang dan pengaruhnya terhadap kehidupan sosial');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (42, 15, 10, 7, '1', 'KD01', 'K', 0, 'menjelaskan konsep ruang dan interaksi antara ruang di Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (43, 15, 10, 7, '1', 'KD02', 'K', 0, 'menyajikan hasil indentifikasi tentang interaksin sosial dalam ruang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (44, 15, 10, 7, '1', 'K03', 'P', 0, 'memahami konsep interaksi antara  manusia dengan ruang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (45, 20, 14, 7, '1', 'KD311', 'P', 0, 'jenis, sifat, karakter, dan teknik pengolahan serat dan tekstil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (46, 20, 14, 7, '1', 'KD312', 'P', 0, 'prinsip perancangan, pembuatan, dan penyajian produk kerajinan dari bahan serat dan tekstil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (47, 10, 9, 8, '1', 'K02', 'P', 0, 'memahami  gerak lurus dan pengaruh gaya terhadap gerak berdasarkan hukum Newton');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (48, 10, 9, 8, '1', 'K03', 'P', 0, 'menerapkan konsep usaha dan pesawat sederhana');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (49, 10, 9, 8, '1', 'K04', 'P', 0, 'menganalisis keterkaitan struktur jaringan tumbuhan danpemanfatannya dalam teknologi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (50, 10, 9, 8, '1', 'K05', 'P', 0, 'menganalisis sistem pencernaan pada manusia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (52, 20, 14, 7, '1', 'KD321', 'P', 0, 'perkembangan teknologi, keselamatan kerja, sketsa, dan gambar teknik ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (53, 20, 14, 7, '1', 'KD322', 'P', 0, 'karakteristik, kekuatan bahan, serta peralatan kerja pengolahnya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (54, 20, 14, 7, '1', 'KD331', 'P', 0, 'tanaman sayuran yang dapat dikembangkan  sesuai kebutuhan wilayah setempat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (55, 20, 14, 7, '1', 'KD332', 'P', 0, 'Memahami tahapan budidaya tanaman sayuran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (56, 20, 14, 7, '1', 'KD341', 'P', 0, 'pembuatan, penyajian dan pengemasan bahan pangan buah menjadi makanan dan  minuman segar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (57, 20, 14, 7, '1', 'KD342', 'P', 0, 'pembuatan, penyajian dan pengemasan bahan hasil samping dari pengolahan makanan dan minuman buah seg');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (58, 20, 14, 8, '1', 'KD3.1', 'P', 0, 'memahami pengetahuan tentang jenis, sifat, karakter dan teknik pengolahan bahan lunak  ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (59, 20, 14, 8, '1', 'KD3.1', 'P', 0, 'memahami pengetahuan tentang prinsip perancangan, pembuatan, dan penyajian produk kerajinan \r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (60, 20, 14, 8, '1', 'KD3.2', 'P', 0, 'memahamiperkembangan, peralatan, dan media pengantar teknologi informasi dan komunikasi\r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (61, 20, 14, 8, '1', 'KD3.2', 'P', 0, 'memahami penerapan jenis, karakteristik, dan istilah-istilah teknologi informasi dan komunikasi\r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (62, 20, 14, 8, '1', 'KD3.3', 'P', 0, 'memahami komoditas ternak kesayangan yang dapat dikembangkan sesuai kebutuhan wilayah setempat\r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (63, 20, 14, 8, '1', 'KD3.3', 'P', 0, ' memahamikebutuhan dan karakteristik sarana dan peralatan budidaya ternak kesayangan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (65, 20, 14, 8, '1', 'KD3.3', 'P', 0, 'memahami tahapan budidaya ternak kesayangan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (66, 20, 14, 8, '1', 'KD3.4', 'P', 0, 'menganalisis rancangan pembuatan bahan pangan serealia, kacang-kacangan dan umbi menjadi makanan dan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (67, 20, 14, 7, '1', 'KD411', 'K', 0, 'pengolahan serat/tekstil ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (68, 20, 14, 7, '1', 'KD412', 'K', 0, 'menyajikan produk kerajinan dari bahan serat/tekstil yang kreatif dan inovatif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (69, 20, 14, 7, '1', 'KD421', 'K', 0, 'sketsa dan gambar teknik dari suatu rancangan produk');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (70, 20, 14, 7, '1', 'KD422', 'K', 0, 'produk sederhana menggunakan peralatan kerja sesuai dengan jenis, karakteristik, dan kekuatan bahan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (71, 20, 14, 7, '1', 'KD431', 'K', 0, 'komoditas tanaman sayuran yang akan dibudidayakan  sesuai kebutuhan wilayah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (72, 20, 14, 7, '1', 'KD432', 'K', 0, 'tahapan budidaya tanaman sayuran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (73, 20, 14, 7, '1', 'KD441', 'K', 0, 'Buah segar menjadi makanan dan minuman  sesuai pengetahuan rancangan dan bahan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (74, 20, 14, 7, '1', 'KD442', 'K', 0, 'menyaji, dan mengemas bahan hasil samping dari pengolahan makanan dan minuman buah segar  menjadi pr');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (75, 20, 14, 8, '1', 'KD4.1', 'K', 0, 'memilih jenis bahan dan teknik pengolahan bahan lunak yang sesuai dengan potensi daerah setempat ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (76, 20, 14, 8, '1', 'KD4.1', 'K', 0, 'perancangan, pembuatan dan penyajian produk kerajinan dari bahan lunak yang kreatif dan inovatif, se');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (77, 20, 14, 8, '1', 'KD4.2', 'K', 0, 'memanipulasi sistem teknologi informasi dan komunikasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (78, 20, 14, 8, '1', 'KD4.2', 'K', 0, 'membuat produk teknologi informasi dan komunikasi dengan menggunakan bahan-bahan yang tersedia di se');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (79, 20, 14, 8, '1', 'KD4.3', 'K', 0, 'menentukan komoditas ternak kesayangan  yang dapat dikembangkan sesuai kebutuhan wilayah setempat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (80, 20, 14, 8, '1', 'KD4.3', 'K', 0, 'mempersiapkan sarana dan peralatan budidaya ternak kesayangan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (82, 20, 14, 8, '1', 'KD4.3', 'K', 0, 'mempraktikkan tahapan budidaya ternak kesayangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (84, 19, 9, 7, '1', 'K01', 'P', 0, 'Menerapkan konsep pengukuran berbagai besaran menggunakan satuan setandar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (85, 19, 9, 7, '1', 'K02', 'P', 0, 'Mengklasifikasikan makhluk hidup dan benda berdasarkan karakteristik yang diamati');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (86, 19, 9, 7, '1', 'K03', 'P', 0, 'Menjelaskan konsep campuran dan zat tunggal (unsur dan senyawa),sifat fisika dan kimia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (88, 19, 9, 7, '1', 'K04', 'P', 0, 'Menganalisis konsep suhu, pemuian,kalor,perpindahan kalor,dan penerapan dalam kehidupan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (89, 19, 9, 7, '1', 'K05', 'P', 0, 'Menganalisis konsep energi,berbagai sumber energi,dan perubahan bentuk energi dalam kehidupan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (91, 19, 9, 7, '1', 'K01', 'K', 0, 'Menyajikan data hasil pengukuran dengan alat ukur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (92, 19, 9, 7, '1', 'K02', 'K', 0, 'Menyajikan hasil pengklasifikasian makhluk hidup');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (93, 19, 9, 7, '1', 'K03', 'K', 0, 'Menyajikan hasil penyelidikan atau karya tentang sifat larutan, perubahan fisika dan kimia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (95, 19, 9, 7, '1', 'K04', 'K', 0, 'Melakukan percobaan untuk menyelidiki pengaruh kalor,suhu, dan wujud benda');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (96, 19, 9, 7, '1', 'K05', 'K', 0, 'Menyajikan hasil percobaan tentang perubahan bentuk energi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (98, 10, 9, 8, '1', 'K06', 'P', 0, 'Menjelaskan berbagai zat aditif dalam makanan dan minuman, zat adiktif, serta dampaknya terhadap kes');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (99, 10, 9, 8, '1', 'K02', 'K', 0, 'menyajikan hasil penyelidikan pengaruh gaya terhadap gerak benda');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (100, 10, 9, 8, '1', 'K03', 'K', 0, 'mnyajikan hasil penyelidikan tentang manfaat penggunaan pesawat sederhana');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (101, 10, 9, 8, '1', 'K04', 'K', 0, 'mengkomunikasikan teknologi yang terinspirasi oleh hasil pengamatan struktur tumbuhan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (102, 10, 9, 8, '1', 'K05', 'K', 0, 'menyajikan hasil penyelidikan tentang pencernaan mekanis dan kimiawi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (103, 10, 9, 8, '1', 'K06', 'K', 0, 'membuat karya tulis tentang dampak penyalahgunaan zat aditif dan zat adiktif bagi kesehatan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (107, 1, 15, 9, '1', '2.1', 'P', 0, 'Praktek membaca cerita pendek');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (108, 1, 15, 9, '1', '2.2', 'P', 0, 'mendiskusikan praktek membaca cerita pendek');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (109, 1, 15, 9, '1', '2.3', 'P', 0, 'Melagukan tembang Sinom');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (110, 1, 15, 9, '1', '2.4', 'P', 0, 'Melagukan Tembang Dhandhanggula');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (111, 1, 15, 9, '1', '3.1', 'P', 0, 'Menanggapi cerita pendek kegiatan di sekolah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (112, 1, 15, 9, '1', '3.2 ', 'P', 0, 'Menanggapi naskah cerita pendek kegiatan lingkungan tempat tinggal');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (113, 1, 15, 9, '1', '4.1', 'P', 0, 'Menulis cerita pendek kegiata  sekolah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (114, 1, 15, 9, '1', '4.2', 'P', 0, 'Menulis cerita gambar kegiatan sekolah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (115, 1, 15, 9, '1', '4.3', 'P', 0, 'menulis cerita pendek kegiatan lingkungan tempat tinggal');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (117, 13, 13, 7, '1', 'KD01', 'P', 0, 'Memahami konsep permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (118, 13, 13, 7, '1', 'KD02', 'P', 0, 'Memahami konsep permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (119, 13, 13, 7, '1', 'KD03', 'P', 0, 'Memahami konsep nomor atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (120, 13, 13, 7, '1', 'KD05', 'P', 0, 'Memahami konsep senam lantai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (121, 13, 13, 7, '1', 'KD06', 'P', 0, 'Memahami konsep aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (122, 13, 13, 7, '1', 'KD07', 'P', 0, 'Memahami konsep kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (125, 13, 13, 7, '1', 'KD01', 'K', 0, 'Mempraktikkan permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (126, 13, 13, 7, '1', 'KD02', 'K', 0, 'Mempraktikkan permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (127, 13, 13, 7, '1', 'KD03', 'K', 0, 'Mempraktikkan nomor atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (128, 13, 13, 7, '1', 'KD05', 'K', 0, 'Mempraktikkan senam lantai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (129, 13, 13, 7, '1', 'KD06', 'K', 0, 'Mempraktikkan aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (130, 13, 13, 7, '1', 'KD07', 'K', 0, 'Mempraktikkan latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (133, 5, 5, 7, '1', 'k02', 'P', 0, 'memahami semangat pendiri negara dalam perumusan pancasila');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (134, 5, 5, 7, '1', 'k03', 'P', 0, 'sejarah pengesahan uud negara RI');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (135, 5, 5, 7, '1', 'k04', 'P', 0, 'memahami keragaman suku agama ras budaya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (136, 15, 10, 7, '1', 'K04', 'P', 0, 'memahami kronologi perubahan dan kesinambungan dalam kihidupan bangsa Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (138, 13, 13, 8, '1', 'KD01', 'P', 0, 'Memahami konsep permainan bola besar.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (139, 13, 13, 8, '1', 'KD02', 'P', 0, 'Memahami konsep permainan bola kecil.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (140, 13, 13, 8, '1', 'KD03', 'P', 0, 'Memahami konsep nomor atletik ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (141, 13, 13, 8, '1', 'KD05', 'P', 0, 'Memahami konsep senam lantai ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (142, 13, 13, 8, '1', 'KD06', 'P', 0, 'Memahami konsep aktivitas ritmik ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (143, 13, 13, 8, '1', 'KD07', 'P', 0, 'Memahami konsep kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (146, 13, 13, 8, '1', 'KD01', 'K', 0, 'Mempraktikkan permainan bola besar.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (147, 13, 13, 8, '1', 'KD02', 'K', 0, 'Mempraktikkan permainan bola kecil ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (148, 13, 13, 8, '1', 'KD03', 'K', 0, 'Mempraktikkan keterampilan atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (149, 13, 13, 8, '1', 'KD05', 'K', 0, 'Mempraktikkan senam lantai ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (150, 13, 13, 8, '1', 'KD06', 'K', 0, 'Mempraktikkan aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (151, 13, 13, 8, '1', 'KD07', 'K', 0, 'Mempraktikkan latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (154, 15, 10, 7, '1', 'K03', 'K', 0, 'menjelaskan hasil analisis tentang konsep intruksi antara manusia dengan ruang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (155, 15, 10, 7, '1', 'K04', 'K', 0, 'menguraikan kronologi perubahan dan kesinambungan dalam kehidupan bangsa Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (156, 5, 5, 7, '1', '4.1', 'K', 0, 'menyaji hasil telaah sejarah semangat pendiri negara dalam merumuskan dasar negara');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (157, 5, 5, 7, '1', 'k.2', 'K', 0, 'menyaji hasil telaah tentang pengesahan uud 1945');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (158, 5, 5, 7, '1', 'k.3', 'K', 0, 'menyajikan isi pembukaan uud ri');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (159, 5, 5, 7, '1', 'k.4', 'K', 0, 'menyaji hasil pengamatan tentang norma norma yang berlaku dalam masyarakat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (160, 9, 8, 7, '1', '3.1  ', 'P', 0, 'Menjelaskan,menguraikan dan mengoprasikan Bilangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (161, 9, 8, 7, '1', '3.2', 'P', 0, 'Menjelaskan dan mengoprasikan Himpunan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (162, 9, 8, 7, '1', '3.3', 'P', 0, 'Mampu menyelesaikan operasi bentuk aljabar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (163, 9, 8, 7, '1', '3.4', 'P', 0, 'Menjelaskan Persamaan dan pertidak samaan linear satu variabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (164, 16, 2, 7, '1', 'K05', 'P', 0, 'Menganalisis kisah keteladanan Nabi Sulaiman dan umatnya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (165, 16, 2, 8, '1', 'K01', 'P', 0, 'memahami hakikat beriman kepada kitab-kitab Allah SWT');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (166, 16, 2, 8, '1', 'K02', 'P', 0, 'Memahami pengertian ,contoh dan dampak positif sifat tawakal, ikhtiar, sabar,syukur dan qona\"ah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (167, 16, 2, 8, '1', 'K03', 'P', 0, 'Memahami pengertian contoh dan dampak negatif sifta ananiah, putus asa, gadab dan tamak');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (168, 16, 2, 8, '1', 'K04', 'P', 0, 'Memahami Adab kepada orang tua dan guru');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (169, 16, 2, 8, '1', 'K05', 'P', 0, 'Menganilisis kisah keteladanan Nabi Yunus dan Nabi Ayub');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (170, 16, 2, 7, '1', 'K03', 'K', 0, 'Menceritakan kisah dari perilaku ikhlas, taat, khauf dan taubat dalam fenomena kehidupan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (171, 16, 2, 7, '1', 'K04', 'K', 0, 'Menyimulasikan adab shalat dan dzikir');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (172, 16, 2, 7, '1', 'K05', 'K', 0, 'Menceritakan kisah keteladanan Nabi Sulaiamn dan umatnya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (173, 16, 2, 8, '1', 'K01', 'K', 0, 'Menyajikan data dari berbagai sumber tentang kebenaran kitab-kitab Allah SWT');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (174, 16, 2, 8, '1', 'K02', 'K', 0, 'Menunjukkan contoh perilaku tawakal, ikhtiar, sabar, syukur dan qana\"ah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (175, 16, 2, 8, '1', 'K03', 'K', 0, 'Mensimulasikan akibat buruk dari ananiah, putus asa, gadab, tamak dalam kehidupan sehari-hari');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (176, 16, 2, 8, '1', 'K04', 'K', 0, 'Mensimulasikan adab kepada orang tua dan guru');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (177, 16, 2, 8, '1', 'K05', 'K', 0, 'Menceritakan kisah keteladanan Nabi Yunus dan Nabi Ayub');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (178, 16, 4, 7, '1', 'K01', 'P', 0, 'Memahami pola dakwah nabi Muhammad saw di Makkah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (179, 16, 4, 7, '1', 'K02', 'P', 0, 'Menganalisis pola dakwah Nabi Muhammad Saw di Makkah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (180, 16, 4, 7, '1', 'K03', 'P', 0, 'Memahami sejarah Nabi Muhhamd Saw dalam membangun masyarakat melalui kegiatan ekonomi dan perdaganga');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (181, 16, 4, 7, '1', 'K01', 'K', 0, 'Memahami pola dakwah nabi Muhammad saw di Makkah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (182, 16, 4, 7, '1', 'K02', 'K', 0, 'Menganalisis pola dakwah Nabi Muhammad Saw di Makkah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (183, 16, 4, 7, '1', 'K03', 'K', 0, 'Memahami sejarah Nabi Muhammad dalam membangung masyarakat melalui perekonomian');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (184, 16, 4, 7, '1', 'K04', 'K', 0, 'Memahami misi nabi Muhammad saw sebagai rahmat bagi alam semesta');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (185, 16, 4, 7, '1', 'K05', 'K', 0, 'Memahami pola dakwah Nabi Muhammad Saw di Madinah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (186, 16, 4, 8, '1', 'K01', 'P', 0, 'Memahami sejarah berdirinya Dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (187, 16, 4, 8, '1', 'K02', 'P', 0, 'Mengidentifikasi tokoh ilmuwan muslim pada masa dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (188, 16, 4, 8, '1', 'K03', 'P', 0, 'Mengidentifikasi para \"ulama penyusun Kutubus Sittah pada masa dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (189, 16, 4, 8, '1', 'K04', 'P', 0, 'Mengidentifikasi perkembangan kebudayaan/peradaban Islam pada masa Dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (190, 16, 4, 8, '1', 'K05', 'P', 0, 'Menyimpulkan kemajuankebudayaan/peradaban Islam yang diraih pada masa Dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (191, 16, 4, 8, '1', 'K01', 'K', 0, 'Menceritakan silsilah kekhalifahan Dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (192, 16, 4, 8, '1', 'K02', 'K', 0, 'Menceritakan biografi dan karya para ilmuwan muslim pada masa dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (193, 16, 4, 8, '1', 'K03', 'K', 0, 'Memaparkan peran ilmuwan muslim pada masa dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (194, 16, 4, 8, '1', 'K04', 'K', 0, 'Menceritakan perkembangan Islam pada masa Dinasti Abbasiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (195, 9, 8, 7, '1', '4.1', 'K', 0, 'Menyelesaikan masalah yang berkaitan tentang bilangan bulat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (196, 9, 8, 7, '1', '4.2', 'K', 0, 'Menyelesaikan masalah yang berkaitan dg masalah himpunan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (197, 9, 8, 7, '1', '4.3', 'K', 0, 'Menyelesaikan masalah pada bentuk dan operasi aljabar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (198, 9, 8, 7, '1', '4.4', 'K', 0, 'Menyelesaikan masalah yang berkaitan Persamaan dan pertadaksamaan linear satu variabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (199, 15, 5, 8, '1', 'kd1', 'P', 0, 'memahami nilai-nilai Pancasila sebagai dasar negara dan pandangan hidup bangsa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (200, 15, 5, 8, '1', 'kd02', 'P', 0, 'memahami fungsi-fungsi lembaga-lembaga negara dalam uud negara republik Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (201, 15, 5, 8, '1', 'kd03', 'P', 0, 'memahami tata urutan peraturan perundangan nasional');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (202, 15, 5, 8, '1', 'kd04', 'P', 0, 'memahami norma dan kebiasaan antar daerah di Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (203, 15, 5, 8, '1', 'kd4.1', 'K', 0, 'menalar nilai-nilai Pancasila sebagai dasar negara dan pandangan hidup bangsa dalam kehidupan sehari');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (204, 15, 5, 8, '1', 'kd4.2', 'K', 0, 'menyajikan hasil telaah fungsi lembaga-lembaga negara dalam UUD negara RI Tahun 1945');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (205, 15, 5, 8, '1', 'kd4.3', 'K', 0, 'menyajikan hasi telaah tata urutanperaturan perundang-undangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (206, 15, 5, 8, '1', 'kd4.4', 'K', 0, 'menalar hasil telaah norma dan kebiasaan antar daerah di Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (207, 15, 5, 8, '1', 'kd4.5', 'K', 0, 'menyajikanbentuk partisipasi kewarganegaran yang mencerminkan komitmen terhadap keutuhan nasional');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (208, 11, 8, 8, '1', 'KD1', 'P', 0, 'menentukan pola pada barisan bilangan dan barisan konfigurasi obyek');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (209, 11, 8, 8, '1', 'KD2', 'P', 0, 'Menjelaskan kedudukan titik dalam bidang kartesius');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (210, 11, 8, 8, '1', 'KD3', 'P', 0, 'mendiskripsikan dan menyatakan relasi dan fungsi dengan menggunakan berbagai representasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (211, 11, 8, 8, '1', 'KD4', 'P', 0, 'menjelaskan gradien, persamaan dan grafik garis lurus');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (212, 12, 11, 7, '1', '3.1', 'P', 0, 'Teks interaksi transaksional tindakan menyapa, berpamitan, terima kasih dan meminta maaf serta respo');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (213, 12, 11, 7, '1', '3.2', 'P', 0, 'Teks interaksi transaksional tindakan memberi dan meminta informasi jati diri pendek dan sederhana');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (214, 12, 11, 7, '1', '3.3', 'P', 0, 'Teks transaksional lisan dan tulis memberi dan meminta nama hari, bulan, waktu dalam hari/angka, tan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (215, 12, 11, 7, '1', '3.4', 'P', 0, 'Teks interaksi transaksional memberi dan meminta nama dan jumlah binatang, benda dan bangunan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (216, 12, 11, 7, '1', '4.1', 'K', 0, 'Menyusun teks transaksional menyapa, berpamitan, terima kasih dan meminta maaf.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (217, 17, 6, 7, '1', 'K31', 'P', 0, 'Mengidentifikasi informasi dan menelaah struktur dan kebahasaan teks deskripsi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (218, 12, 11, 7, '1', '4.2', 'K', 0, 'Menyusun teks transaksional memberi dan meminta informasi jati diri pendek dan sederhana');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (219, 17, 6, 7, '1', 'K32', 'P', 0, 'Mengidentifikasi unsur dan menelaah struktur dan kebahasaan teks fantasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (220, 17, 6, 7, '1', 'K33', 'P', 0, 'Mengidentifikasi teks dan menelaah struktur dan kebahasaan teks prosedur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (221, 12, 11, 7, '1', '4.3', 'K', 0, 'Menyusun teks transaksional memberi dan meminta nama hari, bulan, waktu dalam hari/angka, tanggal/ta');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (222, 17, 6, 7, '1', 'K34', 'P', 0, 'Mengidentifikasi informasi dan menelaah struktur dan kebahasaan teks laporan hasil observasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (223, 12, 11, 7, '1', '4.4', 'K', 0, 'Menyusun teks transaksional memberi dan meminta nama dan jumlah binatang, benda dan bangunan publik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (224, 11, 8, 8, '1', 'KD1', 'K', 0, 'menyelesaikan masalah yang berkaitan dengan pola pada barisan bilangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (225, 11, 8, 8, '1', 'KD2', 'K', 0, 'menyelesaikan masalah yag berkaitan dengan titik dalam bidang kartesius');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (226, 11, 8, 8, '1', 'KD3', 'K', 0, 'Menyelesaikan masalah yang berkaitan dengan relasi dan fungsi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (227, 11, 8, 8, '1', 'KD4', 'K', 0, 'menyelesaikan masalah yang berkaitan dengan SPLDV');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (228, 17, 6, 7, '1', 'K41', 'K', 0, 'Menjelaskan isi dan menyajikan data, gagasan dan kesan teks deskripsi secara lisan dan tulis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (229, 17, 6, 7, '1', 'K42', 'K', 0, 'Menceritakan kembali dan menyajikan gagasan kreatif teks fantasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (230, 17, 6, 7, '1', 'K43', 'K', 0, 'Menyimpulkan isi dan menyajikan data teks prosedur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (231, 17, 6, 7, '1', 'K44', 'K', 0, 'Menyimpulkan isi dan menyajikan rangkuman teks hasil observasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (232, 1, 16, 7, '1', '1.1', 'P', 0, 'membaca ayat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (233, 1, 16, 7, '1', '1.2', 'P', 0, 'Menulis ayat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (234, 1, 16, 7, '1', '1.3', 'P', 0, 'Menghafal surat ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (235, 1, 16, 7, '1', '1.4', 'P', 0, 'Menerjemahkan ayat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (256, 3, 12, 7, '1', 'K01', 'P', 0, 'memahami konsep dan prosedur menggambar flora fauna dan alam benda');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (257, 3, 12, 7, '1', 'K02', 'P', 0, 'memahami konsep dan prosedur menggambar gubahan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (258, 3, 12, 7, '1', 'K03', 'P', 0, 'memahami tehnik vokal dalam bernyanyi lagu unisono');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (259, 3, 12, 7, '1', 'K04', 'P', 0, 'memahami tehnik bermain musik ansambel sederhana');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (260, 3, 15, 7, '1', 'K01', 'P', 0, 'Memahami isi teks lisan sesuai dengan unggah ungguh jawa							');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (261, 3, 15, 7, '1', 'K02', 'P', 0, 'Memahami tujuan ,fungsi menceritakan pengalaman');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (262, 3, 15, 7, '1', 'K03', 'P', 0, 'memahami cangkriman dan parikan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (264, 3, 15, 7, '1', 'K01', 'K', 0, 'Menyusun teks lisan sesuai unggah ungguh jawa untuk berbagai kepentingan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (265, 3, 15, 7, '1', 'K02', 'K', 0, 'Menyusun teks lisan dan tulis untuk menceritakan pengalaman');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (269, 3, 15, 8, '1', 'K01', 'P', 0, 'memahami isi teks cerita legenda');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (270, 3, 15, 8, '1', 'K02', 'P', 0, 'menelaah teks piwulang serat Wulangreh pupuh Gambuh');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (271, 3, 15, 8, '1', 'K03', 'P', 0, 'menelaah teks berita');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (272, 3, 15, 8, '1', 'K04', 'P', 0, 'memahami isi teks dialog berisi pesan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (273, 3, 15, 8, '1', 'K01', 'K', 0, 'menceritakan kembali cerita legenda dengan dialeg setempat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (274, 3, 15, 8, '1', 'K02', 'K', 0, 'menanggapi teks piwulang serat Wulangreh pupuh Gambuh');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (275, 3, 15, 8, '1', 'K03', 'K', 0, 'menulis berita dan membaca teknik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (276, 3, 15, 8, '1', 'K04', 'K', 0, 'menyampaikan pesan secara lisan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (277, 3, 15, 8, '1', 'K05', 'K', 0, 'mengalihaksarakan serat Wulangreh pupuh Gambuh satu pada dari huruf latin ke huruf Jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (278, 17, 11, 8, '1', 'K31', 'P', 0, 'Teks lisan dan tulis meminta perhatian, mengecek pemahaman, menghargai, meminta dan mengungkapkan pe');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (279, 17, 11, 8, '1', 'K32', 'P', 0, 'Teks lisan dan tulis tentang kemampuan dan kemauan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (280, 17, 11, 8, '1', 'K33', 'P', 0, 'Teks lisan dan tulis tentang memberi keharusan, himbauan dan larangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (281, 17, 11, 8, '1', 'K34', 'P', 0, 'Teks lisan dan tulis tentang menyuruh, mengajak, dan meminta ijin');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (282, 17, 11, 8, '1', 'K35', 'P', 0, 'Teks greeting card');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (283, 17, 11, 8, '1', 'K36', 'P', 0, 'Teks lisan dan tulis tentang keberadaan orang, benda, dan binatang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (284, 17, 11, 8, '1', 'K37', 'P', 0, 'Teks lisan dan tulis tentang Simple Present Tense');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (285, 17, 11, 8, '1', 'K41', 'K', 0, 'Menyusun teks lisan meminta perhatian, mengecek pemahaman, menghargai, meminta dan mengungkapkan pen');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (286, 17, 11, 8, '1', 'K42', 'K', 0, 'Menyusun teks lisan dan tulis tentang kemampuan dan kemauan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (287, 17, 11, 8, '1', 'K43', 'K', 0, 'Menyusun teks lisan dan tulis keharusan, larangan dan himbauan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (288, 17, 11, 8, '1', 'K44', 'K', 0, 'Menyusun teks lisan dan tulis tentang menyuruh, mengajak dan meminta ijin');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (289, 17, 11, 8, '1', 'K45', 'K', 0, 'Menyusun teks greeting card');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (290, 17, 11, 8, '1', 'K46', 'K', 0, 'Menyusun teks lisan dan tulis tentang keberadaan orang, benda, dan binatang ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (291, 17, 11, 8, '1', 'K47', 'K', 0, 'Menyusun teks lisan dan tulis tentang Simple Present Tense');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (293, 6, 3, 7, '1', 'K01', 'P', 0, 'memahami najis dan tata cara menyucikan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (294, 6, 3, 7, '1', 'K02', 'P', 0, 'menganalisis hadas dan menyucikan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (295, 6, 3, 7, '1', 'K03', 'P', 0, 'memahami waktu-waktu shalat lima waktu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (296, 6, 3, 7, '1', 'K04', 'P', 0, 'memahami ketentuan sujud sahwi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (297, 6, 3, 7, '1', 'K05', 'P', 0, 'memahami ketentuan azan dan iqamah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (298, 6, 3, 7, '1', 'K06', 'P', 0, 'menganalisis ketentuan shalat berjamaah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (299, 6, 3, 7, '1', 'K07', 'P', 0, 'memahami tata cara berzikir dan berdoa setelah shalat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (300, 6, 3, 8, '1', 'K01', 'P', 0, 'memahami ketentuan sujud syukur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (301, 6, 3, 8, '1', 'K02', 'P', 0, 'memahami ketentuan sujud tilawah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (302, 6, 3, 8, '1', 'K03', 'P', 0, 'menganalisis ketentuan ibadah puasa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (303, 6, 3, 8, '1', 'K04', 'P', 0, 'menganalisis ketentuan pelaksanaan zakat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (304, 7, 7, 7, '1', 'K01', 'P', 0, 'mengidentifikasi bunyi kata, frasa dan kal b Arab yg berkaitan dg at Ta rifu binnafsi wa bil amiliin');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (305, 7, 7, 7, '1', 'KD2', 'P', 0, 'melafalkan bunyi kata, frasa dan kal b Arab yg berkaitan dg at Ta rifu binnafsi wa bil amiliin');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (306, 7, 7, 7, '1', 'KD3', 'P', 0, 'menemukan makna kata, frasa dan kal b Arab yg berkaitan dg at Ta rifu binnafsi wa bil amiliin');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (307, 7, 7, 7, '1', 'KD1', 'K', 0, 'Mendemontrasikan ungkapan sederhana tentang topik at ta rifu binnafsi wabilamiliina fil madrosah,alm');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (308, 7, 7, 7, '1', 'KD2', 'K', 0, 'Menunjukkan ungkapan sederhana tentang topik at ta rifu binnafsi wabilamiliina fil madrosah, almarof');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (309, 7, 7, 7, '1', 'KD3', 'K', 0, 'Menyampaikan info lisan tentang topik at ta rifu binnafsi wabilamiliina fil madrosah, almarof');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (310, 7, 7, 7, '1', 'KD4', 'K', 0, 'Mengungkapkan info scr tertulis sederhana tentang topik at ta rifu binnafsi wabilamiliina fil madros');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (311, 7, 7, 7, '1', 'KD5', 'K', 0, 'Menyusun teks sederhana tentang topik at ta rifu binnafsi wabilamiliina fil madrosah, almarof');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (312, 7, 7, 8, '1', 'KD1', 'P', 0, 'Mengidentifikasii bunyi,makna dan gagasan dari kata, frase, kal b Arab  dg topik assa ah, yaumiyatun');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (313, 7, 7, 8, '1', 'KD2', 'P', 0, 'Melafalkan bunyi,makna dan gagasan dari kata, frase, kal b Arab dg topik assa\'ah,yaumiyatuna fil mad');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (314, 7, 7, 8, '1', 'KD3', 'P', 0, 'Menemukan makna dan gagasan dari kata, frase dan kal b Arab dg topik assa\'ah, yaumiyatuna fil madros');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (315, 7, 7, 8, '1', 'KD1', 'K', 0, 'Mendemontrasikan ungkapan info lisan dan tulisan sederhana tentang topik assa\'ah, yaumiyatuna fil ma');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (316, 7, 7, 8, '1', 'KD2', 'K', 0, 'Menunjukkan ungkapan sederhana tentang topik assa\'ah, yaumiyatuna fil madrosah dan yaumiyatuna fil b');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (317, 7, 7, 8, '1', 'KD3', 'K', 0, 'Menyampaikan info lisan tentang topik assa\'ah, yaumiyatuna fil baiti dan yaumiyatuna fil baiti.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (319, 9, 8, 8, '1', '3.1', 'P', 0, 'Menentukan pola pd barisan bilangan dan barisan konfigurasi obyek');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (320, 9, 8, 8, '1', '3.2', 'P', 0, 'Menjelaskan kedudukan titik dalam bidang koordinat kartesius');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (321, 9, 8, 8, '1', '3.3', 'P', 0, 'Mendiskripsikan dan menyatakan relasi dan fungsi dg menggunakan berbagai representasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (322, 6, 1, 8, '1', 'k01', 'K', 0, 'menerapkan hukum bacaan mad iwad, layyin, mad Arid lissukun dalam Al-Wuran surah-surah pendek piliha');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (323, 6, 1, 8, '1', 'k02', 'K', 0, 'menuliskan isi kandungan QS.Quraisy [106], Al-Insyirah [94] tentang ketentuan rizqi dari Allah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (324, 20, 14, 8, '1', 'KD4.4', 'K', 0, 'mengolah, menyaji dan mengemas bahan pangan serealia, kacang- kacangan dan umbi yang ada di wilayah ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (325, 6, 1, 8, '1', 'K02', 'K', 0, 'mensimulasikan sikap tolong menolong dan peduli terhadap anak yatim sesuai isi QS. Al-Kautsar [108],');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (326, 9, 8, 8, '1', '4.1', 'K', 0, 'Menyelesaikan masalah yg berkaitan dg pola pd barisan bilangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (327, 9, 8, 8, '1', '4.2', 'K', 0, 'Menyelesaikan masalah yang berkaitan dg kedudukan ttk dalam bidang kartesius');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (328, 9, 8, 8, '1', '4.3', 'K', 0, 'Menyelesaikan masalah yang berkaitan dg relasi dan fungsi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (329, 9, 8, 8, '1', '4.4', 'K', 0, 'Menyelesaikan masalah yang berkaitan dg gradien, persamaan, dan grafik garis lurus');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (330, 6, 1, 8, '1', 'K01', 'P', 0, 'memahami hukum bacaan mad iwad, layyin, mad Arid lissukun dalam Al-Wuran surah-surah pendek piliha');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (331, 6, 1, 8, '1', 'K02', 'P', 0, 'memahami isi kandungan QS.Quraisy [106], Al-Insyirah [94] tentang ketentuan rizqi dari Allah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (332, 6, 1, 8, '1', 'K03', 'P', 0, 'memahami isi kandungan QS. Al-Kautsar [108], dan QS. Al-Maun [107]');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (333, 6, 3, 8, '1', 'K01', 'K', 0, 'memperagakan tata cara sujud syukur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (334, 6, 3, 8, '1', 'K02', 'K', 0, 'memperagakan tata cara sujud tilawah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (335, 6, 3, 8, '1', 'K03', 'K', 0, 'mensimulasikan tata cara melaksanakan puasa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (336, 6, 3, 8, '1', 'K04', 'K', 0, 'mendemonstrasikan pelaksanaan zakat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (337, 6, 3, 7, '1', 'K01', 'K', 0, 'mendemoinstrasikan tata cara bersuci');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (338, 6, 3, 7, '1', 'K02', 'K', 0, 'mempraktikkan azan dan iqamah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (339, 6, 3, 7, '1', 'K03', 'K', 0, 'mempraktikkan shalat lima waktu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (340, 6, 3, 7, '1', 'K04', 'K', 0, 'memperagakan sujud sahwi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (341, 6, 3, 7, '1', 'K05', 'K', 0, 'mendemonstrasikan tata cara shalat berjamaah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (342, 6, 3, 7, '1', 'K06', 'K', 0, 'mendemonstrasikan zikir setelah shalat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (343, 3, 12, 7, '1', 'K01', 'K', 0, 'Menggambar floura fauna dan alam benda');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (344, 3, 12, 7, '1', 'K02', 'K', 0, 'Menggambar gubahan flora fauna serta geometrik menjadi ragam hias');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (345, 3, 12, 7, '1', 'K03', 'K', 0, 'Menyanyikan lagu secara unisono');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (346, 3, 12, 7, '1', 'K04', 'K', 0, 'Memainkan musikansambel sederhana');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (347, 14, 10, 8, '1', '3.1', 'P', 0, 'menelaah perubahan keruangan dan interaksi antar ruang di Indonesia dan negara - negara ASEAN');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (348, 14, 10, 8, '1', '3.2', 'P', 0, 'menganalisis pengaruh interaksi sosial dalam ruang yang berbeda - beda');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (351, 3, 12, 8, '1', 'K01', 'P', 0, 'Memahami konsep dan prosedur menggambar model pada berbagai bahan dan teknik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (352, 3, 12, 8, '1', 'K02', 'P', 0, 'Memahami konsep dan prosedur menggabar ilustrasi dg teknik manual dan digital');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (353, 14, 10, 8, '1', '4.1', 'K', 0, 'menyajikan hasil telaah tentang Perubahan keruangan dan interaksi antar ruang di Indonesia dan ASEAN');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (354, 14, 10, 8, '1', '4.2', 'K', 0, 'menyajikan hasil analisis tentang pengaruh interaksi sosial dalam ruang yang berbeda');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (355, 3, 12, 8, '1', 'K03', 'P', 0, 'Memahami yeknik dan gaya lagu daerah secara unisono atau perorangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (356, 3, 12, 8, '1', 'K04', 'P', 0, 'Memahami teknik dan gaya lagu daerah dalam bentuk vokal group');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (358, 3, 12, 8, '1', 'K01', 'K', 0, 'Menggambar model pada berbagai bahan dan teknik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (359, 3, 12, 8, '1', 'K02', 'K', 0, 'Menggambar ilustrasi dengan teknik manual dan digital');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (360, 3, 12, 8, '1', 'K03', 'K', 0, 'menyanyikan lagu daerah secara unisono atau perorangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (361, 3, 12, 8, '1', 'K04', 'K', 0, 'Menyanyikan lagu daerah bentuk vokal group');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (371, 7, 1, 7, '1', 'KD1', 'P', 0, 'Memahami kedudukan al-Qur an dan Hadits dalam kehidupan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (372, 7, 1, 7, '1', 'KD2', 'P', 0, 'Memahami isi kandungan Q.S al Fatihah, an Naas, al Falaq dan al Ikhlas tentang keesaan Alloh');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (376, 7, 1, 7, '1', 'KD3', 'P', 0, 'Memahami keterkaitan isi kandungan hadits tentang iman dalam fenomena kehidupan dan akibatnya.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (378, 7, 1, 7, '1', 'KD1', 'K', 0, 'Membaca  Q.S al Fatihah, an Naas, al Falaq dan al Ikhlas.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (379, 7, 1, 7, '1', 'KD2', 'K', 0, 'Menghafal  Q.S al Fatihah, an Naas, al Falaq dan al Ikhlas secara fasih dan tartil.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (380, 7, 1, 7, '1', 'KD3', 'K', 0, 'Menulis hadits tentang iman  dan ibadah yang diterima Alloh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (382, 7, 1, 7, '1', 'KD4', 'K', 0, 'Menerjemahkan makna hadits tentang iman dan ibadah yang diterima Alloh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (386, 19, 9, 7, '2', 'K06', 'P', 0, 'Mengidentifikasi sistem organisasi kehidupan tingkat sel sampai organisme');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (387, 19, 9, 7, '2', 'K07', 'P', 0, 'Menganalisis interaksi antara makhluk hidup dan lingkungannya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (388, 19, 9, 7, '2', 'K08', 'P', 0, 'Menganalisis terjadinya pencemaran lingkungan dan dampaknya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (389, 19, 9, 7, '2', 'K09', 'P', 0, 'Menganalisis perubahan iklim dan dampaknya bagi ekosistem');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (390, 19, 9, 7, '2', 'K10', 'P', 0, 'Menjelaskan lapisan bumi,gunung api,gempa bumi dan tindakan pengurangan resiko');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (391, 19, 9, 7, '2', 'K11', 'P', 0, 'Menganalisis sistem tata surya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (392, 19, 9, 7, '2', 'K06', 'K', 0, 'Membuat model struktur sel tumbuhan/hewan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (393, 19, 9, 7, '2', 'K07', 'K', 0, 'Menyajikan hasil pengamatan interaksi makhluk hidup dengan lingkungan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (394, 19, 9, 7, '2', 'K08', 'K', 0, 'Membuat tulisan tentang gagasan penyelesaian masalah pencemaran lingkungan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (395, 19, 9, 7, '2', 'K09', 'K', 0, 'Membuat tulisan tentang gagasan adaptasi perubahan iklim');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (396, 19, 9, 7, '2', 'K10', 'K', 0, 'Mengomunikasikan upaya pengurangan resiko dan dampak bencana alam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (397, 19, 9, 7, '2', 'K11', 'K', 0, 'Menyajikan karya tentang dampak rotasi dan revolusi bumi dan bulan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (399, 10, 9, 8, '2', '3.7', 'P', 0, 'memahami sistem peredaran darah pada manusia,,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (400, 10, 9, 8, '2', '3.8', 'P', 0, 'memahami tekanan zat,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (401, 10, 9, 8, '2', '3.9', 'P', 0, 'menganalisis sistem pernapasan pada manusia,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (402, 10, 9, 8, '2', '3.10', 'P', 0, 'menganalisis sistem ekskresi pada manusia,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (403, 10, 9, 8, '2', '3.11', 'P', 0, 'menerapkan konsep getaran, gelombang dan bunyi,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (404, 10, 9, 8, '2', '4.7', 'K', 0, 'menyajikan hasil percobaan pengaruh aktivitas pada frekuensi denyut jantung, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (405, 10, 9, 8, '2', '4.8', 'K', 0, 'menyajikan data hasil percobaan untuk menyelidiki tekanan zat cair pada kedalaman tertentu, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (406, 10, 9, 8, '2', '4.9', 'K', 0, 'menyajikan karya tentang upaya menjaga kesehatan sistem pernapasan, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (407, 10, 9, 8, '2', '4.10', 'K', 0, 'membuat karya tentang sistem ekskresi pada manusia, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (408, 10, 9, 8, '2', '4.11', 'K', 0, 'menyajikan hasil percobaan tentang getaran, gelombang, dan bunyi, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (417, 20, 14, 8, '2', 'KD3.1', 'P', 0, 'Memahami desain kerajinan dari bahan limbah anorganik lunak atau keras ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (418, 20, 14, 8, '2', 'KD3.1', 'P', 0, 'Mendeskripsikan proses modifikasi jenis bahan limbah anorganik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (419, 20, 14, 8, '2', 'KD3.2', 'P', 0, 'Memahami prosedur jenis produk rekayasa yang dibuat berdasarkan rangkaian pengubah besaran listrik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (420, 20, 14, 8, '2', 'KD3.2', 'P', 0, 'Mengidentifikasi bahan, material, dan alat bantu yang digunakan untuk membuat produk rekayasa berdas');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (421, 20, 14, 8, '2', 'KD3.3', 'P', 0, 'Mengidentifikasi desain wadah budidaya ikan konsumsi diwilayah setempat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (422, 20, 14, 8, '2', 'KD3.3', 'P', 0, 'Memahami konsep dan prosedur pemeliharaan ikan hias sesuai wilayah    setempat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (423, 20, 14, 8, '2', 'KD3.4', 'P', 0, 'Memahami rancangan pembuatan,  penyajian, dan pengemasan olahan bahan pangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (424, 20, 14, 8, '2', 'KD3.4', 'P', 0, 'Memahami manfaat dan proses olahan seralia dan umbi menjadi produk non pangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (425, 20, 14, 8, '2', 'KD4.1', 'K', 0, 'Membuat karya kerajinan dan pengemasan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (426, 20, 14, 8, '2', 'KD4.1', 'K', 0, 'Memodifikasi kerajinan dan pengemasan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (427, 20, 14, 8, '2', 'KD4.2', 'K', 0, 'Membuat model alat pengubah listrik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (428, 20, 14, 8, '2', 'KD4.2', 'K', 0, 'Membuat produk sensor menggunakan teknologi kelistrikan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (429, 20, 14, 8, '2', 'KD4.3', 'K', 0, 'Mendesain wadah budidaya ikan hias ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (430, 20, 14, 8, '2', 'KD4.3', 'K', 0, 'Memelihara ikan hias berdasarkan konsep dan prosedur sesuai wilayah setempat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (431, 20, 14, 8, '2', 'KD4.4', 'K', 0, 'Membuat olahan bahan pangan setengah jadi ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (432, 20, 14, 8, '2', 'KD4.4', 'K', 0, 'Membuat olahan dari hasil samping seralia dan umbi ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (433, 20, 14, 7, '2', 'KD3.1', 'P', 0, 'Memahami tentang jenis, sifat, karakter, dan Teknik pengolahan kertas dan plastik lembar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (434, 20, 14, 7, '2', 'KD3.1', 'P', 0, 'Memahami tentang prinsip perancangan, pembuatan, dan penyajian produk kerajinan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (435, 20, 14, 7, '2', 'KD3.2', 'P', 0, 'Memahami jenis-jenis dan fungsi teknologi konstruksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (436, 20, 14, 7, '2', 'KD3.2', 'P', 0, 'Memahami sistem, jenis, serta karakteristik persambungan dan penguatan pada konstruksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (437, 20, 14, 7, '2', 'KD3.3', 'P', 0, 'Memahami komoditas tanaman obat yang dapat dikembangkan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (438, 20, 14, 7, '2', 'KD3.3', 'P', 0, 'Memahami tahapan budidaya tanaman obat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (439, 20, 14, 7, '2', 'KD3.4', 'P', 0, 'Memahami rancangan pengolahan, penyajian, dan pengemasan bahan pangan sayuran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (442, 20, 14, 7, '2', 'KD3.4', 'P', 0, 'Memahami rancangan pengolahan, penyajian, dan pengemasan bahan hasil samping sayuran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (443, 20, 14, 7, '2', 'KD4.1', 'K', 0, 'Memilih jenis bahan dan teknik pengolahan kertas dan plastik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (444, 20, 14, 7, '2', 'KD4.1', 'K', 0, 'Merancang, membuat, dan menyajikan produk kerajinan dari bahan kertas dan plastik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (445, 20, 14, 7, '2', 'KD4.2', 'K', 0, 'Memanipulasi jenis-jenis dan fungsi teknologi konstruksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (446, 20, 14, 7, '2', 'KD4.2', 'K', 0, 'Membuat produk teknologi konstruksi ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (447, 20, 14, 7, '2', 'KD4.3', 'K', 0, 'Menentukan komoditas tanaman obat yang akan dibudidayakan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (448, 20, 14, 7, '2', 'KD4.3', 'K', 0, 'Mempraktikan tahapan budidaya tanaman obat ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (449, 20, 14, 7, '2', 'KD4.4', 'K', 0, 'Mengolah, menyaji, dan mengemas bahan pangan sayuran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (450, 20, 14, 7, '2', 'KD4.4', 'K', 0, 'Mengolah, menyaji, dan mengemas bahan hasil samping sayuran menjadi produk pangan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (451, 17, 11, 8, '2', 'K.D.1', 'P', 0, 'Menerapkan fungsi sosial, struktur teks, unsur kebahasaan Present Continous Tense');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (452, 17, 11, 8, '2', 'K.D. ', 'P', 0, 'Menerapkan fungsi sosial,struktur teks, unsur  kebahasaan Comparison Degree');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (453, 17, 11, 8, '2', 'K.D. ', 'P', 0, 'Menerapkan fungsi sosial, struktur teks dan unsur kebahasaan Past Tense');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (454, 17, 11, 8, '2', 'KD. 4', 'P', 0, 'Menerapkan dan membandingkan fungsi sosial, struktur teks, unsur kebahasaan teks recount');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (455, 17, 11, 8, '2', 'K.D. ', 'P', 0, 'Membandingkan fungsi sosial, struktur teks dan unsur kebahasaan pesan singkat dan pengumuman');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (456, 17, 11, 8, '2', 'K.D. ', 'P', 0, 'Menafsirkan fungsi sosial, struktur teks, unsur kebahasaan lagu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (459, 17, 11, 8, '2', 'K.D.1', 'K', 0, 'Menyusun kalimat Present Continous Tense');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (462, 17, 11, 8, '2', 'K.D. ', 'K', 0, 'Menyusun kalimat perbandingan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (463, 17, 11, 8, '2', 'K.D 3', 'K', 0, 'Menyusun kalimat Past Tense');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (464, 17, 11, 8, '2', 'K.D 4', 'K', 0, 'Menangkap makna dan menyusun teks recount');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (465, 17, 11, 8, '2', 'K.D. ', 'K', 0, 'Menangkap makna dan menyusun teks pesan singkat dan pengumuman');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (466, 17, 11, 8, '2', 'K.D.6', 'K', 0, 'Menangkap makna lagu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (470, 17, 6, 7, '2', 'K.D. ', 'P', 0, 'Mengidentifikasi informasi dan menyimpulkan isi puisi rakyat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (471, 17, 6, 7, '2', 'K.D.2', 'P', 0, 'Mengidentifikasi informasi dan menceritakan kembali fabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (473, 17, 6, 7, '2', 'K.D. ', 'P', 0, 'Mengidentifikasi informasi dan menyimpulkan isi surat pribadi/dinas');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (474, 17, 6, 7, '2', 'K.D.4', 'P', 0, 'Menemukan unsur-unsur dan membuat rangkuman isi buku fiksi/nonfiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (475, 17, 6, 7, '2', 'K.D.1', 'K', 0, 'Menelaah struktur dan mengungkapkan gagasan, pesan puisi rakyat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (476, 17, 6, 7, '2', 'K.D. ', 'K', 0, 'Menelaah struktur dan kebahasaan fabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (477, 17, 6, 7, '2', 'K.D. ', 'K', 0, 'Memerankan isi fabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (478, 17, 6, 7, '2', 'K.D. ', 'K', 0, 'Menelaah unsur dan kebahasaan dan menulis surat pribadi/dinas');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (480, 17, 6, 7, '2', 'K.D. ', 'K', 0, 'Menelaah hubungan unsur dan menyajikan tanggapan isi buku fiksi/nonfiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (483, 14, 10, 8, '2', '3.1', 'P', 0, 'Memahami aspek keruangan dan konektivitas antar ruang dan waktu dalam lingkup nasional');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (484, 14, 10, 8, '2', '3.4', 'P', 0, 'Mendiskripsikan bentuk-bentuk dan sifat dinamika interaksi manusia dengan lingkungan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (485, 14, 10, 8, '2', '3.3.', 'P', 0, 'Mendeskripsikn fungsi dan peran kelembagaan sosial, buadaya, ekonomi dan politik dalam masyarakat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (488, 14, 10, 8, '2', ' 4.3', 'K', 0, 'Menyajikan hasil pengamatan bentuk-bentuk dan sifat dinamika interaksi manusia dengan lingkungan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (490, 7, 7, 7, '2', 'KD.1', 'K', 0, 'Mendemonstrasikan ungkapan tentang al\'unwaan, baiti dan min yaumiyyatil usroh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (491, 7, 7, 7, '2', 'KD.1', 'P', 0, 'Mengidentifikasi bunyi tentang Al\'unwaan, baiti dan min yaumiyyatil usroh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (492, 7, 7, 8, '2', 'KD.1', 'K', 0, 'Mendemonstrasikan ungkapan tentang almihnah, allaa\'ibunarriyadhiyuun, almihnatu tibbiyyah dan attada');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (493, 7, 7, 8, '2', 'KD.1', 'P', 0, 'Mengidentifikasi bunyi tentang almihnah, allaa\'ibunarriyadhiyun, almihnatu tibbiyyah dan attadawi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (494, 12, 11, 7, '2', '3.5', 'P', 0, 'teks lisan dan tulis tentang orang, binatang dan benda lain dari sifatnya,															');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (495, 12, 11, 7, '2', '3.6', 'P', 0, 'teks lisan dan tulis tentang orang, binatang dan benda lain dari tindakannya,															');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (496, 12, 11, 7, '2', '3.7', 'P', 0, 'teks deskripsi lisan dan tulis tentang orang, binatang dan benda,															');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (497, 12, 11, 7, '2', '3.8', 'P', 0, 'lagu remaja,															');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (498, 12, 11, 7, '2', '4.5', 'K', 0, 'menyusun teks lisan dan tulis tentang orang, binatang dan benda lain dari sifatnya,															');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (499, 12, 11, 7, '2', '4.6', 'K', 0, 'menyusun teks lisan dan tulis tentang orang, binatang dan benda lain dari tindakannya,														');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (500, 12, 11, 7, '2', '4.7', 'K', 0, 'menyusun teks deskripsi lisan dan tulis tentang orang, binatang dan benda,															');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (501, 12, 11, 7, '2', '4.8', 'K', 0, 'menafsirkan makna lagu remaja															');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (502, 7, 7, 7, '2', 'KD.2', 'P', 0, 'Melafalkan bunyi huruf tentang al\'unwaan, baiti dan min yaumiyyatil usroh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (503, 7, 7, 7, '2', 'KD.3', 'P', 0, 'Menemukan makna ujaran tentang al\'unwaan, baiti dan min yaumiyyatil usroh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (504, 7, 7, 7, '2', 'KD.2', 'K', 0, 'Menunjukkan contoh ungkapan tentang al\'unwaan, baiti dan min yaumiyyatil usroh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (505, 7, 7, 7, '2', 'KD.3', 'K', 0, 'Menyampaikan informasi lisan tentang Al\'unwaan, baiti dan min yaumiyyatil usroh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (506, 7, 7, 7, '2', 'KD.4', 'K', 0, 'Mengungkapkan informasi tertulis tentang al\'unwaan, baiti dan min yaumiyyatil usroh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (507, 7, 7, 7, '2', 'KD.5', 'K', 0, 'Menyusun teks tentang al\'unwaan, baiti dan min yaumiyyatil usroh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (508, 7, 7, 8, '2', 'KD.2', 'P', 0, 'Melafalkan bunyi tentang almihnah, allaa\'ibunarriyadhiyun, almihnatu tibbiyyah dan attadawi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (509, 7, 7, 8, '2', 'KD.3', 'P', 0, 'Menentukan makna tentang almihnah, allaa\'ibunarriyadhiyun, almihnatu tibbiyyah dan attadawi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (511, 7, 7, 8, '2', 'KD.2', 'K', 0, 'Menunjukkan contoh tentang almihnah, allaa\'ibunarriyadhiyuun, almihnatu tibbiyyah dan attadawi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (512, 15, 10, 7, '2', '3.4', 'P', 0, 'Memahami pengertian dinamika  interaksi manusia dengan lingkungan alam,sosial,budaya dan ekonomi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (513, 7, 7, 8, '2', 'KD.3', 'K', 0, 'Menyampaikan informasi lisan tentang almihnah, allaa\'ibunarriyadhiyuun, almihnatu tibbiyyah dan atta');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (514, 7, 7, 8, '2', 'KD.4', 'K', 0, 'Mengungkapkan informasi tulis tentang almihnah, allaa\'ibunarriyadhiyuun, almihnatu tibbiyyah dan att');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (515, 15, 10, 7, '2', '3.3', 'P', 0, 'Memahami jenis-jenis kelembagaan sosial ,budaya ekonomi dan politik dalam masyarakat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (516, 7, 7, 8, '2', 'KD.5', 'K', 0, 'Menyusun teks tentang almihnah, allaa\'ibunarriyadhiyuun, almihnatu tibbiyyah dan attadawi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (517, 9, 8, 7, '2', 'KD3.7', 'P', 0, 'Mendeskripsikan lokasi benda dalam koordinat cartesius');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (518, 9, 8, 7, '2', 'KD3.8', 'P', 0, 'Menaksir dan mengukur bangun tidak beraturan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (519, 9, 8, 7, '2', 'KD3.9', 'P', 0, 'Memahami konsep tranformasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (520, 9, 8, 7, '2', 'KD3.1', 'P', 0, 'Menemukan peluang empirik dari sekelompok data');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (521, 9, 8, 7, '2', 'KD4.6', 'K', 0, 'Menerapkan prinsip tranformasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (522, 9, 8, 7, '2', 'KD4.7', 'K', 0, 'Menyelesaikan permasalahan yang berkaitan bangun segi empat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (523, 9, 8, 7, '2', 'KD4.8', 'K', 0, 'Mengolah dan menyajikan data dalam bentuk tabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (524, 9, 8, 7, '2', 'KD4.9', 'K', 0, 'Melakukan percobaan bentuk empirik dalam bentuk tabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (525, 9, 8, 7, '2', 'KD4.1', 'K', 0, 'Menerapkan konsep dan sifat sifat terkait garis dan sudut');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (526, 9, 8, 7, '2', 'KD3.1', 'P', 0, 'Memahami berbagai konsep dan prinsip garis dan sudut');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (527, 3, 12, 7, '2', 'KD 1', 'P', 0, 'Memahami konsep dan prosedur penerapan ragam hias pada bahan tekstil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (528, 3, 12, 7, '2', 'KD 2', 'P', 0, 'Memahami konsep dan prosedur penerapan ragam hias pada bahan alam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (529, 3, 12, 7, '2', 'KD 3', 'P', 0, 'Memahami konsep dasar permainan alat musik sederhana secara perorangan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (530, 3, 12, 7, '2', 'KD 4 ', 'P', 0, 'Memahami konsep dasar ansambel musik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (531, 3, 12, 7, '2', 'KD 1', 'K', 0, 'Menerapkan ragam hias pada bahan tekstil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (532, 3, 12, 7, '2', 'KD 2', 'K', 0, 'Menerapkan ragam hias pada bahan alam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (533, 3, 12, 7, '2', 'KD 3', 'K', 0, 'Memainkan alat musik sederhana secara perorangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (534, 3, 12, 7, '2', 'KD 4', 'K', 0, 'Memainkan ansambel musik sejenis dan campuran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (535, 3, 12, 8, '2', 'KD 1', 'P', 0, 'Memahami prosedur menggambar poster dengan berbagai teknik ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (536, 3, 12, 8, '2', 'KD 2', 'P', 0, 'Memahami prosedur menggambar komik dengan berbagai teknik ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (537, 3, 12, 8, '2', 'KD 3', 'P', 0, 'Memahami teknik memainkan salah satu alat musik tradisional secara perorangan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (538, 3, 12, 8, '2', 'KD 4 ', 'P', 0, 'Memahami teknik memainkan alat-alat musik tradfisional secara kelompok ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (539, 3, 12, 8, '2', 'KD 1', 'K', 0, 'Menggambar poster dengan berbagai media bahan dan teknik ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (540, 3, 12, 8, '2', 'KD 2', 'K', 0, 'Menggambar komik dengan berbagai teknik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (541, 3, 12, 8, '2', 'KD 3', 'K', 0, 'Memainkan salah satu alat musik tradisional secara perorangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (542, 3, 12, 8, '2', 'KD 4 ', 'K', 0, 'Memainkan alat-alat musik tradisional secara berkelompok');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (543, 9, 8, 8, '2', '311', 'P', 0, 'Menaksir dan menghitung luas dan volum bangun ruang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (544, 9, 8, 8, '2', '312', 'P', 0, 'Memahami konsep perbandingan dan menggunakan tabel, grafik dan persamaan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (545, 9, 8, 8, '2', '313', 'P', 0, 'Menemukan peluang empirik dan teoritik dari data');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (546, 9, 8, 8, '2', '314', 'P', 0, 'Memahami teknik penyajian data dua variabel pada grafik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (547, 9, 8, 8, '2', '4.6', 'K', 0, 'Menyelesaikan permasalahan hub sdt pusat,panjang busur dan luas juring');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (548, 9, 8, 8, '2', '4.7', 'K', 0, 'Mengolah dan menginterpretasikan data dalam bentuk tabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (549, 9, 8, 8, '2', '4.8', 'K', 0, 'Melakukan percobaan untuk peluang empirik dibandingkan dengan peluang teoritik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (550, 16, 2, 7, '2', 'KD01', 'P', 0, 'Menguraikan al-Asma al Husna (al-Aziz, Al Ghaffar, al-basit, an-nafi\', Ar rauf, al Barr, Al fattah, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (551, 16, 2, 7, '2', 'KD02', 'P', 0, 'Mendeskripsikan tugas dan sifat-sifat malaikat Allah serta makhluk gaib lainnya seperti jin, iblis, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (552, 16, 2, 7, '2', 'KD03', 'P', 0, 'Memahami akhlak tercela riya\' dan nifaq');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (553, 13, 13, 7, '2', 'KD 01', 'P', 0, 'Memahami konsep dasar permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (554, 16, 2, 7, '2', 'KD04', 'P', 0, 'Memahami adab membaca Al Qur\'an dan adab berdoa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (555, 16, 2, 7, '2', 'KD05', 'P', 0, 'Menganalisis kisah keteladanan Ashabul Kahfi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (556, 13, 13, 7, '2', 'KD 02', 'P', 0, 'Memahami konsep dasar permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (557, 16, 2, 7, '2', 'KD01', 'K', 0, 'Menyajikan fakta dan fenomena kebenaran sifat-sifat Allah yang terkandung dalam al-Asma Al- Husna');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (558, 13, 13, 7, '2', 'KD 03', 'P', 0, 'Memahami konsep dasar atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (559, 16, 2, 7, '2', 'KD02', 'K', 0, 'Menyajikan kisah-kisah dalam fenomena kehidupan tentang kebenaran adanya malaikat dan makhluk gaib ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (560, 16, 2, 7, '2', 'KD03', 'K', 0, 'Menyimulasikan contoh perilaku riya\' dan nifaq serta dampaknya dalam kehidupan sehari-hari');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (561, 16, 2, 7, '2', 'KD04', 'K', 0, 'Menceritakan kisah keteladanan Ashabul Kahfi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (562, 13, 13, 7, '2', 'KD 05', 'P', 0, 'Memahami konsep dasar senam lantai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (563, 13, 13, 7, '2', 'KD 06', 'P', 0, 'Memahami konsep dasar senam irama');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (564, 13, 13, 7, '2', 'KD 07', 'P', 0, 'Memahami konsep dasar latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (567, 13, 13, 8, '2', 'KD 01', 'P', 0, 'Memahami konsep permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (568, 13, 13, 8, '2', 'KD 02', 'P', 0, 'Memahami konsep permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (569, 16, 2, 8, '2', 'KD01', 'P', 0, 'Memahami pengertian, dalil dan pentingnya beriman kepada Rasul Allah Swt');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (570, 13, 13, 8, '2', 'KD 03', 'P', 0, 'Memahami konsep nomor atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (571, 16, 2, 8, '2', 'KD02', 'P', 0, 'Menguraikan sifat-sifat Rasul Allah Swt');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (572, 13, 13, 8, '2', 'KD 05', 'P', 0, 'Memahami konsep senam lantai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (573, 13, 13, 8, '2', 'KD 06', 'P', 0, 'Memahami konsep aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (574, 13, 13, 8, '2', 'KD 07', 'P', 0, 'Memahami konsep latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (577, 16, 2, 8, '2', 'KD03', 'P', 0, 'Memahami pengertian, contoh dan hikmah mukjizat serta kejadian luar biasa lainnya (karamah, ma\'unah ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (578, 9, 8, 7, '2', 'KD3.1', 'P', 0, 'Memahami konsep dan prinsip garis dan sudut dalam pemecahan masalah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (579, 16, 2, 8, '2', 'KD04', 'P', 0, 'Memahami pengertian, contoh dan dampak positifnya sifat husnudzan, tawadhu\', tasamuh dan ta\'awun');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (580, 16, 2, 8, '2', 'KD05', 'P', 0, 'Memahami pengertian, contoh dan dampak negatifnya sifat hasad, dendam, ghibah, fitnah dan namimah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (581, 16, 2, 8, '2', 'KD06', 'P', 0, 'Memahami adab kepada saudara dan teman');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (582, 16, 2, 8, '2', 'KD07', 'P', 0, 'menganalisis kisah keteladanan sahabat Abu Bakar ra');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (583, 16, 2, 8, '2', 'KD01', 'K', 0, 'Menyajikan peta konsep pengertian, dalil dan pentingnya beriman kepada Rasul Allah Swt');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (584, 16, 2, 8, '2', 'KD02', 'K', 0, 'Menyajikan peta konsep sifat-Sifat Rasul Allah Swt');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (585, 16, 2, 8, '2', 'KD03', 'K', 0, 'Menyajikan kisah-kisah dari berbagai sumber tentang adanya mukjizat dan kejadian luar biasa lainnya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (586, 16, 2, 8, '2', 'KD04', 'K', 0, 'Mensimulasikan dampak positif dari akhlak terpuji (husnudzan, tawadhu\', tasamuh dan ta\'awun)');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (587, 16, 2, 8, '2', 'KD05', 'K', 0, 'Mensimulasikan dampak negatif dari akhlak tercela (hasad, dendam, ghibah, dan namimah)');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (588, 13, 13, 7, '2', 'KD 01', 'K', 0, 'Mempraktikkan teknik dasar permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (589, 7, 1, 7, '2', 'KD.1', 'P', 0, 'Memahami isi kandungan Q.S Al Kafirun dan Al Bayyianah dan hadits tentang toleransi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (590, 16, 2, 8, '2', 'KD06', 'K', 0, 'Mensimulasikan adab kepada saudara dan teman');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (591, 13, 13, 7, '2', 'KD 02', 'K', 0, 'Mempraktikkan teknik dasar permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (592, 13, 13, 7, '2', 'KD 03', 'K', 0, 'Mempraktikkan teknik dasar salah satu nomor atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (593, 16, 2, 8, '2', 'KD07', 'K', 0, 'Menceritakan kisah keteladanan sahabat Abu Bakar ra');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (594, 13, 13, 7, '2', 'KD 05', 'K', 0, 'Mempraktikkan teknik dasar senam lantai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (595, 13, 13, 7, '2', 'KD 06', 'K', 0, 'Mempraktikkan teknik dasar aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (596, 7, 1, 7, '2', 'KD.2', 'P', 0, 'Memahami isi kandungan QS. Al Lahab dan An Nashr.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (597, 13, 13, 7, '2', 'KD 07', 'K', 0, 'Mempraktikkan latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (600, 13, 13, 8, '2', 'KD 01', 'K', 0, 'Mempraktikkan permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (601, 7, 1, 7, '2', 'KD.1', 'K', 0, 'Menerapkan hukum bacaan qolqolah dalam QS. Al Bayyinah dan Al Kafirun.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (602, 13, 13, 8, '2', 'KD 02', 'K', 0, 'Mempraktikkan permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (603, 13, 13, 8, '2', 'KD 03', 'K', 0, 'Mempraktikkan salah satu nomor atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (605, 7, 1, 7, '2', 'KD.2', 'K', 0, 'Menulis hadits tentang sikap tasamuh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (606, 13, 13, 8, '2', 'KD 05', 'K', 0, 'Mempraktikkan senam lantai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (607, 13, 13, 8, '2', 'KD 06', 'K', 0, 'Mempraktikkan aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (608, 7, 1, 7, '2', 'KD.3.', 'K', 0, 'Menerjemahkan hadits tentang sikap tasamuh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (609, 13, 13, 8, '2', 'KD 07', 'K', 0, 'Mempraktikkan latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (612, 7, 1, 7, '2', 'KD.4.', 'K', 0, 'Menghafal hadits tentang sikap tasamuh.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (613, 15, 10, 7, '2', '4.4', 'K', 0, 'mengobservasi dan menyajikan bentuk-bentuk dinamika interaksi manusia dengan lingkungan alam,sosial,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (614, 16, 4, 7, '2', 'KD01', 'P', 0, 'Memahami berbagai prestasi yang dicapai oleh Khulafaurrasyidin');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (615, 16, 4, 7, '2', 'KD02', 'P', 0, 'Memahami sejarah berdirinya Dinasti Bani Umayyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (616, 16, 4, 7, '2', 'KD03', 'P', 0, 'Memahami perkembangan kebudayaan/peradaban Islam pada masa Dinasti Bani Umayyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (617, 16, 4, 7, '2', 'KD04', 'P', 0, 'Memahami tokoh ilmuwan muslim dan perannya dalam kemajuan kebudayaan/peradaban islam pada masa Dinas');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (618, 16, 4, 7, '2', 'KD05', 'P', 0, 'Memahami sikap dan gaya kepemimpinan Umar bin Abdul Azis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (619, 16, 4, 7, '2', 'KD01', 'K', 0, 'Meniru model kepemimpinan Khulafaurrasyidin');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (620, 16, 4, 7, '2', 'KD02', 'K', 0, 'Menceritakan kisah ketegasan Abu Bakar as-Siddiq dalam menghadapi kekacauan umat Islam saat wafatnya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (621, 16, 4, 7, '2', 'KD03', 'K', 0, 'Menceritakan kisah tentang kehidupan Umar bin Abdul Azis dalam kehidupan sehari-hari');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (622, 16, 4, 8, '2', 'KD01', 'P', 0, 'Memahami sejarah berdirinya Dinasti Ayyubiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (623, 16, 4, 8, '2', 'KD02', 'P', 0, 'Mengidentifikasi perkembangan kebudayaan/peradaban Islam pada masa Dinasti Ayyubiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (624, 16, 4, 8, '2', 'KD03', 'P', 0, 'Memahami semangat juang para penguasa Dinasti Ayyubiyah yang terkenal (Salahuddin al- Ayyubi, Al Adi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (625, 16, 4, 8, '2', 'KD04', 'P', 0, 'Mengidentifikasi ilmuwan muslim dinasti Ayyubiyah dan perannya dalam kemajuan kebudayaan/peradaban ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (626, 16, 4, 8, '2', 'KD01', 'K', 0, 'menceritakan sejarah berdirinya Dinasti Ayyubiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (627, 16, 4, 8, '2', 'KD02', 'K', 0, 'Membuat peta konsep mengenai hal-hal yang dicapai pada masa Dinasti Ayyubiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (628, 16, 4, 8, '2', 'KD03', 'K', 0, 'Menceritakan biografi tokoh yang terkenal (salahudin al-Ayyubi, Al Adil dan Al Kamil) pada masa Dina');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (629, 16, 4, 8, '2', 'KD04', 'K', 0, 'Memaparkan peran ilmuwan dalam memajukan kebudayaaan dan peradaban Islam pada masa Dinasti Ayyubiyah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (630, 15, 5, 8, '2', '3.4', 'P', 0, 'menemukan makna dan arti penting kebangkitan nasional dalam perjuangan kemerdekaan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (631, 15, 5, 8, '2', '3.5', 'P', 0, 'mengidentifikasi nilai dan semangat sumpah pemuda tahun1928 dalam bingkai Bhinika Tunggal Ika');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (632, 15, 5, 8, '2', '3.6', 'P', 0, 'menggali pentingnya semangat dan komitmen kebangsaan untuk memperkuat negara kesatuan Republik Indon');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (633, 15, 5, 8, '2', '4.4', 'K', 0, 'melaksanakan tanggungjawab terkait keberagaman suku,agamaras,dan antar golongan dalam bingkai Bhinne');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (634, 15, 5, 8, '2', '4.5 ', 'K', 0, 'menunjukan prilaku bertanggungjawab dalam bekerjasama di berbagai bidang kehidupan dimasyarakat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (635, 15, 5, 8, '2', '4.6', 'K', 0, 'menunjukan contoh karakteristik daerah tempat tinggalnya dalam kerangka Negara Kesatuan Republik Ind');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (636, 3, 15, 7, '2', 'KD 1', 'P', 0, 'Memahami geguritan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (637, 3, 15, 7, '2', 'KD 2', 'P', 0, 'Memahami lagu dolanan dan tembang macapat kinanti');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (638, 3, 15, 7, '2', 'KD 3', 'P', 0, 'Memahami teks khusus yang berupa kalimat sederhana beraksara jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (639, 3, 15, 7, '2', 'KD 1', 'K', 0, 'Menyusun geguritan sederhana');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (640, 3, 15, 7, '2', 'KD 2', 'K', 0, 'Melagukan lagu dolanan dan tembang macapat kinanti');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (641, 3, 15, 7, '2', 'KD 3', 'K', 0, 'Membaca dan menulis kalimat sederhana beraksara jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (645, 6, 3, 7, '2', '3.1', 'P', 0, 'Ketentuan salat Jum\'at');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (646, 6, 3, 7, '2', '3.2', 'P', 0, 'Ketentuan Khutbah Jum\'at');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (647, 2, 6, 8, '2', '4.10', 'K', 0, 'Menyajikan informasi dan data dalam bentuk teks eksplanasi proses terjadinya fenomena alam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (648, 6, 3, 7, '2', '3.3', 'P', 0, 'Ketentuan Jama\' danQashar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (649, 2, 6, 8, '2', '4.11', 'K', 0, 'Menceritakan kembali isi teks ulasan tentang kualitas karya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (650, 6, 3, 7, '2', '3.4', 'P', 0, 'Kaifiat salat ketika sakit');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (651, 2, 6, 8, '2', '4.12', 'K', 0, 'Menyajikan tanggapan tentang kualitas karya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (652, 2, 6, 8, '2', '4.13', 'K', 0, 'Menyimpulkan isi saran, ajakan, arahan, pertimbangan tentang hal positif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (653, 6, 3, 7, '2', '3.5', 'P', 0, 'Ketentuan salat sunat muakad');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (655, 2, 6, 8, '2', '4.14', 'K', 0, 'Menyajikan teks persuasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (656, 2, 6, 8, '2', '4.15', 'K', 0, 'Menginterpretasi drama');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (657, 2, 6, 8, '2', '4.16', 'K', 0, 'Menyajikan drama dalam bentuk pentas/naskah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (658, 2, 6, 8, '2', '4.17', 'K', 0, 'Membuat peta konsep/garis alur dari buku fiksi dan non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (659, 6, 3, 7, '2', '3.6', 'P', 0, 'Salat sunat gairu muakad');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (660, 6, 3, 7, '2', '4.1', 'K', 0, 'Mempraktekan salat Jumat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (661, 6, 3, 7, '2', '4.2', 'K', 0, 'Mendemonstrasikan khutbah Jumat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (662, 6, 3, 7, '2', '4.3', 'K', 0, 'Mempraktikan salat sunat muakad');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (663, 6, 3, 7, '2', '4.4', 'K', 0, 'Mempraktikan salat sunat gairu muakad');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (664, 2, 6, 8, '2', '3.10', 'P', 0, 'Menelaah teks eksplanasi berupa paparan kejadian alam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (665, 2, 6, 8, '2', '3.11', 'P', 0, 'Mengidentifikasi informasi pada teks ulasan tentang kualitas karya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (666, 2, 6, 8, '2', '3.12', 'P', 0, 'Menelaah struktur dan kebahasaan teks ulasan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (667, 2, 6, 8, '2', '3.13', 'P', 0, 'Mengidentifikasi jenis saran, ajakan, arahan, dan pertimbangan tentang berbagai hal positif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (668, 2, 6, 8, '2', '3.14', 'P', 0, 'Menelaah struktur dan kebahasaan teks persuasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (669, 2, 6, 8, '2', '3.15', 'P', 0, 'Mengidentifikasi unsur-unsur drama');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (670, 2, 6, 8, '2', '3.16', 'P', 0, 'Menelaah karakteristik unsur dan kaidah kebahasaan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (671, 2, 6, 8, '2', '3.17', 'P', 0, 'Menggali dan menemukan informasi dari buku fiksi dan non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (672, 1, 16, 7, '2', 'KD.1', 'P', 0, 'membaca ayat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (673, 1, 16, 7, '2', 'KD.2', 'P', 0, 'menulis ayat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (674, 1, 16, 7, '2', 'KD.3', 'P', 0, 'menghafal surat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (675, 1, 16, 7, '2', 'KD.4', 'P', 0, 'menerjemahkan surat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (678, 1, 16, 7, '2', 'KD3', 'K', 0, 'menghafal');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (680, 5, 5, 7, '2', '3.5', 'P', 0, 'Memahami keberagaman suku, agama, ras, budaya, gender dalam bingkau Bhinneka Tunggal Ika');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (681, 5, 5, 7, '2', '3.6', 'P', 0, 'Memahami pengertian dan makna NKRI');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (682, 5, 5, 7, '2', '3.7', 'P', 0, 'Memahami daerah temoat tinggalnya dalam kerangka NKRI');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (683, 5, 5, 7, '2', '4.5', 'K', 0, 'Berinterakasi dengan orang lain berdasarkan prinsip Bhenika Tunggal Ika');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (684, 5, 5, 7, '2', '4.6', 'K', 0, 'Menampilkan perilakui kebersatuan dalam keberagaman');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (685, 5, 5, 7, '2', '4.7', 'K', 0, 'Menyajikan karakteristik daerah tempat tinggal');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (686, 6, 3, 8, '2', '3.1', 'P', 0, 'Ketentuan shadaqah,hibah dan hadiah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (687, 6, 3, 8, '2', '3.2', 'P', 0, ' Tata cara melaksanakan haji');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (688, 6, 3, 8, '2', '3.3', 'P', 0, 'Tata cara melaksakan umrah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (689, 6, 3, 8, '2', '3.4', 'P', 0, 'Ketentuan makanan halal-haram');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (690, 6, 3, 8, '2', '3.5', 'P', 0, 'Ketentuan minuman halal-haram');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (691, 6, 3, 8, '2', '3.5', 'P', 0, 'Ketentuan minuman halal-haram');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (692, 6, 3, 8, '2', '4.1', 'K', 0, 'Tata cara shadaqah,hibah,dan hadiah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (693, 6, 3, 8, '2', '4.2', 'K', 0, 'Tata cara haji dan umrah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (694, 6, 3, 8, '2', '4.3', 'K', 0, 'Tata cara mengkonsumsi makanan,minuman halal dan baik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (695, 11, 8, 8, '2', '311', 'P', 0, 'Menaksir dan menghitung Luas dan Volume bangun ruang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (696, 11, 8, 8, '2', '312', 'P', 0, 'Memahami konsep perbandingan dan menggunakan tabel grafik dan persamaan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (697, 11, 8, 8, '2', '313', 'P', 0, 'Menemukan peluang empirik dan teoritikal dari data');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (698, 11, 8, 8, '2', '314', 'P', 0, 'memahami teknik penyajian data dua variabel pada grafik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (699, 11, 8, 8, '2', '46', 'K', 0, 'Menyelesaikan permasalahan hubungan sudut pusat, panjang busur dan luas juring');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (700, 11, 8, 8, '2', '47', 'K', 0, 'mengolah dan menginterpretasikan data dalam bentuk tabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (701, 11, 8, 8, '2', '48', 'K', 0, 'melakukan percobaan untuk peluang empirik dibandingkan peluang teoritik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (702, 3, 15, 8, '2', 'KD 1', 'P', 0, 'Memahami puisi jawa (geguritan)');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (703, 3, 15, 8, '2', 'KD 2', 'P', 0, 'Memahami tembang macapat pangkur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (704, 3, 15, 8, '2', 'KD 3', 'P', 0, 'Memahami teks khusus kalimat sederhana beraksara jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (705, 3, 15, 8, '2', 'KD 1', 'K', 0, 'Membaca geguritan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (706, 3, 15, 8, '2', 'KD 2', 'K', 0, 'Melagukan tembang macapat pangkur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (707, 3, 15, 8, '2', 'KD 3', 'K', 0, 'Mebaca,menulis kalimat beraksara jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (708, 6, 1, 8, '2', '3.1', 'P', 0, 'Ketentuan hukum bacaan lam dan ra\' dalam Al-Qur\'an');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (709, 6, 1, 8, '2', '3.2', 'P', 0, 'Kandungan QS.al-Humazah dan QS.at-Kasur tentang sifat cinta dunia dan melupakan kebahagiaan hakiki');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (710, 6, 1, 8, '2', '3.3', 'P', 0, 'Kandungan Hadis tentang perilaku keseimbangan hidup di dunia dan akhirat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (711, 6, 1, 8, '2', '4.1', 'K', 0, 'Hukum bacaan lam dan ra\' dalam QS.al-Humazah QS.at-Takasur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (712, 6, 1, 8, '2', '4.2', 'K', 0, 'Sikap sesui dengan isi kandungan QS.al-Humazah QS.at-Takasur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (713, 6, 1, 8, '2', '4.3', 'K', 0, 'Sikap hidup seimbang antara dunia dan akhirat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (714, 2, 6, 8, '2', '3.18', 'P', 0, 'Menelaah unsur buku fiksi dan non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (715, 2, 6, 8, '2', '4.18', 'K', 0, 'Menyajikan tanggapan terhadap buku fiksi dan non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (716, 13, 13, 9, '1', 'KD 01', 'P', 0, 'Memahami konsep permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (717, 13, 13, 9, '1', 'KD 02', 'P', 0, 'Memahami konsep permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (718, 13, 13, 9, '1', 'KD 03', 'P', 0, 'Memahami konsep nomor atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (719, 13, 13, 9, '1', 'KD 05', 'P', 0, 'Memahami konsep senam lantai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (720, 13, 13, 9, '1', 'KD 06', 'P', 0, 'Memahami konsep aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (721, 13, 13, 9, '1', 'KD 07', 'P', 0, 'Memahami konsep kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (722, 13, 13, 9, '1', 'KD 01', 'K', 0, 'Mempraktikkan permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (723, 13, 13, 9, '1', 'KD 02', 'K', 0, 'Mempraktikkan permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (724, 13, 13, 9, '1', 'KD 03', 'K', 0, 'Mempraktikkan nomor atletik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (725, 13, 13, 9, '1', 'KD 05', 'K', 0, 'Mempraktikkan senam lantai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (726, 13, 13, 9, '1', 'KD 06', 'K', 0, 'Mempraktikkan aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (727, 13, 13, 9, '1', 'KD 07', 'K', 0, 'Mempraktikkan latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (728, 8, 9, 9, '1', '3.1', 'P', 0, 'Memahami sistem reproduksi manusia dan gangguan sistem reproduksi serta penerapan pola hidup yang me');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (729, 8, 9, 9, '1', '3.2', 'P', 0, 'Memahami sistem perkembangbiakan pada tumbuhan dan hewan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (730, 5, 10, 7, '1', '3.1', 'P', 0, 'Memahami konsep ruang dan interaksi antar ruang diindonesia serta pengaruh thd kehidupan manusia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (731, 5, 10, 7, '1', '3.2', 'P', 0, 'Mengidentifikasi interaksi sosial dalam ruang dan pengaruhnta thd kehidupan Km');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (732, 5, 5, 8, '1', '3.1', 'P', 0, 'Menelaah pancasila sbg dasar negara dan pandangan hidup bangsa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (733, 5, 5, 8, '1', '3.2', 'P', 0, 'Menelaah makna dan fungsi uud ri 1945 serta peraturan perundang undangan lainya dlm sistem hukum nas');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (734, 5, 5, 8, '1', '3.3', 'P', 0, 'Memahami tata urutan peraturan perundang undangan dalam sistem hukum nasional diindonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (735, 19, 6, 8, '1', 'K01', 'P', 0, 'Mengidentifikasi dan menelaah struktur dan unsur-unsur berita');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (736, 5, 10, 7, '1', '4.1', 'K', 0, 'Menjelaskan konsep ruang dan interaksi antar ruang di Indonesia serta pengaruhnya thd kehidupan manu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (737, 19, 6, 8, '1', 'K02', 'P', 0, 'Mengidentifikasi informasi dan menelaah pola penyajian dan unsur kebahasaan iklan,slogan,dan poster');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (738, 19, 6, 8, '1', 'K03', 'P', 0, 'Mengidentifikasi informasi, menelaah struktur dan kebahasaan teks eksposisi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (739, 19, 6, 8, '1', 'K04', 'P', 0, 'Mengidentifikasi dan menelaah unsur-unsur pembangun teks puisi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (740, 19, 6, 8, '1', 'K05', 'P', 0, 'Mengidentifikasi dan menelaah teks eksplanasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (741, 5, 10, 7, '1', '4.2', 'K', 0, 'Menyajikanhasil identifikasi tentang interaksi sosial dlm ruang dan pengaruhnya thd kehidupan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (742, 19, 6, 8, '1', 'K01', 'K', 0, 'Menyimpulkan dan menyajikan data dan informasi dalam bentuk teks berita');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (743, 19, 6, 8, '1', 'K02', 'K', 0, 'Menyimpulkan dan menyajikan gagasan,pesan, dan ajakan dalam bentuk iklan, slogan dan poster');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (744, 19, 6, 8, '1', 'K03', 'K', 0, 'Menyimpulkan isi, menyajikan gagasan dan pendapat dalam bentuk teks eksposisi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (745, 19, 6, 8, '1', 'K04', 'K', 0, 'Menyimpulkan, menyajikan gagasan, perasaan, dan pendapat dalam bentuk puisi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (746, 19, 6, 8, '1', 'K05', 'K', 0, 'Meringkas, menyajikan informasi dalam bentuk teks eksplanasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (747, 8, 9, 9, '1', '3.3', 'P', 0, 'Menerapkan konsep pewarisan sifat dalam pemuliaan dan kelangsungan makhluk hidup');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (748, 8, 9, 9, '1', '3.4', 'P', 0, 'Memahami konsep listrik statis dan gejalanya dalam kehidupan sehari hari termasuk kelistrikan pada s');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (749, 0, 9, 9, '1', '3.5', 'P', 0, 'Menerapkan konsep rangkaian listrik, energi dan daya listrik sumber energi listrik serta upaya mengh');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (750, 0, 9, 9, '1', '3.6', 'P', 0, 'Menerapkan konsep kemagnetan, induksi elektromagnetik dan pemanfaatan medan magnet termasuk pergerak');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (751, 15, 15, 8, '1', '3.1', 'P', 0, 'Memahami berbagai fungsi teks lisan sesuai dengan unggah -ungguh jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (752, 15, 15, 8, '1', '3.2', 'P', 0, 'memahami strategi menyimak berita berbahasa jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (754, 5, 5, 8, '1', '4.1', 'K', 0, 'menyaji hasil telaah nilai nilai pancasila sbg dasar negara dan pandangan hidup');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (755, 5, 5, 8, '1', '4.2', 'K', 0, 'menyajikan telaah makna kedudukan dan fungsi uud negara ri 45 dalam penerapan kehidupan sehari hari');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (756, 5, 5, 8, '1', '4.3', 'K', 0, 'mendemonstrasikan pola pengembangan tata urutan perundang undangan di indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (757, 14, 5, 9, '1', '3.1', 'P', 0, 'Mensyukuri Perwujudan Pancasila Sebagai Dasar Negara yang merupakan anugerah Tuhan yang Maha Esa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (758, 14, 5, 9, '1', '3.2', 'P', 0, 'Menghargai isi alenia dan pokok pikiran yang terkandung dalam Pembukaan Undang - Undang Dasar Negara');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (759, 14, 5, 9, '1', '3.3', 'P', 0, 'Bersyukur Kepada Tuhan yang Maha Esa atas bentuk dan kedaulatan negara Republik Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (760, 14, 5, 9, '1', '3.4', 'P', 0, 'Menghormati dan Mengapresiasi Prinsip harmoni dalam keberagaman');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (761, 14, 5, 9, '1', '3.5', 'P', 0, 'Menunjukan perilaku orang beriman dalam mencintai tanah air dalam bentuk Negara Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (762, 14, 5, 9, '1', '4.1', 'K', 0, 'Menunjukan sikap bangga dan bertanggung jawab akan tanah air ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (763, 14, 5, 9, '1', '4.2', 'K', 0, 'Melaksanakan isi alenia dan pokok pikiran yang terkandung dalam pembukaan Undang - Undang Dasar RI');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (764, 14, 5, 9, '1', '4.3', 'K', 0, 'Mengutamakan sikap tolerandalam menghadapi masalah akibat keberagaman ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (765, 14, 5, 9, '1', '4.4', 'K', 0, 'Menunjukan sikap peduli terhadap masalah - masalah yang muncul dalam bidang sosial, budaya, ekonomi,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (766, 14, 5, 9, '1', '4.5', 'K', 0, 'Mengutamakan sikap disiplin sebagai warga negara ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (767, 16, 2, 9, '1', 'K01', 'P', 0, 'Memahami pengertian beriman kepada hari Akhir dalil/ buktinya, serta tanda dan peristiwa yang berhub');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (771, 16, 2, 9, '1', 'K02', 'P', 0, 'Memahami macam-macam alam gaib yang berhubungan dengan Hari Akhir (\'alam barzakh, yaumul ba\'ts, yaum');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (772, 16, 2, 9, '1', 'K03', 'P', 0, 'Memahami pengertian, contoh dan dampak berilmu, kerja keras, kreatif, dan produktif dalam fenomena k');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (773, 16, 2, 9, '1', 'K04', 'P', 0, 'Memahami adab Islami kepada tetangga');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (774, 16, 2, 9, '1', 'K05', 'P', 0, 'Meganalisis kisah Sahabat Umar bin Khattab ra');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (775, 16, 2, 9, '1', 'KD01', 'K', 0, 'Menyajikan data dari berbagai sumber tantang fakta dan fenomena hari Akhir dan alam gaib lain yang b');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (776, 16, 2, 9, '1', 'KD02', 'K', 0, 'Menyajikan contoh perilaku berilmu, kerja keras, kreatif dan produktif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (777, 16, 2, 9, '1', 'KD03', 'K', 0, 'menyajikan kisah-kisah dari fenomena kehidupan tentang dampak positif dari berilmu, kerja keras, kre');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (778, 16, 2, 9, '1', 'KD04', 'K', 0, 'Mensimulasikan adab islami kepada tetangga');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (779, 16, 2, 9, '1', 'KD05', 'K', 0, 'menceritakan kisah keteladanan sahabat Umar bin Khattab ra');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (780, 16, 4, 9, '1', 'KD01', 'P', 0, 'Memahami sejarah masuknya Islam di Nusantara melalui perdagangan, sosial dan pengajaran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (781, 16, 4, 9, '1', 'KD02', 'P', 0, 'Memahami bukti masuknya Islam di Nusantara abad ke-7, ke-11 dan ke-13.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (782, 16, 4, 9, '1', 'KD03', 'P', 0, 'Memahami faktor penyebab mudahnya perkembangan islam di Nusantara');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (783, 16, 4, 9, '1', 'KD04', 'P', 0, 'Memahami sejarah kerajaan Islam di Jawa, Sumatera, dan Sulawesi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (784, 16, 4, 9, '1', 'KD05', 'P', 0, 'Memahami para tokoh beserta perannya dalam perkembangan Islam di Indonesia (Walisongo, Syaikh Abdur ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (785, 16, 4, 9, '1', 'KD06', 'P', 0, 'Memahami peran para tokoh dalam perkembangan Islam di Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (786, 16, 4, 9, '1', 'KD07', 'P', 0, 'Menerapkan semangat perjuangan walisongo dalam menyebarkan agama Islam di Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (787, 16, 4, 9, '1', 'KD08', 'P', 0, 'Memahami semangat perjuangan Abdur Ra\'uf As singkili, Muhammad Arsyad al- Banjari, Kh. Hasyim Asy\'ar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (788, 16, 4, 9, '1', 'KD01', 'K', 0, 'Menceritakan alur perjalanan para pedagang Arab dalam berdakwah di Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (789, 16, 4, 9, '1', 'KD02', 'K', 0, 'Menceritakan perjuangan walisongo dalam menyebarkan agama Islam di Indonesia.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (790, 16, 4, 9, '1', 'KD03', 'K', 0, 'Menceritakan biografi Abdur rauf as- singkili, Muhammad Arsyad al-Banjari, KH. Hasyim Asy\'ari dan KH');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (791, 8, 9, 9, '1', '4.1', 'K', 0, 'Menyajikan hasil penelusuran informasi terkait kesehatan dan upaya pencegahan gangguan pada organ re');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (792, 8, 9, 9, '1', '4.2', 'K', 0, 'Menyajikan karya hasil perkembangbiakan pada tumbuhan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (793, 8, 9, 9, '1', '4.3', 'K', 0, 'Menyajikan hasil penelusuran informasi terkait tentang tanaman dan hewan hasil pemuliaan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (794, 8, 9, 9, '1', '4.4', 'K', 0, 'Menyajikan hasil pengamatan tentang gejala listrik statis dalam kehidupan sehari-hari');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (795, 8, 9, 9, '1', '4.5', 'K', 0, 'Menyajikan hasil rancangan dan pengukuran berbagai rangkaian listrik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (796, 20, 6, 7, '1', 'KD3.1', 'P', 0, 'Mengidentifikasi informasi dan menelaah struktur dan kebahasaan teks deskripsi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (797, 20, 6, 7, '1', 'KD3.2', 'P', 0, 'Mengidentifikasi informasi dan menelaah struktur dan kebahasaan teks fantasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (798, 20, 6, 7, '1', 'KD3.3', 'P', 0, 'Mengidentifikasi informasi dan menelaah struktur dan kebahasaan teks prosedur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (799, 20, 6, 7, '1', 'KD3.4', 'P', 0, 'Mengidentifikasi informasi dan menelaah struktur dan kebahasaan teks observasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (800, 20, 6, 7, '1', 'KD4.1', 'K', 0, 'Menjelaskan isi dan menyajikan data, gagasan dan kesan teks deskripsi secara lisan dan tulis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (801, 20, 6, 7, '1', 'KD4.2', 'K', 0, 'Menceritakan kembali dan menyajikan gagasan kreatif teks fantasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (802, 20, 6, 7, '1', 'KD4.3', 'K', 0, 'Menyimpulkan isi dan menyajikan data teks prosedur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (803, 20, 6, 7, '1', 'KD4.4', 'K', 0, 'Menyimpulkan isi dan menyajikan rangkuman teks hasil observasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (804, 15, 5, 7, '1', '3.1 ', 'P', 0, 'menganalisis proses perumusan dan penetapan Pancasila sebagai Dasar Negara');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (805, 15, 5, 7, '1', '3.2', 'P', 0, 'memahami norma-norma yang berlaku dalam kehidupan bermasyarakat untuk mewujudkan keadilan HBD tv');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (806, 15, 5, 7, '1', '3.3', 'P', 0, 'menganalisis kesejahteraan perumusan da pengesyahan UUD Negara RI tahun 1945');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (807, 20, 14, 9, '1', 'KD3.1', 'P', 0, 'memahami pengetahuan tentang jenis, sifat, karakter, dan teknik pengolahan bahan kayu,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (808, 20, 14, 9, '1', 'KD3.1', 'P', 0, 'menganalisis prinsip perancangan, pembuatan, dan penyajian produk kerajinan dari bahan kayu, bambu, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (809, 20, 14, 9, '1', 'KD3.2', 'P', 0, 'menganalisis prinsip kelistrikan dan sistem instalasi listrik rumah tangga\r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (811, 20, 14, 9, '1', 'KD3.2', 'P', 0, 'menganalisis instalasi listrik rumah tangga\r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (812, 20, 14, 9, '1', 'KD3.3', 'P', 0, 'memahami komoditas ikan konsumsi yang dapat dikembangkan sesuai kebutuhan wilayah setempat\r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (813, 20, 14, 9, '1', 'KD3.3', 'P', 0, 'memahami sarana dan peralatan untuk budidaya ikan konsumsi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (814, 20, 14, 9, '1', 'KD3.3', 'P', 0, 'memahami tahapan budidaya (pembesaran) ikan konsumsi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (815, 20, 14, 9, '1', 'KD3.4', 'P', 0, 'memahami  tentang prinsip perancangan, pembuatan, penyajian, dan pengemasan hasil peternakan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (818, 20, 14, 9, '1', 'KD4.1', 'K', 0, 'memilih jenis bahan dan teknik pengolahan bahan kayu dan bambu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (819, 20, 14, 9, '1', 'KD4.1', 'K', 0, 'merancang, membuat, dan menyajikan produk kerajinan dari bahan kayu, bambu, dan atau rotan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (820, 20, 14, 9, '1', 'KD4.2', 'K', 0, 'membuat desain konstruksi instalasi listrik rumah tangga');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (821, 20, 14, 9, '1', 'KD4.2', 'K', 0, 'membuat instalasi listrik rumah tangga');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (822, 20, 14, 9, '1', 'KD4.3', 'K', 0, 'menentukan komoditas ikan konsumsi yang dapat dikembangkan sesuai kebutuhan wilayah setempat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (823, 20, 14, 9, '1', 'KD4.3', 'K', 0, 'menyiapkan sarana dan peralatan untuk budidaya ikan konsumsi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (824, 20, 14, 9, '1', 'KD4.3', 'K', 0, 'mempraktikkan budidaya (pembesaran) ikan konsumsi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (825, 20, 14, 9, '1', 'KD4.4', 'K', 0, 'mengolah bahan pangan hasil peternakan dan perikanan yang ada di wilayah setem');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (826, 1, 16, 8, '1', '4.3', 'P', 0, 'Menghafal');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (827, 1, 16, 8, '1', '4.4', 'P', 0, 'Menulis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (828, 1, 16, 8, '1', '4.5', 'P', 0, 'Membaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (829, 1, 16, 8, '1', '4.6', 'P', 0, 'Menerjemahkan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (830, 1, 16, 8, '1', '4.3', 'K', 0, 'Menghafal');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (831, 1, 16, 8, '1', '4.4', 'K', 0, 'Membaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (832, 1, 16, 8, '1', '4.5', 'K', 0, 'Menulis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (833, 1, 16, 8, '1', '4.6', 'K', 0, 'Menerjemah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (837, 1, 15, 9, '1', '4.3', 'P', 0, 'Menghargai dan menghayati ajaran agama yang dianut');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (838, 1, 15, 9, '1', '4.4', 'P', 0, 'Menghargai dan menghayati perilaku jujur, disiplin, tanggungjawab, peduli dan santun dalam lingkunga');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (839, 1, 15, 9, '1', '4.5', 'P', 0, 'Memahami pengetahuan (faktual, konseptual dan prosedural) berdasar rasa ingin tau tentang iptek seni');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (840, 1, 15, 9, '1', '4.6', 'P', 0, 'Mencoba, mengolah dan menyajikan dalam ranah konkret');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (841, 3, 12, 9, '1', 'K01', 'P', 0, 'Memahami konsep dan prosedur karya seni lukis dengan beragammedia dan teknik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (842, 3, 12, 9, '1', 'KD 2', 'P', 0, 'Memahami konsep dan prosedur karya seni patung dengan beragam media dan teknik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (843, 3, 12, 9, '1', 'KD 3', 'P', 0, 'Memahami cara mengubah musik modern secara unisono atau perorangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (844, 3, 12, 9, '1', 'KD 4 ', 'P', 0, 'Memahami teknik bernyanyi modern');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (845, 3, 12, 9, '1', 'KD 1', 'K', 0, 'Membuat karya seni lukis dengan berbagai media teknik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (846, 3, 12, 9, '1', 'KD 2', 'K', 0, 'Membuat karya seni patung dengan beragam media dan teknik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (847, 3, 12, 9, '1', 'KD 3', 'K', 0, 'Menggubahmusik modern secara unisono');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (848, 3, 12, 9, '1', 'KD 4 ', 'K', 0, 'Menyanyikan musik modern secara perorangan atau kelompok');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (849, 15, 10, 9, '1', '3:2', 'P', 0, 'Menelaah perubahan masyarakat Indonesia di zaman kemerdekaan sampai awal reformasi dalam segala aspe');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (850, 15, 10, 9, '1', '31', 'P', 0, 'Menerapkan aspek keruangan dan konektifitas antar ruangan waktu dalam mewujudkan kesatuan wilayah Nu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (853, 8, 9, 9, '1', '3.5', 'P', 0, 'Menerapkan konsep rangkaian listrik, energi dan daya listrik, sumber energi listrik serta menghemat ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (854, 20, 14, 9, '1', 'KD3.4', 'P', 0, 'menganalisis prinsip perancangan, pembuatan, penyajian, dan pengemasan bahan pangan hasil peternakan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (855, 20, 14, 9, '1', 'KD4.4', 'K', 0, 'membuat bahan pangan setengah jadi dari bahan pangan hasil peternakan  dan perikanan  yang ada di wi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (856, 15, 10, 9, '1', '4.1', 'K', 0, 'menyajikan hasil pengolahan telaah tentang hasil-hasil kebudayaandanfikiran masyarakat indonesia pad');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (857, 15, 10, 9, '1', '4.2', 'K', 0, 'merumuskan alternatif tindakan nyata dalam mengatasi,masalah yangkelembagaan sosial,budaya ,ekonomi ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (858, 20, 14, 8, '1', 'KD3.4', 'P', 0, 'menganalisis rancangan pembuatan, penyajian, dan pengemasan bahan pangan serealia, kacang-kacangan, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (859, 15, 5, 7, '1', '4.1', 'K', 0, 'menyajikan hasil analisisnproses perumusan dan penetapan Pancasila sebagai Dasar negara');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (860, 15, 5, 7, '1', '4.2', 'K', 0, 'mengupayakan perilaku sesuai norma-norma yang berlaku dalam kehidupan bermasyarakat untuk mewujudkan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (861, 15, 5, 7, '1', '4.3', 'K', 0, 'menjelaskan proses kesejarahan perumusan dan pengesyaha UUD Negara RI tahun 1945');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (862, 9, 8, 8, '1', '3.4', 'P', 0, 'Menjelaskan Gradien, Persamaan, dan grafik garis lurus');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (863, 20, 14, 8, '1', 'KD4.4', 'K', 0, 'mengolah, menyaji dan mengemas bahan pangan serealia, kacang- kacangan dan umbi yang ada di wilayah ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (864, 9, 8, 8, '1', '3.5', 'P', 0, 'Menjelaskan SPLDV dan penyelesaianya dengan masalah kontektual');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (865, 9, 8, 8, '1', '4.5', 'K', 0, 'Menyelesaikan masalah yang berkaitan dg SPLDV');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (867, 7, 7, 9, '1', '(KD1)', 'K', 0, 'Mendemontrasikan ungkapan sederhana tentang topik ro\'sussanatilhijriyatiljadidah, alhaflu bimaulidir');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (868, 7, 7, 9, '1', '(KD2)', 'K', 0, 'Menunjukkan ungkapan sederhana tentang topik ro\'sussanatilhijriyatiljadidah,alhaflu bimaulidirrosul,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (869, 7, 7, 9, '1', '(KD3)', 'K', 0, 'Menyampaikan info lisan tentang topik rosussanatilhijriyatiljadidah, alhaflu bimaulidirrosul, nuzulu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (870, 7, 7, 9, '1', '(KD4)', 'K', 0, 'Mengungkapkan info scr tertulis sederhana tentang topik rosussanatilhijriyatiljadidah, alhaflu bimau');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (871, 7, 7, 9, '1', '(KD5)', 'K', 0, 'Menyusun teks sederhana tentang topik rosussanatilhijriyatildadidah, alhaflu bimaulidirrosul, nuzulu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (872, 15, 15, 8, '1', '4.3', 'K', 0, 'menyusun tanggapan siaran berita berbahasa jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (873, 12, 11, 9, '1', '3.1', 'P', 0, 'Teks lisan dan tulis tentang tindakan menyatakan harapan,doa dan ucapan selamat.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (874, 12, 11, 9, '1', '3.2', 'P', 0, 'teks lisan dan tulis tentang memberi dan meminta informasi serta persetujuan dan ketidaksetujuan.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (875, 12, 11, 9, '1', '3.3', 'P', 0, 'Teks lisan dan tulis tentang label makanan/minuman dan obat.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (876, 12, 11, 9, '1', '3.4', 'P', 0, 'Teks lisan dan tulis prosedur membuat makanan/minuman dan manual.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (877, 12, 11, 9, '1', '3.5', 'P', 0, 'Teks lisan dan tulis tentang present continuous tense, past contunuous tense dan future tense.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (878, 12, 11, 9, '1', '3.6', 'P', 0, 'Teks lisan dan tulis tentang present perfect tense.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (879, 12, 11, 9, '1', '4.1', 'K', 0, 'Menyusun teks lisan dan tulis tentang tindakan menyatakan harapan, doa dan ucapan selamat.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (880, 12, 11, 9, '1', '4.2', 'K', 0, 'Menyusun teks lisan dan tulis tentang meminta dan memberi informasi serta persetujuan dan ketidakset');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (881, 12, 11, 9, '1', '4.3', 'K', 0, 'Menangkap makna teks label makanan/minuman dan obat.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (882, 12, 11, 9, '1', '4.4', 'K', 0, 'Menangkap makna teks prosedur resep makanan/minuman dan manual.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (883, 12, 11, 9, '1', '4.5', 'K', 0, 'Menyusun teks lisan dan tulis tentang present continuous tense, past continuous tense dan future ten');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (884, 12, 11, 9, '1', '4.6', 'K', 0, 'Menyusun teks lisan dan tulis tentang present perfect tense.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (885, 7, 7, 8, '1', '(KD4)', 'K', 0, 'Mengungkapkan info scr tertulis tentang topik assa\'ah,yaumiyatuna filmadrosah dan yaumiyatuna fil ba');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (886, 7, 7, 8, '1', '(KD5)', 'K', 0, 'Menyusun teks sederhana tentang assa\'ah,yaumiyatuna fil madrosah dan yaumiyatuna fil baiti');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (888, 7, 7, 9, '1', '(KD1)', 'P', 0, 'Mengidentifikasi bunyi, kata,frasa dan kal b Arab yang terkait dengan ro\'susanatilhijriyatiljadidah,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (889, 11, 8, 9, '1', 'kd3', 'P', 0, 'memahami konsep kesebangunan dan kekongruenan geometri melalui pengamatan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (890, 11, 8, 9, '1', 'kd4', 'P', 0, 'menentukan luas selimut dan volume tabung, kerucut dan bola');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (891, 7, 7, 9, '1', '(KD2)', 'P', 0, 'Melafalkan bunyi,kata,frasa dan kal b Arab tentang ro\'sussanatilhijriyatiljadidah,alhaflu bimaulidir');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (892, 11, 8, 9, '1', 'kd5', 'P', 0, 'menentukan rata-rata, median dan modus dari berbagai jenis data');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (893, 7, 7, 9, '1', '(KD3)', 'P', 0, 'Menemukan makna kata,frasa dan kal b Arab tentang ro\'sussanatilhijriyatiljadidah, alhaflu bimaulidir');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (894, 11, 8, 9, '1', 'kd1', 'K', 0, 'menggunakan konsep perbandingan untuk menyelesaikan masalah nyata mencakup perbandingan bertingkat d');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (895, 11, 8, 9, '1', 'kd2', 'K', 0, 'mengenal pola bilangan, barisan, deret dan semacam dan menggunakan untuk menyelesaikan masalan nyata');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (896, 11, 8, 9, '1', 'kd3', 'K', 0, 'menyelesaikan masalah nyata hasil pengamatan yang terkait penerapan kesebangunan dan kekongruenan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (897, 11, 8, 9, '1', 'kd04', 'K', 0, 'mengumpulkan, mengolah, menginterprestasi dan menampilkan data hasil pengamatan dalanm bentuk tabel ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (898, 2, 6, 9, '1', '3.1.2', 'P', 0, 'Mengidentifikasi , menelaah struktur dan kebahasaan teks lanoran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (899, 2, 6, 9, '1', '3.3.4', 'P', 0, 'Mengidentifikasi , menelaah struktur dan ciri-');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (900, 2, 6, 9, '1', '3.5.6', 'P', 0, 'Mengidentifikasi,menelaah struktur dan unsur-unsur pembangun cerpen');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (901, 2, 6, 9, '1', '3.7.8', 'P', 0, 'Mengidentifikasi,menelaah struktur dan kebahasaan teks tanggapan.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (902, 2, 6, 9, '1', '3.9.1', 'P', 0, 'Mengidentifikasi,menelaah pendapat dan argumen dlm teks diskusi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (903, 2, 6, 9, '1', '4.1.2', 'K', 0, 'Menyimpulkan,menyajikan tujuan,bahan,alat langkah dan hasil laporan.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (904, 11, 8, 8, '1', 'kd5', 'P', 0, 'menjelaskan SPLDV dan menyelesaikannya dengan masalah kontektual');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (905, 2, 6, 9, '1', '4.3.4', 'K', 0, 'Menyimpulkan,menuangkan gagasan,pikiran arahan dan pesan pidato');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (906, 2, 6, 9, '1', '4.5.6', 'K', 0, 'Menyimpulkan,mengungkapkan pengalaman ,gagasan dan unsur-unsur pembangun cerpen.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (908, 2, 6, 9, '1', '4.7.8', 'K', 0, 'Menyimpulkan,mengungkapkan kritik,tanggapan,sanggahan dan pujian.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (909, 2, 6, 9, '1', '4.9.1', 'K', 0, 'Menyimpulkan,menyajikan gagasan/pendapat dan argumen dalam teks diskusi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (910, 7, 16, 7, '1', '(KD1)', 'P', 0, 'Menghapal dengan baik QS Annas sampai dengan Al Qodar.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (911, 7, 16, 7, '1', '(KD1)', 'K', 0, 'Melafalkan dengan fasih QS Annaas  sampai dengan Al Qodar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (912, 7, 16, 7, '1', '(KD2)', 'K', 0, 'Menulis ayat-ayat Al Quran, QS Annaas sampai dengan Al Qodar.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (913, 2, 6, 8, '1', '3.1.2', 'P', 0, 'Mengidentifikasi dan menelaah struktur dan unsur-unsur berita');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (914, 2, 6, 8, '1', '3.3.4', 'P', 0, 'Mengidentifikasi informasi dan menelaah pola penyajian dan unsur kebahasaan iklan, slogan dan poster');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (915, 2, 6, 8, '1', '3.5.6', 'P', 0, 'Mengidentifikasi Informasi, menelaah stuktur dan kebahasaan teks eskposisi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (916, 2, 6, 8, '1', '3.7.8', 'P', 0, 'Mengidentifikasi dan menelaah unsur-unsur pembangun teks puisi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (917, 2, 6, 8, '1', '3.9.1', 'P', 0, 'Mengidentifikasi dan menelaah teks ekplanasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (918, 2, 6, 8, '1', '4.1.2', 'K', 0, 'Menyimpulkan dan menyajikan data dan informasi dalam bentuk teks berita.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (919, 2, 6, 8, '1', '4.3.4', 'K', 0, 'Menyimpulkan dan menyajikan gagasan, pesan, dan ajakan dalam bentuk iklan, slogan dan poster');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (920, 2, 6, 8, '1', '4.5.6', 'K', 0, 'Menyimpulkan isi, menyajikan gagasan dan pendapat daam bentuk teks ekposisi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (921, 2, 6, 8, '1', '4.7.8', 'K', 0, 'Menyimpulkan , menyajikan gagasan, perasaan, dana pendapat dalam bentuk puisi.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (922, 2, 6, 8, '1', '4.9.1', 'K', 0, 'Meringkas, menyajikan informasi dalam bentuk teks ekplanasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (928, 6, 1, 9, '1', '3.1', 'P', 0, 'Memahami ketentuan hukum madsilah, madbadal, madtamkin, madfarqi dalam Q.S. Al Qoriah (101), Q.S. Al');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (929, 6, 1, 9, '1', '3.2', 'P', 0, 'Memahami isi kandungan Q.S. Al Qoriah (101), Q.S. Al Zazalah (99) tentang fenomena alam dalam kehidu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (930, 6, 1, 9, '1', '4.1', 'K', 0, 'menerapkan hukum madsilah, madbadal, madtamkin, dan madfarqi dalam Q.S. Al Qoriah (101), Q.S. Al Zaz');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (931, 6, 1, 9, '1', '3.3', 'P', 0, 'Memahami keterkaitan isi kandungan H.R. Tirmidzi, Ibnu Majah, Ahmad, Al Bazzar tentang perilaku menj');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (932, 6, 1, 9, '1', '4.2', 'K', 0, 'Mensimulasikan isi kandungan Q.S. Al Qoriah (101), Q.S. Al Zazalah (99) tentang fenomena alam dalam ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (933, 6, 1, 9, '1', '4.3', 'K', 0, 'Mendemonstrasikan sikap tentang upaya pelestarian alam sesuai H.R. Tirmidzi, H.R Ibnu majah, Ahmad, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (934, 6, 1, 7, '1', '3.1', 'P', 0, 'Memahami kedudukan Al Qur\'an dan Hadist sebagai pedoman hidup umat manusia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (935, 6, 1, 7, '1', '3.2', 'P', 0, 'Memahami isi kandungan Q.S. Al Fatikah (1), Annas (114), Al Falaq (113) Al Ikhlas (112) tentang ke E');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (936, 6, 1, 7, '1', '3.3', 'P', 0, 'Memahami keterkaitan isi kandungan Hadist tentang iman riwayat Ali bin Abi Tholib dari Ibnu Majah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (937, 6, 1, 7, '1', '4.1', 'K', 0, 'Membaca Q.S. Al Fatikhah, Annas, Al Falaq, Al Ikhlas dengan fasih dan tartil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (938, 6, 1, 7, '1', '4.2', 'K', 0, 'Menghafal Q.S. Al Fatikhah, Annas, Al Falaq, Al Ikhlas secara fasih dan tartil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (939, 6, 1, 7, '1', '4.3', 'K', 0, 'Menulis hadist tentang iman yang diterima Allah dan menulis hadist tentang ibadah yang diterima Alla');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (940, 6, 3, 9, '1', '3.1', 'P', 0, 'Memahami ketentuan menyembelih binatang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (941, 6, 3, 9, '1', '3.2', 'P', 0, 'Memahami ketentuan Qurban dan Aqikoh');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (942, 6, 3, 9, '1', '3.3', 'P', 0, 'Memahami ketentuan jual beli dan qirod');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (943, 6, 3, 9, '1', '3.4', 'P', 0, 'Menganalisis larangan riba');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (944, 6, 3, 9, '1', '4.1', 'K', 0, 'Mendemonstrasikan tata cara menyembelih binatang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (945, 6, 3, 9, '1', '4.2', 'K', 0, 'Menyajikan contoh tata cara pelaksanaan qurban dan aqikah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (946, 6, 3, 9, '1', '4.3', 'K', 0, 'Mempraktikan pelaksanaan jual beli dan qirod');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (947, 6, 3, 9, '1', '4.4', 'K', 0, 'Mensimulasikan tata cara menghindari riba');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (949, 1, 15, 9, '1', '4.3', 'K', 0, 'Menghargai dan menghayati ajaran agama yang dianut');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (950, 1, 15, 9, '1', '4.4', 'K', 0, 'Menghargai dan menghayati perilaku jujur, disiplin, tanggungjawab, peduli dan santun dalam lingkunga');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (951, 1, 15, 9, '1', '4.5', 'K', 0, 'Memahami pengetahuan (faktual, konseptual dan prosedural) berdasar rasa ingin tau tentang iptek seni');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (952, 1, 15, 9, '1', '4.6', 'K', 0, 'Mencoba, mengolah dan menyajikan dalam ranah konkret');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (953, 14, 5, 9, '2', '3.4', 'P', 0, 'Menganalisis prinsip persatuan dalam keberagaman suku, agama, ras, dan antargolongan (SARA), sosial,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (954, 14, 5, 9, '2', '3.5', 'P', 0, 'Menganalisis prinsip harmoni dalam keberagaman suku, agama, ras, dan antargolongan (SARA) sosial, bu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (955, 14, 5, 9, '2', '3.6', 'P', 0, 'Mengkreasikan konsep cinta tanah air/bela negara dalam konteks Negara Kesatuan Republik Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (956, 14, 5, 9, '2', '4.4', 'K', 0, 'Mendemonstrasikan hasil analisis prinsip persatuan dalam keberagaman suku, agama, ras, dan antargolo');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (957, 14, 5, 9, '2', '4.5', 'K', 0, 'Menyampaikan hasil analisis prinsip harmoni dalam keberagaman suku, agama, ras, dan antargolongan (S');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (958, 14, 5, 9, '2', '4.6', 'K', 0, 'Mengorganisasikan kegiatan lingkungan yang mencerminkan konsep cinta tanah air dalam konteks kehidup');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (959, 15, 10, 9, '2', '3.3', 'P', 0, 'Menganalisis ketergantungan\r\nantarruang dilihat dari konsep\r\nekonomi (produksi, distribusi,\r\nkonsums');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (960, 15, 10, 9, '2', '3.4', 'P', 0, 'Menganalisis kronologi, perubahan\r\ndan kesinambungan ruang (geografis,\r\npolitik, ekonomi, pendidikan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (961, 15, 10, 9, '2', '4.3', 'K', 0, 'Menyajikan hasil analisis tentang ketergantungan antarruang dilihat dari konsep ekonomi (produksi, d');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (962, 15, 10, 9, '2', '4.4', 'K', 0, 'Menyajikan hasil analisis kronologi, perubahan dan kesinambungan ruang (geografis, politik, ekonomi,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (963, 13, 13, 9, '2', 'KD 01', 'P', 0, 'Memahami konsep permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (964, 13, 13, 9, '2', 'KD 02', 'P', 0, 'Memahami konsep permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (965, 13, 13, 9, '2', 'KD 06', 'P', 0, 'Memahami konsep aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (966, 13, 13, 9, '2', 'KD 07', 'P', 0, 'Memahami konsep latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (967, 13, 13, 9, '2', 'KD 01', 'K', 0, 'Mempraktikkan permainan bola besar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (968, 13, 13, 9, '2', 'KD 02', 'K', 0, 'Mempraktikkan permainan bola kecil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (969, 13, 13, 9, '2', 'KD 06', 'K', 0, 'Mempraktikkan aktivitas ritmik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (970, 13, 13, 9, '2', 'KD 07', 'K', 0, 'Mempraktikkan latihan kebugaran jasmani');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (971, 5, 10, 7, '2', '3.3', 'P', 0, 'Memahami konsep interaksi antara \r\nmanusia dengan ruang sehingga \r\nmenghasilkan berbagai kegiatan \r\n');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (972, 5, 10, 7, '2', '3.4', 'P', 0, '3.4 Memahami kronologi perubahan, dan \r\nkesinambungan dalam kehidupan \r\nbangsa Indonesia pada aspek ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (973, 5, 10, 7, '2', '4.3', 'K', 0, 'Menjelaskan hasil analisis tentang  konsep interaksi antara manusia  dengan ruang sehingga menghasil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (974, 5, 10, 7, '2', '4.4', 'K', 0, 'Menguraikan kronologi perubahan,  dan kesinambungan dalam  kehidupan bangsa Indonesia pada  aspek po');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (975, 8, 9, 9, '2', '3.6', 'P', 0, 'Menerapkan konsep kemagnetan, induksi elektromagnetik dan pemanfaatan medan magnet termasuk pergerak');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (976, 8, 9, 9, '2', '3.7', 'P', 0, 'Menerapkan konsep bioteknologi dan perannya dalam kehidupan manusia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (977, 8, 9, 9, '2', '3.8', 'P', 0, 'Menghubungkan konsep partikel materi ( atom,ion,molekul ) struktur zat sederhana dengan sifat bahan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (978, 8, 9, 9, '2', '3.9', 'P', 0, 'Menghubungkan sifat fisika dan kimia tanah, organisme dalam tanah dan pentingnya tanah dalam kehidup');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (979, 8, 9, 9, '2', '3.10', 'P', 0, 'Memahami proses dan produk teknologi ramah lingkungan untuk keberlanjutan kehidupan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (980, 8, 9, 9, '2', '4.6', 'K', 0, 'Membuat karya sederhana yang memanfaatkan prinsip elektromagnet');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (981, 8, 9, 9, '2', '4.7', 'K', 0, 'Membuat salah satu produk bioteknologi konvensional yang ada di lingkungan sekitar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (982, 8, 9, 9, '2', '4.8', 'K', 0, 'Menyajikan hasil penyelidikan tentang sifat dan pemanfaatan bahan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (983, 8, 9, 9, '2', '4.9', 'K', 0, 'Menyajikan hasil penyelidikan tentang sifat - sifat tanah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (984, 8, 9, 9, '2', '4.10', 'K', 0, 'Menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (985, 5, 5, 8, '2', '3.4', 'P', 0, 'Menganalisa makna dan arti\r\nKebangkitan nasional 1908 dalam\r\nperjuangan kemerdekaan Republik\r\nIndons');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (986, 5, 5, 8, '2', '3.5', 'P', 0, 'Memproyeksikan nilai dan semangat\r\nSumpah Pemuda tahun 1928 dalam\r\nbingkai Bhinneka Tunggal Ika');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (987, 5, 5, 8, '2', '3.6', 'P', 0, 'Menginterpretasikan semangat dan\r\nkomitmen kebangsaan kolektif\r\nuntuk memperkuat Negara Kesatuan\r\nRe');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (988, 5, 5, 8, '2', '4.4', 'K', 0, 'Menyaji hasil penalaran tentang tokoh kebangkitan nasional dalam perjuangan kemerdekaan Republik Ind');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (989, 5, 5, 8, '2', '4.5', 'K', 0, 'Mengaitkan hasil proyeksi nilai-nilai dan semangat Sumpah Pemuda Tahun 1928 dalam bingkai Bhineka Tu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (990, 5, 5, 8, '2', '4.6', 'K', 0, 'Mengorganisasikan kegiatan lingkungan yang mencerminkan semangat dan komitmen kebangsaan untuk mempe');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (993, 16, 2, 9, '2', '01', 'P', 0, 'Menunjukkan bukti/dalil kebenaran akan adanya Qadha dan Qadar dan ciri-ciri perilaku orang yang beri');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (994, 16, 2, 9, '2', '02', 'P', 0, 'Memahami pentingnya akhlak terpuji dalam pergaulan remaja dan dampak negatif pergaulan remaja yang t');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (995, 16, 2, 9, '2', '03', 'P', 0, 'memahami adab terhadap lingkungan yaitu kepada binatang, tumbuhan, ditempat umum dan dijalan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (996, 16, 2, 9, '2', '04', 'P', 0, 'Menganalisis kisah keteladanan sahabat Usman bin Affan dan Ali bin Abi Thalib');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (997, 16, 2, 9, '2', '01', 'K', 0, 'Menyajikan kisah-kisah dari berbagai sumber dalam fenomena kehidupan tentang Qadha dan Qadar');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (998, 16, 2, 9, '2', '02', 'K', 0, 'Menyajikan data dari berbagai sumber tentang dampak negatif pergaulan remaja yang salah dalam fenome');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (999, 16, 2, 9, '2', '03', 'K', 0, 'Mensimulasikan adab terhadap lingkungan, yaitu kepada binatang, tumbuhan, tempat umum dan jalan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1000, 16, 2, 9, '2', '04', 'K', 0, 'Menceritakan kisah keteladanan Usman bin Affan dan Ali bin Abi Thalib');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1001, 16, 4, 9, '2', '01', 'P', 0, 'Memahami bentuk tradisi, adat dan seni budaya lokal sebagai bagian dari tradisi islam (Jawa, Sunda, ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1002, 16, 4, 9, '2', '02', 'P', 0, 'Menerapkan seni budaya lokal sebagai bagian dari tradisi Islam ( Jawa, Sunda, Melayu, Bugis, Minang ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1003, 16, 4, 9, '2', '03', 'P', 0, 'Menerapkan seni budaya lokal sebagai bagian dari tradisi Islam (Jawa, Sunda, Melayu, Bugis, Minang d');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1004, 16, 4, 9, '2', '04', 'P', 0, 'Menerapkan seni budaya lokal sebagai bagian dari tradisi Islam (Jawa, Sunda, melayu, Bugis, Minang d');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1005, 16, 4, 9, '2', '05', 'P', 0, 'Menerapkan seni budaya lokal sebagai bagian dari tradisi Islam (jawa, Sunda, Melayu, Bugis, Minang d');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1006, 16, 4, 9, '2', '06', 'P', 0, 'Menerapkan Seni budaya lokal sebagai bagian dari tradisi Islam (Jawa, Sunda, Melayu, Bugis, Minang d');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1007, 16, 4, 9, '2', '01', 'K', 0, 'Menunjukkan contoh tradisi, adat dan seni budaya lokal di Jawa, Sunda, Melayu, Bugis, Minang dan Mad');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1008, 16, 4, 9, '2', '02', 'K', 0, 'Menyajikan bentuk tradisi, adat dan seni budaya lokal di Jawa, Sunda, Melayu, Bugis, Minang dan Madu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1009, 16, 4, 9, '2', '03', 'K', 0, 'Menyajikan bentuk tradisi, adat dan seni budaya lokal di Jawa, Sunda, Melayu, Bugis, Minang dan Madu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1010, 16, 4, 9, '2', '04', 'K', 0, 'Menyajikan bentuk tradisi, adat dan seni budaya lokal di Jawa, Sunda, Melayu, Bugis, Minang dan Madu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1011, 16, 4, 9, '2', '05', 'K', 0, 'Menyajikan bentuk tradisi, adat dan seni budaya lokal di Jawa, Sunda, Melayu, Bugis, Minang dan Madu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1012, 16, 4, 9, '2', '06', 'K', 0, 'Menyajikan bentuk tradisi, adat dan seni budaya lokal di Jawa, Sunda, Melayu, Bugis, Minang dan Madu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1013, 0, 14, 9, '2', '1.3.3', 'P', 0, 'memahami pengetahuan tentang\r\njenis, sifat, karakter, dan teknik\r\npengolahan bahan logam, batu, dan\r');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1014, 20, 14, 9, '2', '3.3.1', 'P', 0, 'memahami pengetahuan tentang\r\njenis, sifat, karakter, dan teknik\r\npengolahan bahan logam, batu, dan\r');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1015, 20, 14, 9, '2', '3.4.1', 'P', 0, 'menganalisis prinsip perancangan,\r\npembuatan, dan penyajian produk\r\nkerajinan dari bahan logam, batu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1016, 20, 14, 9, '2', '3.3.2', 'P', 0, 'menganalisis dasar-dasar sistem\r\nelektronika analog, elektronika\r\ndigital, dan sistem pengendali');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1017, 20, 14, 9, '2', '3.4.2', 'P', 0, 'menganalisis penerapan sistem\r\npengendali elektronik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1018, 20, 14, 9, '2', '3.4.3', 'P', 0, 'memahami komoditas ikan hias\r\nyang dapat dikembangkan sesuai\r\nkebutuhan wilayah setempat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1019, 20, 14, 9, '2', '3.5.3', 'P', 0, 'memahami sarana dan peralatan\r\nuntuk budidaya ikan hias');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1020, 20, 14, 9, '2', '3.6.3', 'P', 0, 'memahami tahapan budidaya\r\n(pembesaran) ikan hias');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1021, 20, 14, 9, '2', '3.3.4', 'P', 0, 'menganalisis prinsip perancangan,\r\npembuatan, penyajian, dan\r\npengemasan bahan pangan setengah\r\njadi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1022, 20, 14, 9, '2', '3.4.4', 'P', 0, 'menganalisis rancangan pembuatan,\r\npenyajian, dan pengemasan bahan\r\nhasil samping dari pengolahan ha');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1023, 20, 14, 9, '2', '4.3.1', 'K', 0, 'memilih jenis bahan dan teknik pengolahan bahan logam, batu, dan atau plastik,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1024, 20, 14, 9, '2', '4.4.1', 'K', 0, 'merancang, membuat, dan menyajikan produk kerajinan dari bahan logam, batu, dan atau plastik,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1025, 20, 14, 9, '2', '4.3.2', 'K', 0, 'memanipulasi sistem pengendali');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1026, 20, 14, 9, '2', '4.4.2', 'K', 0, 'membuat alat pengendali elektronik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1027, 20, 14, 9, '2', '4.4.3', 'K', 0, 'menentukan komoditas ikan hias,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1028, 20, 14, 9, '2', '4.5.3', 'K', 0, 'mengembangkan sarana dan peralatan untuk budidaya ikan hias');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1029, 20, 14, 9, '2', '4.6.3', 'K', 0, 'mempraktikkan budidaya (pembesaran) ikan hias');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1030, 20, 14, 9, '2', '4.3.4', 'K', 0, 'membuat bahan pangan setengah jadi dari hasil peternakan dan perikanan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1031, 20, 14, 9, '2', '4.4.4', 'K', 0, 'mengolah bahan hasil samping dari pengolahan hasil peternakan dan perikanan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1032, 7, 7, 9, '2', 'KD 1', 'P', 0, 'Mengidentifikasi bunyi kata,frasa dan kalimat  bahasa Arab yang berkaitan dengan tema Jamaluthobii\'a');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1033, 14, 10, 8, '2', '4.4', 'K', 0, 'analisis kronologi, perubahan dan kesinambungan ruang dari masa penjajahan sampai tumbuhnya semangat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1034, 2, 6, 9, '2', '3.9', 'P', 0, 'mengidentifikasi informasi teksdiskusi berupa pemdapat pro kontra dari permasalahan aktual yg dibaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1035, 2, 6, 9, '2', '3.10', 'P', 0, 'Menelaah pendapat dan argumen\r\nyang mendukung dan yang kontra\r\ndalam teks diskusi berkaitan\r\ndengan ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1036, 2, 6, 9, '2', '3.11', 'P', 0, 'Mengidentifikasi isi ungkapan\r\nsimpati, kepedulian, empati, atau\r\nperasaan pribadi dari teks cerita\r');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1037, 2, 6, 9, '2', '3.12', 'P', 0, 'Menelaah struktur, kebahasaan,\r\ndan isi teks cerita inspiratif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1038, 2, 6, 9, '2', '3.13', 'P', 0, 'Menggali informasi unsur-unsur\r\nbuku fiksi dan nonfiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1039, 2, 6, 9, '2', '3.14', 'P', 0, 'Menelaah hubungan antara unsur-\r\nunsur buku fiksi/nonfiksi yang\r\n\r\ndibaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1040, 2, 6, 9, '2', '3.15', 'P', 0, 'Menemukan unsur-unsur dari\r\nbuku fiksi dan nonfiksi yang dibaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1041, 2, 6, 9, '2', '3.16', 'P', 0, 'Menelaah hubungan unsur-unsur\r\ndalam buku fiksi dan nonfiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1042, 2, 6, 9, '2', '4.9', 'K', 0, 'Menyimpulkan isi gagasan, pendapat, argumen yang mendukung dan yang kontra serta solusi atas permasa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1043, 2, 6, 9, '2', '4.10', 'K', 0, 'Menyajikan gagasan/pendapat, argumen yang mendukung dan yang kontra serta solusi atas permasalahan a');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1044, 2, 6, 9, '2', '4.11', 'K', 0, 'Menyimpulkan isi ungkapan simpati, kepedulian, empati atau perasaan pribadi dalam bentuk cerita insp');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1045, 2, 6, 9, '2', '4.12', 'K', 0, 'Mengungkapkan rasa simpati, empati, kepedulian, dan perasaan dalam bentuk cerita inspiratif dengan m');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1046, 2, 6, 9, '2', '4.13', 'K', 0, 'Membuat peta konsep/garis alur dari buku fiksi dan nonfiksi yang dibaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1047, 2, 6, 9, '2', '4.14', 'K', 0, 'Menyajikan tanggapan terhadap buku fiksi dan nonfiksi yang dibaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1048, 2, 6, 9, '2', '4.15', 'K', 0, 'Membuat peta pikiran/ rangkuman alur tentang isi buku nonfiksi/ buku fiksi yang dibaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1049, 2, 6, 9, '2', '4.16', 'K', 0, 'Menyajikan tanggapan terhadap isi buku fiksi nonfiksi yang dibaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1050, 7, 7, 9, '2', 'KD 2', 'P', 0, 'Melafalkan bunyi huruf,kata,frasa dan kalimat bahasa Arab yang berkaitan dengan tema Jamaluthobi\'ah,');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1051, 1, 16, 8, '2', '4.1', 'K', 0, 'Menulis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1052, 1, 16, 8, '2', '4.2', 'K', 0, 'menghafal');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1053, 1, 16, 8, '2', '4.3', 'K', 0, 'Membaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1054, 1, 16, 8, '2', '4.4', 'K', 0, 'Menterjemahkan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1055, 12, 11, 9, '2', '3.7', 'P', 0, 'Membandingkan teks lisan dan tulis tentang naratif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1056, 12, 11, 9, '2', '3.8', 'P', 0, 'Teks lisan dan tulis meminta dan memberi informasi dengan menggunakan unsur kebahasaan passive voice');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1057, 7, 7, 9, '2', 'KD 3', 'P', 0, 'Menemukan makna atau gagasan dari ujaran kata, frasa dan kal b Arab yang berkaitan dengan Jamaluthob');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1058, 1, 16, 8, '2', '4.1', 'P', 0, 'Menulis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1059, 1, 16, 8, '2', '4.2', 'P', 0, 'Membaca');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1060, 1, 16, 8, '2', '4.3', 'P', 0, 'Menerjemahkan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1061, 1, 16, 8, '2', '4.4', 'P', 0, 'Menghapal');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1062, 12, 11, 9, '2', '3.9', 'P', 0, 'teks information report lisan dan tulis tentang memberi dan meminta informasi terkait mata pelajaran');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1063, 12, 11, 9, '2', '3.10', 'P', 0, 'Teks lisan dan tulis tentang iklan produk barang dan jasa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1064, 12, 11, 9, '2', '3.11', 'P', 0, 'Teks lisan dan tulis lirik lagu remaja');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1065, 12, 11, 9, '2', '4.7', 'K', 0, 'Menangkap makna teks lisan dan tulis tentang teks naratif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1066, 12, 11, 9, '2', '4.8', 'K', 0, 'Menyusun teks lisan dan tulis meminta dan memberi informasi dengan menggunakan unsur kebahasaan pass');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1067, 7, 7, 9, '2', 'KD 1', 'K', 0, 'Mendemontrasikan ungkapan tentang Jamaluthobi\'ah,Kholiqul \'alam dan Hafidzu\'alalbi\'ah ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1068, 12, 11, 9, '2', '4.9.1', 'K', 0, 'menangkap makna teks information report lisan dan tulis terkait topik dalam mata pelajaran lain di k');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1069, 12, 11, 9, '2', '4.9.2', 'K', 0, 'Menyusun teks lisan dan tulis report terkait topik dalam mata pelajaran lain di kelas IX');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1070, 12, 11, 9, '2', '4.10', 'K', 0, 'Menangkap makna teks lisan dan tulis teks iklan produk barang dan jasa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1071, 12, 11, 9, '2', '4.11', 'K', 0, 'Menangkap makna teks lisan dan tulis lagu remaja');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1072, 7, 7, 9, '2', 'KD 2', 'K', 0, 'Menunjukkan contoh ungkapan tentang Jamaluthobi\'ah,Kholiqul\'alam dan Hafidzu\'alalbi\'ah.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1073, 7, 7, 9, '2', 'KD3', 'K', 0, 'Menyampaikan info lisan tentang Jamaluthibi\'ah,Kholiqul \'alam dan Hafidzu\'alalbii\'ah.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1074, 7, 7, 9, '2', 'KD4', 'K', 0, 'Mengungkapkan informasi tentang Jamaluthobi\'ah, Kholiqul \'alam dan hafidzu \'alalbii\'ah.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1075, 7, 7, 9, '2', 'kd 5', 'K', 0, 'Menyusun teks sederhana tentang Jamaluthobi\'ah,Kholiqul \'alam dan Hafidzu\'alalbi\'ah.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1076, 15, 15, 8, '2', '3.5', 'P', 0, 'Memahami puisi jawa (geguritan}');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1077, 15, 15, 8, '2', '3.6', 'P', 0, 'Memahami tembang Macapat Pangkur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1078, 15, 15, 8, '2', '3.7', 'P', 0, 'Memahami teks khusus yang berupa kalimat sederhana berakasara jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1079, 15, 15, 8, '2', '4.5', 'K', 0, 'Membaca geguritan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1080, 15, 15, 8, '2', '4.6', 'K', 0, 'Melagukan tembang Macapat Pangkur');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1081, 15, 15, 8, '2', '4.7', 'K', 0, 'Membaca,menulis kalimat beraksara,Jawa');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1082, 19, 6, 8, '2', '(3.10', 'P', 0, 'Menelaah teks eksplanasi berupa paparan kejadian alam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1083, 19, 6, 8, '2', '(3.11', 'P', 0, 'Mengidentifikasi informasi pada teks ulasan tentang kualitas karya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1084, 19, 6, 8, '2', '(3.12', 'P', 0, 'Menelaah struktur dan kebahasaan teks ulasan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1085, 19, 6, 8, '2', '(3.13', 'P', 0, 'Mengidentifikasi jenis saran, ajakan,arahan, dan pertimbangan tentang berbagai hal positif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1086, 19, 6, 8, '2', '(3.14', 'P', 0, 'Menelaah struktur dan kebahasaan teks persuasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1087, 19, 6, 8, '2', '(3.15', 'P', 0, 'Mengidentifikasi unsur-unsur drama');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1088, 19, 6, 8, '2', '(3.16', 'P', 0, 'Menelaah karakteristik unsur dan kaidah kebahasaan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1089, 19, 6, 8, '2', '(3.17', 'P', 0, 'Menggali dan menemukan informasi dari buku fiksi dan non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1090, 19, 6, 8, '2', '(3.18', 'P', 0, 'Menelaah unsur buku fiksi dan non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1091, 7, 16, 7, '2', 'KD1', 'P', 0, 'Hafal Al Qur\'an dari surat Al \'Alaq sampai Asy Syams');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1092, 7, 16, 7, '2', 'kd1', 'K', 0, 'Mampu membaca dengan makhroj dan tajwid yang baik dari QS Al \'Alaq sampai Asy Syams.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1093, 10, 9, 8, '2', '3.12', 'P', 0, 'memahami cahaya dan alat optik.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1094, 19, 6, 8, '2', '4.1', 'K', 0, 'Menyajikan informasi dan data dalam bentuk teks eksplanasi proses terjadinya fenomena alam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1095, 19, 6, 8, '2', '4.11', 'K', 0, 'Menceritakan kembali isi teks ulasan tentang kualitas karya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1096, 19, 6, 8, '2', '4.12', 'K', 0, 'Menyajikan tanggapan tentang kualitas karya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1097, 19, 6, 8, '2', '4.13', 'K', 0, 'Menyimpulkan isi saran, ajakan, arahan, pertimbangan tentang hal positif');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1098, 19, 6, 8, '2', '4.14', 'K', 0, 'Menyajikan teks persuasi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1099, 19, 6, 8, '2', '4.15', 'K', 0, 'Menginterpretasi drama');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1100, 10, 9, 8, '2', '4.12', 'K', 0, 'menyajikan hasil percobaan tentang pembentukan bayangan pada cermin dan lensa.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1101, 19, 6, 8, '2', '4.16', 'K', 0, 'Menyajikan drama dalam bentuk pentas atau naskah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1102, 19, 6, 8, '2', '4.17', 'K', 0, 'Membuat peta konsep atau garis alur dari buku fiksi dan non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1103, 19, 6, 8, '2', '4.18', 'K', 0, 'Menyajikan tanggapan terhadap buku fiksi dan non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1104, 1, 15, 9, '2', '4.1', 'P', 0, 'Menghargai dan menghayati ajaran agama yang dianutnya.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1105, 1, 15, 9, '2', '4.2', 'P', 0, 'Menghargai dan menghayati perilaku jujur, disiplin, tanggung jawab, peduli . . . .');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1106, 1, 15, 9, '2', '4.3', 'P', 0, 'Memahami dan menerapkan pengetahuan (faktual, konseptual, dan prosedural)');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1107, 1, 15, 9, '2', '4.4', 'P', 0, 'Mencoba, mengolah, dan menyaji dalam ranah konkret.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1108, 1, 15, 9, '2', '4.1', 'K', 0, 'Menghargai dan menghayati ajaran agama yang dianutnya.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1109, 1, 15, 9, '2', '4.2', 'K', 0, 'Menghargai dan menghayati perilaku jujur, disiplin, tanggung jawab, peduli . . . .');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1110, 1, 15, 9, '2', '4.3', 'K', 0, 'Memahami dan menerapkan pengetahuan (faktual, konseptual, dan prosedural)');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1111, 1, 15, 9, '2', '4.4', 'K', 0, 'Mencoba, mengolah, dan menyaji dalam ranah konkret.');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1112, 15, 5, 7, '2', '3.4', 'P', 0, 'Mengidentifikasi keberagama suku,Agama,ras dan antar golongan dalam bingkai Byinneka Tunggal Ika');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1113, 15, 5, 7, '2', '3.5', 'P', 0, 'Menganalisis bentuk-bentuk kerjasama dealam berbagai bidang kehidupan dalam masyarakat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1114, 15, 5, 7, '2', '3.6', 'P', 0, 'Mengasasosiasikan karakteristik daerah dalam kerangka negara kesatuan Republik Indonesia');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1115, 15, 5, 7, '2', '4.4', 'K', 0, 'Mendemontrasikan hasil identifikasi hasil identifikasi suku,Agama,ras dan antar golongan dalam bingk');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1116, 15, 5, 7, '2', '4.5 ', 'K', 0, 'Menunjukan bentuk-bentuk kerjasama diberbagai bidang  kehidupan masyarkat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1117, 15, 5, 7, '2', '4.6', 'K', 0, 'Melaksnakan penelitian sederhana untuk mengilustrasika karakteristik daerah tempat tinggalnya sebaga');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1118, 3, 12, 9, '2', 'Kd.1 ', 'P', 0, 'Mensintesis secarakonseptual dan operasional tentang seni lukis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1119, 3, 12, 9, '2', 'KD.2', 'P', 0, 'Mensintesis secara konseptual dan operasional tentang seni patung');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1120, 3, 12, 9, '2', 'Kd.3', 'P', 0, 'Mensintesis secara konseptual dan operasional tentang seni grafis');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1121, 3, 12, 9, '2', 'Kd. 4', 'P', 0, 'Menganalisis prosedur mengubah lagu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1122, 3, 12, 9, '2', 'Kd.1', 'K', 0, 'Membuat Karya Seni Grafis dengan Berbagai Media dan Teknik ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1123, 3, 12, 9, '2', 'KD.2', 'K', 0, 'Merancang penyelenggaraan pameran ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1124, 3, 12, 9, '2', 'Kd.3', 'K', 0, 'Menyanyikan musik modern sederhana secara perorangan maupun kelompok');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1125, 3, 12, 9, '2', 'Kd. 4', 'K', 0, 'Menyanyikan musik ansambel modern ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1126, 6, 1, 9, '2', '4,1', 'K', 0, 'Hukum Md Lazm mukhafaf Kalimi,Musqal Kalimi Musaqal Hrfi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1127, 6, 1, 9, '2', '4,2', 'K', 0, 'Memahami isi kandungn HR Bukhari tentng menghargai waktu dan menuntut Ilmu');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1128, 6, 1, 9, '2', '4,3', 'K', 0, 'Memanfaatkan waktu dan Menuntut lmu Q.S.al-\'Asr (03),q.s al-\'Alaq (96)');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1129, 20, 6, 7, '2', 'KD1', 'P', 0, 'Mengidentifikasi informasi dan menyimpulkan isi puisi rakyat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1130, 20, 6, 7, '2', 'KD2', 'P', 0, 'Mengidentifikasi informasi dan menceritakan kembali fabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1131, 20, 6, 7, '2', 'KD3', 'P', 0, 'Menceritakan informasi dan menyimpulkan isi surat pribadi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1132, 20, 6, 7, '2', 'KD4', 'P', 0, 'Menemukan unsur-unsur dan membuat rangkuman isi buku fiksi atau non fiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1133, 20, 6, 7, '2', 'KD1', 'K', 0, 'Menelaah struktur dan mengungkapkan gagasan pesan puisi rakyat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1134, 20, 6, 7, '2', 'KD2', 'K', 0, 'Menelaah struktur dan kebahasaan fabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1135, 20, 6, 7, '2', 'KD3', 'K', 0, 'Memerankan isi fabel');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1136, 20, 6, 7, '2', 'KD4', 'K', 0, 'menelaah unsur, kebahasaan dan menulis surat pribadi atau dinas');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1137, 20, 6, 7, '2', 'KD5', 'K', 0, 'Menelaah hubungan unsur dan menyajikan tanggapan isi buku fiksi atau nonfiksi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1138, 6, 3, 9, '2', '4.1', 'K', 0, 'Mendemontrasikan pelaksanaan pnjam meminjam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1139, 6, 3, 9, '2', '4.2', 'K', 0, 'Mendemontrasikan tata cara pelaksaan utang piutang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1140, 6, 3, 9, '2', '4.3 ', 'K', 0, 'Mensimulasikan tata cara gadai');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1141, 6, 3, 9, '2', '4.4', 'K', 0, 'Mensimulasikan tata cara pelaksanaan pemberian upah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1142, 6, 1, 9, '2', '3.1', 'P', 0, 'Hukum Mad Lazim mukhafaf Kalimi,Musaqal Kalmi,Mad Lazim \r\n Musaqal Harfi dan Mad Lazi Mukhafaf Harfi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1143, 6, 1, 9, '2', '3.2', 'P', 0, 'Memahami isi kandungan Q.S.al-Ashr (103) dan Q.S. al-Alaq (96) tentang menghargai waktu dan menuntut');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1144, 6, 1, 9, '2', '3.3.1', 'P', 0, 'Memahami isi kandungan H.R Bukhori dari Abdullah bin Umar tentan menghargai waktu dan HR Ibnu majah ');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1145, 0, 8, 9, '2', '3.3', 'P', 0, 'menganalisis sifat-sifat fungsi kuadrat ditinjau dari koefisien dan determinannya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1146, 0, 8, 9, '2', '3.5', 'P', 0, 'Menentukan orientasi dan lokasi benda dalam koordinat Cartesius');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1147, 0, 8, 9, '2', '3.9', 'P', 0, 'Menentukan peluang suatu kejadian sederhana  secara empirik dan teoritik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1148, 0, 8, 9, '2', '3.13', 'P', 0, 'Memahami konsep ruang sampel suatu percobaan serta memilih strategi dan aturan-aturan yang sesuai un');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1149, 11, 8, 9, '2', '3.3', 'P', 0, 'menganalisis sifat-sifat fungsi kuadrat ditinjau dari koefisien dan determinannya');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1150, 11, 8, 9, '2', '3.5', 'P', 0, 'Menentukan orientasi dan lokasi benda dalam koordinat Cartesius');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1151, 11, 8, 9, '2', '3.9', 'P', 0, 'Menentukan peluang suatu kejadian sederhana  secara empirik dan teoritik');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1152, 11, 8, 9, '2', '3.13', 'P', 0, 'Memahami konsep ruang sampel suatu percobaan serta memilih strategi dan aturan-aturan yang sesuai un');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1153, 11, 8, 9, '2', '4.1', 'K', 0, 'Menyelesaikan permasalahan yang berkaitan persamaan linear dua variabel, SPLDV, dan fungsi kuadrat');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1154, 11, 8, 9, '2', '4.7', 'K', 0, 'Menerapkan prinsip-prinsip peluang untuk menyelesaikan masalah nyata');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1155, 11, 8, 9, '2', '4.8', 'K', 0, 'Membuat dan menyelesaikan model matematika dari berbagai permasalahan nyata');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1156, 6, 1, 7, '2', '3.1', 'P', 0, 'Memahami isi kandungan al-kafirun (109),Q.H al-Bayyinah(98) tentang toleransi');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1157, 6, 1, 7, '2', '3.2', 'P', 0, 'Memahami isi kandungan Q.S. al-Lahab (111),Q.S.an-Nashr(110) tentang problemayika dakwah');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1158, 6, 1, 7, '2', '4.1', 'K', 0, 'Menulis hadis tentang sikap tasamuh');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1159, 6, 1, 7, '2', '4.2', 'K', 0, 'Menerapkan hukum bacaan Qalqah Q.S. al-Bayyinah(98) al-Kafirun (1090');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1160, 6, 3, 9, '2', '3.1', 'P', 0, 'Memahami ketentuan pinjam meminjam');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1161, 6, 3, 9, '2', '3.2', 'P', 0, 'Memahami ketentuan utang piutang');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1162, 6, 3, 9, '2', '3.3.', 'P', 0, 'Memahami ketentuan pengurusan jenazah (Memandikan,Mengkafani,menyalati,menguburkan)');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1163, 6, 3, 9, '2', '3.4.', 'P', 0, 'Memahami ketentuan Waris');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1164, 1, 8, 7, '1', 'KD 1', 'P', 0, 'Mengetahui angka dan bilangan');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1165, 1, 8, 7, '1', 'KD 2', 'P', 0, 'Mengetahui deret geometri');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1166, 1, 8, 7, '1', 'KD 1', 'K', 0, 'Terampil');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1167, 1, 8, 7, '1', 'KD 2', 'K', 0, 'Pinter');
INSERT INTO `sr_mapel_kd` (`id`, `id_guru`, `id_mapel`, `tingkat`, `semester`, `no_kd`, `jenis`, `bobot`, `nama_kd`) VALUES (1168, 2, 6, 7, '1', '(3.1.', 'P', 0, 'Mengidentifikasi , menelaah struktur dan kebahasaan teks lanoran\r\n');


#
# TABLE STRUCTURE FOR: sr_mata_pelajaran
#

DROP TABLE IF EXISTS `sr_mata_pelajaran`;

CREATE TABLE `sr_mata_pelajaran` (
  `idmata_pelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `mp_kode` varchar(50) NOT NULL,
  `mp_nama` varchar(255) NOT NULL,
  `mp_kelompok` enum('A','B','C','C1','C2') NOT NULL,
  `mp_urutan` int(11) NOT NULL,
  PRIMARY KEY (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (1, '5', 'PAI', 'Pendidikan Agama Islam', 'A', 1);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (2, '5', 'BIND', 'Bahasa Indonesia', 'A', 3);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (3, '5', 'MTK', 'Matematika', 'A', 5);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (46, '5', 'PKn', 'Pendidikan Kewarganegaraan', 'A', 2);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (47, '5', 'SBdP', 'Seni Budaya dan Prakarya', 'B', 1);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (48, '5', 'PJOK', 'Pendidikan Jasmani, Olahraga dan Kesehatan', 'B', 2);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (49, '5', 'IPA', 'Ilmu Pengetahuan Alam', 'A', 6);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (50, '5', 'IPS', 'Ilmu Pengetahuan Sosial', 'A', 7);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (51, '5', 'BING', 'Bahasa Inggris', 'A', 8);
INSERT INTO `sr_mata_pelajaran` (`idmata_pelajaran`, `unit`, `mp_kode`, `mp_nama`, `mp_kelompok`, `mp_urutan`) VALUES (63, '5', 'MM', 'Multimedia', 'C1', 13);


#
# TABLE STRUCTURE FOR: sr_mata_pelajaran_guru
#

DROP TABLE IF EXISTS `sr_mata_pelajaran_guru`;

CREATE TABLE `sr_mata_pelajaran_guru` (
  `idmata_pelajaran_guru` int(11) NOT NULL AUTO_INCREMENT,
  `idmata_pelajaran` int(11) NOT NULL,
  `idusers` int(11) unsigned NOT NULL,
  PRIMARY KEY (`idmata_pelajaran_guru`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  KEY `idusers` (`idusers`)
) ENGINE=InnoDB AUTO_INCREMENT=57 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (12, 48, 39);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (13, 1, 40);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (14, 51, 41);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (15, 2, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (16, 3, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (17, 49, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (18, 50, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (19, 2, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (20, 3, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (21, 49, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (22, 50, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (23, 2, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (24, 3, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (25, 49, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (26, 50, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (27, 2, 43);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (28, 3, 43);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (29, 49, 43);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (30, 50, 43);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (31, 2, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (32, 3, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (33, 49, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (34, 50, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (35, 2, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (36, 49, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (37, 50, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (38, 3, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (42, 47, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (43, 46, 38);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (44, 46, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (45, 47, 37);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (46, 46, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (47, 47, 45);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (48, 46, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (49, 47, 44);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (50, 46, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (51, 47, 42);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (52, 2, 57);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (53, 51, 57);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (54, 2, 1);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (55, 48, 40);
INSERT INTO `sr_mata_pelajaran_guru` (`idmata_pelajaran_guru`, `idmata_pelajaran`, `idusers`) VALUES (56, 1, 45);


#
# TABLE STRUCTURE FOR: sr_materi
#

DROP TABLE IF EXISTS `sr_materi`;

CREATE TABLE `sr_materi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `mapel_id` int(11) NOT NULL,
  `kelas_id` varchar(11) NOT NULL,
  `pengajar_id` int(11) DEFAULT NULL,
  `judul` varchar(255) NOT NULL,
  `konten` text DEFAULT NULL,
  `file` text DEFAULT NULL,
  `video` text NOT NULL,
  `tgl_posting` datetime NOT NULL,
  `publish` tinyint(1) NOT NULL DEFAULT 0,
  `views` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `kelas_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (1, '5', 50, '3', 0, 'BAB I - Sejarah', NULL, 'Reza_Lesmana.png', '', '2022-04-05 11:27:11', 1, 1);
INSERT INTO `sr_materi` (`id`, `unit`, `mapel_id`, `kelas_id`, `pengajar_id`, `judul`, `konten`, `file`, `video`, `tgl_posting`, `publish`, `views`) VALUES (2, '5', 51, '2', 0, 'Kata Kata B Inggris', NULL, NULL, 'https://www.youtube.com/watch?v=Ek2yatLDl2E', '2022-04-05 11:28:59', 1, 1);


#
# TABLE STRUCTURE FOR: sr_naikkelas
#

DROP TABLE IF EXISTS `sr_naikkelas`;

CREATE TABLE `sr_naikkelas` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) NOT NULL,
  `naik` enum('Y','N') NOT NULL,
  `catatan_wali` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `sr_naikkelas` (`id`, `id_siswa`, `ta`, `naik`, `catatan_wali`) VALUES (1, 11, '1', 'Y', 'Bagus, pertahankan');
INSERT INTO `sr_naikkelas` (`id`, `id_siswa`, `ta`, `naik`, `catatan_wali`) VALUES (2, 339, '20181', 'Y', 'Bagus, tingkatkan lagi');


#
# TABLE STRUCTURE FOR: sr_nilai_absensi
#

DROP TABLE IF EXISTS `sr_nilai_absensi`;

CREATE TABLE `sr_nilai_absensi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tp_tahun` varchar(20) NOT NULL,
  `idsiswa` int(10) NOT NULL,
  `idkelas` varchar(50) NOT NULL,
  `s` int(3) NOT NULL,
  `i` int(3) NOT NULL,
  `a` int(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_nilai_absensi` (`id`, `tp_tahun`, `idsiswa`, `idkelas`, `s`, `i`, `a`) VALUES (1, '2021/2022-2', 11, '1', 1, 1, 0);


#
# TABLE STRUCTURE FOR: sr_nilai_ekstrakulikuler
#

DROP TABLE IF EXISTS `sr_nilai_ekstrakulikuler`;

CREATE TABLE `sr_nilai_ekstrakulikuler` (
  `id_nilai_ekstrakulikuler` int(11) NOT NULL AUTO_INCREMENT,
  `id_ekstrakulikuler` varchar(11) DEFAULT NULL,
  `id_siswa` varchar(11) DEFAULT NULL,
  `id_kelas` varchar(11) DEFAULT NULL,
  `unit` varchar(11) NOT NULL,
  `tahun_ajaran` varchar(50) DEFAULT NULL,
  `nilai` varchar(10) DEFAULT NULL,
  `deskripsi` text DEFAULT NULL,
  PRIMARY KEY (`id_nilai_ekstrakulikuler`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `sr_nilai_ekstrakulikuler` (`id_nilai_ekstrakulikuler`, `id_ekstrakulikuler`, `id_siswa`, `id_kelas`, `unit`, `tahun_ajaran`, `nilai`, `deskripsi`) VALUES (2, '3', '11', '1', '5', '2021/2022-2', '82', '');
INSERT INTO `sr_nilai_ekstrakulikuler` (`id_nilai_ekstrakulikuler`, `id_ekstrakulikuler`, `id_siswa`, `id_kelas`, `unit`, `tahun_ajaran`, `nilai`, `deskripsi`) VALUES (3, '4', '11', '1', '5', '2021/2022-2', '65', '');
INSERT INTO `sr_nilai_ekstrakulikuler` (`id_nilai_ekstrakulikuler`, `id_ekstrakulikuler`, `id_siswa`, `id_kelas`, `unit`, `tahun_ajaran`, `nilai`, `deskripsi`) VALUES (4, '2', '13', '1', '5', '2021/2022-2', '72', '');
INSERT INTO `sr_nilai_ekstrakulikuler` (`id_nilai_ekstrakulikuler`, `id_ekstrakulikuler`, `id_siswa`, `id_kelas`, `unit`, `tahun_ajaran`, `nilai`, `deskripsi`) VALUES (5, '3', '13', '1', '5', '2021/2022-2', '90', '');


#
# TABLE STRUCTURE FOR: sr_nilai_keterampilan
#

DROP TABLE IF EXISTS `sr_nilai_keterampilan`;

CREATE TABLE `sr_nilai_keterampilan` (
  `idnilai_keterampilan` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idsiswa` int(11) NOT NULL,
  `idkompetensi_dasar` int(11) NOT NULL,
  `nk_harian` text NOT NULL,
  PRIMARY KEY (`idnilai_keterampilan`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  KEY `idusers` (`idusers`),
  KEY `idkelas` (`idkelas`),
  KEY `idsiswa` (`idsiswa`),
  KEY `idkompetensi_dasar` (`idkompetensi_dasar`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_nilai_pengetahuan
#

DROP TABLE IF EXISTS `sr_nilai_pengetahuan`;

CREATE TABLE `sr_nilai_pengetahuan` (
  `idnilai_pengetahuan` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `idusers` int(11) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idsiswa` int(11) NOT NULL,
  `idkompetensi_dasar` int(11) NOT NULL,
  `np_harian` text DEFAULT NULL,
  PRIMARY KEY (`idnilai_pengetahuan`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idusers` (`idusers`),
  KEY `idkelas` (`idkelas`),
  KEY `idsiswa` (`idsiswa`),
  KEY `idkompetensi_dasar` (`idkompetensi_dasar`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (1, 1, 2, 1, 1, 11, 29, '60,75,89,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (2, 1, 2, 1, 1, 12, 29, '48,48,66,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (3, 1, 2, 1, 1, 13, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (4, 1, 2, 1, 1, 14, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (5, 1, 2, 1, 1, 15, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (6, 1, 2, 1, 1, 16, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (7, 1, 2, 1, 1, 17, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (8, 1, 2, 1, 1, 18, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (9, 1, 2, 1, 1, 19, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (10, 1, 2, 1, 1, 20, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (11, 1, 2, 1, 1, 21, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (12, 1, 2, 1, 1, 22, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (13, 1, 2, 1, 1, 23, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (14, 1, 2, 1, 1, 24, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (15, 1, 2, 1, 1, 25, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (16, 1, 2, 1, 1, 26, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (17, 1, 2, 1, 1, 27, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (18, 1, 2, 1, 1, 28, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (19, 1, 2, 1, 1, 29, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (20, 1, 2, 1, 1, 30, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (21, 1, 2, 1, 1, 31, 29, ',,,');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (22, 1, 2, 1, 1, 11, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (23, 1, 2, 1, 1, 12, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (24, 1, 2, 1, 1, 13, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (25, 1, 2, 1, 1, 14, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (26, 1, 2, 1, 1, 15, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (27, 1, 2, 1, 1, 16, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (28, 1, 2, 1, 1, 17, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (29, 1, 2, 1, 1, 18, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (30, 1, 2, 1, 1, 19, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (31, 1, 2, 1, 1, 20, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (32, 1, 2, 1, 1, 21, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (33, 1, 2, 1, 1, 22, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (34, 1, 2, 1, 1, 23, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (35, 1, 2, 1, 1, 24, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (36, 1, 2, 1, 1, 25, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (37, 1, 2, 1, 1, 26, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (38, 1, 2, 1, 1, 27, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (39, 1, 2, 1, 1, 28, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (40, 1, 2, 1, 1, 29, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (41, 1, 2, 1, 1, 30, 30, '');
INSERT INTO `sr_nilai_pengetahuan` (`idnilai_pengetahuan`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_harian`) VALUES (42, 1, 2, 1, 1, 31, 30, '');


#
# TABLE STRUCTURE FOR: sr_nilai_pengetahuan_utsuas
#

DROP TABLE IF EXISTS `sr_nilai_pengetahuan_utsuas`;

CREATE TABLE `sr_nilai_pengetahuan_utsuas` (
  `idnp_utsuas` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `idusers` int(11) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idsiswa` int(11) NOT NULL,
  `idkompetensi_dasar` varchar(10) NOT NULL,
  `np_uts` double NOT NULL,
  `np_uas` double NOT NULL,
  PRIMARY KEY (`idnp_utsuas`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  KEY `idusers` (`idusers`),
  KEY `idkelas` (`idkelas`),
  KEY `idsiswa` (`idsiswa`),
  CONSTRAINT `sr_nilai_pengetahuan_utsuas_ibfk_1` FOREIGN KEY (`idtahun_pelajaran`) REFERENCES `sr_tahun_pelajaran` (`idtahun_pelajaran`),
  CONSTRAINT `sr_nilai_pengetahuan_utsuas_ibfk_2` FOREIGN KEY (`idmata_pelajaran`) REFERENCES `sr_mata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_nilai_pengetahuan_utsuas_ibfk_4` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`),
  CONSTRAINT `sr_nilai_pengetahuan_utsuas_ibfk_5` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`),
  CONSTRAINT `sr_nilai_pengetahuan_utsuas_ibfk_6` FOREIGN KEY (`idsiswa`) REFERENCES `sr_siswa` (`idsiswa`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (1, 1, 2, 1, 1, 11, '', '100', '80');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (2, 1, 2, 1, 1, 12, '', '90', '98');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (3, 1, 2, 1, 1, 13, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (4, 1, 2, 1, 1, 14, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (5, 1, 2, 1, 1, 15, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (6, 1, 2, 1, 1, 16, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (7, 1, 2, 1, 1, 17, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (8, 1, 2, 1, 1, 18, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (9, 1, 2, 1, 1, 19, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (10, 1, 2, 1, 1, 20, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (11, 1, 2, 1, 1, 21, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (12, 1, 2, 1, 1, 22, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (13, 1, 2, 1, 1, 23, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (14, 1, 2, 1, 1, 24, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (15, 1, 2, 1, 1, 25, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (16, 1, 2, 1, 1, 26, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (17, 1, 2, 1, 1, 27, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (18, 1, 2, 1, 1, 28, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (19, 1, 2, 1, 1, 29, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (20, 1, 2, 1, 1, 30, '', '0', '0');
INSERT INTO `sr_nilai_pengetahuan_utsuas` (`idnp_utsuas`, `idtahun_pelajaran`, `idmata_pelajaran`, `idusers`, `idkelas`, `idsiswa`, `idkompetensi_dasar`, `np_uts`, `np_uas`) VALUES (21, 1, 2, 1, 1, 31, '', '0', '0');


#
# TABLE STRUCTURE FOR: sr_nilai_sikap_so
#

DROP TABLE IF EXISTS `sr_nilai_sikap_so`;

CREATE TABLE `sr_nilai_sikap_so` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tp_tahun` varchar(20) NOT NULL,
  `id_guru` int(10) NOT NULL,
  `idsiswa` int(10) NOT NULL,
  `is_wali` enum('Y','N') NOT NULL,
  `deskripsi` varchar(225) NOT NULL,
  `selalu` varchar(20) NOT NULL,
  `mulai_meningkat` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_nilai_sikap_so` (`id`, `tp_tahun`, `id_guru`, `idsiswa`, `is_wali`, `deskripsi`, `selalu`, `mulai_meningkat`) VALUES (2, '2021/2022-2', 1, 11, 'Y', '<p>Mudah berbaur dengan teman teman</p>', '', '');
INSERT INTO `sr_nilai_sikap_so` (`id`, `tp_tahun`, `id_guru`, `idsiswa`, `is_wali`, `deskripsi`, `selalu`, `mulai_meningkat`) VALUES (4, '2021/2022-2', 1, 28, 'Y', '<p>Baik dengan teman teman</p>', '', '');


#
# TABLE STRUCTURE FOR: sr_nilai_sikap_sp
#

DROP TABLE IF EXISTS `sr_nilai_sikap_sp`;

CREATE TABLE `sr_nilai_sikap_sp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tp_tahun` varchar(20) NOT NULL,
  `id_guru` int(10) NOT NULL,
  `idsiswa` int(10) NOT NULL,
  `is_wali` enum('Y','N') NOT NULL,
  `deskripsi` varchar(225) NOT NULL,
  `selalu` varchar(20) NOT NULL,
  `mulai_meningkat` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_nilai_sikap_sp` (`id`, `tp_tahun`, `id_guru`, `idsiswa`, `is_wali`, `deskripsi`, `selalu`, `mulai_meningkat`) VALUES (1, '2021/2022-2', 1, 11, 'Y', ' Selalu melakukan sikap : berdoa sebelum dan sesudah melakukan kegiatan , menjalankan ibadah sesuai dengan agamanya ; Mulai meningkat pada sikap : memberi salam pada saat awal dan akhir kegiatan', '8-9', '10');
INSERT INTO `sr_nilai_sikap_sp` (`id`, `tp_tahun`, `id_guru`, `idsiswa`, `is_wali`, `deskripsi`, `selalu`, `mulai_meningkat`) VALUES (3, '2021/2022-2', 1, 17, 'Y', 'memberi salam pada saat awal dan akhir kegiatan', '', '');
INSERT INTO `sr_nilai_sikap_sp` (`id`, `tp_tahun`, `id_guru`, `idsiswa`, `is_wali`, `deskripsi`, `selalu`, `mulai_meningkat`) VALUES (4, '2021/2022-2', 1, 14, 'Y', '<p>Selalu jujur dalam kondisi apapun dimanapun</p>', '', '');
INSERT INTO `sr_nilai_sikap_sp` (`id`, `tp_tahun`, `id_guru`, `idsiswa`, `is_wali`, `deskripsi`, `selalu`, `mulai_meningkat`) VALUES (5, '2021/2022-2', 1, 12, 'Y', '<p>Berprilaku baik saat belajar</p>', '', '');
INSERT INTO `sr_nilai_sikap_sp` (`id`, `tp_tahun`, `id_guru`, `idsiswa`, `is_wali`, `deskripsi`, `selalu`, `mulai_meningkat`) VALUES (6, '2021/2022-2', 1, 13, 'Y', '<p>Tidak sombong</p>', '', '');


#
# TABLE STRUCTURE FOR: sr_pajak_keuangan
#

DROP TABLE IF EXISTS `sr_pajak_keuangan`;

CREATE TABLE `sr_pajak_keuangan` (
  `id_pajak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pajak` varchar(200) NOT NULL,
  `besaran_pajak` varchar(100) NOT NULL,
  PRIMARY KEY (`id_pajak`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pajak_keuangan` (`id_pajak`, `nama_pajak`, `besaran_pajak`) VALUES (5, 'PPH 201', '20');


#
# TABLE STRUCTURE FOR: sr_paketsoal
#

DROP TABLE IF EXISTS `sr_paketsoal`;

CREATE TABLE `sr_paketsoal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_guru` int(10) NOT NULL,
  `id_mapel` int(10) NOT NULL,
  `nama_paket` varchar(100) NOT NULL,
  `jumlah_soal` int(5) NOT NULL,
  `unit` int(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_paketsoal` (`id`, `id_guru`, `id_mapel`, `nama_paket`, `jumlah_soal`, `unit`) VALUES (8, 1, 3, 'Matematika', 10, 5);
INSERT INTO `sr_paketsoal` (`id`, `id_guru`, `id_mapel`, `nama_paket`, `jumlah_soal`, `unit`) VALUES (9, 1, 3, 'ujian matematika', 10, 5);
INSERT INTO `sr_paketsoal` (`id`, `id_guru`, `id_mapel`, `nama_paket`, `jumlah_soal`, `unit`) VALUES (10, 1, 1, 'Ujian', 0, 5);


#
# TABLE STRUCTURE FOR: sr_pembayaran_bebas
#

DROP TABLE IF EXISTS `sr_pembayaran_bebas`;

CREATE TABLE `sr_pembayaran_bebas` (
  `id_pembayaran_bebas` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `unit` varchar(10) DEFAULT NULL,
  `tanggal` varchar(30) DEFAULT NULL,
  `bayar` float(30,0) DEFAULT NULL,
  `akun` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran_bebas`)
) ENGINE=InnoDB AUTO_INCREMENT=79 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (53, 6, 87, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (54, 6, 88, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (55, 6, 89, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (56, 6, 90, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (57, 6, 91, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (58, 6, 92, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (59, 6, 93, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (60, 6, 94, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (61, 6, 95, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (62, 6, 96, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (63, 6, 97, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (64, 6, 98, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (65, 6, 99, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (66, 6, 100, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (67, 6, 101, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (68, 6, 102, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (69, 6, 103, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (70, 6, 104, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (71, 6, 105, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (72, 6, 106, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (73, 6, 107, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (74, 6, 108, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (75, 6, 145, 4, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (76, 6, 112, 5, '200000', NULL, '2022-04-13', NULL, '622656');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (77, 6, 59, 3, '200000', '5', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bebas` (`id_pembayaran_bebas`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `tagihan`, `unit`, `tanggal`, `bayar`, `akun`) VALUES (78, 6, 140, 11, '20000000', '5', '2022-04-16', NULL, '622655');


#
# TABLE STRUCTURE FOR: sr_pembayaran_bulanan
#

DROP TABLE IF EXISTS `sr_pembayaran_bulanan`;

CREATE TABLE `sr_pembayaran_bulanan` (
  `id_pembayaran_bulanan` int(11) NOT NULL AUTO_INCREMENT,
  `id_jenis_pembayaran` int(11) DEFAULT NULL,
  `id_siswa` int(11) DEFAULT NULL,
  `id_kelas` int(11) DEFAULT NULL,
  `bulan` varchar(15) DEFAULT NULL,
  `tagihan` float DEFAULT NULL,
  `bayar` float DEFAULT 0,
  `tanggal` varchar(20) NOT NULL,
  `unit` varchar(20) DEFAULT NULL,
  `akun` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_pembayaran_bulanan`)
) ENGINE=InnoDB AUTO_INCREMENT=1273 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (625, 2, 58, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (626, 2, 58, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (627, 2, 58, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (628, 2, 58, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (629, 2, 58, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (630, 2, 58, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (631, 2, 58, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (632, 2, 58, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (633, 2, 58, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (634, 2, 58, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (635, 2, 58, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (636, 2, 58, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (637, 2, 59, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (638, 2, 59, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (639, 2, 59, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (640, 2, 59, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (641, 2, 59, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (642, 2, 59, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (643, 2, 59, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (644, 2, 59, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (645, 2, 59, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (646, 2, 59, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (647, 2, 59, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (648, 2, 59, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (649, 2, 60, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (650, 2, 60, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (651, 2, 60, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (652, 2, 60, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (653, 2, 60, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (654, 2, 60, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (655, 2, 60, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (656, 2, 60, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (657, 2, 60, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (658, 2, 60, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (659, 2, 60, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (660, 2, 60, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (661, 2, 61, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (662, 2, 61, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (663, 2, 61, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (664, 2, 61, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (665, 2, 61, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (666, 2, 61, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (667, 2, 61, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (668, 2, 61, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (669, 2, 61, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (670, 2, 61, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (671, 2, 61, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (672, 2, 61, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (673, 2, 62, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (674, 2, 62, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (675, 2, 62, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (676, 2, 62, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (677, 2, 62, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (678, 2, 62, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (679, 2, 62, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (680, 2, 62, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (681, 2, 62, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (682, 2, 62, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (683, 2, 62, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (684, 2, 62, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (685, 2, 63, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (686, 2, 63, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (687, 2, 63, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (688, 2, 63, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (689, 2, 63, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (690, 2, 63, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (691, 2, 63, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (692, 2, 63, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (693, 2, 63, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (694, 2, 63, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (695, 2, 63, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (696, 2, 63, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (697, 2, 64, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (698, 2, 64, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (699, 2, 64, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (700, 2, 64, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (701, 2, 64, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (702, 2, 64, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (703, 2, 64, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (704, 2, 64, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (705, 2, 64, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (706, 2, 64, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (707, 2, 64, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (708, 2, 64, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (709, 2, 65, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (710, 2, 65, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (711, 2, 65, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (712, 2, 65, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (713, 2, 65, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (714, 2, 65, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (715, 2, 65, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (716, 2, 65, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (717, 2, 65, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (718, 2, 65, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (719, 2, 65, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (720, 2, 65, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (721, 2, 66, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (722, 2, 66, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (723, 2, 66, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (724, 2, 66, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (725, 2, 66, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (726, 2, 66, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (727, 2, 66, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (728, 2, 66, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (729, 2, 66, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (730, 2, 66, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (731, 2, 66, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (732, 2, 66, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (733, 2, 67, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (734, 2, 67, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (735, 2, 67, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (736, 2, 67, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (737, 2, 67, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (738, 2, 67, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (739, 2, 67, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (740, 2, 67, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (741, 2, 67, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (742, 2, 67, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (743, 2, 67, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (744, 2, 67, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (745, 2, 68, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (746, 2, 68, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (747, 2, 68, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (748, 2, 68, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (749, 2, 68, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (750, 2, 68, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (751, 2, 68, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (752, 2, 68, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (753, 2, 68, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (754, 2, 68, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (755, 2, 68, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (756, 2, 68, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (757, 2, 69, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (758, 2, 69, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (759, 2, 69, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (760, 2, 69, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (761, 2, 69, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (762, 2, 69, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (763, 2, 69, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (764, 2, 69, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (765, 2, 69, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (766, 2, 69, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (767, 2, 69, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (768, 2, 69, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (769, 2, 70, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (770, 2, 70, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (771, 2, 70, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (772, 2, 70, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (773, 2, 70, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (774, 2, 70, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (775, 2, 70, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (776, 2, 70, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (777, 2, 70, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (778, 2, 70, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (779, 2, 70, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (780, 2, 70, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (781, 2, 71, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (782, 2, 71, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (783, 2, 71, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (784, 2, 71, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (785, 2, 71, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (786, 2, 71, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (787, 2, 71, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (788, 2, 71, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (789, 2, 71, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (790, 2, 71, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (791, 2, 71, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (792, 2, 71, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (793, 2, 72, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (794, 2, 72, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (795, 2, 72, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (796, 2, 72, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (797, 2, 72, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (798, 2, 72, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (799, 2, 72, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (800, 2, 72, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (801, 2, 72, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (802, 2, 72, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (803, 2, 72, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (804, 2, 72, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (805, 2, 73, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (806, 2, 73, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (807, 2, 73, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (808, 2, 73, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (809, 2, 73, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (810, 2, 73, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (811, 2, 73, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (812, 2, 73, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (813, 2, 73, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (814, 2, 73, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (815, 2, 73, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (816, 2, 73, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (817, 2, 74, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (818, 2, 74, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (819, 2, 74, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (820, 2, 74, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (821, 2, 74, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (822, 2, 74, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (823, 2, 74, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (824, 2, 74, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (825, 2, 74, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (826, 2, 74, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (827, 2, 74, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (828, 2, 74, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (829, 2, 75, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (830, 2, 75, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (831, 2, 75, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (832, 2, 75, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (833, 2, 75, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (834, 2, 75, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (835, 2, 75, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (836, 2, 75, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (837, 2, 75, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (838, 2, 75, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (839, 2, 75, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (840, 2, 75, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (841, 2, 76, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (842, 2, 76, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (843, 2, 76, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (844, 2, 76, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (845, 2, 76, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (846, 2, 76, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (847, 2, 76, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (848, 2, 76, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (849, 2, 76, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (850, 2, 76, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (851, 2, 76, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (852, 2, 76, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (853, 2, 77, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (854, 2, 77, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (855, 2, 77, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (856, 2, 77, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (857, 2, 77, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (858, 2, 77, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (859, 2, 77, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (860, 2, 77, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (861, 2, 77, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (862, 2, 77, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (863, 2, 77, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (864, 2, 77, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (865, 2, 78, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (866, 2, 78, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (867, 2, 78, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (868, 2, 78, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (869, 2, 78, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (870, 2, 78, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (871, 2, 78, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (872, 2, 78, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (873, 2, 78, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (874, 2, 78, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (875, 2, 78, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (876, 2, 78, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (877, 2, 79, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (878, 2, 79, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (879, 2, 79, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (880, 2, 79, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (881, 2, 79, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (882, 2, 79, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (883, 2, 79, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (884, 2, 79, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (885, 2, 79, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (886, 2, 79, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (887, 2, 79, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (888, 2, 79, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (889, 2, 80, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (890, 2, 80, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (891, 2, 80, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (892, 2, 80, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (893, 2, 80, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (894, 2, 80, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (895, 2, 80, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (896, 2, 80, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (897, 2, 80, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (898, 2, 80, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (899, 2, 80, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (900, 2, 80, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (901, 2, 81, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (902, 2, 81, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (903, 2, 81, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (904, 2, 81, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (905, 2, 81, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (906, 2, 81, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (907, 2, 81, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (908, 2, 81, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (909, 2, 81, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (910, 2, 81, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (911, 2, 81, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (912, 2, 81, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (913, 2, 82, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (914, 2, 82, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (915, 2, 82, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (916, 2, 82, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (917, 2, 82, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (918, 2, 82, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (919, 2, 82, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (920, 2, 82, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (921, 2, 82, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (922, 2, 82, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (923, 2, 82, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (924, 2, 82, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (925, 2, 83, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (926, 2, 83, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (927, 2, 83, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (928, 2, 83, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (929, 2, 83, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (930, 2, 83, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (931, 2, 83, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (932, 2, 83, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (933, 2, 83, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (934, 2, 83, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (935, 2, 83, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (936, 2, 83, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (937, 2, 84, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (938, 2, 84, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (939, 2, 84, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (940, 2, 84, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (941, 2, 84, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (942, 2, 84, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (943, 2, 84, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (944, 2, 84, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (945, 2, 84, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (946, 2, 84, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (947, 2, 84, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (948, 2, 84, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (949, 2, 85, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (950, 2, 85, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (951, 2, 85, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (952, 2, 85, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (953, 2, 85, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (954, 2, 85, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (955, 2, 85, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (956, 2, 85, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (957, 2, 85, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (958, 2, 85, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (959, 2, 85, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (960, 2, 85, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (961, 2, 86, 3, 'Juli', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (962, 2, 86, 3, 'Agustus', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (963, 2, 86, 3, 'September', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (964, 2, 86, 3, 'Oktober', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (965, 2, 86, 3, 'November', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (966, 2, 86, 3, 'Desember', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (967, 2, 86, 3, 'Januari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (968, 2, 86, 3, 'Febuari', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (969, 2, 86, 3, 'Maret', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (970, 2, 86, 3, 'April', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (971, 2, 86, 3, 'Mei', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (972, 2, 86, 3, 'Juni', '100000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (973, 2, 140, 11, 'Juli', '10000', '10000', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (974, 2, 140, 11, 'Agustus', '10000', '10000', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (975, 2, 140, 11, 'September', '10000', '10000', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (976, 2, 140, 11, 'Oktober', '10000', '10000', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (977, 2, 140, 11, 'November', '10000', '10000', '2022-04-16', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (978, 2, 140, 11, 'Desember', '10000', '10000', '2022-04-17', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (979, 2, 140, 11, 'Januari', '10000', '0', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (980, 2, 140, 11, 'Febuari', '10000', '0', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (981, 2, 140, 11, 'Maret', '10000', '0', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (982, 2, 140, 11, 'April', '10000', '0', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (983, 2, 140, 11, 'Mei', '10000', '0', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (984, 2, 140, 11, 'Juni', '10000', '0', '2022-04-13', NULL, '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (985, 2, 87, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (986, 2, 87, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (987, 2, 87, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (988, 2, 87, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (989, 2, 87, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (990, 2, 87, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (991, 2, 87, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (992, 2, 87, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (993, 2, 87, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (994, 2, 87, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (995, 2, 87, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (996, 2, 87, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (997, 2, 88, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (998, 2, 88, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (999, 2, 88, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1000, 2, 88, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1001, 2, 88, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1002, 2, 88, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1003, 2, 88, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1004, 2, 88, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1005, 2, 88, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1006, 2, 88, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1007, 2, 88, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1008, 2, 88, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1009, 2, 89, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1010, 2, 89, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1011, 2, 89, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1012, 2, 89, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1013, 2, 89, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1014, 2, 89, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1015, 2, 89, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1016, 2, 89, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1017, 2, 89, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1018, 2, 89, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1019, 2, 89, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1020, 2, 89, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1021, 2, 90, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1022, 2, 90, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1023, 2, 90, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1024, 2, 90, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1025, 2, 90, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1026, 2, 90, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1027, 2, 90, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1028, 2, 90, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1029, 2, 90, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1030, 2, 90, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1031, 2, 90, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1032, 2, 90, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1033, 2, 91, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1034, 2, 91, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1035, 2, 91, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1036, 2, 91, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1037, 2, 91, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1038, 2, 91, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1039, 2, 91, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1040, 2, 91, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1041, 2, 91, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1042, 2, 91, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1043, 2, 91, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1044, 2, 91, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1045, 2, 92, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1046, 2, 92, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1047, 2, 92, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1048, 2, 92, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1049, 2, 92, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1050, 2, 92, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1051, 2, 92, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1052, 2, 92, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1053, 2, 92, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1054, 2, 92, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1055, 2, 92, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1056, 2, 92, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1057, 2, 93, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1058, 2, 93, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1059, 2, 93, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1060, 2, 93, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1061, 2, 93, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1062, 2, 93, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1063, 2, 93, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1064, 2, 93, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1065, 2, 93, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1066, 2, 93, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1067, 2, 93, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1068, 2, 93, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1069, 2, 94, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1070, 2, 94, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1071, 2, 94, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1072, 2, 94, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1073, 2, 94, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1074, 2, 94, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1075, 2, 94, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1076, 2, 94, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1077, 2, 94, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1078, 2, 94, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1079, 2, 94, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1080, 2, 94, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1081, 2, 95, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1082, 2, 95, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1083, 2, 95, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1084, 2, 95, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1085, 2, 95, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1086, 2, 95, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1087, 2, 95, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1088, 2, 95, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1089, 2, 95, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1090, 2, 95, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1091, 2, 95, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1092, 2, 95, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1093, 2, 96, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1094, 2, 96, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1095, 2, 96, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1096, 2, 96, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1097, 2, 96, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1098, 2, 96, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1099, 2, 96, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1100, 2, 96, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1101, 2, 96, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1102, 2, 96, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1103, 2, 96, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1104, 2, 96, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1105, 2, 97, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1106, 2, 97, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1107, 2, 97, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1108, 2, 97, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1109, 2, 97, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1110, 2, 97, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1111, 2, 97, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1112, 2, 97, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1113, 2, 97, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1114, 2, 97, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1115, 2, 97, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1116, 2, 97, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1117, 2, 98, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1118, 2, 98, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1119, 2, 98, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1120, 2, 98, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1121, 2, 98, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1122, 2, 98, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1123, 2, 98, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1124, 2, 98, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1125, 2, 98, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1126, 2, 98, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1127, 2, 98, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1128, 2, 98, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1129, 2, 99, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1130, 2, 99, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1131, 2, 99, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1132, 2, 99, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1133, 2, 99, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1134, 2, 99, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1135, 2, 99, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1136, 2, 99, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1137, 2, 99, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1138, 2, 99, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1139, 2, 99, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1140, 2, 99, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1141, 2, 100, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1142, 2, 100, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1143, 2, 100, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1144, 2, 100, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1145, 2, 100, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1146, 2, 100, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1147, 2, 100, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1148, 2, 100, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1149, 2, 100, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1150, 2, 100, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1151, 2, 100, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1152, 2, 100, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1153, 2, 101, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1154, 2, 101, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1155, 2, 101, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1156, 2, 101, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1157, 2, 101, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1158, 2, 101, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1159, 2, 101, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1160, 2, 101, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1161, 2, 101, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1162, 2, 101, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1163, 2, 101, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1164, 2, 101, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1165, 2, 102, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1166, 2, 102, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1167, 2, 102, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1168, 2, 102, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1169, 2, 102, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1170, 2, 102, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1171, 2, 102, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1172, 2, 102, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1173, 2, 102, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1174, 2, 102, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1175, 2, 102, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1176, 2, 102, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1177, 2, 103, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1178, 2, 103, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1179, 2, 103, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1180, 2, 103, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1181, 2, 103, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1182, 2, 103, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1183, 2, 103, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1184, 2, 103, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1185, 2, 103, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1186, 2, 103, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1187, 2, 103, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1188, 2, 103, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1189, 2, 104, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1190, 2, 104, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1191, 2, 104, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1192, 2, 104, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1193, 2, 104, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1194, 2, 104, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1195, 2, 104, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1196, 2, 104, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1197, 2, 104, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1198, 2, 104, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1199, 2, 104, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1200, 2, 104, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1201, 2, 105, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1202, 2, 105, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1203, 2, 105, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1204, 2, 105, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1205, 2, 105, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1206, 2, 105, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1207, 2, 105, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1208, 2, 105, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1209, 2, 105, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1210, 2, 105, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1211, 2, 105, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1212, 2, 105, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1213, 2, 106, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1214, 2, 106, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1215, 2, 106, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1216, 2, 106, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1217, 2, 106, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1218, 2, 106, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1219, 2, 106, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1220, 2, 106, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1221, 2, 106, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1222, 2, 106, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1223, 2, 106, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1224, 2, 106, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1225, 2, 107, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1226, 2, 107, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1227, 2, 107, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1228, 2, 107, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1229, 2, 107, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1230, 2, 107, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1231, 2, 107, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1232, 2, 107, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1233, 2, 107, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1234, 2, 107, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1235, 2, 107, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1236, 2, 107, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1237, 2, 108, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1238, 2, 108, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1239, 2, 108, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1240, 2, 108, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1241, 2, 108, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1242, 2, 108, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1243, 2, 108, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1244, 2, 108, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1245, 2, 108, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1246, 2, 108, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1247, 2, 108, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1248, 2, 108, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1249, 2, 145, 4, 'Juli', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1250, 2, 145, 4, 'Agustus', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1251, 2, 145, 4, 'September', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1252, 2, 145, 4, 'Oktober', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1253, 2, 145, 4, 'November', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1254, 2, 145, 4, 'Desember', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1255, 2, 145, 4, 'Januari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1256, 2, 145, 4, 'Febuari', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1257, 2, 145, 4, 'Maret', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1258, 2, 145, 4, 'April', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1259, 2, 145, 4, 'Mei', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1260, 2, 145, 4, 'Juni', '60000', '0', '2022-04-13', '5', '622656');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1261, 2, 34, 2, 'Juli', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1262, 2, 34, 2, 'Agustus', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1263, 2, 34, 2, 'September', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1264, 2, 34, 2, 'Oktober', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1265, 2, 34, 2, 'November', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1266, 2, 34, 2, 'Desember', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1267, 2, 34, 2, 'Januari', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1268, 2, 34, 2, 'Febuari', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1269, 2, 34, 2, 'Maret', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1270, 2, 34, 2, 'April', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1271, 2, 34, 2, 'Mei', '60000', '0', '2022-04-13', '5', '622655');
INSERT INTO `sr_pembayaran_bulanan` (`id_pembayaran_bulanan`, `id_jenis_pembayaran`, `id_siswa`, `id_kelas`, `bulan`, `tagihan`, `bayar`, `tanggal`, `unit`, `akun`) VALUES (1272, 2, 34, 2, 'Juni', '60000', '0', '2022-04-13', '5', '622655');


#
# TABLE STRUCTURE FOR: sr_pengaduan
#

DROP TABLE IF EXISTS `sr_pengaduan`;

CREATE TABLE `sr_pengaduan` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `what` varchar(100) NOT NULL,
  `where` varchar(100) NOT NULL,
  `when` varchar(100) NOT NULL,
  `how` varchar(225) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `bukti` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_pengumuman
#

DROP TABLE IF EXISTS `sr_pengumuman`;

CREATE TABLE `sr_pengumuman` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `judul` varchar(255) NOT NULL,
  `konten` text NOT NULL,
  `tgl_tampil` date NOT NULL,
  `tgl_tutup` date NOT NULL,
  `tampil_siswa` tinyint(1) NOT NULL DEFAULT 1,
  `tampil_pengajar` tinyint(1) NOT NULL DEFAULT 1,
  `pengajar_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `pengajar_id` (`pengajar_id`),
  KEY `pengajar_id_2` (`pengajar_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

INSERT INTO `sr_pengumuman` (`id`, `judul`, `konten`, `tgl_tampil`, `tgl_tutup`, `tampil_siswa`, `tampil_pengajar`, `pengajar_id`) VALUES (6, 'imlek', '<p>Kepada seluruh SISWA, Libur <strong>IMLEK </strong>akan tiba!</p>\r\n', '2022-01-01', '2022-02-19', 1, 1, 1);


#
# TABLE STRUCTURE FOR: sr_perpusbiaya
#

DROP TABLE IF EXISTS `sr_perpusbiaya`;

CREATE TABLE `sr_perpusbiaya` (
  `id_biaya_denda` int(11) NOT NULL AUTO_INCREMENT,
  `harga_denda` varchar(255) NOT NULL,
  `stat` varchar(255) NOT NULL,
  `tgl_tetap` varchar(255) NOT NULL,
  PRIMARY KEY (`id_biaya_denda`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusbiaya` (`id_biaya_denda`, `harga_denda`, `stat`, `tgl_tetap`) VALUES (1, '40005', 'Aktif', '2019-11-23');


#
# TABLE STRUCTURE FOR: sr_perpusbuku
#

DROP TABLE IF EXISTS `sr_perpusbuku`;

CREATE TABLE `sr_perpusbuku` (
  `id_buku` int(11) NOT NULL AUTO_INCREMENT,
  `buku_id` varchar(255) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_rak` int(11) NOT NULL,
  `sampul` varchar(255) DEFAULT NULL,
  `isbn` varchar(255) DEFAULT NULL,
  `lampiran` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `penerbit` varchar(255) DEFAULT NULL,
  `pengarang` varchar(255) DEFAULT NULL,
  `thn_buku` varchar(255) DEFAULT NULL,
  `isi` text DEFAULT NULL,
  `jml` int(11) DEFAULT NULL,
  `tgl_masuk` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_buku`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusbuku` (`id_buku`, `buku_id`, `id_kategori`, `id_rak`, `sampul`, `isbn`, `lampiran`, `title`, `penerbit`, `pengarang`, `thn_buku`, `isi`, `jml`, `tgl_masuk`) VALUES (8, 'BK008', 2, 1, '0', '132-123-234-231', '0', 'CARA MUDAH BELAJAR PEMROGRAMAN C++', 'INFORMATIKA BANDUNG', 'BUDI RAHARJO ', '2012', '<table class=\"table table-bordered\" style=\"background-color: rgb(255, 255, 255); width: 653px; color: rgb(51, 51, 51);\"><tbody><tr><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Tipe Buku</td><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Kertas</td></tr><tr><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Bahasa</td><td style=\"padding: 8px; line-height: 1.42857; border-color: rgb(244, 244, 244);\">Indonesia</td></tr></tbody></table>', 23, '2019-11-23 11:49:57');
INSERT INTO `sr_perpusbuku` (`id_buku`, `buku_id`, `id_kategori`, `id_rak`, `sampul`, `isbn`, `lampiran`, `title`, `penerbit`, `pengarang`, `thn_buku`, `isi`, `jml`, `tgl_masuk`) VALUES (9, 'BK009', 2, 1, NULL, '121-163-214-231', NULL, 'Perkembangan Tekhnologi WEB 2.0', 'Maju Haya', 'Reza Lesmana', '2022', NULL, 121, '2019-11-23 11:49:57');
INSERT INTO `sr_perpusbuku` (`id_buku`, `buku_id`, `id_kategori`, `id_rak`, `sampul`, `isbn`, `lampiran`, `title`, `penerbit`, `pengarang`, `thn_buku`, `isi`, `jml`, `tgl_masuk`) VALUES (10, 'BK0010', 2, 1, NULL, '212', NULL, 'Pemograman PHP', 'Guntur Purnomo', 'Joko Simajuntak', '2020', NULL, 1, NULL);


#
# TABLE STRUCTURE FOR: sr_perpusdenda
#

DROP TABLE IF EXISTS `sr_perpusdenda`;

CREATE TABLE `sr_perpusdenda` (
  `id_denda` int(11) NOT NULL AUTO_INCREMENT,
  `pinjam_id` varchar(255) NOT NULL,
  `denda` varchar(255) NOT NULL,
  `lama_waktu` int(11) NOT NULL,
  `tgl_denda` varchar(255) NOT NULL,
  PRIMARY KEY (`id_denda`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (3, 'PJ001', '0', 0, '2020-05-20');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (5, 'PJ009', '0', 0, '2020-05-20');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (6, 'PJ0012', '0', 0, '2022-03-14');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (7, 'PJ0011', '0', 0, '2022-03-14');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (8, 'PJ0013', '0', 0, '2022-03-14');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (9, 'PJ0014', '0', 0, '2022-05-30');
INSERT INTO `sr_perpusdenda` (`id_denda`, `pinjam_id`, `denda`, `lama_waktu`, `tgl_denda`) VALUES (10, 'PJ0015', '0', 0, '2022-05-30');


#
# TABLE STRUCTURE FOR: sr_perpuskategori
#

DROP TABLE IF EXISTS `sr_perpuskategori`;

CREATE TABLE `sr_perpuskategori` (
  `id_kategori` int(11) NOT NULL AUTO_INCREMENT,
  `nama_kategori` varchar(255) NOT NULL,
  PRIMARY KEY (`id_kategori`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (2, 'Pemrograman');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (3, 'Kamus');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (4, 'Almanak');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (5, 'Direktori');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (6, 'Ensiklopedia');
INSERT INTO `sr_perpuskategori` (`id_kategori`, `nama_kategori`) VALUES (7, 'Buku Ajar');


#
# TABLE STRUCTURE FOR: sr_perpuspinjam
#

DROP TABLE IF EXISTS `sr_perpuspinjam`;

CREATE TABLE `sr_perpuspinjam` (
  `id_pinjam` int(11) NOT NULL AUTO_INCREMENT,
  `pinjam_id` varchar(255) NOT NULL,
  `anggota_id` varchar(255) NOT NULL,
  `buku_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `tgl_pinjam` varchar(255) NOT NULL,
  `lama_pinjam` int(11) NOT NULL,
  `tgl_balik` varchar(255) NOT NULL,
  `tgl_kembali` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_pinjam`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (12, 'PJ0012', '11', 'BK009', 'Di Kembalikan', '2022-03-14', 2, '2022-03-16', '2022-03-14');
INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (13, 'PJ0013', '14', 'BK009', 'Di Kembalikan', '2022-03-14', 5, '2022-03-19', '2022-03-14');
INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (14, 'PJ0014', '12', 'BK008', 'Di Kembalikan', '2022-05-30', 3, '2022-06-02', '2022-05-30');
INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (17, 'PJ0017', '12', 'BK008', 'Dipinjam', '2022-05-30', 3, '2022-06-02', '0');
INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (18, 'PJ0018', '14', 'BK0010', 'Dipinjam', '2022-05-30', 4, '2022-06-03', '0');
INSERT INTO `sr_perpuspinjam` (`id_pinjam`, `pinjam_id`, `anggota_id`, `buku_id`, `status`, `tgl_pinjam`, `lama_pinjam`, `tgl_balik`, `tgl_kembali`) VALUES (19, 'PJ0019', '17', 'BK0010', 'Dipinjam', '2022-05-30', 2, '2022-06-01', '0');


#
# TABLE STRUCTURE FOR: sr_perpusrak
#

DROP TABLE IF EXISTS `sr_perpusrak`;

CREATE TABLE `sr_perpusrak` (
  `id_rak` int(11) NOT NULL AUTO_INCREMENT,
  `nama_rak` varchar(255) NOT NULL,
  PRIMARY KEY (`id_rak`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_perpusrak` (`id_rak`, `nama_rak`) VALUES (1, 'Rak Buku 1');
INSERT INTO `sr_perpusrak` (`id_rak`, `nama_rak`) VALUES (3, 'Rak Buku 2');


#
# TABLE STRUCTURE FOR: sr_pos_pembayaran
#

DROP TABLE IF EXISTS `sr_pos_pembayaran`;

CREATE TABLE `sr_pos_pembayaran` (
  `id_pos` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `kode_akun` varchar(5) DEFAULT NULL,
  `nama_pos` varchar(100) DEFAULT NULL,
  `keterangan` text DEFAULT NULL,
  PRIMARY KEY (`id_pos`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_pos_pembayaran` (`id_pos`, `unit`, `kode_akun`, `nama_pos`, `keterangan`) VALUES (1, '5', '62265', 'SPP', 'Sumbangan Pendanaan Pendidikan');
INSERT INTO `sr_pos_pembayaran` (`id_pos`, `unit`, `kode_akun`, `nama_pos`, `keterangan`) VALUES (2, '5', '1', 'Biaya Bangunan', 'Bangunan Sekolah');
INSERT INTO `sr_pos_pembayaran` (`id_pos`, `unit`, `kode_akun`, `nama_pos`, `keterangan`) VALUES (3, '5', '62264', 'Buku Paket', 'Paket SMA');


#
# TABLE STRUCTURE FOR: sr_ppdb
#

DROP TABLE IF EXISTS `sr_ppdb`;

CREATE TABLE `sr_ppdb` (
  `id_ppdb` int(10) NOT NULL AUTO_INCREMENT,
  `no_pendaftaran` varchar(30) DEFAULT NULL,
  `nik` varchar(25) DEFAULT NULL,
  `jenis_pendaftaran` varchar(25) DEFAULT NULL,
  `jalur_pendaftaran` varchar(25) DEFAULT NULL,
  `hobi` varchar(55) DEFAULT NULL,
  `cita_cita` varchar(55) DEFAULT NULL,
  `nama_siswa` varchar(100) DEFAULT NULL,
  `jenis_kelamin` varchar(15) DEFAULT NULL,
  `tempat_lahir` varchar(55) DEFAULT NULL,
  `tanggal_lahir` varchar(15) DEFAULT NULL,
  `agama` varchar(15) DEFAULT NULL,
  `alamat` varchar(155) DEFAULT NULL,
  `rt` varchar(4) DEFAULT NULL,
  `rw` varchar(4) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kota` varchar(100) DEFAULT NULL,
  `kode_pos` varchar(15) DEFAULT NULL,
  `tempat_tinggal` varchar(55) DEFAULT NULL,
  `transportasi` varchar(15) DEFAULT NULL,
  `no_hp` varchar(15) DEFAULT NULL,
  `email` varchar(55) DEFAULT NULL,
  `kewarganegaraan` varchar(15) DEFAULT NULL,
  `foto` varchar(155) DEFAULT NULL,
  `tinggi_badan` varchar(3) DEFAULT NULL,
  `berat_badan` varchar(3) DEFAULT NULL,
  `jarak_ke_sekolah` varchar(4) DEFAULT NULL,
  `waktu_tempuh_ke_sekolah` varchar(4) DEFAULT NULL,
  `jumlah_saudara` varchar(2) DEFAULT NULL,
  `asal_sekolah` varchar(255) NOT NULL,
  `alamat_sekolah_asal` varchar(255) NOT NULL,
  `nama_ayah` varchar(55) DEFAULT NULL,
  `tahun_lahir_ayah` varchar(4) DEFAULT NULL,
  `pendidikan_ayah` varchar(15) DEFAULT NULL,
  `pekerjaan_ayah` varchar(55) DEFAULT NULL,
  `penghasilan_ayah` varchar(55) DEFAULT NULL,
  `nama_ibu` varchar(55) DEFAULT NULL,
  `tahun_lahir_ibu` varchar(4) DEFAULT NULL,
  `pendidikan_ibu` varchar(15) DEFAULT NULL,
  `pekerjaan_ibu` varchar(55) DEFAULT NULL,
  `penghasilan_ibu` varchar(55) DEFAULT NULL,
  `nama_wali` varchar(55) DEFAULT NULL,
  `tahun_lahir_wali` varchar(4) DEFAULT NULL,
  `pendidikan_wali` varchar(15) DEFAULT NULL,
  `pekerjaan_wali` varchar(55) DEFAULT NULL,
  `penghasilan_wali` varchar(50) DEFAULT NULL,
  `status` char(1) DEFAULT '0',
  `tanggal_daftar` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id_ppdb`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `sr_ppdb` (`id_ppdb`, `no_pendaftaran`, `nik`, `jenis_pendaftaran`, `jalur_pendaftaran`, `hobi`, `cita_cita`, `nama_siswa`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `agama`, `alamat`, `rt`, `rw`, `provinsi`, `kota`, `kode_pos`, `tempat_tinggal`, `transportasi`, `no_hp`, `email`, `kewarganegaraan`, `foto`, `tinggi_badan`, `berat_badan`, `jarak_ke_sekolah`, `waktu_tempuh_ke_sekolah`, `jumlah_saudara`, `asal_sekolah`, `alamat_sekolah_asal`, `nama_ayah`, `tahun_lahir_ayah`, `pendidikan_ayah`, `pekerjaan_ayah`, `penghasilan_ayah`, `nama_ibu`, `tahun_lahir_ibu`, `pendidikan_ibu`, `pekerjaan_ibu`, `penghasilan_ibu`, `nama_wali`, `tahun_lahir_wali`, `pendidikan_wali`, `pekerjaan_wali`, `penghasilan_wali`, `status`, `tanggal_daftar`) VALUES (5, 'REG-20220407-0001', '3175052605970002', 'Baru', 'Umum', 'Berenang', 'Astronot', 'Reza Lesmana Putra', 'Laki-laki', 'Jakarta', '1997-05-26', 'Islam', 'Jl Pertengahan', '11', '03', 'DKI Jakarta', NULL, '13770', 'Kos', '', '081280462650', 'rzalvaero@gmail.com', 'WNI', '', '170', '50', '50', '', '1', 'SMP Islam Malahayati', 'Jl Bima', 'Andriansyah', '1981', 'S1', 'Wiraswasta', '5.000.000 - 10.000.000', 'Tuti Yati', '1982', 'SMP Sederajat', 'Wiraswasta', '2.000.000 - 4.999.990', '', '', NULL, 'Pekerjaan', 'Pendapatan', '-', '2022-04-07 19:37:34');


#
# TABLE STRUCTURE FOR: sr_prestasi
#

DROP TABLE IF EXISTS `sr_prestasi`;

CREATE TABLE `sr_prestasi` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `id_siswa` int(6) NOT NULL,
  `ta` char(5) NOT NULL,
  `jenis` varchar(100) NOT NULL,
  `keterangan` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `sr_prestasi` (`id`, `id_siswa`, `ta`, `jenis`, `keterangan`) VALUES (1, 11, '1', 'Juara 1', 'Karate');


#
# TABLE STRUCTURE FOR: sr_prota
#

DROP TABLE IF EXISTS `sr_prota`;

CREATE TABLE `sr_prota` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `semester` varchar(100) NOT NULL,
  `pengetahuan` varchar(255) NOT NULL,
  `keterampilan` varchar(225) NOT NULL,
  `waktu` varchar(100) NOT NULL,
  `ket` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_prota` (`id`, `unit`, `semester`, `pengetahuan`, `keterampilan`, `waktu`, `ket`) VALUES (1, '5', '2021/2022-2', 'Pengetahuan Dasar', 'Keterampilan Dasar', '3 Pertemuan / 3 x 40', 'Keterngan');


#
# TABLE STRUCTURE FOR: sr_provinsi
#

DROP TABLE IF EXISTS `sr_provinsi`;

CREATE TABLE `sr_provinsi` (
  `province_id` int(11) NOT NULL,
  `province` varchar(100) NOT NULL,
  PRIMARY KEY (`province_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (1, 'Bali');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (2, 'Bangka Belitung');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (3, 'Banten');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (4, 'Bengkulu');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (5, 'DI Yogyakarta');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (6, 'DKI Jakarta');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (7, 'Gorontalo');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (8, 'Jambi');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (9, 'Jawa Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (10, 'Jawa Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (11, 'Jawa Timur');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (12, 'Kalimantan Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (13, 'Kalimantan Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (14, 'Kalimantan Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (15, 'Kalimantan Timur');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (16, 'Kalimantan Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (17, 'Kepulauan Riau');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (18, 'Lampung');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (19, 'Maluku');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (20, 'Maluku Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (21, 'Nanggroe Aceh Darussalam (NAD)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (22, 'Nusa Tenggara Barat (NTB)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (23, 'Nusa Tenggara Timur (NTT)');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (24, 'Papua');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (25, 'Papua Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (26, 'Riau');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (27, 'Sulawesi Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (28, 'Sulawesi Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (29, 'Sulawesi Tengah');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (30, 'Sulawesi Tenggara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (31, 'Sulawesi Utara');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (32, 'Sumatera Barat');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (33, 'Sumatera Selatan');
INSERT INTO `sr_provinsi` (`province_id`, `province`) VALUES (34, 'Sumatera Utara');


#
# TABLE STRUCTURE FOR: sr_rencana_kd_keterampilan
#

DROP TABLE IF EXISTS `sr_rencana_kd_keterampilan`;

CREATE TABLE `sr_rencana_kd_keterampilan` (
  `idrencana_kd_keterampilan` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `rkdk_penilaian_harian` int(11) NOT NULL,
  PRIMARY KEY (`idrencana_kd_keterampilan`),
  KEY `idusers` (`idusers`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idkelas` (`idkelas`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_rencana_kd_keterampilan_ibfk_1` FOREIGN KEY (`idtahun_pelajaran`) REFERENCES `sr_tahun_pelajaran` (`idtahun_pelajaran`),
  CONSTRAINT `sr_rencana_kd_keterampilan_ibfk_2` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`),
  CONSTRAINT `sr_rencana_kd_keterampilan_ibfk_3` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`),
  CONSTRAINT `sr_rencana_kd_keterampilan_ibfk_4` FOREIGN KEY (`idmata_pelajaran`) REFERENCES `sr_mata_pelajaran` (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (11, 1, 1, 1, 2, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (12, 1, 42, 1, 49, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (13, 1, 42, 1, 50, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (14, 1, 42, 1, 3, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (15, 1, 42, 1, 46, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (16, 1, 42, 1, 47, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (17, 1, 40, 1, 1, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (18, 1, 39, 1, 48, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (19, 1, 41, 1, 51, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (20, 1, 57, 17, 2, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (21, 1, 57, 17, 51, 2);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (22, 2, 42, 1, 2, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (24, 1, 37, 2, 2, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (25, 1, 37, 2, 49, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (26, 1, 37, 2, 50, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (27, 1, 37, 2, 3, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (28, 1, 37, 2, 46, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (29, 1, 37, 2, 47, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (30, 1, 40, 2, 1, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (31, 1, 41, 2, 51, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (32, 1, 39, 2, 48, 1);
INSERT INTO `sr_rencana_kd_keterampilan` (`idrencana_kd_keterampilan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdk_penilaian_harian`) VALUES (33, 2, 42, 1, 49, 1);


#
# TABLE STRUCTURE FOR: sr_rencana_kd_pengetahuan
#

DROP TABLE IF EXISTS `sr_rencana_kd_pengetahuan`;

CREATE TABLE `sr_rencana_kd_pengetahuan` (
  `idrencana_kd_pengetahuan` int(11) NOT NULL AUTO_INCREMENT,
  `idtahun_pelajaran` int(11) NOT NULL,
  `idusers` int(10) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `idmata_pelajaran` int(11) NOT NULL,
  `rkdp_penilaian_harian` int(11) NOT NULL,
  PRIMARY KEY (`idrencana_kd_pengetahuan`),
  KEY `idusers` (`idusers`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idkelas` (`idkelas`),
  KEY `idmata_pelajaran` (`idmata_pelajaran`),
  CONSTRAINT `sr_rencana_kd_pengetahuan_ibfk_1` FOREIGN KEY (`idtahun_pelajaran`) REFERENCES `sr_tahun_pelajaran` (`idtahun_pelajaran`),
  CONSTRAINT `sr_rencana_kd_pengetahuan_ibfk_2` FOREIGN KEY (`idkelas`) REFERENCES `sr_kelas` (`idkelas`),
  CONSTRAINT `sr_rencana_kd_pengetahuan_ibfk_3` FOREIGN KEY (`idusers`) REFERENCES `users` (`id`),
  CONSTRAINT `sr_rencana_kd_pengetahuan_ibfk_4` FOREIGN KEY (`idmata_pelajaran`) REFERENCES `sr_mata_pelajaran` (`idmata_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (23, 1, 1, 1, 2, 3);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (24, 1, 42, 1, 49, 3);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (25, 1, 42, 1, 50, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (26, 1, 42, 1, 3, 3);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (27, 1, 42, 1, 46, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (28, 1, 42, 1, 47, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (29, 1, 40, 1, 1, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (30, 1, 39, 1, 48, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (31, 1, 41, 1, 51, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (33, 1, 57, 17, 2, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (34, 1, 57, 17, 51, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (35, 2, 42, 1, 2, 2);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (37, 1, 37, 2, 2, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (38, 1, 37, 2, 49, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (39, 1, 37, 2, 50, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (40, 1, 37, 2, 3, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (41, 1, 37, 2, 46, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (42, 1, 37, 2, 47, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (43, 1, 40, 2, 1, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (44, 1, 41, 2, 51, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (45, 1, 39, 2, 48, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (46, 2, 42, 1, 49, 1);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (47, 1, 44, 5, 2, 3);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (48, 6, 41, 3, 51, 10);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (49, 6, 41, 1, 51, 4);
INSERT INTO `sr_rencana_kd_pengetahuan` (`idrencana_kd_pengetahuan`, `idtahun_pelajaran`, `idusers`, `idkelas`, `idmata_pelajaran`, `rkdp_penilaian_harian`) VALUES (50, 6, 41, 2, 51, 1);


#
# TABLE STRUCTURE FOR: sr_rpp
#

DROP TABLE IF EXISTS `sr_rpp`;

CREATE TABLE `sr_rpp` (
  `idkompetensi_dasar` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(10) NOT NULL,
  `idtahun_pelajaran` varchar(100) NOT NULL,
  `idusers` int(11) unsigned NOT NULL,
  `idkelas` int(11) NOT NULL,
  `mata_pelajaran` varchar(100) NOT NULL,
  `kd_kategori` enum('Pengetahuan','Keterampilan') NOT NULL,
  `kd_nama` text NOT NULL,
  `kd_status` enum('Y','N') NOT NULL,
  `alokasi` varchar(100) DEFAULT NULL,
  `tujuan` varchar(255) NOT NULL,
  `materi` varchar(255) NOT NULL,
  `metode` varchar(255) NOT NULL,
  `media` varchar(255) NOT NULL,
  `sumber` varchar(255) NOT NULL,
  `penilaian` varchar(255) NOT NULL,
  PRIMARY KEY (`idkompetensi_dasar`),
  KEY `idtahun_pelajaran` (`idtahun_pelajaran`),
  KEY `idusers` (`idusers`),
  KEY `idmata_pelajaran` (`mata_pelajaran`),
  KEY `idkelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_rpp` (`idkompetensi_dasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `mata_pelajaran`, `kd_kategori`, `kd_nama`, `kd_status`, `alokasi`, `tujuan`, `materi`, `metode`, `media`, `sumber`, `penilaian`) VALUES (1, '5', '2021/2022-2', 0, 1, 'Bahasa Indonesia', 'Pengetahuan', 'RPP - Teks Prosedur ', 'Y', '3 Pertemuan / 3 x 40', '<p>Setelah kegiatan belajar mengajar selesai, peserta didik dapat :</p>\r\n\r\n<ol>\r\n	<li>Mengonstruksikan informasi;</li>\r\n	<li>Merancang pernyataan umum dan tahapan-tahapan;</li>\r\n	<li>Menganalisis struktur dan isi teks prosedur; dan</li>\r\n	<li>Mengembangka', '<table border=\"1\" cellpadding=\"1\" cellspacing=\"1\" style=\"width:100%\">\r\n	<tbody>\r\n		<tr>\r\n			<td>Konsep</td>\r\n			<td>Prinsip</td>\r\n			<td>Prosedur</td>\r\n		</tr>\r\n		<tr>\r\n			<td>\r\n			<ul>\r\n				<li>Isi Teks Prosedur</li>\r\n			</ul>\r\n			</td>\r\n			<td>\r\n			<ul>', '<p><em>Pendekatan : Saintifik Model </em></p>\r\n\r\n<p><em>Pembelajaran : Discovery learning</em></p>\r\n', '<p>HP atau Laptop</p>\r\n', '<ul>\r\n	<li>Buku penunjang kurikulum 2013 mata pelajaran Bahasa Indonesia Kelas XI Kemendikbud, 2017</li>\r\n	<li>Pengalaman peserta didik dan guru</li>\r\n</ul>\r\n', '<ul>\r\n	<li>a) Penilaian Sikap a. Ketepatan pegumpulan tugas (disiplin) b. Kejujuran pekerjaan (tidak plagiat)</li>\r\n	<li>b) Pengetahuan a. Pertanyaan tugas di googleclassroom</li>\r\n	<li>c) Keterampilan a. Tampilan tugas (guru sudah meminta agar tugas dike');
INSERT INTO `sr_rpp` (`idkompetensi_dasar`, `unit`, `idtahun_pelajaran`, `idusers`, `idkelas`, `mata_pelajaran`, `kd_kategori`, `kd_nama`, `kd_status`, `alokasi`, `tujuan`, `materi`, `metode`, `media`, `sumber`, `penilaian`) VALUES (3, '5', '2021/2022-2', 0, 4, 'Multimedia', 'Keterampilan', 'RPP - Kesehatan, Keselamatan Kerja dan Lingkungan Hidup', 'Y', '3 Pertemuan / 3 x 40', '<p>Peserta didik mampu:</p>\r\n\r\n<ul>\r\n	<li>&nbsp;Menjelaskan perbedaan kesehatan dan keselamatan kerja</li>\r\n	<li>Menjelaskan peraturan dasar umum keselamatan kerja</li>\r\n	<li>Mengetahui macam-macam perlengkapan alat dan bahan dalam bekerja</li>\r\n</ul>\r\n', '<ol>\r\n	<li>a. Menjelaskan deskripsi Kesehatan, Keselamatan Kerja dan Lingkungan Hidup</li>\r\n	<li>b. Menjelaskan apa saja peralatan yang digunakan sebagai pelindung dalam keselamatan kerja</li>\r\n</ol>\r\n', '<ol>\r\n	<li>Model Pembelajaran</li>\r\n	<li>Kooperatif Learning</li>\r\n	<li>Direct Intruction (DI)</li>\r\n</ol>\r\n', '<p>Handphone / Tulis</p>\r\n', '<p>- Modul</p>\r\n\r\n<p>- Web-based IT</p>\r\n\r\n<p>- Buku teks kesehatan dan keselamatan kerja</p>\r\n', '<p>a. Teknik Penilaian : Tertulis, Lisan</p>\r\n\r\n<p>b. Bentuk instrumen : Tes lisan, Uji tulis</p>\r\n');


#
# TABLE STRUCTURE FOR: sr_setting_gaji
#

DROP TABLE IF EXISTS `sr_setting_gaji`;

CREATE TABLE `sr_setting_gaji` (
  `id_setting_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `nip` varchar(5) DEFAULT NULL,
  `nama` varchar(5) DEFAULT NULL,
  `jabatan` varchar(100) DEFAULT NULL,
  `status_kepegawaian` varchar(20) DEFAULT NULL,
  `jenjang` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_setting_gaji`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

#
# TABLE STRUCTURE FOR: sr_setting_pendapatan_lain_lain
#

DROP TABLE IF EXISTS `sr_setting_pendapatan_lain_lain`;

CREATE TABLE `sr_setting_pendapatan_lain_lain` (
  `id_setting_pendapatan_lain_lain` int(11) NOT NULL AUTO_INCREMENT,
  `nama_setting_pendapatan_lain_lain` varchar(50) NOT NULL,
  `nominal_setting_pendapatan_lain_lain` varchar(30) NOT NULL,
  PRIMARY KEY (`id_setting_pendapatan_lain_lain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_setting_pendapatan_lain_lain` (`id_setting_pendapatan_lain_lain`, `nama_setting_pendapatan_lain_lain`, `nominal_setting_pendapatan_lain_lain`) VALUES (1, 'Bonus THR', '100000');


#
# TABLE STRUCTURE FOR: sr_setting_potongan
#

DROP TABLE IF EXISTS `sr_setting_potongan`;

CREATE TABLE `sr_setting_potongan` (
  `id_setting_potongan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_setting_potongan` varchar(50) NOT NULL,
  `nominal_setting_potongan` varchar(30) NOT NULL,
  PRIMARY KEY (`id_setting_potongan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_setting_potongan` (`id_setting_potongan`, `nama_setting_potongan`, `nominal_setting_potongan`) VALUES (1, 'BPJS Kesehatan1', '1000000');
INSERT INTO `sr_setting_potongan` (`id_setting_potongan`, `nama_setting_potongan`, `nominal_setting_potongan`) VALUES (2, 'makan', '2000');


#
# TABLE STRUCTURE FOR: sr_setting_tunjangan
#

DROP TABLE IF EXISTS `sr_setting_tunjangan`;

CREATE TABLE `sr_setting_tunjangan` (
  `id_setting_tunjangan` int(11) NOT NULL AUTO_INCREMENT,
  `nama_setting_tunjangan` varchar(50) NOT NULL,
  `nominal_setting_tunjangan` varchar(30) NOT NULL,
  PRIMARY KEY (`id_setting_tunjangan`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_setting_tunjangan` (`id_setting_tunjangan`, `nama_setting_tunjangan`, `nominal_setting_tunjangan`) VALUES (2, 'Tunjangan Anak', '100000');


#
# TABLE STRUCTURE FOR: sr_sikap
#

DROP TABLE IF EXISTS `sr_sikap`;

CREATE TABLE `sr_sikap` (
  `id_sikap` int(11) NOT NULL AUTO_INCREMENT,
  `nama_sikap` varchar(200) NOT NULL,
  PRIMARY KEY (`id_sikap`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_sikap` (`id_sikap`, `nama_sikap`) VALUES (2, 'jujur');
INSERT INTO `sr_sikap` (`id_sikap`, `nama_sikap`) VALUES (3, 'bersih');


#
# TABLE STRUCTURE FOR: sr_silabus
#

DROP TABLE IF EXISTS `sr_silabus`;

CREATE TABLE `sr_silabus` (
  `idsilabus` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(100) NOT NULL,
  `kompetensi_dasar` varchar(100) NOT NULL,
  `indikator_kd` text NOT NULL,
  `materi_pembelajaran_kd` text NOT NULL,
  `kegiatan_pembelajaran_kd` text NOT NULL,
  `tk_kd` varchar(200) NOT NULL,
  `bi_kd` varchar(200) NOT NULL,
  `in_kd` varchar(200) NOT NULL,
  `alokasi` varchar(200) NOT NULL,
  `sumber` varchar(255) NOT NULL,
  PRIMARY KEY (`idsilabus`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_silabus` (`idsilabus`, `unit`, `kompetensi_dasar`, `indikator_kd`, `materi_pembelajaran_kd`, `kegiatan_pembelajaran_kd`, `tk_kd`, `bi_kd`, `in_kd`, `alokasi`, `sumber`) VALUES (11, '5', 'Mendiskripsikan fungsi \nkonsumsi dan \nfungsi \ntabungan', '<p><strong>Kognitif Konten</strong></p><ol><li>Mendiskripsikan hubungan konsumsi dan pendapatan</li><li>Menghitung kecenderungan konsumsi</li><li>Mengidentifikasi faktor yang mempengaruh konsumsi</li></ol>', '<ol><li>1. Konsumsi</li><li>1.1. Hubungan fungsional konsumsi dan pendapatan</li><li>1.2. Kecenderngan konsumsi</li><li>1.3. Faktor yang mempengaruhi konsumsi</li><li>1.4. kurva konsumsi</li></ol>', '<p>Mengamati, menghitung, menggambar, merumuskan dan memprediksi fungsi konsumsi</p>', 'Tes tertulis', 'Pilihan  ganda Essei', 'LP 1 Hubungan C  dan Y, kecenderung an, faktor,  kurva dan  fungsi  konsusi', '4 Pertemuan / 4 x 40', '<ul><li>Materi Ajar Fungsi Konsumsi dan Fungsi Tabungan</li><li>Power point 1-25</li><li>Lembar Penilaian</li><li>Kunci LP 1-3</li></ul>');


#
# TABLE STRUCTURE FOR: sr_siswa
#

DROP TABLE IF EXISTS `sr_siswa`;

CREATE TABLE `sr_siswa` (
  `idsiswa` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `s_nisn` varchar(50) NOT NULL,
  `s_nama` varchar(100) NOT NULL,
  `s_nik` varchar(255) NOT NULL,
  `s_jenis_kelamin` enum('P','L') NOT NULL,
  `s_tl_idprovinsi` int(11) NOT NULL,
  `s_tl_idkota` int(11) NOT NULL,
  `s_tanggal_lahir` date NOT NULL,
  `idkelas` int(11) NOT NULL,
  `s_email` varchar(255) NOT NULL,
  `s_telepon` varchar(20) NOT NULL,
  `s_wali` varchar(255) NOT NULL,
  `s_dusun` varchar(255) NOT NULL,
  `s_desa` varchar(255) NOT NULL,
  `s_kecamatan` varchar(255) NOT NULL,
  `s_domisili` enum('Dalam','Luar') NOT NULL,
  `s_abk` enum('Ya','Tidak') NOT NULL,
  `s_bsm_pip` enum('Ya','Tidak') NOT NULL,
  `s_keluarga_miskin` enum('Ya','Tidak') NOT NULL,
  `s_code_generator` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`idsiswa`),
  KEY `s_tl_idprovinsi` (`s_tl_idprovinsi`),
  KEY `s_tl_idkota` (`s_tl_idkota`),
  KEY `idkelas` (`idkelas`)
) ENGINE=InnoDB AUTO_INCREMENT=145 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (11, '5', '204035871360', 'Aji Putra Arshavin ', '3401120912120001', 'L', 5, 210, '2012-01-09', 1, 'mas.ghaly88@gmail.com', '081977700271', 'Sulistyo', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', '');
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (12, '5', '204035871361', 'Alya Zafaranie Rahman', '3401124304130003', 'P', 5, 210, '2013-04-13', 1, 'lorin.enjubella88@gmail.com', '0819928822', 'Fauzur Rahman', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', '716258');
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (13, '5', '204035871362', 'Bintang Rakha Raqila', '3401120711120001', 'L', 5, 210, '2012-11-07', 1, '', '', 'Haryadi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (14, '5', '204035871363', 'Damar Lestari', '3401126504130001', 'P', 5, 210, '2013-04-25', 1, '', '', 'Nuryanto', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (15, '5', '204035871364', 'Dava Bayu Setiawan', '3401122106130001', 'L', 5, 210, '2013-06-21', 1, '', '', 'Kumara', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (16, '5', '204035871365', 'Faris Husnul Arfan', '3401120805130001', 'P', 5, 210, '2013-05-08', 1, '', '', 'Madiyono', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (17, '5', '204035871366', 'Hasna Khaira Nadhiva', '3401125209120001', 'P', 5, 210, '2012-09-12', 1, '', '', 'Sutriyono', 'KLANGON', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (18, '5', '204035871367', 'Lafida Dwi Saputri', '3401126310120001', 'P', 5, 210, '2012-10-23', 1, '', '', 'Hajib Ja&#039;far', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (19, '5', '204035871368', 'Muhammad Barik Al-Bani', '3401120202130001', 'L', 5, 210, '2013-02-02', 1, '', '', 'Slamet Sulbani', 'SEMAWUNG', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (20, '5', '204035871369', 'Muhammad Haidar Yaqdhan', '3401121806130001', 'L', 5, 210, '2013-06-18', 1, '', '', 'Isdadi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (21, '5', '204035871370', 'Muhammad Nehru Wiratama', '3310032711120002', 'L', 10, 196, '2012-11-27', 1, '', '', 'Bachtiar Bakriyanto', 'KARANGLO', 'TANJUNGAN', 'KEC. WEDI', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (22, '5', '204035871371', 'Rani Prasetya Mawardi', '3401126604130002', 'P', 5, 210, '2015-04-16', 1, '', '', 'Mawardi', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (23, '5', '204035871372', 'Raviola Eka Valentina', '3315136901130001', 'P', 10, 134, '2013-01-29', 1, '', '', 'Muhdaryanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (24, '5', '204035871373', 'Reza Rahardyan Firmansyah', '3401121101130001', 'L', 5, 210, '2013-01-11', 1, '', '', 'Hariyanto', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (25, '5', '204035871374', 'Saffa Arumi Ghaisani', '3205306505130002', 'P', 9, 126, '2013-05-25', 1, '', '', 'Ramdani', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (26, '5', '204035871375', 'Salma Safira', '3401125404130001', 'P', 5, 210, '2013-12-04', 1, '', '', 'Porwanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (27, '5', '204035871376', 'Shella Hikmatul Hidayah', '3401124902130001', 'P', 5, 210, '2013-09-02', 1, '', '', 'Haryanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (28, '5', '204035871377', 'Syakira Rizka Prawestri', '3401125109120001', 'P', 5, 210, '2012-11-09', 1, '', '', 'Walmuji', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (29, '5', '204035871378', 'Taufiq Hidayat', '3401122006130001', 'L', 5, 210, '2013-06-20', 1, '', '', 'Edi Hartanto', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (30, '5', '204035871379', 'Zahra Dian Salsabilla', '3401124203130001', 'P', 5, 210, '2013-03-02', 1, '', '', 'Muhdi', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (31, '5', '204035871380', 'Zahwa Adina Putri', '3308036006130001', 'P', 10, 249, '2013-06-20', 1, '', '', 'Afda Setiawan', 'GANJURAN', 'PLOSOGEDE', 'KEC. NGLUWAR', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (32, '5', '0119228271', 'Andhika Rohman Indra Wijaya', '3401122805110003', 'L', 5, 210, '2011-05-28', 2, '', '', 'Agus Anwari', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (33, '5', '0111065143', 'Adit Hendryawan', '3401121812110001', 'L', 5, 210, '2011-12-18', 2, '', '', 'SARJONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (34, '5', '0111566716', 'Alvino Bagus Hendrawan', '3308040907110003', 'L', 10, 249, '2011-07-09', 2, '', '', 'Muh Fahrudin', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (39, '5', '0123535887', 'Anissa Rizki Maulidza', '3401124302120001', 'P', 5, 210, '2012-02-03', 2, '', '', 'NARPANDI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (40, '5', '0117476280', 'Asmawa Fastina Artanti', '3401124302120001', 'P', 10, 476, '2011-08-19', 2, '', '', 'SUDIYANTO', 'KLANGON', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (41, '5', '0108250622', 'Hafidz Nurul Ikhsan', '3401121410100002', 'L', 5, 210, '2010-10-14', 2, '', '', 'MUJIYANTA', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (42, '5', '0129187164', 'Hafiz il Sya&#039;bana', '3401120207120002', 'L', 5, 210, '2012-07-02', 2, '', '', 'UDIYANTO', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (43, '5', '0123340033', 'Haikal Daffa Salman Faiz', '3401121006120001', 'L', 5, 210, '2012-06-10', 2, '', '', 'GUNTORO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (44, '5', '0112159539', 'Hammam Razka Pradipta', '3401120712110001', 'L', 5, 210, '2011-12-07', 2, '', '', 'AGUNG BUDIAJI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (45, '5', '0111083351', 'Heevan Alyansyah Alfajr', '6302151410110001', 'L', 13, 203, '2011-10-14', 2, '', '', 'SYAHRUL FUJIANSYAH', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (46, '5', '0125752767', 'Najwa Zalfa Khoirunnisa', '3401126004120001', 'P', 5, 210, '2012-04-20', 2, '', '', 'OTANG HATAMI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (47, '5', '0117400693', 'Nungraeni Desy Safira Putri', '3401124612110001', 'P', 5, 210, '2011-12-08', 2, '', '', 'SUTARI', 'PANTOG WETAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (48, '5', '0123596402', 'Nur Alifa Loveana Anjani', '3401125101120002', 'P', 5, 210, '2012-01-11', 2, '', '', 'NURKOYIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (49, '5', '0117452080', 'Oktaviar Alhuwa Mufid', '3401120710110001', 'L', 5, 210, '2011-10-07', 2, '', '', 'MUHYIDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (50, '5', '0112830228', 'Qalitza Zahwa Khairani', '3401126509110001', 'P', 5, 210, '2011-09-15', 2, '', '', 'SUNGKONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (51, '5', '0121515850', 'Raffa Ahmad Sholikhin', '3401120803120001', 'L', 5, 210, '2012-03-08', 2, '', '', 'TOHA RUDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (52, '5', '0121854845', 'Rendita Febriana Saputri', '3401124702120002', 'P', 5, 210, '2012-02-07', 2, '', '', 'YULI SUSANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (53, '5', '0114655050', 'Reyhan Saputra', '3308081508120003', 'L', 10, 249, '2011-08-15', 2, '', '', 'FAJAR SETIADI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (54, '5', '0124032295', 'Risky Putra Wahyu Pratama', '3401121602120004', 'L', 5, 210, '2012-02-16', 2, '', '', 'TRI YULIANA', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (55, '5', '0113120197', 'Tedy Ahmad Santoso', '3401120210110001', 'L', 5, 210, '2011-10-02', 2, '', '', 'SUYOTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (56, '5', '0129915965', 'Tsania Zahra Maulida', '3401125602120001', 'P', 5, 210, '2012-02-16', 2, '', '', 'SISWANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (57, '5', '0125805929', 'Wanda Febriani Wulandari', '3211226902120002', 'P', 9, 440, '2012-02-29', 2, '', '', 'MUHROSID', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (58, '5', '0106708074', 'Ananda Aulia', '3401124611100001', 'P', 5, 210, '2010-11-06', 3, '', '', 'SUYADI', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (59, '5', '0108998849', 'Andini Nur Rahmawati', '3401124107100001', 'P', 5, 210, '2010-07-01', 3, '', '', 'YANI FATMAWATI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (60, '5', '0111353064', 'Annas Hamid', '3401121804110001', 'L', 5, 210, '2011-04-18', 3, '', '', 'SURATIN', 'BANJARAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (61, '5', '0118767416', 'As Syifa Dwi Pradayanti  ', '3401124905110002', 'P', 5, 210, '2011-05-09', 3, '', '', 'SUPARNO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (62, '5', '0082175383', 'Astri Widya Pramesti', '3401125408080002', 'P', 10, 196, '2008-08-14', 3, '', '', 'PRAWOTO SUHARYONO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (63, '5', '0103368264', 'Bayu Ardhan Handaru', '3401120209100001', 'L', 5, 210, '2010-09-02', 3, '', '', 'KOMARUDIN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (64, '5', '0103094001', 'Bintara Ardyama Saputra', '3401120907100001', 'L', 5, 210, '2010-07-09', 3, '', '', 'PARJIMIN', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (65, '5', '0107104381', 'Dava Jiffin Adelino Romadi', '3401121110100001', 'L', 5, 210, '2010-10-11', 3, '', '', 'EKA ROMADI', 'DUWET III', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (66, '5', '0102553662', 'Dayinta Kumala Wijaya Esti', '3401124607100002', 'P', 5, 210, '2010-07-06', 3, '', '', 'SUPRIYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (67, '5', '0117972015', 'Fendy Adinata Wicaksono', '3401122103110001', 'L', 5, 210, '2011-03-21', 3, '', '', 'MARWANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (68, '5', '0101989546', 'Ghiffara Najwa Azzahra', '3401126508100001', 'P', 5, 210, '2010-08-25', 3, '', '', 'ASHARIHIDAYAT', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (69, '5', '0106111309', 'Hasna Nur Afifah', '3401125911100001', 'P', 5, 210, '2010-11-19', 3, '', '', 'SUBARDI', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (70, '5', '0111549550', 'Iin Wulan Safa Yanunisa', '3401126001110001', 'P', 5, 210, '2011-01-20', 3, '', '', 'AHMAD SUPRIYADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (71, '5', '0164045268', 'Imam Santoso', '3401120505090001', 'L', 5, 210, '2009-05-05', 3, '', '', 'NURROHMAN', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (72, '5', '0111117352', 'Irma Aprilia Fatmawati', '3401127103110001', 'P', 5, 210, '2011-03-31', 3, '', '', 'SUPARTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (73, '5', '0103650256', 'Khanif Choiru Rochman', '3401122407110001', 'L', 5, 210, '2010-07-24', 3, '', '', 'MUH AHMAD BANI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (74, '5', '0103523847', 'Misbachul Lubab', '3401122907100001', 'L', 5, 210, '2010-07-29', 3, '', '', 'SUWITA', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (75, '5', '0105356940', 'Muhammad Abdul Azis Ramadhan', '3401120409100001', 'L', 5, 210, '2010-09-04', 3, '', '', 'SUDARYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (76, '5', '0122709840', 'Muvida Shobrina', '3401126608110001', 'P', 5, 210, '2012-08-26', 3, '', '', 'SUROTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (77, '5', '0113062348', 'Putri Khansa Udtiana Nafeeza', '3401124203110002', 'P', 5, 210, '2011-03-02', 3, '', '', 'DUL MASHUD', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (78, '5', '0102233405', 'Renata Okta Anjaini', '3401126210100002', 'P', 5, 210, '2010-10-22', 3, '', '', 'NURYANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (79, '5', '0119158123', 'Rendra Alfirkhan Nakholid', '3401121504110001', 'L', 5, 210, '2011-04-15', 3, '', '', 'IDIK IRYANTO', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (80, '5', '0115192584', 'Rifqi Ahmad Yanuarivan', '3401120901110001', 'L', 5, 210, '2011-01-09', 3, '', '', 'MUH AHMAD', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (81, '5', '0112461768', 'Risnawati', '3401125606110001', 'P', 5, 210, '2011-06-26', 3, '', '', 'RISNAWATI', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (82, '5', '0096993456', 'Sri Astuti', '3401120407090001', 'P', 5, 210, '2009-07-04', 3, '', '', 'SITI KALIMAH', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (83, '5', '0111138060', 'Syifa Nuriasari', '3401126802110001', 'P', 5, 210, '2011-02-28', 3, '', '', 'NUR AKHABAH ZAIBAN', 'PRANAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (84, '5', '0114478714', 'Tri Ega Saputra', '3401122003110002', 'L', 5, 210, '2011-03-20', 3, '', '', 'SUKIDI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (85, '5', '0109611361', 'Yumna Aulia Zulfa', '3401124110100001', 'P', 5, 210, '2010-10-01', 3, '', '', 'FARID PRATIKNA', 'POTRONALAN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (86, '5', '0112997704', 'Adnanda Galih Yudistira', '3401120305110001', 'L', 5, 210, '2011-05-03', 3, '', '', 'HERIYANTO', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (87, '5', '0097073468', 'Adnan Rangga Kurniawan', '3401120103090001', 'L', 5, 210, '2009-03-01', 4, '', '', 'SUWARTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (88, '5', '0104677724', 'Ahmad Muthohar', '3401120301100001', 'L', 5, 210, '2010-01-03', 4, '', '', 'SUPRANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (89, '5', '0108115939', 'Delia Anggraeni', '3401126604100001', 'P', 5, 210, '2010-04-26', 4, '', '', 'BADARI', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (90, '5', '0094626840', 'Destin Siti Arofah', '3401124112090001', 'P', 5, 210, '2009-12-01', 4, '', '', 'TUGIMIN', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (91, '5', '0103683075', 'Dwi Yuliana Putri', '3401124307100002', 'P', 5, 210, '2010-07-03', 4, '', '', 'MULYONO', 'BANJARAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (92, '5', '0103048390', 'Emeldy Bunga Astuti', '3308085205100003', 'P', 10, 250, '2010-05-12', 4, '', '', 'EDI SUPRAYITNO', 'NGABLAK', 'KEJI', 'KEC. MUNTILAN', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (93, '5', '0098885960', 'Evandra Emeraldgi Pratama', '3401120310090001', 'L', 5, 210, '2009-10-03', 4, '', '', 'NURWIYONO', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (94, '5', '0075465499', 'Fauziah Ardelinda', '3401127001070001', 'P', 5, 210, '2007-01-30', 4, '', '', 'SUPARMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (95, '5', '0109742705', 'Galih Reza Oktaviano', '3401120505100001', 'L', 5, 210, '2010-05-05', 4, '', '', 'RIYANTO', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (96, '5', '0086716698', 'Galih Kurniawan', '3401122812080001', 'L', 5, 210, '2008-12-28', 4, '', '', 'SUMARWOTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (97, '5', '0082921451', 'Hesti Andriyani', '3401125004080001', 'P', 5, 210, '2008-04-10', 4, '', '', 'SUROTO', 'KEMPONG', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (98, '5', '0091536451', 'Hibban Adib Murthada', '3401122010090001', 'L', 5, 210, '2009-10-20', 4, '', '', 'MUHAMAD NASIR', 'SLANDEN', 'BANJAROYO', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (99, '5', '0157442061', 'Latifa Ramadhani', '3401126808090001', 'P', 5, 210, '2009-08-28', 4, '', '', 'ALIYADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (100, '5', '0103142489', 'Mardianty Putri Anggraeny', '3401124603100001', 'P', 5, 210, '2010-03-06', 4, '', '', 'SUDARMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (101, '5', '0168301632', 'Muhammad Khoiruman Kafa', '3308090203100001', 'L', 10, 250, '2009-03-02', 4, '', '', 'MUHAMMAD BAEDHOWI', 'SARAGAN', 'RAMBEANAK', 'KEC. MUNGKID', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (102, '5', '0098955268', 'Muhammad Minan Fauzi', '3401122107090001', 'L', 5, 210, '2009-07-21', 4, '', '', 'SLAMET', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (103, '5', '0097560656', 'Naufal Hakim', '3401123010090001', 'L', 5, 210, '2009-10-30', 4, '', '', 'SUPNGATI WIDANIYAH', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (104, '5', '0093830651', 'Oktavia Arya Damayanti', '3401125210090001', 'P', 5, 210, '2010-10-12', 4, '', '', 'WAKIJAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (105, '5', '0098381033', 'Raffi Ahmad Afifudin', '3401121704090001', 'L', 5, 210, '2009-04-17', 4, '', '', 'NASRODIN', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (106, '5', '02040412029', 'Shafira Mutiara Valen', '3401125502100001', 'P', 5, 210, '2010-02-15', 4, '', '', 'NOFIYALDI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (107, '5', '0093846102', 'Yuda Edi Wahyana', '3401120108090003', 'L', 5, 210, '2009-08-01', 4, '', '', 'PUTRI JAZIMAH', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (108, '5', '0082840617', 'Yusuf Pamungkas', '3401122804080001', 'L', 5, 210, '2008-04-28', 4, '', '', 'RAHMADI', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (109, '5', '0153278170', 'Afif Rafiudin', '3401122708090001', 'L', 5, 210, '2009-06-27', 5, '', '', 'JUDARDIN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (110, '5', '088476284', 'Ahmad Faiq Athaya', '3401122802080001', 'L', 10, 249, '2008-02-28', 5, '', '', 'Ahmad Baehaqi', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (111, '5', '083034124', 'Amira Zerlinda', '3308026211080004', 'P', 34, 278, '2008-11-22', 5, '', '', 'Muhammad Zuamar', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (112, '5', '0072961067', 'Andrian Putra Pangestu', '3401122206070001', 'L', 5, 210, '2007-06-22', 5, '', '', 'SURAHMAN', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (113, '5', '0086534500', 'Gresiya Suma Safitri', '3401125010080002', 'P', 5, 210, '2008-10-10', 5, '', '', 'DUL JALIL', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (114, '5', '0095912960', 'Hasna Fathitya Sabrina', '3401126909090002', 'P', 5, 210, '2009-09-29', 5, '', '', 'EKO NURAHMAN SUROJO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (115, '5', '0083313497', 'Indah Fitria Ningrum', '3401124210080001', 'P', 5, 210, '2008-10-02', 5, '', '', 'SUTARI', 'PANTOG WETAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (116, '5', '0087301623', 'Muhammad Ilham Sarifuddin', '3401122103080002', 'L', 5, 210, '2008-03-21', 5, '', '', 'NURCHOLIS', 'POTRONALAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (117, '5', '0155408388', 'Muhammad Raditya Ainul Yaqin', '3401121607080001', 'L', 5, 210, '2008-07-16', 5, '', '', 'FARIKIN', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (118, '5', '0095231681', 'Muhammad Shulhan Al-farisi', '3401120106090001', 'L', 5, 210, '2009-06-01', 5, '', '', 'SLAMET SULBANI', 'SEMAWUNG', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (119, '5', '0153200473', 'Novaris Dwi Firmansyah', '3401121711080002', 'L', 10, 249, '2008-11-17', 5, '', '', 'SARYANTO', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (120, '5', '0072706748', 'Oktafiya Duwi Safitri', '3401125510070001', 'P', 5, 210, '2007-10-15', 5, '', '', 'SUNARDI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (121, '5', '0083690882', 'Prastika Guntur Firmansyah', '3401120307080002', 'L', 5, 210, '2008-07-03', 5, '', '', 'KALIM', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (122, '5', '0098488467', 'Siti Musyafiani', '3401124901090001', 'P', 5, 210, '2009-09-10', 5, '', '', 'ZURISAM', 'PRANAN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (123, '5', '0158891388', 'Tegar Arya Pangestu', '3401121308080001', 'L', 5, 210, '2008-08-13', 5, '', '', 'HARYADI', 'SLANDEN', 'BANJAROYA', 'KEC. KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (124, '5', '0081232726', 'Adi Bagus Saputra', '3401120703080001', 'L', 5, 210, '2008-03-07', 6, '', '', 'Suwita', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (125, '5', '0071776993', 'Ageng Ratri Dewi', '340112591207002', 'P', 5, 210, '2007-12-19', 6, '', '', 'Sudarman', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (126, '5', '0077101667', 'Ahmad Hidayat', '3401122701070002', 'L', 5, 210, '2007-01-27', 6, '', '', 'Masicun', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (127, '5', '0074217306', 'Ahmad Mirza Arvinudin', '3401121612070001', 'L', 5, 210, '2007-12-16', 6, '', '', 'Muh Ahmad', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (128, '5', '0074203935', 'Aqila Chusnia Mu&#039;mina', '3204156509070001', 'P', 9, 22, '2007-09-25', 6, '', '', 'Heru Gunadi', 'POTRONALAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (129, '5', '0072510958', 'Ardian Ramadhan', '3401122209070001', 'L', 5, 210, '2007-09-22', 6, '', '', 'Widodo', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (130, '5', '0089913911', 'Arif Duwiyanto', '3401122303090001', 'L', 5, 210, '2008-03-23', 6, '', '', 'Muh Ahmad Bani', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (131, '5', '0085552671', 'Choiriatunnisa Tsani Hasya', '3401126707080002', 'P', 5, 210, '2008-07-27', 6, '', '', 'Riyadi', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (132, '5', '0071429595', 'Febriana Alfiyani', '3401124806810002', 'P', 5, 210, '2007-02-24', 6, '', '', 'Alfandi', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (133, '5', '0066771589', 'Fitri Andriani', '3401125510060002', 'P', 5, 210, '2006-10-15', 6, '', '', 'Suroto', 'KEMPONG', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (134, '5', '0082016833', 'Iqbal Dzaky Reevansyah', '6302152103080001', 'L', 15, 215, '2008-03-21', 6, '', '', 'Fujiansyah', 'POTRONALAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (135, '5', '0077252994', 'Junita Adinda Suryandika', '3401126606070001', 'P', 5, 210, '2007-06-26', 6, '', '', 'Suroto', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (136, '5', '0077859964', 'Nabil Chandra Susilo Nugroho', '3401123011070001', 'L', 5, 210, '2007-11-30', 6, '', '', 'Sucipto Susilo', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (137, '5', '0074539804', 'Revania Oktaviani', '3401126610070001', 'P', 5, 210, '2007-10-26', 6, '', '', 'Abidin', 'PRANAN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (138, '5', '0078559059', 'Zulfa Ulya', '3401126807070001', 'P', 5, 210, '2007-07-28', 6, '', '', 'Sudaryanto', 'SLANDEN', 'BANJAROYO', 'KALIBAWANG', 'Dalam', 'Tidak', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (140, '5', '11111', '11111', '111', 'L', 2, 56, '2021-01-16', 11, 'ghalyfadhillah@gmail.com', '087722777245', 'Gunadi Abdullah', 'ASDASD', 'ASDASD', 'ASDASD', 'Dalam', 'Tidak', 'Ya', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (141, '5', '3243', '44334', '34243342', 'P', 10, 169, '2021-01-18', 16, 'saddsa@sadads.com', '2332', 'dassad', 'SADASD', 'SADSAD', 'SADASD', 'Dalam', 'Tidak', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (142, '5', '323242', '3243443', '232434', 'P', 8, 393, '2021-01-26', 17, 'dasdas@dsadsa.com', '432342', 'asddsa', 'SADASD', 'SADASD', 'ASDAS', 'Luar', 'Ya', 'Tidak', 'Tidak', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (143, '5', '11314141441', 'Jumaidi Saputraaaa', '14141413141', 'L', 6, 151, '1999-10-19', 2, 'jumaidi@gmail.com', '08937272728128', 'Budi', '-', '-', 'PONDOK AREN', 'Dalam', 'Ya', 'Ya', 'Ya', NULL);
INSERT INTO `sr_siswa` (`idsiswa`, `unit`, `s_nisn`, `s_nama`, `s_nik`, `s_jenis_kelamin`, `s_tl_idprovinsi`, `s_tl_idkota`, `s_tanggal_lahir`, `idkelas`, `s_email`, `s_telepon`, `s_wali`, `s_dusun`, `s_desa`, `s_kecamatan`, `s_domisili`, `s_abk`, `s_bsm_pip`, `s_keluarga_miskin`, `s_code_generator`) VALUES (144, '5', '2131231231123', 'Ade Sentosah', '3175052605970002', 'L', 1, 94, '2022-02-22', 21, 'ade@gmail.com', '0819990281214', '', '', '', '', 'Dalam', 'Ya', 'Ya', 'Ya', NULL);


#
# TABLE STRUCTURE FOR: sr_soal
#

DROP TABLE IF EXISTS `sr_soal`;

CREATE TABLE `sr_soal` (
  `id_soal` int(11) NOT NULL AUTO_INCREMENT,
  `idmata_pelajaran` int(11) DEFAULT NULL,
  `idkelas` int(11) DEFAULT NULL,
  `idusers` int(11) DEFAULT NULL,
  `unit` int(10) NOT NULL,
  PRIMARY KEY (`id_soal`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=latin1;

INSERT INTO `sr_soal` (`id_soal`, `idmata_pelajaran`, `idkelas`, `idusers`, `unit`) VALUES (50, 3, 3, 1, 5);
INSERT INTO `sr_soal` (`id_soal`, `idmata_pelajaran`, `idkelas`, `idusers`, `unit`) VALUES (51, 3, 3, 1, 5);


#
# TABLE STRUCTURE FOR: sr_soaldetail
#

DROP TABLE IF EXISTS `sr_soaldetail`;

CREATE TABLE `sr_soaldetail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_soal` int(5) NOT NULL,
  `soal` text DEFAULT NULL,
  `gambar_soal` varchar(200) DEFAULT NULL,
  `opsi_a` text DEFAULT NULL,
  `opsi_b` text DEFAULT NULL,
  `opsi_c` text DEFAULT NULL,
  `opsi_d` text DEFAULT NULL,
  `opsi_e` text DEFAULT NULL,
  `jawaban` varchar(1) NOT NULL,
  `status` int(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=latin1;

INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (26, 50, 'Hasil dari 7.598 - 1.637 - 2.893 + 4.716 adalah', NULL, '7.784', '7.812', '7.856', '7.903', '7.901', 'A', 0);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (27, 51, 'Hasil pengerjaan dari 64 x 826 : 28 adalah ....', NULL, '1.678', '1.762', '1.888', '1.916', '1.915', 'C', 0);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (28, 51, 'Suhu udara di puncak gunung pada pukul 03.00 adalah -10° C. Setelah matahari terbit,\r\nenergi matahari menaikkan suhu udara di puncak gunung tersebut. Jika setiap jam suhu\r\nudara di puncak guning naik 5° C, suhu udara pada pukul 15.00 menjadi .... C°', NULL, '23', '24', '26', '28', '29', 'C', 1);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (29, 51, 'Bus Harapan Jaya berangkat dari terminal setiap 30 menit sekali. Bus Pelita Indah berangkat\r\ndari terminal setiap 45 menit sekali, dan bus Barokah berangkat setiap 60 menit sekali. Jika\r\n\r\nketiga bus berangkat bersama-sama pada pukul 05.00, ketiga bus akan berangkat bersama-\r\nsama lagi pada pukul ....', NULL, '07.00', '08.00', '09.00', '10.00', '11.00', 'B', 0);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (30, 51, 'Herlina ingin membuat gelang. Ia membeli manik-manik warna merah 80 butir, hijau 75\r\nbutir, dan biru 50 butir. Herlina akan membuat gelang dari manik-manik tersebut dengan\r\nbagian warna yang sama. Banyaknya manik-manik pada setiap gelang adalah', NULL, 'manik-manik merah 20, manik-manik hijau 15, manik-manik biru 10', 'manik-manik merah 18, manik-manik hijau 16, manik-manik biru 12', 'manik-manik merah 18, manik-manik hijau 15, manik-manik biru 10', 'manik-manik merah 16, manik-manik hijau 15, manik-manik biru 10', 'manik-manik merah 16, manik-manik hijau 15, manik-manik biru 11', 'D', 1);
INSERT INTO `sr_soaldetail` (`id`, `id_soal`, `soal`, `gambar_soal`, `opsi_a`, `opsi_b`, `opsi_c`, `opsi_d`, `opsi_e`, `jawaban`, `status`) VALUES (31, 51, 'KPK dari 85, 90, dan 125 dalam bentuk faktorisasi prima adalah ....', NULL, '2 x 3 x 52', '2 x 32 x 52', '2 x 33 x 52', '2 x 32 x 53', '2 x 32 x 54', 'D', 0);


#
# TABLE STRUCTURE FOR: sr_tabungan
#

DROP TABLE IF EXISTS `sr_tabungan`;

CREATE TABLE `sr_tabungan` (
  `idtabungan` int(11) NOT NULL AUTO_INCREMENT,
  `idsiswa` varchar(255) NOT NULL,
  `tanggal` varchar(255) NOT NULL,
  `kode` varchar(255) NOT NULL,
  `catatan` varchar(255) NOT NULL,
  `debet` varchar(255) NOT NULL,
  `credit` varchar(255) NOT NULL,
  `saldo` varchar(255) NOT NULL DEFAULT '0',
  `unit` varchar(10) DEFAULT NULL,
  `deskripsi` varchar(200) DEFAULT NULL,
  `tingkat` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`idtabungan`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tabungan` (`idtabungan`, `idsiswa`, `tanggal`, `kode`, `catatan`, `debet`, `credit`, `saldo`, `unit`, `deskripsi`, `tingkat`) VALUES (1, '323242', '2022-04-08', '', 'ok', '20000000', '0', '20000000', '5', 'Setor Tabungan-20000000-2022-04-08-3243443', '2022');
INSERT INTO `sr_tabungan` (`idtabungan`, `idsiswa`, `tanggal`, `kode`, `catatan`, `debet`, `credit`, `saldo`, `unit`, `deskripsi`, `tingkat`) VALUES (2, '0103368264', '2022-04-08', '', 'ok', '2000000', '0', '2000000', '5', 'Setor Tabungan-2000000-2022-04-08-Bayu Ardhan Handaru', '2022');
INSERT INTO `sr_tabungan` (`idtabungan`, `idsiswa`, `tanggal`, `kode`, `catatan`, `debet`, `credit`, `saldo`, `unit`, `deskripsi`, `tingkat`) VALUES (3, '0103368264', '2022-04-08', '', 'ok', '20000', '0', '2020000', '5', 'Setor Tabungan-20000-2022-04-08-Bayu Ardhan Handaru', '2022');
INSERT INTO `sr_tabungan` (`idtabungan`, `idsiswa`, `tanggal`, `kode`, `catatan`, `debet`, `credit`, `saldo`, `unit`, `deskripsi`, `tingkat`) VALUES (4, '0103368264', '2022-04-08', '', 'ok', '30000', '0', '2050000', '5', 'Setor Tabungan-30000-2022-04-08-Bayu Ardhan Handaru', '2022');
INSERT INTO `sr_tabungan` (`idtabungan`, `idsiswa`, `tanggal`, `kode`, `catatan`, `debet`, `credit`, `saldo`, `unit`, `deskripsi`, `tingkat`) VALUES (6, '0103368264', '2022-04-08', '', 'test', '0', '50000', '2000000', '5', 'Setor Tabungan-50000-2022-04-08-Bayu Ardhan Handaru', '2022');
INSERT INTO `sr_tabungan` (`idtabungan`, `idsiswa`, `tanggal`, `kode`, `catatan`, `debet`, `credit`, `saldo`, `unit`, `deskripsi`, `tingkat`) VALUES (7, '11111', '2022-04-13', '', 'ok', '200000', '0', '200000', '', 'Setor Tabungan-200000-2022-04-13-11111', '2022');
INSERT INTO `sr_tabungan` (`idtabungan`, `idsiswa`, `tanggal`, `kode`, `catatan`, `debet`, `credit`, `saldo`, `unit`, `deskripsi`, `tingkat`) VALUES (8, '11111', '2022-04-17', '', 'tabungan qurban', '0', '200000', '0', '5', 'Setor Tabungan-200000-2022-04-17-11111', '2022');


#
# TABLE STRUCTURE FOR: sr_tahun_pelajaran
#

DROP TABLE IF EXISTS `sr_tahun_pelajaran`;

CREATE TABLE `sr_tahun_pelajaran` (
  `idtahun_pelajaran` int(11) NOT NULL AUTO_INCREMENT,
  `tp_tahun` varchar(20) NOT NULL,
  PRIMARY KEY (`idtahun_pelajaran`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (1, '2019/2020-1');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (2, '2019/2020-2');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (3, '2020/2021-1');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (4, '2020/2021-2');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (5, '2021/2022-1');
INSERT INTO `sr_tahun_pelajaran` (`idtahun_pelajaran`, `tp_tahun`) VALUES (6, '2021/2022-2');


#
# TABLE STRUCTURE FOR: sr_tanggal_gaji
#

DROP TABLE IF EXISTS `sr_tanggal_gaji`;

CREATE TABLE `sr_tanggal_gaji` (
  `idtanggal_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` varchar(255) NOT NULL,
  `unit` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`idtanggal_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tanggal_gaji` (`idtanggal_gaji`, `tanggal`, `unit`) VALUES (1, '2022-04-06', '5');
INSERT INTO `sr_tanggal_gaji` (`idtanggal_gaji`, `tanggal`, `unit`) VALUES (3, '2022-03-30', '2 ');


#
# TABLE STRUCTURE FOR: sr_tarif_gaji_user
#

DROP TABLE IF EXISTS `sr_tarif_gaji_user`;

CREATE TABLE `sr_tarif_gaji_user` (
  `id_gaji` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `id_user` varchar(10) DEFAULT NULL,
  `id_tunjangan` varchar(200) DEFAULT NULL,
  `deskripsi` varchar(20) DEFAULT NULL,
  `id_potongan` int(11) DEFAULT NULL,
  `id_lain` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_gaji`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (8, '5', '40', '2', 'gaji_pokok', NULL, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (9, '5', '40', '2', 'gaji_pokok', NULL, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (10, '5', '40', '2', 'gaji_pokok', NULL, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (11, '5', '40', '2', 'gaji_pokok', NULL, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (16, '5', '40', NULL, 'potongan', 2, NULL);
INSERT INTO `sr_tarif_gaji_user` (`id_gaji`, `unit`, `id_user`, `id_tunjangan`, `deskripsi`, `id_potongan`, `id_lain`) VALUES (21, '5', '40', NULL, 'lain', NULL, '1');


#
# TABLE STRUCTURE FOR: sr_tarif_unit_pos
#

DROP TABLE IF EXISTS `sr_tarif_unit_pos`;

CREATE TABLE `sr_tarif_unit_pos` (
  `id_tarif_unit_pos` int(11) NOT NULL AUTO_INCREMENT,
  `id_unit_pos` varchar(10) DEFAULT NULL,
  `unit` varchar(11) DEFAULT NULL,
  `id_kode_akun` varchar(20) DEFAULT NULL,
  `tipe` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id_tarif_unit_pos`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tarif_unit_pos` (`id_tarif_unit_pos`, `id_unit_pos`, `unit`, `id_kode_akun`, `tipe`) VALUES (7, '3', '', '1', 'pendapatan');
INSERT INTO `sr_tarif_unit_pos` (`id_tarif_unit_pos`, `id_unit_pos`, `unit`, `id_kode_akun`, `tipe`) VALUES (8, '3', '', '622655', 'pendapatan');
INSERT INTO `sr_tarif_unit_pos` (`id_tarif_unit_pos`, `id_unit_pos`, `unit`, `id_kode_akun`, `tipe`) VALUES (9, '3', '5', '622656', 'pendapatan');


#
# TABLE STRUCTURE FOR: sr_tr_paketsoal
#

DROP TABLE IF EXISTS `sr_tr_paketsoal`;

CREATE TABLE `sr_tr_paketsoal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_soal` int(10) NOT NULL,
  `id_paket` int(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (22, 25, 7);
INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (23, 24, 7);
INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (24, 28, 9);
INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (25, 30, 9);
INSERT INTO `sr_tr_paketsoal` (`id`, `id_soal`, `id_paket`) VALUES (26, 30, 8);


#
# TABLE STRUCTURE FOR: sr_unit_pos
#

DROP TABLE IF EXISTS `sr_unit_pos`;

CREATE TABLE `sr_unit_pos` (
  `id_unit_pos` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) DEFAULT NULL,
  `nama_unit_pos` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id_unit_pos`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_unit_pos` (`id_unit_pos`, `unit`, `nama_unit_pos`) VALUES (3, '5', 'Catering');
INSERT INTO `sr_unit_pos` (`id_unit_pos`, `unit`, `nama_unit_pos`) VALUES (4, '5', 'SPP');


#
# TABLE STRUCTURE FOR: sr_users
#

DROP TABLE IF EXISTS `sr_users`;

CREATE TABLE `sr_users` (
  `idusers` int(11) unsigned NOT NULL,
  `unit` varchar(11) NOT NULL,
  `u_nbm_nip` varchar(255) NOT NULL,
  `u_nuptk_nuks` varchar(255) DEFAULT NULL,
  `u_tl_idprovinsi` int(11) NOT NULL,
  `u_tl_idkota` int(11) NOT NULL,
  `u_tanggal_lahir` date NOT NULL,
  `u_jenis_kelamin` enum('P','L') NOT NULL,
  `u_status_pegawai` varchar(100) NOT NULL,
  `u_tunjangan_apbd` varchar(100) DEFAULT NULL,
  `u_tugas_tambahan` varchar(100) DEFAULT NULL,
  `u_jenjang` varchar(50) NOT NULL,
  `u_perguruan_tinggi` varchar(255) NOT NULL,
  `u_jurusan` varchar(100) DEFAULT NULL,
  `u_tahun_lulus` varchar(20) NOT NULL,
  `u_npwp` varchar(255) DEFAULT NULL,
  `u_sertifikasi` enum('Sudah','Belum') NOT NULL,
  `u_sertifikasi_tahun` year(4) DEFAULT NULL,
  `u_prestasi` text DEFAULT NULL,
  `u_honor` int(11) NOT NULL,
  `u_kerja_pasangan` varchar(255) DEFAULT NULL,
  `u_alamat_tinggal` text NOT NULL,
  `u_photo` text DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idusers`),
  KEY `idusers` (`idusers`),
  KEY `u_tl_idprovinsi` (`u_tl_idprovinsi`),
  KEY `u_tl_idkota` (`u_tl_idkota`),
  KEY `idusers_2` (`idusers`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (1, '5', '954033', '3433754656300012 / 16023L0010404122016516', 6, 153, '1987-02-13', 'L', 'GTY', '', 'Kepala Sekolah', 'S1', 'Undip', 'Sistem Informasi', '2010', '66.907.985.7-544.000', 'Sudah', '2013', 'Guru Teladan tahun 2015', 2600000, 'Pegawai Swasta', 'Lenteng Agung, Jagakarsa, Jakarta Selatan', '3454bd5004b1bd6d20a9ff3f633a37d1.png', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (37, '5', '992052', '9060760662300003', 5, 210, '1982-07-28', 'P', 'GTY', 'PTTD', 'Guru Kelas II', 'S1', 'Univ Terbuka Yogyakarta', 'PGSD', '2018', '', 'Belum', '0000', '', 1000000, 'Swasta', 'Demangan, Banjarharjo, Kalibawang', 'f5b05744233acca3b73d179279d83ff4.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (38, '5', '1062801', '', 5, 210, '1985-01-07', 'L', 'GTY', '', 'Guru Kelas IV', 'S1', 'Univ Sanata Dharma', 'PGSD', '2010', '91.003.379.4-544.000', 'Belum', '0000', '', 400000, 'Swasta', 'Duwet 3, Banjarharjo, Kalibawang', 'ef2cbde3636968a2bbb9f76a5df7909e.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (39, '5', '1295422', '', 5, 210, '1992-07-19', 'L', 'GTT', '', 'Guru Penjasorkes', 'S1', 'Univ Ahmad Dahlan', 'PBSI', '2012', '', 'Belum', '0000', '', 350000, '', 'Paras, Banjarasri, Kalibawang', '9f23f5e97972e5e98537f51b76db76ec.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (40, '5', '19671206 198903 1 003', '2538745647110043', 5, 210, '1967-12-06', 'L', 'PNS KEMENAG', '', 'Guru PAI', 'D2', 'UIN Sunan Kalij Jaga Yogyakarta', 'Pend. Agama Islam', '1993', '', 'Sudah', '2013', '', 4200000, 'IRT', 'Gunungmojo, Argosari, Sedayu, Bantul', '42ef1ac722851008e5e9bcb35351827c.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (41, '5', '1335358', '', 9, 115, '1994-04-04', 'P', 'GTT', '', 'Operator', 'S1', 'UIN Raden Fatah Palembang', 'Pend. Bahasa Inggris', '2017', '', 'Belum', '0000', '', 150000, 'Swasta', 'Salam, Banjarharjo, Kalibawang', 'e20f5b298a4d05cb1d22977403f73062.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (42, '5', '1335360', '', 5, 210, '1993-02-07', 'P', 'GTT', '', 'Guru Kelas I', 'S1', 'Univ Terbuka Banten', 'PGSD', '2018', '', 'Belum', '0000', '', 300000, 'Swasta', 'Pranan, Banjaroya, Kalibawang', '7079eeff453c257d36b51af9413281ec.jpeg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (43, '5', '1314346', '', 5, 210, '1974-10-27', 'P', 'GTT', '', 'Guru Kelas III', 'S1', 'Univ Widya Mataram Yogyakarta', 'Teknologi pertanian', '1998', '', 'Belum', '0000', '', 300000, 'Karyawan', 'Kedondong 1, Banjararum, Kalibawang', '373f490ef28c28450a359b46e73525d7.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (44, '5', '1295423', '', 5, 210, '1987-04-15', 'P', 'GTT', '', 'Guru Kelas V', 'S1', 'Univ Indraprasta PGRI Jakarta', 'Pendidikan Matematika', '2011', '', 'Belum', '0000', '', 350000, 'Swasta', 'Semawung, Banjarharjo, Kalibawang', '17773abbb91433f028f4183bc51c80de.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (45, '5', '1187611', '', 5, 210, '1991-05-08', 'P', 'GTY', '', 'Guru Kelas VI', 'S1', 'Univ PGRI Yogyakarta', 'Pendidikan Matematika', '2013', '', 'Belum', '0000', '', 400000, '', 'Semaken 3, Banjararum, Kalibawang', '785a17c1772c4c0ed74a372bffca962f.jpg', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (57, '5', '104352', '10435342456', 2, 56, '2021-01-18', 'L', 'GTY', '', 'Operator', 'S1', 'Universitas Amikom Yogyakarta', 'Sistem Informasi', '2021', '9999999999999', 'Belum', '0000', 'Pegawai Terganteng', 5300000, 'Kepala Dinas Pariwisata', 'Jln Bintara RT 12 RW 09', 'fb9a0bb598302e966995357ef0d12ab8.png', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (59, '5', '104353', '10435342457', 6, 153, '1987-12-23', 'L', 'GTY', '0', 'Kepala Program', 'S1', 'Universitas Indra Prasta PGRI', 'Pendidikan Ekonomi', '2017', '12.345.76543', 'Belum', '0000', '0', 1400000, '0', 'Jl. Rawa Sari', '8b1746b499eea7a042bf6bd4ffb35f80.png', 0);
INSERT INTO `sr_users` (`idusers`, `unit`, `u_nbm_nip`, `u_nuptk_nuks`, `u_tl_idprovinsi`, `u_tl_idkota`, `u_tanggal_lahir`, `u_jenis_kelamin`, `u_status_pegawai`, `u_tunjangan_apbd`, `u_tugas_tambahan`, `u_jenjang`, `u_perguruan_tinggi`, `u_jurusan`, `u_tahun_lulus`, `u_npwp`, `u_sertifikasi`, `u_sertifikasi_tahun`, `u_prestasi`, `u_honor`, `u_kerja_pasangan`, `u_alamat_tinggal`, `u_photo`, `status`) VALUES (64, '2', '', NULL, 0, 0, '0000-00-00', 'P', '', NULL, NULL, '', '', NULL, '', NULL, 'Sudah', NULL, NULL, 0, NULL, '', NULL, 0);


#
# TABLE STRUCTURE FOR: sr_virtualclass
#

DROP TABLE IF EXISTS `sr_virtualclass`;

CREATE TABLE `sr_virtualclass` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `pengajar_id` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `url` text NOT NULL,
  `libur` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (1, '', 0, 0, 'Tahun Baru Masehi', '2022-01-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (2, '', 0, 0, 'Hari Siwa Ratri', '2022-01-1', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (3, '', 0, 0, 'Tahun Baru Imlek 2573 Kongzili', '2022-02-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (4, '', 0, 0, 'Isra Mikraj Nabi Muhammad SAW', '2022-02-28', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (5, '', 0, 0, 'Hari Raya Nyepi', '2022-03-3', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (6, '', 0, 0, 'Hari Saraswati', '2022-03-26', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (7, '', 0, 0, 'Wafat Isa Al Masih', '2022-04-15', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (8, '', 0, 0, 'Hari Buruh Internasional', '2022-05-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (9, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-2', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (10, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-3', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (11, '', 0, 0, 'Hari Raya Waisak 2566', '2022-05-16', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (12, '', 0, 0, 'Kenaikan Isa Al Masih', '2022-05-26', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (13, '', 0, 0, 'Hari Lahirnya Pancasila', '2022-06-1', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (14, '', 0, 0, 'Penampahan Galungan', '2022-06-7', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (15, '', 0, 0, 'Hari Raya Galungan', '2022-06-8', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (16, '', 0, 0, 'Umanis Galungan', '2022-06-9', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (17, '', 0, 0, 'Hari Raya Kuningan', '2022-06-18', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (18, '', 0, 0, 'Hari Raya Idul Adha 1443 Hijriyah', '2022-07-9', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (19, '', 0, 0, 'Tahun Baru Islam 1444 Hijriyah', '2022-07-30', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (20, '', 0, 0, 'Hari Proklamasi Kemerdekaan RI', '2022-08-17', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (21, '', 0, 0, 'Maulid Nabi Muhammad SAW', '2022-10-8', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (22, '', 0, 0, 'Hari Saraswati', '2022-10-22', '', '2');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (23, '', 0, 0, 'Hari Raya Natal', '2022-12-25', '', '1');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (24, '5', 1, 1, 'BAB I - Adminstrasi Perkantoran Dasar', '2022-03-22', 'https://meet.jit.si/Lekum', '');
INSERT INTO `sr_virtualclass` (`id`, `unit`, `pengajar_id`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (35, '5', 1, 1, 'BAB 1 - Membuat Company Profile', '2022-02-22', 'https://meet.jit.si/hQPtq', '');


#
# TABLE STRUCTURE FOR: sr_wali_murid
#

DROP TABLE IF EXISTS `sr_wali_murid`;

CREATE TABLE `sr_wali_murid` (
  `id_wali_murid` int(11) NOT NULL AUTO_INCREMENT,
  `nama_lengkap` varchar(200) DEFAULT NULL,
  `nik` varchar(200) DEFAULT NULL,
  `tempat_lahir` varchar(200) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `jenis_kelamin` varchar(200) DEFAULT NULL,
  `agama` varchar(200) DEFAULT NULL,
  `email` varchar(200) DEFAULT NULL,
  `no_telp` varchar(200) DEFAULT NULL,
  `alamat` varchar(200) DEFAULT NULL,
  `idsiswa` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_wali_murid`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `sr_wali_murid` (`id_wali_murid`, `nama_lengkap`, `nik`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `agama`, `email`, `no_telp`, `alamat`, `idsiswa`) VALUES (2, 'Gilang', '3175052605971251', 'Madiun', '1978-02-01', 'Laki-laki', 'Islam', '', '081280462612', 'Jl Mandeh', 127);
INSERT INTO `sr_wali_murid` (`id_wali_murid`, `nama_lengkap`, `nik`, `tempat_lahir`, `tanggal_lahir`, `jenis_kelamin`, `agama`, `email`, `no_telp`, `alamat`, `idsiswa`) VALUES (3, 'Tono', '21321424214124', 'Jakarta', '1982-06-22', 'Laki-laki', 'Islam', 'tono@gmail.com', '08976766562212', 'Jalan Cendrawasih', 87);


#
# TABLE STRUCTURE FOR: users
#

DROP TABLE IF EXISTS `users`;

CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(254) NOT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `multirole` enum('Y','N') DEFAULT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `phone` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uc_email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (1, '5', '127.0.0.1', '$2y$12$DPBC0GqrE7QhiYgWOBdbW.c/jZQ0qD7KS7mO8z5HtaiPa35WwuxyK', 'sutan.daulay@gmail.com', 1268889823, 1645102751, 1, 'N', 'Sutan', 'Daulay, S.Kom', '081283960337');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (37, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'h.yuliajie@gmail.com', 1604316790, 1611518343, 1, 'Y', 'Heri', 'Yuli Astuti, S.Pd.', '081802637311');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (38, '5', '127.0.0.1', '$2y$10$3Hfg3GDUGrnqzRJeFO1L0u3tHe.jEvBjl0AUi3GGOeYcLKUDwI60a', 'foreverbarca24@gmail.com', 1604324461, 1640778495, 1, 'Y', 'Eka', 'Romadi, S.Pd.', '087719045202');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (39, '5', '127.0.0.1', '$2y$10$P1fNQaXHq7SDMI89fVyeAuNtbskbLbS6X9GzuvqLhyOpYGjb2jr66', 'prodocid.id@gmail.com', 1604404981, 1611515571, 1, 'N', 'Muhammad ', 'Yuli Nugroho, S.Pd.', '081328086524');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (40, '5', '127.0.0.1', '$2y$10$eICdXdcDjiUKA7ieNqHTueuCVl47eLEkdCzHccWoip7HvN4Sx7sa2', 'foreverbarca17@gmail.com', 1604405357, 1640675168, 1, 'N', 'Ahwanto, A.Ma', '', '081328579072');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (41, '5', '127.0.0.1', '$2y$10$ZlApEjZiUXuUQvPrelvWWOjqIlCK6mWlgyZAtskny353GxpATj6.O', 'trilestari40@yahoo.com', 1604405791, 1645100999, 1, 'N', 'Tri ', 'Lestari, S.Pd', '085279657826');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (42, '5', '127.0.0.1', '$2y$10$26FP8tRR/0UwORH8tI5eS.RNTMs3.RnIbZ7ldxy0PhIO/n94g2Jpe', 'widayatiasih93@gmail.com', 1604406384, 1645101063, 1, 'Y', 'Widayati ', 'Asih Rusilah, S.Pd', '087877633339');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (43, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'tripuji298@gmail.com', 1604406639, NULL, 1, 'Y', 'Tri ', 'Puji Lestari, S.TP', '081225422320');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (44, '5', '127.0.0.1', '$2y$10$vyeEuY7OB3ECbYUTZiBGnuCsW5GXcTrbxiB6NDON7oZkUA0/bKUEy', 'tutikrahayu086@gmail.com', 1604407059, 1645100832, 1, 'Y', 'Tutik ', 'Rahayu, S.Pd.', '087738264098');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (45, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'fulileo.astuti06@gmail.com', 1604407243, NULL, 1, 'Y', 'Tri ', 'Fuji Astuti, S.Pd.', '085764945075');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (57, '5', '127.0.0.1', '$2y$10$y6tuPYX8c8k2OkmmmLGQuOt6ReU7iYHzxEkTm9G..U4a1dJ20WqUS', 'ghalyfadhillah@gmail.com', 1610969508, 1612615966, 1, 'Y', 'Ghaly', 'Fadhillah, S.Kom', '087722777245');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (59, '5', '103.119.141.186', '$2y$10$ztlP7HXx3yYRbbcldtK7V.dNLDzFirPis1LJ96KI6yftEFMBGS7py', 'saka87aja@gmail.com', 1640777850, NULL, 1, 'N', 'Galuh', 'Saka Twinta S.pd', '0838654876342');
INSERT INTO `users` (`id`, `unit`, `ip_address`, `password`, `email`, `created_on`, `last_login`, `active`, `multirole`, `first_name`, `last_name`, `phone`) VALUES (64, '2', '::1', '$2y$10$38UHPhu.ge7KZfs4jmLsLukZyuK27j0rTOJBxvzdKQpCZKdIMabR6', 'rzalvaero@gmail.com', 4294967295, NULL, 1, 'N', 'Reza', 'Lesmana Putra A.md', '081280462659');


#
# TABLE STRUCTURE FOR: web_backup
#

DROP TABLE IF EXISTS `web_backup`;

CREATE TABLE `web_backup` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `datestamp` varchar(100) NOT NULL,
  `filedata` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (5, '2022-02-19 14:41:34', 'backup-220219-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (6, '2022-02-20 17:07:15', 'backup-220220-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (7, '2022-02-22 14:13:51', 'backup-220222-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (8, '2022-02-23 15:17:49', 'backup-220223-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (9, '2022-03-02 10:02:40', 'backup-220302-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (10, '2022-03-09 09:55:35', 'backup-220309-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (11, '2022-03-09 17:18:41', 'backup-220309-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (12, '2022-03-10 10:46:56', 'backup-220310-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (13, '2022-03-10 19:27:32', 'backup-220310-db.zip');
INSERT INTO `web_backup` (`id`, `datestamp`, `filedata`) VALUES (14, '2022-03-22 10:40:55', 'backup-220322-db.zip');


#
# TABLE STRUCTURE FOR: web_calender
#

DROP TABLE IF EXISTS `web_calender`;

CREATE TABLE `web_calender` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `created` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `waktu` varchar(50) NOT NULL,
  `url` text NOT NULL,
  `libur` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=latin1;

INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (1, '', 0, 0, 'Tahun Baru Masehi', '2022-01-1', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (2, '', 0, 0, 'Hari Siwa Ratri', '2022-01-1', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (3, '', 0, 0, 'Tahun Baru Imlek 2573 Kongzili', '2022-02-1', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (4, '', 0, 0, 'Isra Mikraj Nabi Muhammad SAW', '2022-02-28', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (5, '', 0, 0, 'Hari Raya Nyepi', '2022-03-3', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (6, '', 0, 0, 'Hari Saraswati', '2022-03-26', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (7, '', 0, 0, 'Wafat Isa Al Masih', '2022-04-15', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (8, '', 0, 0, 'Hari Buruh Internasional', '2022-05-1', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (9, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-2', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (10, '', 0, 0, 'Hari Raya Idul Fitri 1443 Hijriyah', '2022-05-3', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (11, '', 0, 0, 'Hari Raya Waisak 2566', '2022-05-16', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (12, '', 0, 0, 'Kenaikan Isa Al Masih', '2022-05-26', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (13, '', 0, 0, 'Hari Lahirnya Pancasila', '2022-06-1', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (14, '', 0, 0, 'Penampahan Galungan', '2022-06-7', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (15, '', 0, 0, 'Hari Raya Galungan', '2022-06-8', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (16, '', 0, 0, 'Umanis Galungan', '2022-06-9', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (17, '', 0, 0, 'Hari Raya Kuningan', '2022-06-18', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (18, '', 0, 0, 'Hari Raya Idul Adha 1443 Hijriyah', '2022-07-9', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (19, '', 0, 0, 'Tahun Baru Islam 1444 Hijriyah', '2022-07-30', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (20, '', 0, 0, 'Hari Proklamasi Kemerdekaan RI', '2022-08-17', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (21, '', 0, 0, 'Maulid Nabi Muhammad SAW', '2022-10-8', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (22, '', 0, 0, 'Hari Saraswati', '2022-10-22', '', '2');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (23, '', 0, 0, 'Hari Raya Natal', '2022-12-25', '', '1');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (24, '5', 1, 1, 'BAB I - Adminstrasi Perkantoran Dasar', '2022-03-22', 'https://meet.jit.si/Lekum', '');
INSERT INTO `web_calender` (`id`, `unit`, `created`, `kelas_id`, `title`, `waktu`, `url`, `libur`) VALUES (35, '5', 1, 1, 'BAB 1 - Membuat Company Profile', '2022-02-22', 'https://meet.jit.si/hQPtq', '');


#
# TABLE STRUCTURE FOR: web_default
#

DROP TABLE IF EXISTS `web_default`;

CREATE TABLE `web_default` (
  `id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `maintenance` enum('tidak','iya') NOT NULL,
  `whatsapp_group` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `web_default` (`id`, `url`, `title`, `logo`, `description`, `email`, `maintenance`, `whatsapp_group`, `whatsapp`) VALUES (1, 'https://www.proschool.id/', 'PROschool by DesaTech', 'logo.png', 'Elearning by ProSchool for a Smart Learning for Student in New Era! ', 'admin@proschool.id', 'tidak', '#', '6281280462650');


#
# TABLE STRUCTURE FOR: web_log
#

DROP TABLE IF EXISTS `web_log`;

CREATE TABLE `web_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `idusers` varchar(11) DEFAULT NULL,
  `datestamp` varchar(50) NOT NULL,
  `note` varchar(225) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=193 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (1, '5', 'siswa', '11', '2022-02-20 17:02:55', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (2, '5', 'guru', '1', '2022-02-20 17:06:20', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (3, '5', 'guru', '1', '2022-02-22 10:08:16', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (4, '5', 'siswa', '11', '2022-02-22 12:16:16', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (5, '5', 'guru', '1', '2022-02-22 13:05:25', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (6, '5', 'siswa', '11', '2022-02-22 15:13:52', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (7, '5', 'guru', '1', '2022-02-22 15:53:42', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (8, '5', 'siswa', '11', '2022-02-22 16:12:33', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (9, '5', 'guru', '1', '2022-02-22 16:27:36', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (10, '5', 'siswa', '11', '2022-02-22 16:43:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (11, '5', 'guru', '1', '2022-02-22 16:50:10', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (12, '5', 'siswa', '11', '2022-02-22 16:51:40', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (13, '5', 'siswa', '11', '2022-02-22 21:25:17', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (14, '5', 'siswa', '11', '2022-02-22 21:27:06', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (15, '5', 'guru', '1', '2022-02-22 21:34:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (16, '5', 'guru', '1', '2022-02-22 21:34:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (17, '5', 'guru', '1', '2022-02-23 10:23:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (18, '5', 'guru', '1', '2022-02-23 12:29:26', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (19, '5', 'siswa', '11', '2022-02-23 14:13:27', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (20, '5', 'siswa', '11', '2022-02-23 14:13:31', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (21, '5', 'siswa', '11', '2022-02-23 14:13:51', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (22, '5', 'siswa', '11', '2022-02-23 14:14:46', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (23, '5', 'guru', '1', '2022-02-23 14:15:21', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (24, '5', 'siswa', '11', '2022-02-23 15:18:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (25, '5', 'siswa', '11', '2022-02-23 15:18:50', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (26, '5', 'guru', '1', '2022-02-23 15:20:38', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (27, '5', 'guru', '1', '2022-02-23 15:40:07', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (28, '5', 'siswa', '11', '2022-02-23 17:23:27', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (29, '5', 'siswa', '11', '2022-02-23 17:23:30', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (30, '5', 'siswa', '11', '2022-02-23 17:23:33', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (31, '5', 'guru', '1', '2022-02-23 17:27:12', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (32, '5', 'guru', '1', '2022-02-23 19:50:24', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (33, '5', 'guru', '1', '2022-02-24 15:46:59', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (34, '', 'siswa', '11', '2022-03-02 09:56:45', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (35, '', 'guru', '1', '2022-03-02 09:59:59', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (36, '', 'guru', '1', '2022-03-02 11:19:45', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (37, '', 'guru', '1', '2022-03-02 11:36:54', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (38, '', 'guru', '1', '2022-03-04 15:54:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (39, '5', 'guru', '1', '2022-03-09 09:40:18', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (40, '5', 'guru', '1', '2022-03-09 09:49:38', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (41, '5', 'guru', '1', '2022-03-09 09:55:00', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (42, '5', 'guru', '1', '2022-03-09 11:00:58', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (43, '', 'siswa', '11', '2022-03-09 11:02:22', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (44, '5', 'guru', '1', '2022-03-09 14:07:52', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (45, '5', 'guru', '1', '2022-03-09 14:23:43', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (46, '5', 'guru', '1', '2022-03-09 15:10:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (47, '', 'siswa', '11', '2022-03-09 15:10:39', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (48, '5', 'guru', '1', '2022-03-09 15:58:41', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (49, '5', 'guru', '1', '2022-03-10 10:42:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (50, '5', 'guru', '1', '2022-03-10 11:43:13', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (51, '5', 'guru', '1', '2022-03-10 11:43:20', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (52, '5', 'guru', '1', '2022-03-10 11:43:30', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (53, '5', 'guru', '1', '2022-03-10 11:45:48', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (54, '5', 'guru', '1', '2022-03-10 11:46:09', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (55, '5', 'guru', '1', '2022-03-10 14:57:15', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (56, '5', 'guru', '1', '2022-03-10 15:52:03', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (57, '5', 'guru', '1', '2022-03-10 16:38:46', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (58, '', 'siswa', '11', '2022-03-11 11:34:57', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (59, '', 'siswa', '11', '2022-03-14 15:16:01', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (60, '5', 'guru', '1', '2022-03-14 15:18:18', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (61, '', 'siswa', '11', '2022-03-14 15:18:45', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (62, '5', 'guru', '1', '2022-03-14 15:56:24', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (63, '', 'siswa', '11', '2022-03-21 16:07:47', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (64, '5', 'guru', '1', '2022-03-22 11:09:37', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (65, '5', 'guru', '1', '2022-03-25 11:53:07', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (66, '5', 'guru', '1', '2022-04-04 15:28:31', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (67, '', 'siswa', '19', '2022-04-04 21:48:00', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (68, '', 'siswa', NULL, '2022-04-04 21:57:45', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (69, '', 'siswa', NULL, '2022-04-04 21:58:38', 'Anda merubah data Profile');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (70, '5', 'guru', '1', '2022-04-05 13:45:51', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (71, '', 'siswa', '11', '2022-04-05 15:03:12', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (72, '5', 'guru', '1', '2022-04-05 15:07:56', 'Anda melakukan login dengan \"::1\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (73, '5', 'guru', '1', '2022-04-08 09:28:40', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (74, '5', 'guru', '1', '2022-04-08 13:03:17', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (75, '5', 'guru', '1', '2022-04-08 13:10:19', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (76, '5', 'guru', '1', '2022-04-08 13:17:21', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (77, '5', 'guru', '1', '2022-04-08 14:33:16', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (78, '5', 'guru', '1', '2022-04-08 15:06:27', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (79, '5', 'guru', '1', '2022-04-08 15:24:34', 'Anda melakukan login dengan \"103.119.140.138\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (80, '5', 'guru', '1', '2022-04-08 20:39:41', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (81, '', 'siswa', '11', '2022-04-10 01:06:02', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (82, '', 'siswa', '11', '2022-04-10 01:59:38', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (83, '', 'siswa', '11', '2022-04-10 09:24:25', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (84, '', 'siswa', '11', '2022-04-10 10:24:36', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (85, '5', 'guru', '1', '2022-04-11 11:27:20', 'Anda melakukan login dengan \"36.69.82.37\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (86, '5', 'guru', '1', '2022-04-11 14:18:47', 'Anda melakukan login dengan \"103.119.140.130\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (87, '', 'siswa', '13', '2022-04-11 14:18:58', 'Anda melakukan login dengan \"103.119.140.130\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (88, '5', 'guru', '1', '2022-04-11 14:21:37', 'Anda melakukan login dengan \"103.119.140.130\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (89, '5', 'guru', '1', '2022-04-11 14:28:34', 'Anda melakukan login dengan \"103.119.140.130\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (90, '5', 'guru', '1', '2022-04-12 07:42:04', 'Anda melakukan login dengan \"103.82.15.129\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (91, '5', 'guru', '1', '2022-04-12 09:54:08', 'Anda melakukan login dengan \"103.119.141.200\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (92, '', 'siswa', '11', '2022-04-12 10:00:23', 'Anda melakukan login dengan \"103.119.141.200\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (93, '5', 'guru', '1', '2022-04-12 10:11:17', 'Anda melakukan login dengan \"103.119.141.200\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (94, '5', 'guru', '1', '2022-04-12 13:54:05', 'Anda melakukan login dengan \"103.119.141.200\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (95, '5', 'guru', '1', '2022-04-13 14:29:58', 'Anda melakukan login dengan \"103.119.141.200\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (96, '5', 'guru', '1', '2022-04-17 21:01:50', 'Anda melakukan login dengan \"116.206.28.4\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (97, '5', 'guru', '1', '2022-04-17 22:57:05', 'Anda melakukan login dengan \"103.82.15.129\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (98, '5', 'guru', '1', '2022-04-17 22:57:37', 'Anda melakukan login dengan \"103.82.15.129\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (99, '5', 'guru', '1', '2022-04-18 11:58:35', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (100, '5', 'guru', '1', '2022-04-18 14:12:55', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (101, '5', 'guru', '1', '2022-04-20 09:46:52', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (102, '', 'siswa', '11', '2022-04-20 11:27:52', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (103, '5', 'guru', '1', '2022-04-20 13:23:06', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (104, '', 'siswa', '11', '2022-04-21 10:05:55', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (105, '5', 'guru', '1', '2022-04-21 10:53:20', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (106, '5', 'guru', '1', '2022-04-21 11:41:29', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (107, '', 'siswa', '11', '2022-04-21 12:45:06', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (108, '', 'siswa', '11', '2022-04-21 13:34:28', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (109, '', 'siswa', '11', '2022-04-21 13:34:43', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (110, '', 'siswa', '124', '2022-04-21 13:58:41', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (111, '5', 'guru', '1', '2022-04-21 14:16:41', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (112, '5', 'guru', '1', '2022-04-21 16:04:12', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (113, '5', 'guru', '1', '2022-04-21 16:06:44', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (114, '5', 'guru', '1', '2022-04-21 16:07:33', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (115, '5', 'guru', '1', '2022-04-21 23:29:41', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (116, '5', 'guru', '1', '2022-04-22 09:56:23', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (117, '5', 'guru', '1', '2022-04-22 10:24:30', 'Anda melakukan login dengan \"103.119.141.124\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (118, '5', 'guru', '1', '2022-04-25 10:47:33', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (119, '', 'siswa', '11', '2022-04-25 10:55:32', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (120, '5', 'guru', '1', '2022-04-25 10:56:08', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (121, '5', 'guru', '1', '2022-04-25 11:05:39', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (122, '5', 'guru', '1', '2022-04-25 11:07:56', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (123, '', 'siswa', '11', '2022-04-25 11:10:14', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (124, '5', 'guru', '1', '2022-04-25 11:10:26', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (125, '5', 'guru', '1', '2022-04-25 11:15:57', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (126, '', 'siswa', '11', '2022-04-25 15:47:04', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (127, '5', 'guru', '1', '2022-04-25 15:47:34', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (128, '5', 'guru', '1', '2022-04-26 09:08:53', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (129, '5', 'guru', '1', '2022-04-27 11:15:15', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (130, '5', 'guru', '1', '2022-04-27 12:31:14', 'Anda melakukan login dengan \"103.119.140.245\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (131, '5', 'guru', '1', '2022-05-09 00:41:43', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (132, '5', 'guru', '1', '2022-05-09 08:13:16', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (133, '5', 'guru', '1', '2022-05-09 10:50:51', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (134, '5', 'guru', '1', '2022-05-09 16:13:54', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (135, '5', 'guru', '1', '2022-05-09 16:21:55', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (136, '5', 'guru', '1', '2022-05-09 22:32:29', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (137, '5', 'guru', '1', '2022-05-10 10:47:39', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (138, '5', 'guru', '1', '2022-05-11 11:44:33', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (139, '5', 'guru', '1', '2022-05-12 12:15:13', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (140, '5', 'guru', '1', '2022-05-12 12:29:10', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (141, '5', 'guru', '1', '2022-05-12 15:25:41', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (142, '5', 'guru', '1', '2022-05-12 15:43:51', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (143, '5', 'guru', '1', '2022-05-12 15:45:32', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (144, '5', 'guru', '1', '2022-05-12 15:46:38', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (145, '', 'siswa', '11', '2022-05-12 15:56:10', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (146, '5', 'guru', '1', '2022-05-12 15:56:24', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (147, '5', 'guru', '1', '2022-05-13 14:00:35', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (148, '5', 'guru', '1', '2022-05-14 04:37:29', 'Anda melakukan login dengan \"110.136.9.128\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (149, '5', 'guru', '1', '2022-05-16 03:57:19', 'Anda melakukan login dengan \"110.137.154.125\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (150, '5', 'guru', '1', '2022-05-16 04:43:16', 'Anda melakukan login dengan \"110.137.154.125\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (151, '5', 'guru', '1', '2022-05-16 16:33:46', 'Anda melakukan login dengan \"110.137.154.125\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (152, '5', 'guru', '1', '2022-05-17 06:40:24', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (153, '', 'siswa', '11', '2022-05-17 06:51:05', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (154, '5', 'guru', '1', '2022-05-17 07:11:22', 'Anda melakukan login dengan \"103.208.205.90\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (155, '5', 'guru', '1', '2022-05-17 13:55:15', 'Anda melakukan login dengan \"110.137.154.125\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (156, '5', 'guru', '1', '2022-05-17 15:21:14', 'Anda melakukan login dengan \"110.137.194.61\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (157, '5', 'guru', '1', '2022-05-19 09:58:26', 'Anda melakukan login dengan \"125.165.146.142\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (158, '', 'siswa', '11', '2022-05-23 10:20:57', 'Anda melakukan login dengan \"180.252.170.182\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (159, '5', 'guru', '1', '2022-05-23 10:23:24', 'Anda melakukan login dengan \"180.252.170.182\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (160, '5', 'guru', '1', '2022-05-23 11:20:31', 'Anda melakukan login dengan \"180.252.170.182\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (161, '5', 'guru', '1', '2022-05-23 14:51:01', 'Anda melakukan login dengan \"180.252.170.182\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (162, '5', 'guru', '1', '2022-05-23 15:15:09', 'Anda melakukan login dengan \"180.252.170.182\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (163, '5', 'guru', '1', '2022-05-23 15:21:58', 'Anda melakukan login dengan \"180.252.170.182\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (164, '5', 'guru', '1', '2022-05-23 15:57:43', 'Anda melakukan login dengan \"180.252.170.182\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (165, '5', 'guru', '1', '2022-05-23 16:03:52', 'Anda melakukan login dengan \"180.252.170.182\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (166, '5', 'guru', '1', '2022-05-24 09:58:21', 'Anda melakukan login dengan \"180.252.164.162\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (167, '5', 'guru', '1', '2022-05-24 11:09:35', 'Anda melakukan login dengan \"180.252.164.162\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (168, '5', 'guru', '1', '2022-05-24 14:57:57', 'Anda melakukan login dengan \"180.252.164.162\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (169, '5', 'guru', '1', '2022-05-25 10:42:33', 'Anda melakukan login dengan \"180.252.162.178\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (170, '5', 'guru', '1', '2022-05-25 11:14:28', 'Anda melakukan login dengan \"180.252.162.178\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (171, '5', 'guru', '1', '2022-05-25 11:15:04', 'Anda melakukan login dengan \"180.252.162.178\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (172, '5', 'guru', '1', '2022-05-25 13:59:43', 'Anda melakukan login dengan \"180.252.162.178\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (173, '5', 'guru', '1', '2022-05-25 16:45:51', 'Anda melakukan login dengan \"180.252.162.178\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (174, '5', 'guru', '1', '2022-05-25 16:46:03', 'Anda melakukan login dengan \"180.252.162.178\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (175, '5', 'guru', '1', '2022-05-27 09:33:51', 'Anda melakukan login dengan \"180.252.167.162\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (176, '5', 'guru', '1', '2022-05-27 15:04:33', 'Anda melakukan login dengan \"180.252.167.162\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (177, '5', 'guru', '1', '2022-05-27 16:36:42', 'Anda melakukan login dengan \"180.252.167.162\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (178, '5', 'guru', '1', '2022-05-29 23:57:58', 'Anda melakukan login dengan \"180.214.233.74\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (179, '5', 'guru', '1', '2022-05-30 06:34:57', 'Anda melakukan login dengan \"180.214.232.93\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (180, '5', 'guru', '1', '2022-05-30 10:22:54', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (181, '5', 'guru', '1', '2022-05-30 13:20:57', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (182, '5', 'guru', '1', '2022-05-30 13:25:44', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (183, '', 'siswa', '11', '2022-05-30 13:32:34', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (184, '5', 'guru', '1', '2022-05-30 14:56:39', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (185, '5', 'guru', '1', '2022-05-30 15:00:02', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (186, '', 'siswa', '11', '2022-05-30 15:02:53', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (187, '5', 'guru', '1', '2022-05-30 15:28:02', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (188, '5', 'guru', '1', '2022-05-30 15:35:36', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (189, '', 'siswa', '11', '2022-05-30 15:37:04', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (190, '', 'siswa', '11', '2022-05-30 15:37:19', 'Anda mencetak Kartu Pelajar anda');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (191, '', 'siswa', '140', '2022-05-30 15:37:30', 'Anda melakukan login dengan \"125.160.19.100\"');
INSERT INTO `web_log` (`id`, `unit`, `type`, `idusers`, `datestamp`, `note`) VALUES (192, '', 'siswa', '11', '2022-05-30 17:05:28', 'Anda melakukan login dengan \"125.160.19.100\"');


#
# TABLE STRUCTURE FOR: web_payement_method
#

DROP TABLE IF EXISTS `web_payement_method`;

CREATE TABLE `web_payement_method` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `gambar` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `sistem` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `nama` varchar(255) COLLATE utf8_swedish_ci NOT NULL,
  `rate` varchar(10) COLLATE utf8_swedish_ci NOT NULL,
  `minimum` varchar(100) COLLATE utf8_swedish_ci NOT NULL,
  `note` text COLLATE utf8_swedish_ci NOT NULL,
  `status` varchar(50) COLLATE utf8_swedish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8 COLLATE=utf8_swedish_ci;

INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (1, 'qris-tb.jpg', 'QRscan', 'QRIS', 'GOJEK | DANA | OVO | TCASH - An. Tempatbeli', '0.98', '50000', 'ID1020038171911', 'Not Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (2, 'ovo-tb.jpg', 'Emoney', 'OVO', 'OVO Qr - Reza Lesmana Putra', '1', '50000', '081280462650', 'Not Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (3, 'qr-dana.jpg', 'Credit', 'VC', 'Credit Card (Visa / Master)', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (4, 'qr-dana.jpg', 'Bank', 'BK', 'BCA KlikPay', '1', '50000', '', 'Not Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (5, 'qr-dana.jpg', 'Bank', 'M1', 'Mandiri Virtual Account', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (6, 'qr-dana.jpg', 'Bank', 'BT', 'Permata Bank Virtual Account', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (7, 'qr-dana.jpg', 'Bank', 'B1', 'CIMB Niaga Virtual Account', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (8, 'qr-dana.jpg', 'Bank', 'A1', 'ATM Bersama', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (9, 'qr-dana.jpg', 'Bank', 'I1', 'BNI Virtual Account', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (10, 'qr-dana.jpg', 'Bank', 'VA', 'Maybank Virtual Account', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (11, 'qr-dana.jpg', 'Emoney', 'OV', 'OVO Apps', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (12, 'qr-dana.jpg', 'Retail', 'FT', 'Alfamart | POS Indonesia | Pegadaian', '1', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (13, 'qr-dana.jpg', 'Paylater', 'DN', 'Indodana Paylater', '0.98', '50000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (14, 'qr-dana.jpg', 'QRscan', 'SP', 'QRIS via ShopeePay - OVO | GOPAY | DANA | LinkAja | Mandiripay', '0.98', '100000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (15, 'qr-dana.jpg', 'Emoney', 'SA', 'ShopeePay Applink', '1', '100000', '', 'Active');
INSERT INTO `web_payement_method` (`id`, `gambar`, `sistem`, `name`, `nama`, `rate`, `minimum`, `note`, `status`) VALUES (16, 'qr-dana.jpg', 'Emoney', 'LA', 'LINK Aja', '1', '50000', '', 'Active');


#
# TABLE STRUCTURE FOR: web_sekolah
#

DROP TABLE IF EXISTS `web_sekolah`;

CREATE TABLE `web_sekolah` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(11) NOT NULL,
  `nama_sekolah` varchar(100) DEFAULT NULL,
  `kepsek` varchar(100) NOT NULL,
  `npsn` varchar(50) DEFAULT NULL,
  `nss` varchar(50) DEFAULT NULL,
  `alamat` text DEFAULT NULL,
  `kelurahan` varchar(100) DEFAULT NULL,
  `kecamatan` varchar(100) DEFAULT NULL,
  `kabupaten` varchar(100) DEFAULT NULL,
  `provinsi` varchar(100) DEFAULT NULL,
  `kodepos` varchar(15) DEFAULT NULL,
  `no_telepon` varchar(20) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `ttd` varchar(100) NOT NULL,
  `stampel` varchar(100) NOT NULL,
  `design` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (1, '1', 'SD ProSchool', 'Sutan Daulay', '20108989', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'tk@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (2, '2', 'SMP ProSchool', 'Panji Nugraha', '20108997', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'sd@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (3, '3', 'SMP ProSchool', 'Damara', '20108990', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'smp@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (4, '4', 'SMA ProSchool', 'Andre Taulany', '20108812', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'sma@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');
INSERT INTO `web_sekolah` (`id`, `unit`, `nama_sekolah`, `kepsek`, `npsn`, `nss`, `alamat`, `kelurahan`, `kecamatan`, `kabupaten`, `provinsi`, `kodepos`, `no_telepon`, `email`, `logo`, `ttd`, `stampel`, `design`) VALUES (5, '5', 'SMK ProSchool', 'Reza Lesmana', '20108813', '83960337', 'Jl. TB Simatupang, Menara 165, ESQ Tower No 1', 'Cilandak Timur', 'Pasar Minggu', 'Jakarta Selatan', 'DKI Jakarta', '12560', '082289663344', 'smk@proschool.id', 'twh.png', 'Kepsek_copy.png', 'STEMPEL-SMK.png', 'birunom.png');


#
# TABLE STRUCTURE FOR: web_setting
#

DROP TABLE IF EXISTS `web_setting`;

CREATE TABLE `web_setting` (
  `id` int(10) NOT NULL,
  `url` varchar(50) NOT NULL,
  `title` varchar(100) NOT NULL,
  `logo` varchar(100) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `email` varchar(100) NOT NULL,
  `tahun_ajaran` varchar(100) NOT NULL,
  `default_print` varchar(100) NOT NULL,
  `maintenance` enum('tidak','iya') NOT NULL,
  `whatsapp_group` varchar(100) NOT NULL,
  `whatsapp` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

INSERT INTO `web_setting` (`id`, `url`, `title`, `logo`, `description`, `email`, `tahun_ajaran`, `default_print`, `maintenance`, `whatsapp_group`, `whatsapp`) VALUES (1, 'https://www.proschool.id/', 'PROschool by DesaTech', 'logo.png', 'Elearning by ProSchool for a Smart Learning for Student in New Era! ', 'admin@proschool.id', '2021/2022-2', 'A4', 'tidak', '#', '6281280462650');


#
# TABLE STRUCTURE FOR: web_surat
#

DROP TABLE IF EXISTS `web_surat`;

CREATE TABLE `web_surat` (
  `id_surat` int(11) NOT NULL AUTO_INCREMENT,
  `arti` varchar(100) NOT NULL,
  `asma` varchar(100) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `audio` varchar(100) NOT NULL,
  `ayat` varchar(10) NOT NULL,
  `nomer` varchar(10) NOT NULL,
  `agama` varchar(20) NOT NULL,
  PRIMARY KEY (`id_surat`)
) ENGINE=InnoDB AUTO_INCREMENT=115 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (1, 'Pembukaan', 'الفاتحة', 'Al Fatihah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/001AlFaatihah.mp3', '7', '1', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (2, 'Sapi Betina', 'البقرة', 'Al Baqarah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/002AlBaqarah.mp3', '286', '2', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (3, 'Keluarga Imran', 'آل عمران', 'Ali Imran', 'https://ia802609.us.archive.org/13/items/quraninindonesia/003AliImran.mp3', '200', '3', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (4, 'Wanita', 'النساء', 'An Nisaa', 'https://ia802609.us.archive.org/13/items/quraninindonesia/004AnNisaa.mp3', '176', '4', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (5, 'Hidangan', 'المائدة', 'Al Maidah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/005AlMaaidah.mp3', '120', '5', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (6, 'Binatang Ternak', 'الأنعام', 'Al An039am', 'https://ia802609.us.archive.org/13/items/quraninindonesia/006AlAnaam.mp3', '165', '6', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (7, 'Tempat Tertinggi', 'الأعراف', 'Al A039raf', 'https://ia802609.us.archive.org/13/items/quraninindonesia/007AlAaraaf.mp3', '206', '7', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (8, 'Harta Rampasan Perang', 'الأنفال', 'Al Anfaal', 'https://ia802609.us.archive.org/13/items/quraninindonesia/008AlAnfaal.mp3', '75', '8', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (9, 'Pengampunan', 'التوبة', 'At Taubah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/009AtTaubah.mp3', '129', '9', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (10, 'Yunus', 'يونس', 'Yunus', 'https://ia802609.us.archive.org/13/items/quraninindonesia/010Yunus.mp3', '109', '10', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (11, 'Hud', 'هود', 'Huud', 'https://ia802609.us.archive.org/13/items/quraninindonesia/011Huud.mp3', '123', '11', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (12, 'Yusuf', 'يوسف', 'Yusuf', 'https://ia802609.us.archive.org/13/items/quraninindonesia/012Yusuf.mp3', '111', '12', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (13, 'Guruh', 'الرعد', 'Ar Ra039du', 'https://ia802609.us.archive.org/13/items/quraninindonesia/013ArRaad.mp3', '43', '13', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (14, 'Ibrahim', 'ابراهيم', 'Ibrahim', 'https://ia802609.us.archive.org/13/items/quraninindonesia/014Ibrahim.mp3', '52', '14', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (15, 'Negeri Kaum Samud', 'الحجر', 'Al Hijr', 'https://ia802609.us.archive.org/13/items/quraninindonesia/015AlHijr.mp3', '99', '15', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (16, 'Lebah', 'النحل', 'An Nahl', 'https://ia802609.us.archive.org/13/items/quraninindonesia/016AnNahl.mp3', '128', '16', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (17, 'Keturunan Isra’il', 'الإسراء', 'Al Israa039', 'https://ia802609.us.archive.org/13/items/quraninindonesia/017AlIsraa.mp3', '111', '17', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (18, 'Gua', 'الكهف', 'Al Kahfi', 'https://ia802609.us.archive.org/13/items/quraninindonesia/018AlKahfi.mp3', '110', '18', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (19, 'Maryam', 'مريم', 'Maryam', 'https://ia802609.us.archive.org/13/items/quraninindonesia/019Maryam.mp3', '98', '19', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (20, 'TaHa', 'طه', 'Thaahaa', 'https://ia802609.us.archive.org/13/items/quraninindonesia/020Thaahaa2.mp3', '135', '20', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (21, 'Nabi-Nabi', 'الأنبياء', 'Al Anbiyaa', 'https://ia802609.us.archive.org/13/items/quraninindonesia/021AlAnbiyaa.mp3', '112', '21', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (22, 'Haji', 'الحج', 'Al Hajj', 'https://ia802609.us.archive.org/13/items/quraninindonesia/022AlHajj.mp3', '78', '22', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (23, 'Orang-Orang yang Beriman', 'المؤمنون', 'Al Mu039minun', 'https://ia802609.us.archive.org/13/items/quraninindonesia/023AlMuminuun.mp3', '118', '23', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (24, 'Cahaya', 'النور', 'An Nuur', 'https://ia802609.us.archive.org/13/items/quraninindonesia/024AnNuur.mp3', '64', '24', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (25, 'Pembeda', 'الفرقان', 'Al Furqaan', 'https://ia802609.us.archive.org/13/items/quraninindonesia/025AlFurqaan.mp3', '77', '25', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (26, 'Para Penyair', 'الشعراء', 'Asy Syu039ara', 'https://ia802609.us.archive.org/13/items/quraninindonesia/026AsySyuaaraa.mp3', '227', '26', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (27, 'Semut', 'النمل', 'An Naml', 'https://ia802609.us.archive.org/13/items/quraninindonesia/027AnNaml.mp3', '93', '27', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (28, 'Cerita-Cerita', 'القصص', 'Al Qashash', 'https://ia802609.us.archive.org/13/items/quraninindonesia/028AlQashash.mp3', '88', '28', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (29, 'Laba-Laba', 'العنكبوت', 'Al 039Ankabut', 'https://ia802609.us.archive.org/13/items/quraninindonesia/029AlAnkabuut.mp3', '69', '29', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (30, 'Bangsa Romawi', 'الروم', 'Ar Ruum', 'https://ia802609.us.archive.org/13/items/quraninindonesia/030ArRuum.mp3', '60', '30', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (31, 'Luqman', 'لقمان', 'Luqman', 'https://ia802609.us.archive.org/13/items/quraninindonesia/031Luqman.mp3', '34', '31', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (32, 'Sujud', 'السجدة', 'As Sajdah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/032AsSajdah.mp3', '30', '32', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (33, 'Golongan yang Bersekutu', 'الأحزاب', 'Al Ahzab', 'https://ia802609.us.archive.org/13/items/quraninindonesia/033AlAhzab.mp3', '73', '33', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (34, 'Kaum Saba’', 'سبإ', 'Saba039', 'https://ia802609.us.archive.org/13/items/quraninindonesia/034Sabaa.mp3', '54', '34', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (35, 'Pencipta', 'فاطر', 'Faathir', 'https://ia802609.us.archive.org/13/items/quraninindonesia/035Faathir.mp3', '45', '35', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (36, 'YaSin', 'يس', 'Yaa Siin', 'https://ia802609.us.archive.org/13/items/quraninindonesia/036Yaasiin.mp3', '83', '36', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (37, 'Yang Bersaf-saf', 'الصافات', 'Ash Shaaffat', 'https://ia802609.us.archive.org/13/items/quraninindonesia/037AshShaaffaat.mp3', '182', '37', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (38, 'Sad', 'ص', 'Shaad', 'https://ia802609.us.archive.org/13/items/quraninindonesia/038Shaad.mp3', '88', '38', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (39, 'Rombongan-Rombongan', 'الزمر', 'Az Zumar', 'https://ia802609.us.archive.org/13/items/quraninindonesia/039AzZumar.mp3', '75', '39', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (40, 'Orang yang Beriman', 'غافر', 'Al Ghaafir', 'https://ia802609.us.archive.org/13/items/quraninindonesia/040AlMuumin.mp3', '85', '40', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (41, 'Ha Mim As-Sajdah', 'فصلت', 'Al Fushilat', 'https://ia802609.us.archive.org/13/items/quraninindonesia/041Fushshilat.mp3', '54', '41', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (42, 'Musyawarah', 'الشورى', 'Asy Syuura', 'https://ia802609.us.archive.org/13/items/quraninindonesia/042AsySyuura.mp3', '53', '42', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (43, 'Perhiasan', 'الزخرف', 'Az Zukhruf', 'https://ia802609.us.archive.org/13/items/quraninindonesia/043AzZukhruf.mp3', '89', '43', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (44, 'Kabut', 'الدخان', 'Ad Dukhaan', 'https://ia802609.us.archive.org/13/items/quraninindonesia/044AdDukhaan.mp3', '59', '44', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (45, 'Yang Berlutut', 'الجاثية', 'Al Jaatsiyah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/045AlJaatsiyah.mp3', '37', '45', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (46, 'Bukit-Bukit Pasir', 'الأحقاف', 'Al Ahqaaf', 'https://ia802609.us.archive.org/13/items/quraninindonesia/046AlAhqaaf.mp3', '35', '46', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (47, 'Nabi Muhammad SAW', 'محمد', 'Muhammad', 'https://ia802609.us.archive.org/13/items/quraninindonesia/047Muhammad.mp3', '38', '47', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (48, 'Kemenangan', 'الفتح', 'Al Fath', 'https://ia802609.us.archive.org/13/items/quraninindonesia/048AlFath.mp3', '29', '48', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (49, 'Kamar-Kamar', 'الحجرات', 'Al Hujuraat', 'https://ia802609.us.archive.org/13/items/quraninindonesia/049AlHujuraat.mp3', '18', '49', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (50, 'Qaf', 'ق', 'Qaaf', 'https://ia802609.us.archive.org/13/items/quraninindonesia/050Qaaf.mp3', '45', '50', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (51, 'Angin yang menerbangkan', 'الذاريات', 'Adz Dzaariyaat', 'https://ia802609.us.archive.org/13/items/quraninindonesia/051AdzDzaariyaat.mp3', '60', '51', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (52, 'Bukit', 'الطور', 'Ath Thuur', 'https://ia802609.us.archive.org/13/items/quraninindonesia/052AthThuur.mp3', '49', '52', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (53, 'Bintang', 'النجم', 'An Najm', 'https://ia802609.us.archive.org/13/items/quraninindonesia/053AnNajm.mp3', '62', '53', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (54, 'Bulan', 'القمر', 'Al Qamar', 'https://ia802609.us.archive.org/13/items/quraninindonesia/054AlQamar.mp3', '55', '54', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (55, 'Yang Maha Pemurah', 'الرحمن', 'Ar Rahmaan', 'https://ia802609.us.archive.org/13/items/quraninindonesia/055ArRahmaan.mp3', '78', '55', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (56, 'Hari Kiamat', 'الواقعة', 'Al Waaqi039ah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/056AlWaqiah.mp3', '96', '56', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (57, 'Besi', 'الحديد', 'Al Hadiid', 'https://ia802609.us.archive.org/13/items/quraninindonesia/057AlHadiid.mp3', '29', '57', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (58, 'Wanita yang Mengajukan Gugatan', 'المجادلة', 'Al Mujaadalah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/058AlMujaadilah.mp3', '22', '58', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (59, 'Pengusiran', 'الحشر', 'Al Hasyr', 'https://ia802609.us.archive.org/13/items/quraninindonesia/059AlHasyr.mp3', '24', '59', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (60, 'Perempuan yang Diuji', 'الممتحنة', 'Al mumtahanah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/060AlMumtahanah.mp3', '13', '60', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (61, 'Barisan', 'الصف', 'Ash Shaff', 'https://ia802609.us.archive.org/13/items/quraninindonesia/061AshShaff.mp3', '14', '61', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (62, 'Hari Jum’at', 'الجمعة', 'Al Jumuah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/062AlJumuah.mp3', '11', '62', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (63, 'Orang-Orang yang Munafik', 'المنافقون', 'Al Munafiqun', 'https://ia802609.us.archive.org/13/items/quraninindonesia/063AlMunaafiquun.mp3', '11', '63', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (64, 'Hari Ditampakkan Segala Kesalahan', 'التغابن', 'Ath Taghabun', 'https://ia802609.us.archive.org/13/items/quraninindonesia/064AtTaghaabun.mp3', '18', '64', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (65, 'Talak', 'الطلاق', 'Ath Thalaaq', 'https://ia802609.us.archive.org/13/items/quraninindonesia/065AthThalaaq.mp3', '12', '65', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (66, 'Mengharamkan', 'التحريم', 'At Tahriim', 'https://ia802609.us.archive.org/13/items/quraninindonesia/066AtTahrim.mp3', '12', '66', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (67, 'Kerajaan', 'الملك', 'Al Mulk', 'https://ia802609.us.archive.org/13/items/quraninindonesia/067AlMulk.mp3', '30', '67', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (68, 'Kalam', 'القلم', 'Al Qalam', 'https://ia802609.us.archive.org/13/items/quraninindonesia/068AlQalam.mp3', '52', '68', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (69, 'Hari Kiamat', 'الحاقة', 'Al Haaqqah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/069AlHaaqqah.mp3', '52', '69', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (70, 'Tempa-Tempat Naik', 'المعارج', 'Al Ma039aarij', 'https://ia802609.us.archive.org/13/items/quraninindonesia/070AlMaaarij.mp3', '44', '70', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (71, 'Nuh', 'نوح', 'Nuh', 'https://ia802609.us.archive.org/13/items/quraninindonesia/071Nuh.mp3', '28', '71', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (72, 'Jin', 'الجن', 'Al Jin', 'https://ia802609.us.archive.org/13/items/quraninindonesia/072AlJin.mp3', '28', '72', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (73, 'Orang-orang yang Berselimut', 'المزمل', 'Al Muzammil', 'https://ia802609.us.archive.org/13/items/quraninindonesia/073AlMuzzammil.mp3', '20', '73', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (74, 'Orang yang berkemul', 'المدثر', 'Al Muddastir', 'https://ia802609.us.archive.org/13/items/quraninindonesia/074AlMuddatstsir.mp3', '56', '74', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (75, 'Hari Kiamat', 'القيامة', 'Al Qiyaamah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/075AlQiyaamah.mp3', '40', '75', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (76, 'Manusia', 'الانسان', 'Al Insaan', 'https://ia802609.us.archive.org/13/items/quraninindonesia/076AlInsaan.mp3', '31', '76', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (77, 'Malaikat yang Diutus', 'المرسلات', 'Al Mursalaat', 'https://ia802609.us.archive.org/13/items/quraninindonesia/077AlMursalaat.mp3', '50', '77', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (78, 'Berita Besar', 'النبإ', 'An Naba039', 'https://ia802609.us.archive.org/13/items/quraninindonesia/078AnNaba.mp3', '40', '78', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (79, 'Malaikat-Malaikat yang Mencabut', 'النازعات', 'An Naazi039at', 'https://ia802609.us.archive.org/13/items/quraninindonesia/079AnNaaziaat.mp3', '46', '79', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (80, 'Ia Bermuka Masam', 'عبس', '039Abasa', 'https://ia802609.us.archive.org/13/items/quraninindonesia/080Abasa.mp3', '42', '80', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (81, 'Menggulung', 'التكوير', 'At Takwiir', 'https://ia802609.us.archive.org/13/items/quraninindonesia/081AtTakwiir.mp3', '29', '81', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (82, 'Terbelah', 'الإنفطار', 'Al Infithar', 'https://ia802609.us.archive.org/13/items/quraninindonesia/082AlInfithaar.mp3', '19', '82', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (83, 'Kecurangan', 'المطففين', 'Al Muthaffifin', 'https://ia802609.us.archive.org/13/items/quraninindonesia/083AlMuthaffifin.mp3', '36', '83', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (84, 'Terbelah', 'الإنشقاق', 'Al Insyiqaq', 'https://ia802609.us.archive.org/13/items/quraninindonesia/084AlInsyiqaaq.mp3', '25', '84', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (85, 'Gugusan Bintang', 'البروج', 'Al Buruuj', 'https://ia802609.us.archive.org/13/items/quraninindonesia/085AlBuruuj.mp3', '22', '85', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (86, 'Yang Datang di Malam Hari', 'الطارق', 'Ath Thariq', 'https://ia802609.us.archive.org/13/items/quraninindonesia/086AthThaariq.mp3', '17', '86', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (87, 'Yang Paling Tinggi', 'الأعلى', 'Al A039laa', 'https://ia802609.us.archive.org/13/items/quraninindonesia/087AlAalaa.mp3', '19', '87', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (88, 'Hari Pembalasan', 'الغاشية', 'Al Ghaasyiah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/088AlGhaasyiyah.mp3', '26', '88', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (89, 'Fajar', 'الفجر', 'Al Fajr', 'https://ia802609.us.archive.org/13/items/quraninindonesia/089AlFajr.mp3', '30', '89', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (90, 'Negeri', 'البلد', 'Al Balad', 'https://ia802609.us.archive.org/13/items/quraninindonesia/090AlBalad.mp3', '20', '90', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (91, 'Matahari', 'الشمس', 'Asy Syams', 'https://ia802609.us.archive.org/13/items/quraninindonesia/091AsySyams.mp3', '15', '91', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (92, 'Malam', 'الليل', 'Al Lail', 'https://ia802609.us.archive.org/13/items/quraninindonesia/092AlLail.mp3', '21', '92', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (93, 'Waktu Dhuha', 'الضحى', 'Adh Dhuhaa', 'https://ia802609.us.archive.org/13/items/quraninindonesia/093AdhDhuhaa.mp3', '11', '93', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (94, 'Kelapangan', 'الشرح', 'Asy Syarh', 'https://ia802609.us.archive.org/13/items/quraninindonesia/094AlamNasyrah.mp3', '8', '94', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (95, 'Buah Tin', 'التين', 'At Tiin', 'https://ia802609.us.archive.org/13/items/quraninindonesia/095AtTiin.mp3', '8', '95', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (96, 'Segumpal Darah', 'العلق', 'Al 039Alaq', 'https://ia802609.us.archive.org/13/items/quraninindonesia/096AlAlaq.mp3', '19', '96', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (97, 'Kemuliaan', 'القدر', 'Al Qadr', 'https://ia802609.us.archive.org/13/items/quraninindonesia/097AlQadr.mp3', '5', '97', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (98, 'Bukti yang Nyata', 'البينة', 'Al Bayyinah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/098AlBayyinah.mp3', '8', '98', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (99, 'Keguncangan', 'الزلزلة', 'Az Zalzalah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/099AlZalzalah.mp3', '8', '99', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (100, 'Kuda Perang yang Berlari Kencang', 'العاديات', 'Al 039Aadiyah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/100AlAadiyaat.mp3', '11', '100', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (101, 'Hari Kiamat', 'القارعة', 'Al Qaari039ah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/101AlQaariah.mp3', '11', '101', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (102, 'Bermegah-Megahan', 'التكاثر', 'At Takaatsur', 'https://ia802609.us.archive.org/13/items/quraninindonesia/102AtTakaatsur.mp3', '8', '102', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (103, 'Masa', 'العصر', 'Al 039Ashr', 'https://ia802609.us.archive.org/13/items/quraninindonesia/103AlAshr.mp3', '3', '103', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (104, 'Pengumpat', 'الهمزة', 'Al Humazah', 'https://ia802609.us.archive.org/13/items/quraninindonesia/104AlHumazah.mp3', '9', '104', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (105, 'Gajah', 'الفيل', 'Al Fiil', 'https://ia802609.us.archive.org/13/items/quraninindonesia/105AlFiil.mp3', '5', '105', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (106, 'Suku Quraysy', 'قريش', 'Quraisy', 'https://ia802609.us.archive.org/13/items/quraninindonesia/106Quraisy.mp3', '4', '106', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (107, 'Barang-Barang yang Berguna', 'الماعون', 'Al Maa039uun', 'https://ia802609.us.archive.org/13/items/quraninindonesia/107AlMaauun.mp3', '7', '107', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (108, 'Nikmat yang Banyak', 'الكوثر', 'Al Kautsar', 'https://ia802609.us.archive.org/13/items/quraninindonesia/108AlKautsar.mp3', '3', '108', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (109, 'Orang-Orang Kafir', 'الكافرون', 'Al Kafirun', 'https://ia802609.us.archive.org/13/items/quraninindonesia/109AlKaafiruun.mp3', '6', '109', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (110, 'Pertolongan', 'النصر', 'An Nashr', 'https://ia802609.us.archive.org/13/items/quraninindonesia/110AnNashr.mp3', '3', '110', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (111, 'Gejolak Api', 'المسد', 'Al Lahab', 'https://ia802609.us.archive.org/13/items/quraninindonesia/111AlLahab.mp3', '5', '111', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (112, 'Kemurnian Keesaan Allah', 'الإخلاص', 'Al Ikhlash', 'https://ia802609.us.archive.org/13/items/quraninindonesia/112AlIkhlash.mp3', '4', '112', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (113, 'Waktu Subuh', 'الفلق', 'Al Falaq', 'https://ia802609.us.archive.org/13/items/quraninindonesia/113AlFalaq.mp3', '5', '113', 'ISLAM');
INSERT INTO `web_surat` (`id_surat`, `arti`, `asma`, `nama`, `audio`, `ayat`, `nomer`, `agama`) VALUES (114, 'Manusia', 'الناس', 'An Naas', 'https://ia802609.us.archive.org/13/items/quraninindonesia/114AnNaas.mp3', '6', '114', 'ISLAM');


#
# TABLE STRUCTURE FOR: web_unit
#

DROP TABLE IF EXISTS `web_unit`;

CREATE TABLE `web_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_unit` (`id`, `nama`) VALUES (1, 'TK');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (2, 'SD');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (3, 'SMP');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (4, 'SMA');
INSERT INTO `web_unit` (`id`, `nama`) VALUES (5, 'SMK');


#
# TABLE STRUCTURE FOR: web_visitor
#

DROP TABLE IF EXISTS `web_visitor`;

CREATE TABLE `web_visitor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(26) NOT NULL,
  `date` date NOT NULL,
  `hits` int(11) NOT NULL,
  `online` varchar(255) NOT NULL,
  `time` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4;

INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (1, '::1', '2022-02-18', 2, '1645176744', '2022-02-18 16:31:40');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (2, '::1', '2022-02-19', 31, '1645256376', '2022-02-19 11:16:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (3, '::1', '2022-02-20', 4, '1645351663', '2022-02-20 17:00:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (4, '::1', '2022-02-22', 127, '1645541912', '2022-02-22 10:08:17');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (5, '::1', '2022-02-23', 20, '1645620624', '2022-02-23 10:23:03');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (6, '::1', '2022-02-24', 2, '1645694578', '2022-02-24 15:46:59');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (7, '::1', '2022-03-02', 88, '1646211941', '2022-03-02 09:56:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (8, '::1', '2022-03-04', 11, '1646386633', '2022-03-04 14:46:36');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (9, '::1', '2022-03-07', 9, '1646644603', '2022-03-07 10:15:52');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (10, '::1', '2022-03-09', 107, '1646817882', '2022-03-09 09:40:18');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (11, '::1', '2022-03-10', 27, '1646915630', '2022-03-10 10:39:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (12, '::1', '2022-03-11', 12, '1646993633', '2022-03-11 09:02:06');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (13, '::1', '2022-03-14', 25, '1647250952', '2022-03-14 09:43:53');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (14, '::1', '2022-03-15', 7, '1647317290', '2022-03-15 09:29:17');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (15, '::1', '2022-03-17', 6, '1647495518', '2022-03-17 09:40:46');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (16, '::1', '2022-03-18', 4, '1647575703', '2022-03-18 10:37:35');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (17, '::1', '2022-03-21', 17, '1647854259', '2022-03-21 09:22:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (18, '::1', '2022-03-22', 20, '1647960899', '2022-03-22 08:55:55');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (19, '::1', '2022-03-24', 3, '1648107873', '2022-03-24 12:04:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (20, '::1', '2022-03-25', 8, '1648197338', '2022-03-25 09:53:23');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (21, '::1', '2022-03-28', 4, '1648450552', '2022-03-28 09:16:06');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (22, '::1', '2022-03-29', 2, '1648534395', '2022-03-29 10:38:38');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (23, '::1', '2022-03-30', 5, '1648612601', '2022-03-30 08:53:33');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (24, '::1', '2022-04-02', 1, '1648879777', '2022-04-02 13:09:37');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (25, '::1', '2022-04-04', 44, '1649084372', '2022-04-04 09:56:21');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (26, '::1', '2022-04-05', 38, '1649151217', '2022-04-05 10:00:14');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (27, '::1', '2022-04-06', 3, '1649259253', '2022-04-06 21:52:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (28, '::1', '2022-04-07', 15, '1649321433', '2022-04-07 11:07:35');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (29, '103.208.205.90', '2022-04-07', 1, '1649339730', '2022-04-07 20:55:30');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (30, '103.119.140.138', '2022-04-08', 17, '1649406274', '2022-04-08 09:28:40');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (31, '103.208.205.90', '2022-04-08', 2, '1649425181', '2022-04-08 19:40:51');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (32, '103.208.205.90', '2022-04-09', 1, '1649482892', '2022-04-09 12:41:32');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (33, '125.160.237.228', '2022-04-09', 3, '1649487540', '2022-04-09 13:52:45');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (34, '103.208.205.90', '2022-04-10', 12, '1649561416', '2022-04-10 00:47:11');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (35, '36.69.82.37', '2022-04-11', 1, '1649651240', '2022-04-11 11:27:20');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (36, '103.119.140.130', '2022-04-11', 13, '1649664543', '2022-04-11 12:47:40');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (37, '103.82.15.129', '2022-04-12', 2, '1649724124', '2022-04-12 07:28:18');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (38, '103.119.141.200', '2022-04-12', 22, '1649752534', '2022-04-12 08:44:33');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (39, '114.124.236.5', '2022-04-12', 5, '1649737265', '2022-04-12 11:12:09');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (40, '182.0.148.148', '2022-04-12', 1, '1649738113', '2022-04-12 11:35:13');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (41, '103.119.141.200', '2022-04-13', 5, '1649835676', '2022-04-13 14:29:59');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (42, '116.206.28.4', '2022-04-17', 4, '1650204358', '2022-04-17 21:01:50');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (43, '103.82.15.129', '2022-04-17', 2, '1650211057', '2022-04-17 22:57:05');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (44, '103.82.15.129', '2022-04-18', 1, '1650215446', '2022-04-18 00:10:46');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (45, '180.243.8.227', '2022-04-18', 1, '1650226683', '2022-04-18 03:18:03');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (46, '103.119.141.124', '2022-04-18', 20, '1650272541', '2022-04-18 09:51:17');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (47, '103.119.141.124', '2022-04-19', 1, '1650346579', '2022-04-19 12:36:19');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (48, '103.208.205.90', '2022-04-20', 7, '1650448575', '2022-04-20 09:46:53');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (49, '103.119.141.124', '2022-04-20', 6, '1650443696', '2022-04-20 10:19:27');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (50, '103.119.141.124', '2022-04-21', 122, '1650532298', '2022-04-21 09:53:25');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (51, '103.208.205.90', '2022-04-21', 3, '1650558740', '2022-04-21 23:29:41');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (52, '103.119.141.124', '2022-04-22', 3, '1650600059', '2022-04-22 09:56:24');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (53, '103.119.140.245', '2022-04-25', 37, '1650876454', '2022-04-25 10:47:33');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (54, '103.119.140.245', '2022-04-26', 1, '1650938933', '2022-04-26 09:08:53');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (55, '103.119.140.245', '2022-04-27', 2, '1651037474', '2022-04-27 11:15:15');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (56, '118.101.33.211', '2022-05-06', 1, '1651829751', '2022-05-06 16:35:51');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (57, '110.136.9.128', '2022-05-09', 26, '1652110350', '2022-05-09 00:41:44');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (58, '103.208.205.90', '2022-05-09', 1, '1652088115', '2022-05-09 16:21:55');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (59, '110.136.9.128', '2022-05-10', 1, '1652154459', '2022-05-10 10:47:39');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (60, '110.136.9.128', '2022-05-11', 1, '1652244273', '2022-05-11 11:44:33');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (61, '110.136.9.128', '2022-05-12', 6, '1652345198', '2022-05-12 12:15:13');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (62, '103.208.205.90', '2022-05-12', 8, '1652348718', '2022-05-12 15:25:41');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (63, '110.136.9.128', '2022-05-13', 1, '1652425235', '2022-05-13 14:00:35');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (64, '110.136.9.128', '2022-05-14', 1, '1652477849', '2022-05-14 04:37:29');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (65, '110.137.154.125', '2022-05-16', 3, '1652693627', '2022-05-16 03:57:20');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (66, '103.208.205.90', '2022-05-17', 6, '1652746282', '2022-05-17 06:40:24');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (67, '110.137.154.125', '2022-05-17', 1, '1652770515', '2022-05-17 13:55:15');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (68, '110.137.194.61', '2022-05-17', 4, '1652775674', '2022-05-17 15:10:29');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (69, '125.165.146.142', '2022-05-19', 4, '1652930056', '2022-05-19 09:58:26');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (70, '180.252.170.182', '2022-05-23', 46, '1653303865', '2022-05-23 10:20:57');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (71, '180.252.164.162', '2022-05-24', 6, '1653379492', '2022-05-24 09:58:21');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (72, '180.252.162.178', '2022-05-25', 24, '1653472805', '2022-05-25 10:42:33');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (73, '180.252.167.162', '2022-05-27', 9, '1653644202', '2022-05-27 09:33:51');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (74, '180.214.233.74', '2022-05-29', 1, '1653843478', '2022-05-29 23:57:58');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (75, '180.214.232.93', '2022-05-30', 1, '1653867297', '2022-05-30 06:34:57');
INSERT INTO `web_visitor` (`id`, `ip`, `date`, `hits`, `online`, `time`) VALUES (76, '125.160.19.100', '2022-05-30', 51, '1653905171', '2022-05-30 10:22:54');


